-- Caminho: database/migrations/3.6.23.sql
-- Ampliação preserva os pedidos existentes; reaplicável, sem exclusão de dados.
SET @arc_explorer_alter = IF((SELECT DATA_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='arc_agent_terminal_jobs' AND COLUMN_NAME='request_text')='varchar','ALTER TABLE `arc_agent_terminal_jobs` MODIFY COLUMN `request_text` TEXT COLLATE utf8mb4_unicode_ci NOT NULL','DO 0');
PREPARE arc_explorer_statement FROM @arc_explorer_alter;
EXECUTE arc_explorer_statement;
DEALLOCATE PREPARE arc_explorer_statement;
CREATE TABLE IF NOT EXISTS `arc_file_browser_requests` (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, command_id BIGINT UNSIGNED NOT NULL,
 network_id BIGINT UNSIGNED NOT NULL, account_id BIGINT UNSIGNED NOT NULL,
 agent_id BIGINT UNSIGNED NOT NULL, requested_by BIGINT UNSIGNED NOT NULL,
 path_text VARCHAR(1024) NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'pending',
 result_json MEDIUMTEXT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NULL, UNIQUE KEY command_id(command_id), KEY request_lookup(network_id,agent_id,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
