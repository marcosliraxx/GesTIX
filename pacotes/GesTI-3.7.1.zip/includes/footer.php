<?php
/* Caminho: includes/footer.php */
declare(strict_types=1);


/* ============================================================
   includes/footer.php — RODAPÉ PADRÃO + JS COMPARTILHADO
   ------------------------------------------------------------
   Fecha a estrutura aberta por header.php/sidebar.php,
   exibe o rodapé (sempre visível) e injeta o JS da página
   quando a variável $ARCPageJs estiver definida.
   ============================================================ */
?><?php if (($ARCMode ?? 'app') === 'app'): ?></div><!-- /.app-body --><?php endif; ?>

<footer class="app-footer arc-compact-footer" aria-label="Rodapé do sistema">
    <nav aria-label="Links do rodapé"><?php if(isset($pdo))foreach(arc_navigation_items($pdo,'footer') as $entry):if($entry['url']==='')continue;?><a class="<?=arc_h($entry['device_class'])?>" href="<?=arc_h($entry['url'])?>"><span class="arc-db-icon" data-icon="<?=arc_h($entry['icon'])?>" aria-hidden="true"></span><?=arc_h($entry['label'])?></a><?php endforeach;?></nav>
    <span class="arc-footer-system-name" title="<?=arc_h((string)$arcSiteName)?>">&copy; <?=date('Y')?> · <?=arc_h((string)$arcSiteName)?> · v<?=arc_h(arc_app_version())?></span>
<?php if (($ARCMode ?? 'app') === 'app'): ?>
<?php
$dock=arc_navigation_items($pdo,'mobile');$primary=null;$dockLinks=[];$seen=[];
foreach($dock as $entry){if(!in_array('mobile',explode(',',$entry['devices']),true)||isset($seen[$entry['url']]))continue;$seen[$entry['url']]=1;if($entry['mobile_primary'])$primary=$entry;else $dockLinks[]=$entry;}
$dockLinks=array_slice($dockLinks,0,3);$dockIds=array_column($dockLinks,'id');if($primary)$dockIds[]=$primary['id'];
$moreLinks=arc_navigation_more($pdo,$dockIds);
?>
<nav class="arc-mobile-dock arc-mobile-dock-five" aria-label="Navegação do aplicativo">
<?php foreach($dockLinks as $index=>$entry):?><a style="grid-column:<?= [1,2,4][$index]?>" href="<?=arc_h($entry['url'])?>" class="<?=arc_h($entry['device_class'])?>" <?=($ARCActiveNav??'')===$entry['key']?'aria-current="page"':''?>><span class="arc-db-icon" data-icon="<?=arc_h($entry['icon'])?>" aria-hidden="true"></span><span><?=arc_h($entry['label'])?></span></a><?php endforeach;?>
<?php if($primary):?><a class="arc-mobile-start <?=arc_h($primary['device_class'])?>" style="grid-column:3" href="<?=arc_h($primary['url'])?>" aria-label="<?=arc_h($primary['label'])?>"><span class="arc-db-icon" data-icon="<?=arc_h($primary['icon'])?>" aria-hidden="true"></span><span><?=arc_h($primary['label'])?></span></a><?php endif;?>
<button type="button" style="grid-column:5" data-mobile-more aria-label="Mais opções" aria-controls="arc-mobile-more" aria-expanded="false"><i class="fa fa-ellipsis-h" aria-hidden="true"></i><span>Mais</span></button>
</nav>
<dialog id="arc-mobile-more" class="arc-mobile-more" aria-labelledby="arc-mobile-more-title"><header><h2 id="arc-mobile-more-title">Mais</h2><button type="button" data-close-more aria-label="Fechar mais opções"><i class="fa fa-times" aria-hidden="true"></i></button></header><nav aria-label="Outras páginas"><?php foreach($moreLinks as $entry):?><a class="<?=arc_h($entry['device_class'])?>" href="<?=arc_h($entry['url'])?>"><span class="arc-db-icon" data-icon="<?=arc_h($entry['icon'])?>" aria-hidden="true"></span><span><?=arc_h($entry['label'])?></span></a><?php endforeach;?></nav></dialog>

<?php endif; ?>
</footer>

<script>
(function () {
    'use strict';

    var more=document.getElementById('arc-mobile-more');
    document.querySelectorAll('[data-mobile-more]').forEach(function(button){button.addEventListener('click',function(){if(more&&!more.open)more.showModal();document.querySelectorAll('[data-mobile-more]').forEach(function(b){b.setAttribute('aria-expanded','true');});});});
    if(more){more.querySelector('[data-close-more]').addEventListener('click',function(){more.close();});more.addEventListener('click',function(e){if(e.target===more)more.close();});more.addEventListener('close',function(){document.querySelectorAll('[data-mobile-more]').forEach(function(b){b.setAttribute('aria-expanded','false');});});}
    /* ---------- Sidebar recolhível (persistente; respeita a preferência da conta) ---------- */
    var toggle = document.getElementById('sidebar-collapse');
    var stored = null;
    try { stored = localStorage.getItem('arc_sidebar'); } catch (e) {}
    var prefDefault = (window.ARC_PREFS && window.ARC_PREFS.sidebar_default) || 'expanded';

    if (stored === 'collapsed' || (stored === null && prefDefault === 'collapsed')) {
        document.body.classList.add('sidebar-collapsed');
    }

    function syncSidebarToggle() {
        if (!toggle) return;
        var collapsed = document.body.classList.contains('sidebar-collapsed');
        toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        toggle.setAttribute('aria-label', collapsed ? 'Expandir menu lateral' : 'Recolher menu lateral');
        toggle.title = collapsed ? 'Expandir menu lateral' : 'Recolher menu lateral';
        var icon = toggle.querySelector('[data-sidebar-toggle-icon]');
        if (icon) {
            icon.classList.toggle('fa-angle-double-right', collapsed);
            icon.classList.toggle('fa-angle-double-left', !collapsed);
        }
    }
    syncSidebarToggle();
    if (toggle) {
        toggle.addEventListener('click', function () {
            var collapsed = document.body.classList.toggle('sidebar-collapsed');
            try { localStorage.setItem('arc_sidebar', collapsed ? 'collapsed' : 'expanded'); } catch (e) {}
            syncSidebarToggle();
        });
    }

    /* Avisos translúcidos: entram pela direita, permanecem por 3 segundos. */
    (function () {
        var toasts = Array.prototype.slice.call(document.querySelectorAll('.flash, .arc-toast'));
        toasts.forEach(function (toast) {
            if (toast.closest('.arc-toast-host')) return;
            var host = document.getElementById('arc-toast-host');
            if (!host) { host = document.createElement('div'); host.id = 'arc-toast-host'; host.setAttribute('aria-live','polite'); document.body.appendChild(host); }
            toast.classList.add('arc-toast');
            var close = document.createElement('button');
            close.type = 'button'; close.className = 'arc-toast-close'; close.setAttribute('aria-label','Fechar aviso');
            close.textContent = '×'; toast.appendChild(close);
            host.appendChild(toast);
            var timer;
            function dismiss() { clearTimeout(timer); toast.classList.add('arc-toast-leaving'); setTimeout(function(){toast.remove();},280); }
            close.addEventListener('click',dismiss);
            requestAnimationFrame(function(){toast.classList.add('arc-toast-visible');});
            timer=setTimeout(dismiss,3000);
        });
    })();

    /* ---------- Abas padrão (padrão .tab-btn / .tab-panel) ---------- */
    var tabButtons = document.querySelectorAll('.tab-btn');
    var tabPanels = document.querySelectorAll('.tab-panel');

    if (tabButtons.length && tabPanels.length) {
        var activateTab = function (name) {
            var found = false;
            tabButtons.forEach(function (b) {
                var on = b.getAttribute('data-tab') === name;
                b.classList.toggle('active', on);
                if (on) { found = true; }
            });
            tabPanels.forEach(function (p) {
                p.classList.toggle('active', p.id === 'tab-' + name);
            });
            if (found) {
                try { history.replaceState(null, '', '#' + name); } catch (e) {}
            }
        };

        tabButtons.forEach(function (b) {
            b.addEventListener('click', function () { activateTab(b.getAttribute('data-tab')); });
        });
        window.addEventListener('hashchange', function () {
            var h = (location.hash || '').replace('#', '');
            if (h && document.getElementById('tab-' + h)) { activateTab(h); }
        });

        var initialTab = (location.hash || '').replace('#', '');
        if (!initialTab || !document.getElementById('tab-' + initialTab)) {
            initialTab = tabButtons[0].getAttribute('data-tab');
        }
        activateTab(initialTab);
    }
})();
</script>

<?php if (!empty($ARCPageJs)) { echo $ARCPageJs; } ?>
</body>
</html>