<?php
/* Caminho: redes/_menu.php */
$arcNetworkLinks=arc_navigation_items($pdo,'header',(int)$networkId);
?>
<nav class="arc-redes-menu" aria-label="Seções da rede gerenciada">
<?php foreach($arcNetworkLinks as $item):$active=basename((string)parse_url($item['url'],PHP_URL_PATH),'.php')===$arcSectionFile;?>
<a class="arc-redes-menu-link <?=arc_h($item['device_class'])?> <?=$active?'active':''?>" href="<?=arc_h(arc_workspace_base_url().$item['url'])?>" <?=$active?'aria-current="page"':''?> title="<?=arc_h($item['label'])?>"><span class="arc-db-icon" data-icon="<?=arc_h($item['icon'])?>" aria-hidden="true"></span><span><?=arc_h($item['label'])?></span></a>
<?php endforeach;?></nav>
