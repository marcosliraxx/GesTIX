<?php
/* Caminho: pages/cobrancas.php */
declare(strict_types=1);
require dirname(__DIR__).'/includes/bootstrap.php';$pdo=arc_db();arc_ensure_user_schema($pdo);
if(!arc_is_user()){header('Location: '.arc_workspace_base_url().'index.php',true,303);exit;}
header('Cache-Control: no-store, private');$uid=(int)arc_user_id();$status=(string)($_GET['status']??'');$search=mb_substr(trim((string)($_GET['q']??'')),0,100);$page=max(1,min(100000,(int)($_GET['page']??1)));$from=(string)($_GET['from']??date('Y-m-d',strtotime('-1 year')));$to=(string)($_GET['to']??date('Y-m-d'));$error='';
$a=DateTimeImmutable::createFromFormat('!Y-m-d',$from);$b=DateTimeImmutable::createFromFormat('!Y-m-d',$to);
if(!$a||!$b||$a->format('Y-m-d')!==$from||$b->format('Y-m-d')!==$to||$a>$b){$error='Escolha um período válido.';$from=date('Y-m-d',strtotime('-1 year'));$to=date('Y-m-d');}
$allowed=[];$invoices=[];$total=0;$pages=1;
try{
 arc_require_billing_release();
$allowed=['pending','processing','review','paid','reversed','cancelled'];if(!in_array($status,$allowed,true))$status='';
$where='i.account_id=? AND i.created_at>=? AND i.created_at<?';$args=[$uid,$from.' 00:00:00',(new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d').' 00:00:00'];
if($status!==''){$where.=' AND i.status=?';$args[]=$status;}if($search!==''){$where.=' AND (p.name LIKE ? OR CAST(i.id AS CHAR)=? OR i.reference=?)';$args[]='%'.str_replace(['!','%','_'],['!!','!%','!_'],$search).'%';$where=str_replace('p.name LIKE ?','p.name LIKE ? ESCAPE \'!\'',$where);$args[]=$search;$args[]=$search;}
$join=' FROM '.arc_table('billing_invoices').' i JOIN '.arc_table('billing_plans').' p ON p.id=i.plan_id WHERE '.$where;
$q=$pdo->prepare('SELECT COUNT(*)'.$join);$q->execute($args);$total=(int)$q->fetchColumn();$pages=max(1,(int)ceil($total/30));$page=min($page,$pages);
$q=$pdo->prepare('SELECT i.*,p.name'.$join.' ORDER BY i.id DESC LIMIT 30 OFFSET '.(($page-1)*30));$q->execute($args);$invoices=$q->fetchAll();
}catch(Throwable $e){
 error_log('Histórico de cobranças: '.$e->getMessage());http_response_code(503);$allowed=[];$invoices=[];$total=0;$pages=1;
 $error=$e instanceof RuntimeException&&!($e instanceof PDOException)?$e->getMessage():'Não foi possível consultar as cobranças. Tente novamente mais tarde.';
}
$ARCPageTitle='Histórico de cobranças';$ARCActiveNav='billing_history';require dirname(__DIR__).'/includes/header.php';require dirname(__DIR__).'/includes/sidebar.php';
?>
<main class="app-main"><div class="page-content arc-service"><header class="arc-service-heading"><h1>Cobranças</h1><a class="arc-icon-action" href="pages/assinatura.php" title="Planos" aria-label="Ver planos"><i class="fa fa-th-large" aria-hidden="true"></i></a></header>
<form method="get" class="arc-filter-bar"><input name="q" value="<?=arc_h($search)?>" placeholder="Plano ou cobrança" aria-label="Buscar cobrança"><select name="status" aria-label="Situação"><option value="">Todas</option><?php foreach($allowed as $s):?><option value="<?=$s?>" <?=$status===$s?'selected':''?>><?=arc_h(arc_billing_status_label($s))?></option><?php endforeach;?></select><input type="date" name="from" value="<?=arc_h($from)?>" aria-label="De"><input type="date" name="to" value="<?=arc_h($to)?>" aria-label="Até"><button class="arc-icon-action" aria-label="Filtrar" title="Filtrar"><i class="fa fa-search" aria-hidden="true"></i></button></form>
<?php if($error):?><p role="alert"><?=arc_h($error)?></p><?php endif;?>
<?php if($error===''):?><p><?=number_format($total,0,',','.')?> cobranças · página <?=$page?> de <?=$pages?></p><div class="arc-service-list"><?php foreach($invoices as $i):?><article><div><strong><?=arc_h($i['name'])?> · <?=arc_money((int)$i['amount_cents'])?></strong><p>#<?=(int)$i['id']?> · <?=arc_h(arc_when($i['created_at']))?> · <?=arc_h(['pix'=>'Pix manual','asaas'=>'Asaas','mercadopago'=>'Mercado Pago'][$i['provider']]??'Pagamento')?></p><small><?=arc_h(arc_billing_status_label($i['status']))?><?=$i['paid_at']?' · pago em '.arc_h(arc_when($i['paid_at'])):''?></small><?php if($i['receipt_note']):?><details><summary>Referência enviada</summary><p><?=arc_h($i['receipt_note'])?></p></details><?php endif;?></div><a class="arc-icon-action" href="pages/checkout.php?invoice=<?=(int)$i['id']?>" aria-label="Abrir cobrança <?=(int)$i['id']?>" title="Abrir cobrança"><i class="fa fa-angle-right" aria-hidden="true"></i></a></article><?php endforeach;?><?php if(!$invoices):?><p>Nenhuma cobrança neste filtro.</p><?php endif;?></div>
<nav class="arc-service-tabs" aria-label="Páginas das cobranças"><?php if($page>1):?><a href="<?=arc_h('pages/cobrancas.php?'.http_build_query(array_merge($_GET,['page'=>$page-1])))?>" aria-label="Página anterior"><i class="fa fa-angle-left" aria-hidden="true"></i></a><?php endif;?><?php if($page<$pages):?><a href="<?=arc_h('pages/cobrancas.php?'.http_build_query(array_merge($_GET,['page'=>$page+1])))?>" aria-label="Próxima página"><i class="fa fa-angle-right" aria-hidden="true"></i></a><?php endif;?></nav><?php endif;?></div></main>
<?php require dirname(__DIR__).'/includes/footer.php';?>
