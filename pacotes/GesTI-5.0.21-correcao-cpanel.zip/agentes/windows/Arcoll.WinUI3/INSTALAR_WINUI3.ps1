﻿# Caminho: agentes/windows/Arcoll.WinUI3/INSTALAR_WINUI3.ps1
# Instalacao e atualizacao, por usuario, do agente Windows nativo (C# WinUI 3): atalhos, execucao em segundo plano e progresso em porcentagem.
# -Update: troca silenciosa disparada pelo proprio agente (atualizacao remota); -ForceRebuild: reinstalacao integral (build limpo).
[CmdletBinding()]
param([switch]$Update,[int]$ParentPid=0,[switch]$ForceRebuild,[switch]$Unattended)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
# Implantacao por ferramenta de TI: nao abre UAC nem qualquer confirmacao local.
# Falha antes de alterar arquivos se a ferramenta nao forneceu token administrativo.
if ($Unattended) {
    $isDeploymentAdmin = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isDeploymentAdmin) {
        [Console]::Error.WriteLine('Implantacao sem interacao exige contexto administrativo fornecido pela ferramenta de TI. Nenhuma janela UAC sera aberta.')
        exit 5
    }
}

$root = $PSScriptRoot
# Mensagens do MSBuild/.NET em ingles e UTF-8: evita texto corrompido nos logs e facilita a busca por erros.
$env:DOTNET_CLI_UI_LANGUAGE = 'en'
$env:VSLANG = '1033'
$env:DOTNET_NOLOGO = '1'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$publish = $null
$swapped = $false
$previous = $null
$bootStatus = $null
$destination = Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3'
$appName = 'Arcoll.WinUI3.exe'
function Step([int]$Percent,[string]$Message) {
    Write-Host ('[' + $Percent + '] ' + $Message)
    if ($Update) {
        # Os 55% iniciais sao download e SHA-256; a compilacao e a troca ocupam 55-99%.
        $shown = if ($Percent -lt 45) { 55 } elseif ($Percent -lt 82) { 65 } elseif ($Percent -lt 88) { 88 } elseif ($Percent -lt 93) { 92 } elseif ($Percent -lt 96) { 96 } elseif ($Percent -lt 99) { 98 } else { 99 }
        try {
            $progressPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\update-progress.json'
            $state = @{ percent = $shown; message = $Message; when = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }
            [IO.File]::WriteAllText($progressPath, ($state | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
        } catch { }
        # O processo anterior deve fechar para substituir os arquivos. O instalador
        # continua informando o progresso pela mesma fila autenticada do agente.
        try {
            $pendingPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\update-pending.json'
            if (-not (Test-Path -LiteralPath $pendingPath)) { return }
            $pending = Get-Content -LiteralPath $pendingPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([int64]$pending.command_id -le 0) { return }
            $cfgFile = Join-Path $destination 'agent-config.json'
            $migrating = Join-Path $root 'agent-config.json'
            if (Test-Path -LiteralPath $migrating) { $cfgFile = $migrating }
            if (-not (Test-Path -LiteralPath $cfgFile)) { return }
            $cfg = Get-Content -LiteralPath $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json
            $endpoint = ([string]$cfg.origin).TrimEnd('/') + '/api/api.php?action=agent-command-ack'
            $uri = $null
            if (-not [Uri]::TryCreate($endpoint, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo -ne '') { return }
            $body = @{ fingerprint = [string]$cfg.fingerprint; site_code = [string]$cfg.site_code;
                       download_key = [string]$cfg.download_key; command_id = [int64]$pending.command_id;
                       status = 'running'; result = 'WinUI 3 ' + $shown + '%: ' + $Message } | ConvertTo-Json -Compress
            Invoke-RestMethod -Uri $endpoint -Method Post -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 8 -MaximumRedirection 0 -ErrorAction Stop | Out-Null
        } catch { } # Desconexao nao interrompe instalacao: o aplicativo retomara o recibo.
    }
}
function Write-UpdateResult([bool]$Ok,[string]$Message) {
    if (-not $Update) { return }
    try { $o = [ordered]@{ ok = $Ok; message = $Message; finished = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }; [IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'TI-Digital\update-result.json'), ($o | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false))) } catch { }
}
$logs = Join-Path $env:LOCALAPPDATA 'TI-Digital\Logs'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$log = Join-Path $logs ('Instalar-WinUI3-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Start-Transcript -Path $log -Force | Out-Null
try {
    Write-Host ('T.I Digital - ' + $(if ($Update) { 'Atualizacao' } else { 'Instalacao' }) + ' do Agente Windows') -ForegroundColor Cyan
    Step 36 'Verificando requisitos do Windows...'
    if ($Update -and $ParentPid -gt 0) {
        Step 38 'Aguardando o agente encerrar...'
        $parent = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
        if ($parent) { if (-not $parent.WaitForExit(90000)) { Stop-Process -Id $ParentPid -Force -ErrorAction SilentlyContinue } }
    }
    if ([Environment]::OSVersion.Version.Build -lt 19041) { throw 'Necessario Windows 10 2004 (build 19041) ou superior.' }
    $project = Join-Path $root 'Arcoll.WinUI3.csproj'
    $required = @('App.xaml', 'MainWindow.xaml', 'app.manifest', 'PreLogin-Setup.ps1'); if (-not $Update) { $required += 'agent-config.json' }
    foreach ($file in $required) {
        if (-not (Test-Path -LiteralPath (Join-Path $root $file))) { throw "Arquivo ausente: $file" }
    }
    # Detectar SDK 8 sem depender do PATH de uma sessao antiga.
    $dotnetExe = (Get-Command dotnet.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
    $defaultDotnet = Join-Path ${env:ProgramFiles} 'dotnet\dotnet.exe'
    if (-not $dotnetExe -and (Test-Path -LiteralPath $defaultDotnet)) { $dotnetExe = $defaultDotnet }
    $hasSdk = $false
    if ($dotnetExe) {
        $sdkList = @(& $dotnetExe --list-sdks 2>&1)
        $hasSdk = [bool](@($sdkList | Where-Object { $_ -match '^8\.' }).Count)
    }
    if (-not $hasSdk) {
        Write-Host 'SDK .NET 8 nao encontrado. Instalando pelo WinGet (Microsoft)...' -ForegroundColor Yellow
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) {
            throw 'WinGet indisponivel. Instale o SDK .NET 8 em https://dotnet.microsoft.com/download/dotnet/8.0 e execute o BAT novamente.'
        }
        # Instalacao solicitada pelo proprio usuario ao executar o BAT.
        # Sem Read-Host, pois o bootstrap funciona em modo nao interativo.
        & $winget.Source install --id Microsoft.DotNet.SDK.8 --exact --source winget --silent --disable-interactivity --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -ne 0) { throw ('Instalacao do SDK .NET 8 pelo WinGet falhou (codigo ' + $LASTEXITCODE + '). Instale-o em https://dotnet.microsoft.com/download/dotnet/8.0 e execute o BAT novamente.') }
        if (Test-Path -LiteralPath $defaultDotnet) {
            $dotnetExe = $defaultDotnet
            $env:PATH = (Split-Path -Parent $defaultDotnet) + ';' + $env:PATH
        }
        if (-not $dotnetExe) { throw 'SDK instalado, mas dotnet.exe nao foi localizado. Reabra o terminal e execute o BAT novamente.' }
        $sdkList = @(& $dotnetExe --list-sdks 2>&1)
        if (-not @($sdkList | Where-Object { $_ -match '^8\.' }).Count) {
            throw 'SDK .NET 8 ainda nao detectado. Reabra o terminal e execute o BAT novamente.'
        }
    }
    Step 45 'SDK .NET 8 disponivel.'
    if ($ForceRebuild) { foreach ($d in 'bin','obj','BootWorker\bin','BootWorker\obj') { $path = Join-Path $root $d; if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue } } }
    $arch = if ([Environment]::Is64BitOperatingSystem) { 'win-x64' } else { '' }
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'win-arm64' }
    if (-not $arch) { throw 'Windows de 32 bits nao suportado.' }
    $platform = if ($arch -eq 'win-arm64') { 'ARM64' } else { 'x64' }
    $publish = Join-Path $env:TEMP ('ti-digital-winui-build-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $publish | Out-Null
    Step 50 'Restaurando pacotes assinados da Microsoft pelo NuGet...'
    & $dotnetExe restore $project "-p:Platform=$platform" "-p:RuntimeIdentifier=$arch"
    if ($LASTEXITCODE -ne 0) { throw 'Restauracao do projeto falhou. Consulte o log.' }
    # Validacao previa: o App.xaml deve constar uma unica vez como ApplicationDefinition.
    # Duplicidade faz o XamlCompiler.exe encerrar com codigo 1 sem mensagem.
    $appDefs = $null
    try {
        $rawItems = & $dotnetExe msbuild $project -nologo -getItem:ApplicationDefinition "-p:Platform=$platform" "-p:RuntimeIdentifier=$arch" 2>$null | Out-String
        $appDefs = @(($rawItems | ConvertFrom-Json).Items.ApplicationDefinition)
    } catch { $appDefs = $null }
    if ($appDefs -and $appDefs.Count -gt 1) { throw ('Projeto invalido: App.xaml declarado ' + $appDefs.Count + ' vezes no .csproj.') }
    Step 62 'Compilando a interface nativa C#...'
    # Preferir o MSBuild do Visual Studio quando presente.
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    $msbuild = $null
    if (Test-Path -LiteralPath $vswhere) {
        $foundMsbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' 2>$null
        if ($foundMsbuild) { $msbuild = @($foundMsbuild)[0] }
    }
    $buildLog = Join-Path $logs ('Compilacao-WinUI3-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
    $binLog = [System.IO.Path]::ChangeExtension($buildLog, '.binlog')
    $baseMsbuild = @('/nologo','/m:1','/t:Build','/p:Configuration=Release',"/p:Platform=$platform", "/p:RuntimeIdentifier=$arch",'/p:WindowsPackageType=None','/p:WindowsAppSDKSelfContained=true','/v:normal',"/bl:$binLog")
    if ($msbuild) {
        Write-Host ('Compilando com Visual Studio MSBuild: ' + $msbuild)
        & $msbuild $project @baseMsbuild 2>&1 | Tee-Object -FilePath $buildLog
    } else {
        Write-Host 'MSBuild do Visual Studio nao encontrado; usando MSBuild do SDK .NET.'
        & $dotnetExe msbuild $project @baseMsbuild 2>&1 | Tee-Object -FilePath $buildLog
    }
    $result = $LASTEXITCODE
    if ($result -ne 0) {
        Write-Host ('Compilacao falhou (codigo ' + $result + ').') -ForegroundColor Red
        if (Test-Path -LiteralPath $buildLog) { Get-Content -LiteralPath $buildLog -Tail 35 | ForEach-Object { Write-Host $_ } }
        Write-Host ('Log: ' + $buildLog)
        Write-Host ('Diagnostico MSBuild: ' + $binLog)
        # Preservar a resposta estruturada do compilador XAML para obter o erro original.
        $objDir = Join-Path $root 'obj'
        if (Test-Path -LiteralPath $objDir) {
            # Exibe no proprio log a resposta do compilador XAML (erros reais de XAML).
            Get-ChildItem -LiteralPath $objDir -Recurse -File -Filter 'output.json' -ErrorAction SilentlyContinue | ForEach-Object {
                $txt = Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue
                if ($txt) { Write-Host ('XamlCompiler output.json: ' + $txt.Substring(0, [Math]::Min(3000, $txt.Length))) }
            }
            $diagnosticDir = Join-Path $logs ('Xaml-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
            New-Item -ItemType Directory -Path $diagnosticDir -Force | Out-Null
            Get-ChildItem -LiteralPath $objDir -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -in @('input.json','output.json') } | ForEach-Object {
                    $relative = $_.FullName.Substring($objDir.Length).TrimStart('\')
                    $destFile = Join-Path $diagnosticDir $relative
                    New-Item -ItemType Directory -Path (Split-Path -Parent $destFile) -Force | Out-Null
                    Copy-Item -LiteralPath $_.FullName -Destination $destFile -Force
                }
            Write-Host ('Diagnosticos XAML: ' + $diagnosticDir)
        }
        throw ('Falha na compilacao XAML (codigo ' + $result + ').')
    }
    Step 82 'Compilacao concluida. Publicando arquivos...'
    & $dotnetExe publish $project -c Release -r $arch --self-contained true -p:WindowsPackageType=None -p:WindowsAppSDKSelfContained=true "-p:Platform=$platform" -p:PublishReadyToRun=false -p:PublishTrimmed=false -o $publish --no-restore 2>&1 | Tee-Object -FilePath $buildLog -Append
    if ($LASTEXITCODE -ne 0) { throw ('Publicacao falhou, codigo ' + $LASTEXITCODE + '. Veja ' + $buildLog) }
    $exe = Join-Path $publish 'Arcoll.WinUI3.exe'
    if (-not (Test-Path $exe)) { throw 'Executavel nao encontrado apos a compilacao.' }
    # Compila somente a presenca de boot (sem UI e sem comandos remotos).
    # Instalada em Program Files pela etapa administrativa; nunca execute WinUI em Session 0.
    $bootProject = Join-Path $root 'BootWorker\BootWorker.csproj'
    $bootPublish = Join-Path $env:TEMP ('ti-digital-boot-build-' + [guid]::NewGuid().ToString('N'))
    if (-not (Test-Path -LiteralPath $bootProject)) { throw 'Projeto BootWorker ausente no pacote.' }
    try {
        & $dotnetExe publish $bootProject -c Release -r $arch --self-contained true -p:PublishTrimmed=false -p:PublishReadyToRun=false -o $bootPublish
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $bootPublish 'TIDigital.BootPresence.exe'))) {
            throw 'Falha na compilacao do worker de inicializacao antes do login.'
        }
        Copy-Item -LiteralPath (Join-Path $root 'PreLogin-Setup.ps1') -Destination (Join-Path $publish 'PreLogin-Setup.ps1') -Force
        Copy-Item -LiteralPath (Join-Path $root 'HABILITAR_PRELOGIN.ps1') -Destination (Join-Path $publish 'HABILITAR_PRELOGIN.ps1') -Force
        Copy-Item -Path $bootPublish -Destination (Join-Path $publish 'BootWorker') -Recurse -Force
    } finally {
        if (Test-Path -LiteralPath $bootPublish) { Remove-Item -LiteralPath $bootPublish -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Step 88 'Instalando arquivos do agente...'
    # A configuracao (origem, codigo e chave) do computador ja instalado e preservada na atualizacao.
    $installedConfig = Join-Path $destination 'agent-config.json'
    # A ponte de migracao do Python fornece a mesma identidade revogavel no pacote ja
    # autenticado. Em atualizacoes WinUI normais nao ha config no ZIP; preserve a instalada.
    # Dar prioridade ao cadastro migrado evita reativar uma rede antiga instalada em paralelo.
    $migratedConfig = Join-Path $root 'agent-config.json'
    if ($Update -and (Test-Path -LiteralPath $migratedConfig)) { Copy-Item -LiteralPath $migratedConfig -Destination (Join-Path $publish 'agent-config.json') -Force }
    elseif ($Update -and (Test-Path -LiteralPath $installedConfig)) { Copy-Item -LiteralPath $installedConfig -Destination (Join-Path $publish 'agent-config.json') -Force }
    elseif (Test-Path -LiteralPath $migratedConfig) { Copy-Item -LiteralPath $migratedConfig -Destination (Join-Path $publish 'agent-config.json') -Force }
    else { throw 'agent-config.json ausente: reinstale pelo painel da plataforma.' }
    $running = Get-Process -Name 'Arcoll.WinUI3' -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq (Join-Path $destination $appName) }
    $running | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 700
    $stage = Join-Path $env:LOCALAPPDATA ('TI-Digital\WinUI3-stage-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    Copy-Item -Path (Join-Path $publish '*') -Destination $stage -Recurse -Force
    if (-not (Test-Path (Join-Path $stage $appName))) { throw 'Falha ao preparar os arquivos.' }
    # Nao mexe em tarefas, servicos ou credenciais do agente antigo.
    $previous = $destination + '.anterior'
    if (Test-Path $previous) { Remove-Item -LiteralPath $previous -Recurse -Force }
    if (Test-Path $destination) { Move-Item -LiteralPath $destination -Destination $previous; $swapped = $true }
    Move-Item -LiteralPath $stage -Destination $destination
    $swapped = $true
    $target = Join-Path $destination $appName
    Step 93 'Criando atalhos...'
    $brandIcon = Join-Path $destination 'Assets\system.ico'
    $shortcutIcon = $target + ',0'
    if (Test-Path -LiteralPath $brandIcon) {
        $iconHash = (Get-FileHash -LiteralPath $brandIcon -Algorithm SHA256).Hash.Substring(0,16)
        $cachedIcon = Join-Path $destination ('system-' + $iconHash + '.ico')
        Copy-Item -LiteralPath $brandIcon -Destination $cachedIcon -Force
        $shortcutIcon = $cachedIcon + ',0'
    }
    $shell = New-Object -ComObject WScript.Shell
    $programs = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
    $oldShortcut = Join-Path $programs 'T.I Digital - WinUI3 (Teste).lnk'
    if (Test-Path -LiteralPath $oldShortcut) { Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue }
    foreach ($folder in @($programs, [Environment]::GetFolderPath('Desktop'))) {
        if (-not $folder -or -not (Test-Path -LiteralPath $folder)) { continue }
        $link = $shell.CreateShortcut((Join-Path $folder 'T.I Digital - Agente Windows.lnk'))
        $link.TargetPath = $target; $link.WorkingDirectory = $destination; $link.IconLocation = $shortcutIcon
        $link.Description = 'Agente Windows T.I Digital'; $link.Save()
    }
    Step 96 'Configurando execucao em segundo plano...'
    $taskName = 'TI-Digital Agente Windows'
    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    try {
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $action = New-ScheduledTaskAction -Execute $target -Argument '--background' -WorkingDirectory $destination
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $me
        $principal = New-ScheduledTaskPrincipal -UserId $me -LogonType Interactive -RunLevel Limited
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
        Remove-ItemProperty -Path $runKey -Name 'TIDigitalAgente' -ErrorAction SilentlyContinue
    } catch {
        Write-Host ('Tarefa agendada indisponivel (' + $_.Exception.Message + '); usando a inicializacao do usuario.')
        New-ItemProperty -Path $runKey -Name 'TIDigitalAgente' -Value ('"' + $target + '" --background') -PropertyType String -Force | Out-Null
    }
    # Eleva somente a instalacao do componente de boot; preserva o perfil da interface.
    Step 98 'Verificando componente de presenca antes do login...'
    # Resolve a configuracao ainda no perfil original, antes de eventual UAC
    # com credenciais de outro administrador (mesma prioridade de AgentConfig.Load).
    $effectiveConfig = @{}
    foreach ($cfgPath in @((Join-Path $env:APPDATA 'Arcoll\agent.json'), (Join-Path $destination 'agent-config.json'))) {
        if (-not (Test-Path -LiteralPath $cfgPath)) { continue }
        try {
            $cfgObject = Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($field in @('origin','site_code','download_key','fingerprint','system_name')) {
                $value = [string]$cfgObject.$field
                if (-not $effectiveConfig.ContainsKey($field) -and -not [string]::IsNullOrWhiteSpace($value)) { $effectiveConfig[$field] = $value.Trim() }
            }
        } catch { Write-Warning ('Configuracao ignorada: ' + $cfgPath) }
    }
    [IO.File]::WriteAllText((Join-Path $destination 'agent-config.json'), ($effectiveConfig | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    . (Join-Path $root 'PreLogin-Setup.ps1')
    $elevated = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $bootStatus = Invoke-PreLoginSetup -AgentFolder $destination -LogFolder $logs -Update $Update.IsPresent -Unattended $Unattended.IsPresent -Elevated $elevated
    [IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'TI-Digital\boot-status.json'), ($bootStatus | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    if ($bootStatus.pending) { Write-Host ('BOOT-PENDING: ' + $bootStatus.message) -ForegroundColor Yellow }
    else { Write-Host $bootStatus.message }
    Step 99 'Iniciando o agente...'
    $readyPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\native-ready.json'
    if ($Update -and (Test-Path -LiteralPath $readyPath)) { Remove-Item -LiteralPath $readyPath -Force -ErrorAction SilentlyContinue }
    if ($Update) { $launched = Start-Process -FilePath $target -ArgumentList '--background' -WorkingDirectory $destination -PassThru }
    else { $launched = Start-Process -FilePath $target -WorkingDirectory $destination -PassThru }
    if (-not $launched) { throw 'A inicializacao do agente falhou.' }
    Start-Sleep -Seconds 3
    $active = Get-Process -Id $launched.Id -ErrorAction SilentlyContinue
    if (-not $active -or $active.HasExited) { throw 'O executavel encerrou imediatamente apos a instalacao.' }
    if ($Update) {
        # Nao basta a janela abrir: a nova instancia precisa estar APROVADA pela
        # plataforma, possuir a mesma identidade e informar a versao publicada.
        $projectSource = Get-Content -LiteralPath $project -Raw -Encoding UTF8
        $expected = ([regex]::Match($projectSource, '<Version>(\d+\.\d+\.\d+)</Version>')).Groups[1].Value
        $installedIdentity = Get-Content -LiteralPath (Join-Path $destination 'agent-config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        $verified = $false
        for ($attempt = 0; $attempt -lt 25; $attempt++) {
            $active = Get-Process -Id $launched.Id -ErrorAction SilentlyContinue
            if (-not $active -or $active.HasExited) { throw 'O agente encerrou antes de validar a autorizacao.' }
            if (Test-Path -LiteralPath $readyPath) {
                try {
                    $receipt = Get-Content -LiteralPath $readyPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    # Instalações antigas podem não guardar o fingerprint em
                    # agent-config.json; nesses casos, o próprio agente o deriva
                    # do MachineGuid e o servidor já validou a identidade.
                    $identityOk = (-not [string]$installedIdentity.fingerprint) -or
                        ([string]$receipt.fingerprint -eq [string]$installedIdentity.fingerprint)
                    if ([int]$receipt.pid -eq $launched.Id -and
                        [string]$receipt.version -eq $expected -and $identityOk -and
                        [int64]$receipt.approved_at -ge ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - 100)) {
                        $verified = $true; break
                    }
                } catch { }
            }
            Start-Sleep -Seconds 2
        }
        if (-not $verified) { throw 'O novo agente nao confirmou autorizacao e versao na plataforma em 50 segundos. Revertendo a instalacao.' }
    }
    $successMessage = 'Versao e autorizacao confirmadas pela plataforma; agente atualizado.'
    if ($bootStatus -and $bootStatus.pending) { $successMessage += ' AVISO: ' + $bootStatus.message }
    Write-UpdateResult $true $successMessage
    Write-Host "Instalado em $destination" -ForegroundColor Green
    Step 100 'Instalacao finalizada.'
} catch {
    $failure = $_.Exception.Message
    if ($Update -and $swapped -and $previous -and (Test-Path -LiteralPath $previous)) {
        try {
            $failedDestination = $destination + '.falhou-' + (Get-Date -Format 'yyyyMMddHHmmss')
            Get-Process -Name 'Arcoll.WinUI3' -ErrorAction SilentlyContinue |
                Where-Object { $_.Path -eq (Join-Path $destination $appName) } |
                Stop-Process -Force -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $destination) { Move-Item -LiteralPath $destination -Destination $failedDestination }
            Move-Item -LiteralPath $previous -Destination $destination
            $restored = Join-Path $destination $appName
            if (Test-Path -LiteralPath $restored) { Start-Process -FilePath $restored -ArgumentList '--background' -WorkingDirectory $destination }
            Write-Host 'Reversao: versao anterior restaurada.' -ForegroundColor Yellow
            $failure += ' A versao anterior foi restaurada.'
        } catch { $failure += ' Falha na reversao automatica: ' + $_.Exception.Message }
    } elseif ($Update -and $swapped -and $previous -and -not (Test-Path -LiteralPath $previous)) {
        # Primeira migracao Python -> WinUI: nao existia uma instalacao nativa
        # anterior. Retire somente a nova instancia incompleta. O atualizador
        # Python reiniciara o agente antigo preservado quando receber este erro.
        try {
            if ($launched) { Stop-Process -Id $launched.Id -Force -ErrorAction SilentlyContinue }
            $nativeTask = Get-ScheduledTask -TaskName 'TI-Digital Agente Windows' -ErrorAction SilentlyContinue
            if ($nativeTask -and @($nativeTask.Actions | Where-Object { $_.Execute -eq (Join-Path $destination $appName) }).Count) {
                Unregister-ScheduledTask -TaskName 'TI-Digital Agente Windows' -Confirm:$false -ErrorAction SilentlyContinue
            }
            Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'TIDigitalAgente' -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction Stop }
            $failure += ' Nova instalacao descartada; agente anterior disponivel.'
        } catch { $failure += ' Falha na limpeza do nativo incompleto: ' + $_.Exception.Message }
    }
    Write-UpdateResult $false $failure
    Write-Host ('ERRO: ' + $failure) -ForegroundColor Red
    Write-Host ('Diagnostico: ' + $log)
    exit 1
} finally {
    if ($publish -and (Test-Path -LiteralPath $publish)) { Remove-Item -LiteralPath $publish -Recurse -Force -ErrorAction SilentlyContinue }
    Stop-Transcript | Out-Null
}
