// Caminho: tests/Programas/Program.cs
// Somente dados sintéticos: não inicia processos, instala nem lê programas do Windows.
using Arcoll.WinUI3.Services;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
int checks=0;
void Check(bool ok,string name){if(!ok)throw new Exception(name);Console.WriteLine("PASS "+name);checks++;}
void Reject(Action action,string name){try{action();}catch(Exception){Check(true,name);return;}throw new Exception("Aceitou "+name);}
var quoted=ProgramService.Split("\"C:\\Program Files\\Example\\remove.exe\" /remove");
Check(quoted.File==@"C:\Program Files\Example\remove.exe"&&quoted.Args=="/remove","caminho com espaços e argumentos preservados");
var plain=ProgramService.Split(@"C:\Program Files\Example\remove.exe /remove");
Check(plain==quoted,"caminho legado sem aspas");
Reject(()=>ProgramService.Split("\"entrada truncada"),"aspas inválidas");
var app=new InstalledApplication("Exemplo","1.0","Fabricante","20261106","HKCU\\64\\example",@"C:\example\remove.exe","");
var catalog=new[]{new CatalogApplication("Exemplo","Vendor.Example","Utilitários")};
Check(ProgramService.CanUninstall(app)&&!ProgramService.CanUninstall(app with{Uninstall=""}),"disponibilidade do desinstalador");
Check(ProgramService.SuccessfulExit(0)&&ProgramService.SuccessfulExit(3010)&&ProgramService.SuccessfulExit(1641)&&!ProgramService.SuccessfulExit(1603),"códigos de sucesso e reinício");
Check(ProgramService.Match(catalog[0],new[]{app})==app,"vínculo exato do catálogo");
Check(ProgramService.Match(new("Exemplo 2","Vendor.Second","Utilitários"),new[]{app})is null,"edições diferentes não confundidas");
var packageArgs=ProgramService.PackageArguments("Vendor.Example",false,catalog);
Check(packageArgs.SequenceEqual(new[]{"install","--id","Vendor.Example","--exact","--source","winget","--interactive"}),"WinGet com argumentos fixos e instalador interativo");
Check(ProgramService.PackageArguments("Vendor.Example",true,catalog)[0]=="upgrade","atualização usa a mesma identidade exata");
Reject(()=>ProgramService.PackageArguments("Vendor.Example & calc",false,catalog),"injeção de comando");
Reject(()=>ProgramService.PackageArguments("Unknown.Example",false,catalog),"pacote fora do catálogo");
var payload=ProgramService.InventoryPayload(new[]{app});
Check((string)payload[0]["id"]! == Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(app.Id))).ToLowerInvariant(),"identificador SHA-256 compatível com a API");
Check((string)payload[0]["method"]! == "interactive"&&(string)payload[0]["name"]! == "Exemplo","contrato do inventário");
Check(ProgramService.InventoryPayload(Enumerable.Repeat(app,1600).ToArray()).Count==1500,"limite do inventário");
var path=Path.Combine(AppContext.BaseDirectory,"Assets","program-catalog.json");Directory.CreateDirectory(Path.GetDirectoryName(path)!);
try
{
 File.WriteAllText(path,JsonSerializer.Serialize(new[]{new{name="Exemplo",id="Vendor.Example",category="Utilitários"}}));
 Check(ProgramService.Catalog().Single().Name=="Exemplo","catálogo publicado com nomes PHP");
 File.WriteAllText(path,"[{\"name\":\"Inválido\",\"id\":\"x & calc\",\"category\":\"Teste\"}]");
 Reject(()=>ProgramService.Catalog(),"catálogo adulterado");
 if(args.Length==1)
 {
  File.Copy(args[0],path,true);var actual=ProgramService.Catalog();
  Check(actual.Count>100&&actual.Select(x=>x.Category).Distinct().Count()>10,"catálogo real da plataforma aceito integralmente");
 }
 File.WriteAllText(path,new string('x',262145));Reject(()=>ProgramService.Catalog(),"catálogo acima do limite");
}
finally{File.Delete(path);}
Console.WriteLine($"{checks} verificações concluídas.");
