<?php
// Caminho: tests/test_windows_icon.php
// Logo sintética temporária; não lê banco, uploads ou credenciais de produção.
declare(strict_types=1);
require dirname(__DIR__).'/includes/support.php';
class IconTestPDO extends PDO { public function __construct() {} }
$directory=sys_get_temp_dir().'/gesti-icon-'.bin2hex(random_bytes(8));mkdir($directory,0700);
$logo=str_repeat('a',32).'.png';$custom=str_repeat('b',32).'.png';$design='';
function arc_platform_setting(PDO $pdo,string $key,string $default=''):string {global $design;return $key==='platform_agent_icon'?$design:$default;}
function arc_upload_dir(string $key):string {global $directory;return $directory;}
function arc_setting_values(PDO $pdo):array {global $logo;return ['logo_path'=>$logo];}
function check_icon(bool $value,string $text):void {if(!$value)throw new RuntimeException($text);echo "PASS $text\n";}
try{
 foreach([[$logo,230,20],[$custom,20,230]] as [$file,$red,$green]){
  $image=imagecreatetruecolor(120,60);imagefill($image,0,0,imagecolorallocate($image,$red,$green,15));imagepng($image,$directory.'/'.$file);imagedestroy($image);
 }
 $pdo=new IconTestPDO();
 foreach(['system','custom'] as $mode){
  $design=$mode==='custom'?'https://example.test/uploads/brand/'.$custom:'';
  $data=arc_support_icon($pdo,'agent');$head=unpack('vreserved/vtype/vcount',substr($data,0,6));
  check_icon($head===['reserved'=>0,'type'=>1,'count'=>7],"$mode: cabeçalho ICO e sete resoluções");
  foreach([16,24,32,48,64,128,256] as $index=>$size){
   $entry=unpack('Cwidth/Cheight/Ccolors/Creserved/vplanes/vbits/Vlength/Voffset',substr($data,6+16*$index,16));
   check_icon($entry['width']===($size===256?0:$size),"$mode: dimensão $size");
   $png=substr($data,$entry['offset'],$entry['length']);$image=imagecreatefromstring($png);
   check_icon($image!==false&&imagesx($image)===$size&&imagesy($image)===$size,"$mode: conteúdo PNG $size");
   $center=imagecolorsforindex($image,imagecolorat($image,intdiv($size,2),intdiv($size,2)));
   check_icon($mode==='system'?$center['red']>$center['green']:$center['green']>$center['red'],"$mode: origem correta da logo $size");
   $corner=imagecolorsforindex($image,imagecolorat($image,0,0));check_icon($corner['alpha']===127,"$mode: transparência e proporção $size");imagedestroy($image);
  }
 }
}finally{foreach(glob($directory.'/*') as $file)unlink($file);rmdir($directory);}
