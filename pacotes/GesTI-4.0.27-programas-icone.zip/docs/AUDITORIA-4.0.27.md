# Etapa 4.0.27 — Programas e identidade do agente Windows

Foram inventariados os 259 caminhos do backup 4.0.26 e os 194 do backup 3.10.10.
A base de alteração é a 4.0.26. Configuração privada, SQL de produção, uploads e
logs não foram incorporados. A análise funcional desta etapa concentrou-se em
Programas, catálogo web, inventário, executores, distribuição e identidade visual.
Não constitui certificação de todos os módulos da plataforma.

## Causas corrigidas

- A distribuição nativa não incluía o ICO produzido pela configuração administrativa.
  `api/download-agent.php` agora usa o gerador original `arc_support_icon` e publica
  o mesmo recurso para compilação e instalação. Não foi criado um gerador paralelo.
- O gerador de ICO entregava apenas 64 pixels. A implementação original gera sete
  resoluções, de 16 a 256, preservando transparência e proporção da logo.
- Atalhos apontavam ao ícone genérico do EXE e a bandeja desenhava apenas um T.
  O executável incorpora a logo, a janela e a bandeja carregam o mesmo ICO; atalhos
  usam nome com hash para renovar o cache do Explorer. O estado de conexão continua
  no rodapé e na dica da bandeja; o indicador visual da bandeja passa a ser a logo.
- Programas utilizava o painel genérico de inventário da janela. Foi substituído por
  `Pages/ProgramsPage.cs`, integrado ao host de páginas existente, e o fluxo antigo
  de desinstalação foi removido da janela principal. `ProgramService` continua sendo
  o executor único; o contrato `InstalledApplication` agora reside nesse componente.
- O catálogo da página é gerado diretamente de `arc_program_install_catalog`, sem
  uma segunda relação de pacotes no C#. A instalação usa IDs exatos autorizados e
  argumentos estruturados do WinGet, com confirmação e elevação nativa.
- Inventário local e remoto compartilham a mesma serialização, limites e identidade
  SHA-256. Atualizações locais usam a API existente; erros de envio são explícitos.

## Preservação e limites

Servidor, Monitoramento, motor de rede, interface Python e configuração administrativa
permaneceram byte a byte iguais à base. Não houve migração de banco nem mudança da
política de atualização forçada. Programas não libera operações em UiLocked.
Ações locais exigem aprovação e confirmação; não forçam reinício ou encerramento de
aplicações. A fila não mata um instalador aberto. A interface lista resultados reais
por programa; o percentual conta itens concluídos e não inventa progresso de download.
Listas grandes exibem lotes de 80, com busca sobre todo o inventário e Carregar mais.

Esta etapa não migra os comandos remotos de instalação/desinstalação que ainda não
são tratados pelo runtime nativo da base. Foi integrado à página o comando remoto
já existente de inventário. Não há promessa de equivalência integral entre os dois
agentes nesta entrega; as demais funções do anexo ficam para etapas posteriores.

## Evidências

- 18 verificações do serviço C# passaram, incluindo o catálogo real gerado pelo PHP.
- 58 verificações PHP passaram para logo geral/específica e sete resoluções ICO.
- Cinco verificações passaram sobre o empacotador real: ICO configurado, catálogo
  idêntico à fonte web, catálogo completo, página incluída e ausência de obj/bin/storage.
- Sintaxe PHP validada; checagem semântica de todo o C# contra referências reais do
  Windows SDK passou sem erros ou avisos. A checagem usa campos XAML temporários
  somente fora da entrega; não substitui a compilação do XAML no Windows.
- A tentativa de build WinUI completo restaurou as dependências, mas parou porque
  XamlCompiler.exe requer Windows (erro de formato executável em Linux).

Não foram produzidos EXEs nem capturas de tela. Instalação Windows, UAC, WinGet,
cache do Explorer, bandeja e aparência real ainda precisam de homologação Windows.
O ZIP contém o delta da base 4.0.26, fontes e instruções. Não há exclusões físicas;
as implementações substituídas foram removidas dos arquivos originais.
