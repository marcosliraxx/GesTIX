﻿# Caminho: agentes/windows/Arcoll.WinUI3/INSTALAR_WINUI3.ps1
# Instalacao e atualizacao, por usuario, do agente Windows nativo (C# WinUI 3): atalhos, execucao em segundo plano e progresso em porcentagem.
# -Update: troca silenciosa disparada pelo proprio agente (atualizacao remota); -ForceRebuild: reinstalacao integral (build limpo).
[CmdletBinding()]
param([switch]$Update,[int]$ParentPid=0,[switch]$ForceRebuild)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
# Mensagens do MSBuild/.NET em ingles e UTF-8: evita texto corrompido nos logs e facilita a busca por erros.
$env:DOTNET_CLI_UI_LANGUAGE = 'en'
$env:VSLANG = '1033'
$env:DOTNET_NOLOGO = '1'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$publish = $null
$destination = Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3'
$appName = 'Arcoll.WinUI3.exe'
function Step([int]$Percent,[string]$Message) { Write-Host ('[' + $Percent + '] ' + $Message) }
function Write-UpdateResult([bool]$Ok,[string]$Message) {
    if (-not $Update) { return }
    try { $o = [ordered]@{ ok = $Ok; message = $Message; finished = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }; [IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'TI-Digital\update-result.json'), ($o | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false))) } catch { }
}
$logs = Join-Path $env:LOCALAPPDATA 'TI-Digital\Logs'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$log = Join-Path $logs ('Instalar-WinUI3-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Start-Transcript -Path $log -Force | Out-Null
try {
    Write-Host ('T.I Digital - ' + $(if ($Update) { 'Atualizacao' } else { 'Instalacao' }) + ' do Agente Windows') -ForegroundColor Cyan
    Step 36 'Verificando requisitos do Windows...'
    if ($Update -and $ParentPid -gt 0) {
        Step 38 'Aguardando o agente encerrar...'
        $parent = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
        if ($parent) { if (-not $parent.WaitForExit(90000)) { Stop-Process -Id $ParentPid -Force -ErrorAction SilentlyContinue } }
    }
    if ([Environment]::OSVersion.Version.Build -lt 19041) { throw 'Necessario Windows 10 2004 (build 19041) ou superior.' }
    $project = Join-Path $root 'Arcoll.WinUI3.csproj'
    $required = @('App.xaml', 'MainWindow.xaml', 'app.manifest'); if (-not $Update) { $required += 'agent-config.json' }
    foreach ($file in $required) {
        if (-not (Test-Path -LiteralPath (Join-Path $root $file))) { throw "Arquivo ausente: $file" }
    }
    # Detectar SDK 8 sem depender do PATH de uma sessao antiga.
    $dotnetExe = (Get-Command dotnet.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
    $defaultDotnet = Join-Path ${env:ProgramFiles} 'dotnet\dotnet.exe'
    if (-not $dotnetExe -and (Test-Path -LiteralPath $defaultDotnet)) { $dotnetExe = $defaultDotnet }
    $hasSdk = $false
    if ($dotnetExe) {
        $sdkList = @(& $dotnetExe --list-sdks 2>&1)
        $hasSdk = [bool](@($sdkList | Where-Object { $_ -match '^8\.' }).Count)
    }
    if (-not $hasSdk) {
        Write-Host 'SDK .NET 8 nao encontrado. Instalando pelo WinGet (Microsoft)...' -ForegroundColor Yellow
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) {
            throw 'WinGet indisponivel. Instale o SDK .NET 8 em https://dotnet.microsoft.com/download/dotnet/8.0 e execute o BAT novamente.'
        }
        # Instalacao solicitada pelo proprio usuario ao executar o BAT.
        # Sem Read-Host, pois o bootstrap funciona em modo nao interativo.
        & $winget.Source install --id Microsoft.DotNet.SDK.8 --exact --source winget --silent --disable-interactivity --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -ne 0) { throw ('Instalacao do SDK .NET 8 pelo WinGet falhou (codigo ' + $LASTEXITCODE + '). Instale-o em https://dotnet.microsoft.com/download/dotnet/8.0 e execute o BAT novamente.') }
        if (Test-Path -LiteralPath $defaultDotnet) {
            $dotnetExe = $defaultDotnet
            $env:PATH = (Split-Path -Parent $defaultDotnet) + ';' + $env:PATH
        }
        if (-not $dotnetExe) { throw 'SDK instalado, mas dotnet.exe nao foi localizado. Reabra o terminal e execute o BAT novamente.' }
        $sdkList = @(& $dotnetExe --list-sdks 2>&1)
        if (-not @($sdkList | Where-Object { $_ -match '^8\.' }).Count) {
            throw 'SDK .NET 8 ainda nao detectado. Reabra o terminal e execute o BAT novamente.'
        }
    }
    Step 45 'SDK .NET 8 disponivel.'
    if ($ForceRebuild) { foreach ($d in 'bin','obj') { $path = Join-Path $root $d; if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue } } }
    $arch = if ([Environment]::Is64BitOperatingSystem) { 'win-x64' } else { '' }
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'win-arm64' }
    if (-not $arch) { throw 'Windows de 32 bits nao suportado.' }
    $platform = if ($arch -eq 'win-arm64') { 'ARM64' } else { 'x64' }
    $publish = Join-Path $env:TEMP ('ti-digital-winui-build-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $publish | Out-Null
    Step 50 'Restaurando pacotes assinados da Microsoft pelo NuGet...'
    & $dotnetExe restore $project "-p:Platform=$platform" "-p:RuntimeIdentifier=$arch"
    if ($LASTEXITCODE -ne 0) { throw 'Restauracao do projeto falhou. Consulte o log.' }
    # Validacao previa: o App.xaml deve constar uma unica vez como ApplicationDefinition.
    # Duplicidade faz o XamlCompiler.exe encerrar com codigo 1 sem mensagem.
    $appDefs = $null
    try {
        $rawItems = & $dotnetExe msbuild $project -nologo -getItem:ApplicationDefinition "-p:Platform=$platform" "-p:RuntimeIdentifier=$arch" 2>$null | Out-String
        $appDefs = @(($rawItems | ConvertFrom-Json).Items.ApplicationDefinition)
    } catch { $appDefs = $null }
    if ($appDefs -and $appDefs.Count -gt 1) { throw ('Projeto invalido: App.xaml declarado ' + $appDefs.Count + ' vezes no .csproj.') }
    Step 62 'Compilando a interface nativa C#...'
    # Preferir o MSBuild do Visual Studio quando presente.
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    $msbuild = $null
    if (Test-Path -LiteralPath $vswhere) {
        $foundMsbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' 2>$null
        if ($foundMsbuild) { $msbuild = @($foundMsbuild)[0] }
    }
    $buildLog = Join-Path $logs ('Compilacao-WinUI3-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
    $binLog = [System.IO.Path]::ChangeExtension($buildLog, '.binlog')
    $baseMsbuild = @('/nologo','/m:1','/t:Build','/p:Configuration=Release',"/p:Platform=$platform", "/p:RuntimeIdentifier=$arch",'/p:WindowsPackageType=None','/p:WindowsAppSDKSelfContained=true','/v:normal',"/bl:$binLog")
    if ($msbuild) {
        Write-Host ('Compilando com Visual Studio MSBuild: ' + $msbuild)
        & $msbuild $project @baseMsbuild 2>&1 | Tee-Object -FilePath $buildLog
    } else {
        Write-Host 'MSBuild do Visual Studio nao encontrado; usando MSBuild do SDK .NET.'
        & $dotnetExe msbuild $project @baseMsbuild 2>&1 | Tee-Object -FilePath $buildLog
    }
    $result = $LASTEXITCODE
    if ($result -ne 0) {
        Write-Host ('Compilacao falhou (codigo ' + $result + ').') -ForegroundColor Red
        if (Test-Path -LiteralPath $buildLog) { Get-Content -LiteralPath $buildLog -Tail 35 | ForEach-Object { Write-Host $_ } }
        Write-Host ('Log: ' + $buildLog)
        Write-Host ('Diagnostico MSBuild: ' + $binLog)
        # Preservar a resposta estruturada do compilador XAML para obter o erro original.
        $objDir = Join-Path $root 'obj'
        if (Test-Path -LiteralPath $objDir) {
            # Exibe no proprio log a resposta do compilador XAML (erros reais de XAML).
            Get-ChildItem -LiteralPath $objDir -Recurse -File -Filter 'output.json' -ErrorAction SilentlyContinue | ForEach-Object {
                $txt = Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue
                if ($txt) { Write-Host ('XamlCompiler output.json: ' + $txt.Substring(0, [Math]::Min(3000, $txt.Length))) }
            }
            $diagnosticDir = Join-Path $logs ('Xaml-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
            New-Item -ItemType Directory -Path $diagnosticDir -Force | Out-Null
            Get-ChildItem -LiteralPath $objDir -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -in @('input.json','output.json') } | ForEach-Object {
                    $relative = $_.FullName.Substring($objDir.Length).TrimStart('\')
                    $destFile = Join-Path $diagnosticDir $relative
                    New-Item -ItemType Directory -Path (Split-Path -Parent $destFile) -Force | Out-Null
                    Copy-Item -LiteralPath $_.FullName -Destination $destFile -Force
                }
            Write-Host ('Diagnosticos XAML: ' + $diagnosticDir)
        }
        throw ('Falha na compilacao XAML (codigo ' + $result + ').')
    }
    Step 82 'Compilacao concluida. Publicando arquivos...'
    & $dotnetExe publish $project -c Release -r $arch --self-contained true -p:WindowsPackageType=None -p:WindowsAppSDKSelfContained=true "-p:Platform=$platform" -p:PublishReadyToRun=false -p:PublishTrimmed=false -o $publish --no-restore 2>&1 | Tee-Object -FilePath $buildLog -Append
    if ($LASTEXITCODE -ne 0) { throw ('Publicacao falhou, codigo ' + $LASTEXITCODE + '. Veja ' + $buildLog) }
    $exe = Join-Path $publish 'Arcoll.WinUI3.exe'
    if (-not (Test-Path $exe)) { throw 'Executavel nao encontrado apos a compilacao.' }
    Step 88 'Instalando arquivos do agente...'
    # A configuracao (origem, codigo e chave) do computador ja instalado e preservada na atualizacao.
    $installedConfig = Join-Path $destination 'agent-config.json'
    if ($Update -and (Test-Path -LiteralPath $installedConfig)) { Copy-Item -LiteralPath $installedConfig -Destination (Join-Path $publish 'agent-config.json') -Force }
    elseif (Test-Path -LiteralPath (Join-Path $root 'agent-config.json')) { Copy-Item -LiteralPath (Join-Path $root 'agent-config.json') -Destination (Join-Path $publish 'agent-config.json') -Force }
    else { throw 'agent-config.json ausente: reinstale pelo painel da plataforma.' }
    Get-Process -Name 'Arcoll.WinUI3' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 700
    $stage = Join-Path $env:LOCALAPPDATA ('TI-Digital\WinUI3-stage-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    Copy-Item -Path (Join-Path $publish '*') -Destination $stage -Recurse -Force
    if (-not (Test-Path (Join-Path $stage $appName))) { throw 'Falha ao preparar os arquivos.' }
    # Nao mexe em tarefas, servicos ou credenciais do agente antigo.
    $previous = $destination + '.anterior'
    if (Test-Path $previous) { Remove-Item -LiteralPath $previous -Recurse -Force }
    if (Test-Path $destination) { Move-Item -LiteralPath $destination -Destination $previous }
    Move-Item -LiteralPath $stage -Destination $destination
    $target = Join-Path $destination $appName
    Step 93 'Criando atalhos...'
    $brandIcon = Join-Path $destination 'Assets\system.ico'
    $shortcutIcon = $target + ',0'
    if (Test-Path -LiteralPath $brandIcon) {
        $iconHash = (Get-FileHash -LiteralPath $brandIcon -Algorithm SHA256).Hash.Substring(0,16)
        $cachedIcon = Join-Path $destination ('system-' + $iconHash + '.ico')
        Copy-Item -LiteralPath $brandIcon -Destination $cachedIcon -Force
        $shortcutIcon = $cachedIcon + ',0'
    }
    $shell = New-Object -ComObject WScript.Shell
    $programs = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
    $oldShortcut = Join-Path $programs 'T.I Digital - WinUI3 (Teste).lnk'
    if (Test-Path -LiteralPath $oldShortcut) { Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue }
    foreach ($folder in @($programs, [Environment]::GetFolderPath('Desktop'))) {
        if (-not $folder -or -not (Test-Path -LiteralPath $folder)) { continue }
        $link = $shell.CreateShortcut((Join-Path $folder 'T.I Digital - Agente Windows.lnk'))
        $link.TargetPath = $target; $link.WorkingDirectory = $destination; $link.IconLocation = $shortcutIcon
        $link.Description = 'Agente Windows T.I Digital'; $link.Save()
    }
    Step 96 'Configurando execucao em segundo plano...'
    $taskName = 'TI-Digital Agente Windows'
    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    try {
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $action = New-ScheduledTaskAction -Execute $target -Argument '--background' -WorkingDirectory $destination
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $me
        $principal = New-ScheduledTaskPrincipal -UserId $me -LogonType Interactive -RunLevel Limited
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
        Remove-ItemProperty -Path $runKey -Name 'TIDigitalAgente' -ErrorAction SilentlyContinue
    } catch {
        Write-Host ('Tarefa agendada indisponivel (' + $_.Exception.Message + '); usando a inicializacao do usuario.')
        New-ItemProperty -Path $runKey -Name 'TIDigitalAgente' -Value ('"' + $target + '" --background') -PropertyType String -Force | Out-Null
    }
    Step 99 'Iniciando o agente...'
    if ($Update) { Start-Process -FilePath $target -ArgumentList '--background' -WorkingDirectory $destination }
    else { Start-Process -FilePath $target -WorkingDirectory $destination }
    Write-UpdateResult $true 'Atualizado e em execucao em segundo plano.'
    Write-Host "Instalado em $destination" -ForegroundColor Green
    Step 100 'Instalacao finalizada.'
} catch {
    Write-UpdateResult $false ($_.Exception.Message)
    Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('Diagnostico: ' + $log)
    exit 1
} finally {
    if ($publish -and (Test-Path -LiteralPath $publish)) { Remove-Item -LiteralPath $publish -Recurse -Force -ErrorAction SilentlyContinue }
    Stop-Transcript | Out-Null
}
