// Caminho: agentes/windows/Arcoll.WinUI3/Services/ProgramService.cs
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Arcoll.WinUI3.Services;

public sealed record InstalledApplication(string Name, string Version, string Publisher, string InstalledOn, string Id = "", string Uninstall = "", string QuietUninstall = "");
public sealed record CatalogApplication(string Name,string Id,string Category);

/// <summary>Um executor para ações locais confirmadas. Catálogo publicado pela própria plataforma.</summary>
public static class ProgramService
{
    public static IReadOnlyList<CatalogApplication> Catalog()
    {
        var path=Path.Combine(AppContext.BaseDirectory,"Assets","program-catalog.json");
        if(!File.Exists(path)) return Array.Empty<CatalogApplication>();
        if(new FileInfo(path).Length>262144) throw new InvalidDataException("Catálogo excede o limite.");
        var rows=JsonSerializer.Deserialize<List<CatalogApplication>>(File.ReadAllText(path),new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??new();
        if(rows.Count>500 || rows.Any(x=>string.IsNullOrWhiteSpace(x.Name)||string.IsNullOrWhiteSpace(x.Id)||!Regex.IsMatch(x.Id,@"^[A-Za-z0-9][A-Za-z0-9.+_-]{1,150}$"))) throw new InvalidDataException("Catálogo inválido.");
        return rows.DistinctBy(x=>x.Id,StringComparer.OrdinalIgnoreCase).ToArray();
    }
    public static List<Dictionary<string,object?>> InventoryPayload(IReadOnlyList<InstalledApplication> programs)=>programs.Take(1500).Select(p=>new Dictionary<string,object?>
    {
        ["id"]=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(p.Id))).ToLowerInvariant(),
        ["name"]=p.Name,["version"]=p.Version,["publisher"]=p.Publisher,["date"]=p.InstalledOn,["size"]=0,
        ["method"]=p.QuietUninstall.Length>0?"silent":p.Uninstall.Length>0?"interactive":""
    }).ToList();
    public static string Normalize(string value)=>Regex.Replace(value.ToLowerInvariant(),@"[^\p{L}\p{N}]","");
    public static InstalledApplication? Match(CatalogApplication app,IReadOnlyList<InstalledApplication> installed)
    {
        var name=Normalize(app.Name);
        // Nunca confunde runtimes diferentes ou edições com o mesmo prefixo.
        return installed.FirstOrDefault(x=>Normalize(x.Name)==name);
    }
    public static (string File,string Args) Split(string command)
    {
        command=Environment.ExpandEnvironmentVariables(command.Trim());
        if(command.Length==0)return("","");
        if(command[0]=='"')
        {
            var end=command.IndexOf('"',1);
            if(end<2)throw new InvalidOperationException("Desinstalador registrado com aspas inválidas.");
            return(command[1..end],command[(end+1)..].Trim());
        }
        var exe=command.IndexOf(".exe",StringComparison.OrdinalIgnoreCase);
        return exe>0?(command[..(exe+4)],command[(exe+4)..].Trim()):(command,"");
    }
    public static bool CanUninstall(InstalledApplication app)=>app.Uninstall.Length>0||app.QuietUninstall.Length>0;
    public static bool SuccessfulExit(int code)=>code is 0 or 1641 or 3010;
    public static async Task<int> UninstallAsync(InstalledApplication app,bool silent,CancellationToken ct)
    {
        var command=silent&&app.QuietUninstall.Length>0?app.QuietUninstall:app.Uninstall.Length>0?app.Uninstall:app.QuietUninstall;
        var(file,args)=Split(command);
        if(file.Length==0)throw new InvalidOperationException("Este programa não informa um desinstalador.");
        using var process=Process.Start(new ProcessStartInfo(file,args){UseShellExecute=true,Verb="runas"})??throw new InvalidOperationException("Não foi possível iniciar o desinstalador.");
        await process.WaitForExitAsync(ct);return process.ExitCode;
    }
    public static string[] PackageArguments(string id,bool installed,IReadOnlyList<CatalogApplication> catalog)
    {
        if(!catalog.Any(x=>x.Id.Equals(id,StringComparison.Ordinal))||!Regex.IsMatch(id,@"^[A-Za-z0-9][A-Za-z0-9.+_-]{1,150}$"))throw new InvalidOperationException("Programa fora do catálogo autorizado.");
        return new[]{installed?"upgrade":"install","--id",id,"--exact","--source","winget","--interactive"};
    }
    public static ProcessStartInfo PackageStart(string id,bool installed,IReadOnlyList<CatalogApplication> catalog)
    {
        var arguments=PackageArguments(id,installed,catalog);
        var winget=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Microsoft","WindowsApps","winget.exe");
        if(!File.Exists(winget))throw new InvalidOperationException("Instale ou atualize o Instalador de Aplicativo da Microsoft Store para disponibilizar o WinGet.");
        var info=new ProcessStartInfo(winget){UseShellExecute=true,Verb="runas"};
        foreach(var arg in arguments)info.ArgumentList.Add(arg);
        return info;
    }
    public static async Task<int> PackageAsync(string id,bool installed,IReadOnlyList<CatalogApplication> catalog,CancellationToken ct)
    {
        using var process=Process.Start(PackageStart(id,installed,catalog))??throw new InvalidOperationException("Não foi possível iniciar o WinGet.");
        // Não interromper um instalador em andamento nem encerrar aplicações do usuário.
        await process.WaitForExitAsync(ct);return process.ExitCode;
    }
}
