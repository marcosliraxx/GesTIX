// Caminho: agentes/windows/Arcoll.WinUI3/Services/AgentRuntime.cs
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Arcoll.WinUI3.Models;

namespace Arcoll.WinUI3.Services;

/// <summary>
/// Ciclo de vida do agente perante a plataforma: autorização (agent-poll/agent-register), fila de comandos
/// (agent-command-poll/ack), telemetria do servidor (agent-data) e presença. Substitui o laço do agente Python.
/// </summary>
public sealed class AgentRuntime : IDisposable
{
    /// <summary>Comandos que ainda dependem do núcleo Python (acesso remoto, arquivos, nuvem, atualização, energia...).</summary>
    private static readonly HashSet<string> Native = new() { "monitor_start", "monitor_pause", "scan_devices", "scan_map", "speed_test", "program_inventory",
        "power_shutdown", "power_restart", "power_cancel", "screen_lock", "terminal_diagnostic", "windows_update",
        "diagnostic", "agent_update", "toolkit", "toolkit_traceroute", "toolkit_services", "toolkit_health", "toolkit_troubleshooter",
        "storage_health", "service_health", "restart_readiness", "quick_health", "dns_test", "public_ip", "system_snapshot", "flush_dns", "wifi_info" };

    private readonly PlatformClient _platform = new(AgentConfig.Load());
    private readonly AuthorizationService _auth;
    private readonly SystemMetrics _metrics = new();
    private readonly CancellationTokenSource _cts = new();
    private readonly List<double> _latencies = new();
    private Task? _loop;
    private DateTime _lastAuth = DateTime.MinValue, _lastMetrics = DateTime.MinValue;
    private bool _busy;

    public AgentRuntime() { _auth = new AuthorizationService(_platform); }

    public PlatformClient Platform => _platform;
    public bool MonitorEnabled { get; private set; } = true;
    public AuthState State => _auth.State;
    public bool Gated => _auth.Gated;
    public bool Allowed => _auth.Allowed;
    public Task RecheckAsync() { _lastAuth = DateTime.MinValue; return Task.CompletedTask; }
    public string Detail => _auth.Detail;
    public string StateNotice => AuthorizationService.Notice(_auth.State, _auth.Detail);
    public string NetworkName => _auth.NetworkName;
    public string SystemName => _platform.Config.SystemName;
    /// <summary>Consentimento local (diálogo da interface) exigido quando o pedido não é do modo sem monitor com administrador.</summary>
    public Func<string, Task<bool>>? Consent { get; set; }
    public MetricSample? LastSample { get; private set; }
    public string LastActivity { get; private set; } = "";
    /// <summary>Disparado fora da thread de interface; a janela deve usar o dispatcher.</summary>
    public event Action? Changed;
    public event Action<string>? ProgramActivity;
    /// <summary>Pede à janela principal que encerre o processo (usado pela atualização, que reabre o agente em seguida).</summary>
    public Action? RequestExit { get; set; }
    private bool _updateChecked;

    public void Start() { if (_loop == null) _loop = Task.Run(() => RunAsync(_cts.Token)); }

    private async Task RunAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                if (DateTime.UtcNow - _lastAuth > TimeSpan.FromSeconds(State == AuthState.Approved || State == AuthState.UiLocked ? 30 : 10))
                {
                    var before = _auth.State; await _auth.RefreshAsync(ct); _lastAuth = DateTime.UtcNow;
                    if (before != _auth.State) RuntimeLog.Write("Autorização: " + before + " → " + _auth.State + (_auth.Detail.Length > 0 ? " (" + _auth.Detail + ")" : ""));
                    Changed?.Invoke();
                }
                if (_auth.Allowed)
                {
                    if (!_updateChecked) { await UpdateService.CompletePendingAsync(_platform, ct); _updateChecked = true; }
                    await PollCommandAsync(ct);
                    if (MonitorEnabled && DateTime.UtcNow - _lastMetrics > TimeSpan.FromSeconds(5)) await SendMetricsAsync(ct);
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
            catch (Exception ex)
            {
                // O laço nunca pode morrer: qualquer falha é registrada e tentada de novo no próximo ciclo.
                LastActivity = "Sem comunicação com a plataforma: " + (ex is TaskCanceledException ? "tempo esgotado" : ex.Message);
                RuntimeLog.Write("Ciclo falhou: " + ex.GetType().Name + ": " + ex.Message); Changed?.Invoke();
            }
            try { await Task.Delay(TimeSpan.FromSeconds(3), ct); } catch (OperationCanceledException) { break; }
        }
    }

    private async Task SendMetricsAsync(CancellationToken ct)
    {
        _lastMetrics = DateTime.UtcNow;
        var sample = _metrics.Sample(); LastSample = sample;
        var gateway = NetworkEngine.Local().Gateway;
        var latency = await NetworkEngine.PingAsync(string.IsNullOrWhiteSpace(gateway) ? "1.1.1.1" : gateway, 1200);
        _latencies.Add(latency is null ? 1 : 0); if (_latencies.Count > 20) _latencies.RemoveAt(0);
        await _platform.SendEventAsync(SystemMetrics.ToPlatformPayload(sample, latency, _latencies.Average() * 100), ct, 10);
        Changed?.Invoke();
    }

    private async Task PollCommandAsync(CancellationToken ct)
    {
        if (_busy) return;
        var body = _platform.Config.Credentials(); body["desktop_state"] = "unlocked";
        var response = await _platform.PostAsync("agent-command-poll", body, ct, 10);
        if (!response.TryGetProperty("command", out var cmd) || cmd.ValueKind != JsonValueKind.Object) return;
        _busy = true;
        try { await ExecuteAsync(cmd, ct); } finally { _busy = false; }
    }

    private async Task ExecuteAsync(JsonElement cmd, CancellationToken ct)
    {
        var id = cmd.TryGetProperty("id", out var i) && i.TryGetInt64(out var n) ? n : 0;
        var name = cmd.TryGetProperty("command_name", out var c) && c.ValueKind == JsonValueKind.String ? c.GetString() ?? "" : "";
        if (id < 1 || name.Length == 0) return;
        LastActivity = "Solicitação da plataforma: " + name.Replace('_', ' '); Changed?.Invoke();
        if (!Native.Contains(name))
        {
            await _platform.AckAsync(id, "failed", "Recurso ainda não disponível no agente nativo; mantenha o agente Python instalado para esta função.", ct);
            return;
        }
        try
        {
            switch (name)
            {
                case "monitor_start": MonitorEnabled = true; _lastMetrics = DateTime.MinValue; await _platform.AckAsync(id, "completed", "Monitoramento iniciado", ct); break;
                case "monitor_pause": MonitorEnabled = false; await _platform.AckAsync(id, "completed", "Monitoramento pausado", ct); break;
                case "scan_devices": case "scan_map": await ScanAsync(id, ct); break;
                case "speed_test": await SpeedAsync(id, ct); break;
                case "program_inventory": await InventoryAsync(id, cmd, ct); break;
                case "power_shutdown": case "power_restart": case "power_cancel": await PowerAsync(id, name, cmd, ct); break;
                case "screen_lock": case "windows_update": await MaintenanceAsync(id, name, cmd, ct); break;
                case "terminal_diagnostic": await TerminalAsync(id, cmd, ct); break;
                case "agent_update": await UpdateAsync(id, cmd, ct); break;
                case "diagnostic": await ConnectionAsync(id, ct); break;
                case string t when t.StartsWith("toolkit", StringComparison.Ordinal): await ToolkitAsync(id, t, ct); break;
                case string q when ToolkitService.QuickTitles.ContainsKey(q): await QuickAsync(id, q, ct); break;
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
        {
            try { await _platform.AckAsync(id, "failed", ex.Message, CancellationToken.None); } catch (Exception) { }
        }
    }

    private async Task ScanAsync(long id, CancellationToken ct)
    {
        var count = await ScanNowAsync(ct);
        await _platform.AckAsync(id, "completed", $"{count} dispositivos sincronizados", ct);
    }

    /// <summary>Varredura da sub-rede e sincronização do inventário na plataforma (comando remoto e botão da interface usam o mesmo caminho).</summary>
    public async Task<int> ScanNowAsync(CancellationToken ct)
    {
        var rows = await NetworkEngine.ScanAsync(null, true, ct);
        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var devices = rows.Take(180).Select(d => new Dictionary<string, object?>
        {
            ["name"] = d.Name, ["ip"] = d.Ip, ["mac"] = d.Mac, ["type"] = d.Kind, ["status"] = "online", ["group"] = "Rede local",
            ["first_seen"] = now, ["last_seen"] = now, ["last_change"] = now, ["source"] = "Agente Windows", ["latency_ms"] = d.LatencyMs,
            ["agent_installed"] = d.Ip == NetworkEngine.Local().Ip,
        }).ToList();
        await _platform.SendEventAsync(new Dictionary<string, object?> { ["event"] = "network_scan", ["device_count"] = devices.Count, ["devices"] = devices, ["groups"] = new List<object>() }, ct, 20);
        return devices.Count;
    }

    private async Task SpeedAsync(long id, CancellationToken ct)
    {
        var last = DateTime.MinValue;
        var progress = new Progress<(double Percent, string Message, double? Download)>(p =>
        {
            if (DateTime.UtcNow - last < TimeSpan.FromSeconds(1) && p.Percent < 100) return; last = DateTime.UtcNow;
            _ = _platform.SendEventAsync(new Dictionary<string, object?> { ["event"] = "speed_progress", ["command_id"] = id, ["percent"] = Math.Round(p.Percent, 1), ["message"] = p.Message, ["download_mbps"] = p.Download }, CancellationToken.None, 8);
        });
        var r = await SpeedTestService.RunAsync(progress, ct);
        await _platform.SendEventAsync(new Dictionary<string, object?> { ["event"] = "speed_test", ["command_id"] = id, ["download_mbps"] = r.Download, ["upload_mbps"] = r.Upload, ["latency_ms"] = r.LatencyMs, ["server"] = r.Server }, ct, 16);
        await _platform.AckAsync(id, "completed", $"Download {r.Download} Mbps · Upload {r.Upload} Mbps", ct);
    }

    /// <summary>Teste de velocidade iniciado na própria interface: mede e publica o resultado na plataforma (evento speed_test).</summary>
    public async Task<SpeedResult> SpeedNowAsync(IProgress<(double Percent, string Message, double? Download)> progress, CancellationToken ct)
    {
        var r = await SpeedTestService.RunAsync(progress, ct);
        await _platform.SendEventAsync(new Dictionary<string, object?> { ["event"] = "speed_test", ["command_id"] = 0, ["download_mbps"] = r.Download, ["upload_mbps"] = r.Upload, ["latency_ms"] = r.LatencyMs, ["server"] = r.Server }, ct, 16);
        return r;
    }

    private async Task InventoryAsync(long id, JsonElement cmd, CancellationToken ct)
    {
        // Mesma regra do agente Python: exige modo sem monitor com administrador e revalida a autorização no servidor.
        var unattended = cmd.TryGetProperty("headless_mode", out var h) && (h.ValueKind == JsonValueKind.True || (h.ValueKind == JsonValueKind.Number && h.GetInt32() == 1) || (h.ValueKind == JsonValueKind.String && h.GetString() == "1"))
            && cmd.TryGetProperty("requester_role", out var role) && role.ValueKind == JsonValueKind.String && role.GetString() is "owner" or "administrator";
        if (!unattended) throw new InvalidOperationException("Modo sem monitor e administrador necessários.");
        var verified = await _platform.PostAsync("agent-command-authorize", _platform.WithCredentials(("command_id", id)), ct, 12);
        if (!verified.TryGetProperty("command", out var vc) || vc.GetString() != "program_inventory") throw new InvalidOperationException("Autorização revogada.");
        ProgramActivity?.Invoke("Solicitação remota: lendo programas instalados…");
        var programs = await Task.Run(() => ProgramService.InventoryPayload(WindowsInventory.Programs()),ct);
        await _platform.PostAsync("agent-program-inventory", _platform.WithCredentials(("command_id", id), ("programs", programs)), ct, 40);
        await _platform.AckAsync(id, "completed", $"{programs.Count} programas inventariados", ct);
        ProgramActivity?.Invoke($"Solicitação remota concluída: {programs.Count} programas enviados à plataforma.");
    }

    private static string Str(JsonElement cmd, string key) => cmd.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";
    private static bool Headless(JsonElement cmd) => cmd.TryGetProperty("headless_mode", out var h) && (h.ValueKind == JsonValueKind.True || (h.ValueKind == JsonValueKind.Number && h.GetInt32() == 1) || (h.ValueKind == JsonValueKind.String && h.GetString() == "1"));
    private static bool Unattended(JsonElement cmd) => Headless(cmd) && Str(cmd, "requester_role") is "owner" or "administrator";

    private async Task<bool> AskAsync(string message)
    {
        var ask = Consent;
        return ask is not null && await ask(message);
    }

    private async Task PowerAsync(long id, string name, JsonElement cmd, CancellationToken ct)
    {
        var unattended = Unattended(cmd);
        if (name != "power_cancel" && !unattended
            && !await AskAsync("O gestor solicitou " + (name == "power_shutdown" ? "desligar" : "reiniciar") + " este computador. Salve seu trabalho. Deseja autorizar? A operação será agendada conforme o prazo selecionado."))
        { await _platform.AckAsync(id, "failed", "Operação não autorizada no computador.", ct); return; }
        var auth = await _platform.PostAsync("agent-power-authorize", _platform.WithCredentials(("command_id", id)), ct, 8);
        if (!auth.TryGetProperty("command", out var ac) || ac.GetString() != name) throw new InvalidOperationException("Autorização expirada. Solicite novamente.");
        if (Headless(cmd) && unattended && !(auth.TryGetProperty("headless", out var hl) && hl.ValueKind == JsonValueKind.True)) throw new InvalidOperationException("O modo de servidor sem monitor foi desativado. Solicite novamente.");
        var message = await Task.Run(() => MaintenanceService.SchedulePower(name, MaintenanceService.DelaySeconds(Str(cmd, "request_text"))), ct);
        await _platform.AckAsync(id, "completed", message, ct);
    }

    private async Task MaintenanceAsync(long id, string name, JsonElement cmd, CancellationToken ct)
    {
        var request = Str(cmd, "request_text"); var unattended = Unattended(cmd); var mode = MaintenanceService.Mode(request);
        if (name == "windows_update" && mode is not ("advanced" or "insider"))
            throw new NotSupportedException("Windows Update (" + mode + ") ainda não está disponível no agente nativo.");
        var what = name == "screen_lock" ? "bloquear esta sessão" : "abrir as configurações do Windows Update";
        if (!unattended && !await AskAsync("O gestor solicitou " + what + ". Autorizar?")) { await _platform.AckAsync(id, "failed", "Usuário não autorizou a operação.", ct); return; }
        if (name == "screen_lock")
        {
            await Task.Delay(TimeSpan.FromSeconds(MaintenanceService.DelaySeconds(request)), ct);
            if (unattended)
            {
                var again = await _platform.PostAsync("agent-command-authorize", _platform.WithCredentials(("command_id", id)), ct, 10);
                if (!again.TryGetProperty("command", out var c) || c.GetString() != name) throw new InvalidOperationException("Autorização revogada durante a espera.");
            }
            await _platform.AckAsync(id, "completed", MaintenanceService.LockSession(), ct);
        }
        else await _platform.AckAsync(id, "completed", MaintenanceService.OpenSettings(mode), ct);
    }

    private async Task QuickAsync(long id, string name, CancellationToken ct)
    {
        var res = await ToolkitService.QuickAsync(name, ct);
        var ok = (string?)res["status"] == "completed";
        await _platform.SendEventAsync(new Dictionary<string, object?>
        {
            ["event"] = "quick_command", ["command_name"] = name, ["command_id"] = id, ["title"] = res["title"], ["status"] = res["status"],
            ["summary"] = res["summary"], ["details"] = res["details"], ["origin"] = "platform",
        }, ct, 16);
        await _platform.AckAsync(id, ok ? "completed" : "failed", (string?)res["summary"] ?? "", ct);
    }

    private async Task ToolkitAsync(long id, string name, CancellationToken ct)
    {
        var report = await ToolkitService.CollectToolkitAsync(name == "toolkit" ? null : name["toolkit_".Length..], ct);
        await _platform.SendEventAsync(new Dictionary<string, object?> { ["event"] = "toolkit", ["report"] = report }, ct, 16);
        await _platform.AckAsync(id, "completed", "Medições sincronizadas com sucesso", ct);
    }

    private async Task UpdateAsync(long id, JsonElement cmd, CancellationToken ct)
    {
        var force = Str(cmd, "request_text").Contains("\"force\"", StringComparison.Ordinal);
        var outcome = await UpdateService.StageAndLaunchAsync(_platform, id, force, (percent, message) => { LastActivity = $"Atualização {percent}% · {message}"; Changed?.Invoke(); }, ct);
        if (!outcome.Launched) { await _platform.AckAsync(id, "completed", outcome.Message, ct); return; }
        // O comando só é confirmado quando o agente atualizado reabrir (CompletePendingAsync).
        await Task.Delay(1500, ct);
        RequestExit?.Invoke();
    }

    private async Task ConnectionAsync(long id, CancellationToken ct)
    {
        var details = await ToolkitService.ConnectionAsync(ct);
        await _platform.SendEventAsync(details, ct, 20);
        await _platform.AckAsync(id, "completed", "Diagnóstico da conexão sincronizado", ct);
    }

    private async Task TerminalAsync(long id, JsonElement cmd, CancellationToken ct)
    {
        string[] argv;
        try { argv = DiagnosticCommands.Argv(Str(cmd, "request_text")); }
        catch (ArgumentException ex) { await _platform.AckAsync(id, "failed", ex.Message, ct); return; }
        long offset = 0; string lastError = ""; var errors = 0; var aborted = false;
        async Task<bool> Send(string chunk)
        {
            var size = Encoding.UTF8.GetByteCount(chunk);
            for (var attempt = 0; attempt < 3; attempt++)
            {
                try
                {
                    var r = await _platform.PostAsync("agent-command-output", _platform.WithCredentials(("command_id", id), ("offset", offset), ("chunk", chunk)), ct, 6);
                    var next = r.TryGetProperty("next_offset", out var n) && n.TryGetInt64(out var v) ? v : -1;
                    if (r.TryGetProperty("status", out var st) && st.ValueKind == JsonValueKind.String && st.GetString() is "failed" or "expired" or "completed") { aborted = true; return false; }
                    if (next == offset + size) { offset = next; errors = 0; lastError = ""; return true; }
                    lastError = "Resposta de sequência inesperada (offset servidor: " + next + ")";
                    if (next >= 0 && next != offset) break;
                }
                catch (Exception ex) when (ex is not OperationCanceledException) { lastError = ex.Message; }
                if (attempt < 2) await Task.Delay(250 * (attempt + 1), ct);
            }
            errors++; return errors < 8;
        }
        var (code, truncated, timedOut) = await DiagnosticCommands.RunAsync(argv, Send, ct);
        if (aborted) return;
        var ok = code == 0 && !truncated && !timedOut && errors == 0 && offset > 0;
        var summary = offset == 0 || errors > 0 ? "Falha na sincronização da saída do CMD: " + (lastError.Length > 0 ? lastError : "nenhum resultado transferido") : (ok ? "Concluído" : "Falha") + $" (código {code})";
        await _platform.AckAsync(id, ok ? "completed" : "failed", summary, ct);
    }

    public void Dispose() { _cts.Cancel(); _platform.Dispose(); _cts.Dispose(); }
}
