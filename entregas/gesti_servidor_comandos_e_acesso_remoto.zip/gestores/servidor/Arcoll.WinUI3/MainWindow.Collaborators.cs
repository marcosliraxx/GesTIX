// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Collaborators.cs
using System.Text.Json;
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3;
public sealed partial class MainWindow
{
    private sealed record CollaboratorChoice(long Id,string Name,bool Allowed=true){public override string ToString()=>Name;}
    private long _selectedCollaborator;
    private long _collaboratorNetwork;
    private bool _collaboratorRefreshing,_changingCollaborator,_collaboratorClosed;
    private string _localInterfaceSignature="";
    private bool _localConsentOpen;
    private readonly DispatcherTimer _collaboratorClock=new(){Interval=TimeSpan.FromSeconds(15)};
    private CollaboratorWorkspacePage? _collaboratorPage;
    private readonly TextBlock _noLocalTools=new(){Text="Nenhuma ferramenta local foi liberada. Entre em contato com o administrador da rede.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};
    private bool MenuVisibleHere(string key)=>_runtime.IsServer||_runtime.VisibleLocalMenus.Contains(key);
    private bool CanOpenHere(string key)=>_runtime.IsServer&&_selectedCollaborator>0?_runtime.Can("coordinate"):_runtime.CanOpenLocalMenu(key);
    private bool LocalSystemActions=>_runtime.LocalSystemControls&&_selectedCollaborator==0;
    private void InitializeCollaborators()
    {
        CollaboratorSelector.Items.Add(new ComboBoxItem{Content="Este computador — Gestor Servidor",Tag=new CollaboratorChoice(0,"Este computador — Gestor Servidor")});CollaboratorSelector.SelectedIndex=0;
        CollaboratorSelector.SelectionChanged+=(_,_)=>{if(_changingCollaborator||CollaboratorSelector.SelectedItem is not ComboBoxItem {Tag:CollaboratorChoice item}||!_runtime.IsServer)return;_selectedCollaborator=item.Id;_emptyGroupShown=null;UpdateCategoryVisibility();if(item.Id==0)_collaboratorPage?.Unavailable("Controle deste computador selecionado.");CompactHost.Content=null;SelectSection(_section);};
        _collaboratorClock.Tick+=async(_,_)=>await RefreshCollaboratorsAsync();_collaboratorClock.Start();
        Closed+=(_,_)=>{_collaboratorClosed=true;_collaboratorClock.Stop();_collaboratorPage?.Disable();};ApplyLocalInterface();
    }
    private async Task RefreshCollaboratorsAsync()
    {
        if(_collaboratorClosed||_collaboratorRefreshing||!_runtime.IsServer||!_runtime.Can("coordinate"))return;_collaboratorRefreshing=true;
        try{
            using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(15));
            var data=await _runtime.Platform.PostAsync("gestor-workspace",_runtime.Platform.WithCredentials(("op","collaborators")),timeout.Token,12);
            if(_collaboratorClosed||!_runtime.IsServer)return;_collaboratorNetwork=data.GetProperty("network_id").GetInt64();
            if(data.TryGetProperty("poll_seconds",out var interval))_collaboratorClock.Interval=TimeSpan.FromSeconds(Math.Clamp(interval.GetInt32(),3,120));
            var choices=new List<CollaboratorChoice>{new(0,"Este computador — Gestor Servidor")};
            foreach(var item in data.GetProperty("devices").EnumerateArray()){
                var id=item.GetProperty("id").GetInt64();var approved=item.GetProperty("status").GetString()=="approved";
                choices.Add(new(id,(item.GetProperty("machine_name").GetString()??"Computador")+" · "+(approved?(item.GetProperty("online").GetBoolean()?"Online":"Offline"):"Não autorizado"),approved));
            }
            var selected=choices.FirstOrDefault(c=>c.Id==_selectedCollaborator);
            if(selected is null&&_selectedCollaborator>0){selected=new(_selectedCollaborator,"Colaborador indisponível — "+_selectedCollaborator,false);choices.Add(selected);}
            _changingCollaborator=true;try{CollaboratorSelector.Items.Clear();foreach(var item in choices)CollaboratorSelector.Items.Add(new ComboBoxItem{Content=item.Name,Tag=item,IsEnabled=item.Allowed});CollaboratorSelector.SelectedIndex=choices.FindIndex(c=>c.Id==_selectedCollaborator);}finally{_changingCollaborator=false;}
            CollaboratorSelector.IsEnabled=true;
            if(selected is {Allowed:false})_collaboratorPage?.Unavailable("O Colaborador selecionado não está autorizado. Escolha outro computador; o alvo não foi alterado automaticamente.");
        }catch(Exception error){RuntimeLog.Write("Lista de colaboradores: "+error.Message);ToolTipService.SetToolTip(CollaboratorSelector,"Não foi possível atualizar a lista: "+error.Message);}
        finally{_collaboratorRefreshing=false;}
    }
    private void ApplyLocalInterface()
    {
        if(_collaboratorClosed)return;
        var signature=_runtime.InstallationRole+":"+string.Join(",",_runtime.VisibleLocalMenus.OrderBy(key=>key))+":"+_runtime.AlwaysBackground;
        var hasTools=_runtime.IsServer||_runtime.HasLocalTools;
        QuickBar.Visibility=hasTools?Visibility.Visible:Visibility.Collapsed;RibbonBar.Visibility=hasTools?Visibility.Visible:Visibility.Collapsed;
        BellButton.Visibility=_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;
        ServerRemoteButton.Visibility=_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;ServerRemoteButton.IsEnabled=_runtime.Can("coordinate")&&_runtime.Can("support");
        CollaboratorSelector.Visibility=_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;CollaboratorSelector.IsEnabled=_runtime.Can("coordinate");
        StatusBorder.Visibility=_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;
        _tray.SetLocalControls(_runtime.IsServer,!_runtime.AlwaysBackground);
        _tray.SetToolCatalog(Groups.SelectMany(g=>g.Items.Where(i=>MenuVisibleHere(i.Key)).Select(i=>(g.Label,i.Label,i.Key))));
        if(!_runtime.IsServer){_selectedCollaborator=0;if(_localInterfaceSignature!=signature)_collaboratorPage?.Disable();}
        if(_runtime.AlwaysBackground&&!_localConsentOpen)AppWindow.Hide();
        if(signature==_localInterfaceSignature)return;_localInterfaceSignature=signature;
        _penteFinoPage.CancelOperations();foreach(var page in _tools.Values)page.CancelOperations();_programsPage.CancelOperations();
        UpdateCategoryVisibility();
        if(!_runtime.IsServer&&!_runtime.HasLocalTools){ShowCollaboratorHome();return;}
        var allowed=Groups.SelectMany(g=>g.Items).FirstOrDefault(i=>MenuVisibleHere(i.Key)&&_runtime.CanOpenLocalMenu(i.Key));
        if(!MenuVisibleHere(_section)){if(allowed is not null)SelectSection(allowed.Key);else ShowCollaboratorHome();}
        else if(_menus.Count>0){BuildRibbon(ResolveGroup(_section));ApplyTheme(_themes.Current);}
        if(_runtime.IsServer)_=RefreshCollaboratorsAsync();
    }
    private void ShowCollaboratorHome()
    {
        _section="remote";PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;HeroFrame.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
        var showCode=!_runtime.LocalAllowed||_runtime.VisibleLocalMenus.Contains("remote");var target=showCode?(object)_remoteAccessPage:_noLocalTools;
        if(!ReferenceEquals(CompactHost.Content,target))CompactHost.Content=target;
    }
    private bool TryShowCollaborator(string section)
    {
        if(!_runtime.IsServer||_selectedCollaborator<=0)return false;
        if(!_runtime.Can("coordinate")){_collaboratorPage?.Unavailable("Coordenação não autorizada para este Servidor.");return true;}
        var item=Groups.SelectMany(g=>g.Items).FirstOrDefault(i=>i.Key==section)??Groups[0].Items[0];_section=item.Key;_group=ResolveGroup(item.Key).Key;_lastSection[_group]=item.Key;
        if(CollaboratorSelector.SelectedItem is ComboBoxItem selected&&selected.Tag is CollaboratorChoice {Allowed:false})return true;
        _collaboratorPage??=new CollaboratorWorkspacePage(_runtime);
        PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;CompactHost.Content=_collaboratorPage;
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;HeroFrame.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
        BuildRibbon(ResolveGroup(item.Key));ApplyTheme(_themes.Current);
        _=_collaboratorPage.NavigateAsync(_collaboratorNetwork,_selectedCollaborator,item.File,item.Query);return true;
    }
    private async void ServerRemote_Click(object sender,RoutedEventArgs e)
    {
        if(!_runtime.IsServer||!_runtime.Can("coordinate")||!_runtime.Can("support"))return;
        ServerRemoteButton.IsEnabled=false;
        try{
            if(_collaboratorNetwork<=0)await RefreshCollaboratorsAsync();
            if(_collaboratorNetwork<=0)throw new InvalidOperationException("Aguarde a conexão com a rede para acessar um Colaborador.");
            _collaboratorPage??=new CollaboratorWorkspacePage(_runtime);
            PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;CompactHost.Content=_collaboratorPage;
            UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;HeroFrame.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
            _section="remote";_group=ResolveGroup(_section).Key;_lastSection[_group]=_section;BuildRibbon(ResolveGroup(_section));ApplyTheme(_themes.Current);
            await _collaboratorPage.NavigateAsync(_collaboratorNetwork,_selectedCollaborator,"remoto","connect_code=1");
        }catch(Exception error){StatusBar.Title="Acesso remoto";StatusBar.Message=error.Message;StatusBar.Severity=InfoBarSeverity.Warning;StatusBar.IsOpen=true;}
        finally{ServerRemoteButton.IsEnabled=_runtime.IsServer&&_runtime.Can("coordinate")&&_runtime.Can("support");}
    }

}
