// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/CollaboratorWorkspacePage.cs
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
namespace Arcoll.WinUI3.Pages;

/// <summary>Reutiliza as ferramentas da plataforma para o alvo selecionado. A sessão web mantém autorização e consentimento por operação.</summary>
public sealed class CollaboratorWorkspacePage : UserControl
{
    private readonly GestorRuntime _runtime;
    private readonly WebView2 _web=new(){HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Stretch};
    private readonly TextBlock _status=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(18)};
    private readonly SemaphoreSlim _gate=new(1,1);
    private Uri? _root;
    private long _network,_target;
    private string _file="painel",_query="";
    private int _generation;
    private string _scriptId="";
    public CollaboratorWorkspacePage(GestorRuntime runtime){_runtime=runtime;Content=_web;}
    public async Task NavigateAsync(long network,long target,string file,string query)
    {
        var generation=++_generation;_network=network;_target=target;_file=file;_query=query;
        if(!_runtime.IsServer||!_runtime.Can("coordinate")||network<=0||target<0||(target==0&&(file!="remoto"||query!="connect_code=1"))){Disable();return;}
        await _gate.WaitAsync();
        try{
            if(generation!=_generation)return;
            if(!System.Text.RegularExpressions.Regex.IsMatch(file,"^[a-z][a-z0-9_-]*$"))throw new InvalidDataException("Ferramenta inválida.");
            _root=new Uri(_runtime.Platform.Config.Origin.TrimEnd('/')+"/");
            if(_web.CoreWebView2 is null){
                var profile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","ServerWorkspace");
                var env=await CoreWebView2Environment.CreateWithOptionsAsync(null,profile,null);await _web.EnsureCoreWebView2Async(env);
                var core=_web.CoreWebView2;core.Settings.AreDevToolsEnabled=false;core.Settings.AreDefaultContextMenusEnabled=false;core.Settings.AreHostObjectsAllowed=false;
                core.NavigationStarting+=(_,e)=>{if(!Allowed(e.Uri)){e.Cancel=true;_status.Text="Navegação bloqueada: use o seletor do Gestor Servidor para alterar o computador.";}};
                core.NewWindowRequested+=(_,e)=>{e.Handled=true;if(Allowed(e.Uri))core.Navigate(e.Uri);};
            }
            if(generation!=_generation)return;
            Content=_web;var browser=_web.CoreWebView2;
            if(_scriptId!="")browser.RemoveScriptToExecuteOnDocumentCreated(_scriptId);
            var script="""
                (()=>{const target=__TARGET__;function pin(){const select=document.getElementById('arc-gestor-target');if(select){select.value=String(target);select.disabled=true;}if(!document.getElementById('ti-delegated-layout')){const css=document.createElement('style');css.id='ti-delegated-layout';css.textContent='.app-header,.app-sidebar,.arc-gestor-ribbon{display:none!important}.app-body{height:100dvh!important}.app-main{margin:0!important;padding:0!important}.arc-redes-shell{max-width:none!important}';(document.head||document.documentElement).append(css);}}document.addEventListener('DOMContentLoaded',pin);addEventListener('pageshow',pin);})();
                """.Replace("__TARGET__",target.ToString(System.Globalization.CultureInfo.InvariantCulture));
            _scriptId=await browser.AddScriptToExecuteOnDocumentCreatedAsync(script);
            if(generation!=_generation)return;
            var url=new Uri(_root,"redes/"+file+".php?network="+network+"&gestor="+target+"&delegated=1"+(query.Length>0?"&"+query:""));browser.Navigate(url.AbsoluteUri);
        }catch(Exception error){if(generation==_generation){_status.Text="Não foi possível abrir o computador selecionado: "+error.Message;Content=_status;}RuntimeLog.Write("Servidor/colaborador: "+error.Message);}
        finally{_gate.Release();}
    }
    private bool Allowed(string value)
    {
        if(value=="about:blank")return true;
        if(!_runtime.IsServer||!_runtime.Can("coordinate")||_root is null||!Uri.TryCreate(value,UriKind.Absolute,out var uri)||uri.Scheme!="https"||uri.GetLeftPart(UriPartial.Authority)!=_root.GetLeftPart(UriPartial.Authority))return false;
        foreach(var part in uri.Query.TrimStart('?').Split('&',StringSplitOptions.RemoveEmptyEntries)){
            var pair=part.Split('=',2);if(pair.Length!=2)continue;var key=Uri.UnescapeDataString(pair[0]);var item=Uri.UnescapeDataString(pair[1]);
            if(key=="network"&&item!=_network.ToString()||key=="gestor"&&item!=_target.ToString())return false;
        }
        return true;
    }
    public void Unavailable(string message){++_generation;_web.CoreWebView2?.Stop();_status.Text=message;Content=_status;}
    public void Disable(){++_generation;if(_web.CoreWebView2 is { } core){core.Stop();core.CookieManager.DeleteAllCookies();core.Navigate("about:blank");}_status.Text="Selecione um Colaborador autorizado no Gestor Servidor.";Content=_status;}
}
