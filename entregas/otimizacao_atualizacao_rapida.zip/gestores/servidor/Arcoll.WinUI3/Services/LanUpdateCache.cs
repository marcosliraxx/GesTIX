// Caminho: gestores/servidor/Arcoll.WinUI3/Services/LanUpdateCache.cs
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text;
using Arcoll.WinUI3.Models;
namespace Arcoll.WinUI3.Services;

/// <summary>Distribuição LAN de uma release INTEGRAL previamente validada e assinada pela plataforma.
/// O servidor mantém somente a última publicação; cada receptor verifica SHA-256 e assinatura
/// no atualizador original antes de executar qualquer arquivo recebido.</summary>
public static class LanUpdateCache
{
    private sealed record Manifest(string Version,string Arch,string Hash,string Key,string Signature,long Size);
    private static string Root => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","LanUpdates");
    private static string Package => Path.Combine(Root,"release.zip");
    private static string Metadata => Path.Combine(Root,"release.json");
    private static readonly object Gate=new();
    private const int ChunkSize=512*1024;
    private static string Header(HttpResponseMessage response,string key)=>response.Headers.TryGetValues(key,out var v)?v.FirstOrDefault()??"":"";

    public static void Store(string zip,HttpResponseMessage response,string version,string arch,string hash)
    {
        try
        {
            var size=new FileInfo(zip).Length;
            if(size is < 100 or > 750L*1024*1024)return;
            var manifest=new Manifest(version,arch,hash,Header(response,"X-Package-Public-Key"),Header(response,"X-Package-Signature"),size);
            if(manifest.Key.Length<100||manifest.Signature.Length<100)return;
            Directory.CreateDirectory(Root);
            lock(Gate)
            {
                var temporary=Package+".tmp";
                File.Copy(zip,temporary,true);
                File.Move(temporary,Package,true);
                File.WriteAllText(Metadata+".tmp",JsonSerializer.Serialize(manifest));
                File.Move(Metadata+".tmp",Metadata,true);
            }
            RuntimeLog.Write("Pacote LAN assinado disponível: "+version+" ("+(size/1048576)+" MiB).");
        }
        catch(Exception error) when(error is IOException or UnauthorizedAccessException){RuntimeLog.Write("Cache LAN: "+error.Message);}
    }

    private static Manifest? ReadManifest()
    {
        try
        {
            if(!File.Exists(Metadata)||!File.Exists(Package))return null;
            var manifest=JsonSerializer.Deserialize<Manifest>(File.ReadAllText(Metadata));
            if(manifest is null||manifest.Size is <100 or >750L*1024*1024||new FileInfo(Package).Length!=manifest.Size)return null;
            if(manifest.Hash.Length!=64||manifest.Hash.Any(c=>!Uri.IsHexDigit(c)))return null;
            return manifest;
        }
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or JsonException){return null;}
    }
    public static object Availability()
    {
        lock(Gate)
        {
            var m=ReadManifest();
            return m is null?new {ok=false,error="Pacote LAN indisponível."}:(object)new {ok=true,version=m.Version,arch=m.Arch,hash=m.Hash,key=m.Key,signature=m.Signature,size=m.Size,stream=true};
        }
    }
    public static object ReadChunk(long offset,int count)
    {
        lock(Gate)
        {
            var m=ReadManifest();
            if(m is null)return new {ok=false,error="Pacote LAN indisponível."};
            if(offset<0||offset>=m.Size||count<1||count>ChunkSize)return new {ok=false,error="Posição de pacote inválida."};
            var size=(int)Math.Min(count,m.Size-offset);
            using var input=new FileStream(Package,FileMode.Open,FileAccess.Read,FileShare.Read);
            input.Seek(offset,SeekOrigin.Begin);
            var bytes=new byte[size];input.ReadExactly(bytes);
            return new {ok=true,offset,bytes=Convert.ToBase64String(bytes)};
        }
    }

    private static readonly SemaphoreSlim Transfers=new(4,4);
    private static readonly object HintGate=new();
    private static (IPEndPoint Endpoint,string Secret,DateTime Seen)? _hint;
    private const int StreamChunkSize=1024*1024;
    private sealed record Remote(Manifest Manifest,IPEndPoint Server,bool Streaming);
    public static void RememberServer(IPAddress address,int port)
    {
        var settings=LanSettings.Load();if(!settings.Ready||port is <1024 or >65535)return;
        lock(HintGate)_hint=(new IPEndPoint(address,port),settings.Secret,DateTime.UtcNow);
    }
    public static string? CurrentVersion()
    {
        lock(Gate){var m=ReadManifest();return m is not null&&AppInfo.SameRelease(m.Version,AppInfo.Version)?m.Version:null;}
    }
    private static IEnumerable<IPAddress> Broadcasts()
    {
        yield return IPAddress.Broadcast;
        foreach(var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if(nic.OperationalStatus!=System.Net.NetworkInformation.OperationalStatus.Up)continue;
            foreach(var uni in nic.GetIPProperties().UnicastAddresses)
            {
                if(uni.Address.AddressFamily!=AddressFamily.InterNetwork||uni.IPv4Mask is null)continue;
                var ip=uni.Address.GetAddressBytes();var mask=uni.IPv4Mask.GetAddressBytes();
                yield return new IPAddress(ip.Select((b,i)=>(byte)(b|~mask[i])).ToArray());
            }
        }
    }
    private static async Task<IPEndPoint?> LocateAsync(LanSettings settings,CancellationToken ct)
    {
        lock(HintGate)if(_hint is {} hint&&hint.Secret==settings.Secret&&DateTime.UtcNow-hint.Seen<TimeSpan.FromMinutes(2))return hint.Endpoint;
        using var udp=new UdpClient(new IPEndPoint(IPAddress.Any,0)){EnableBroadcast=true};
        foreach(var address in Broadcasts().Distinct())
        {
            var discovery=LanCrypto.Seal(settings,"discover",new{machine=Environment.MachineName});
            try{await udp.SendAsync(discovery,discovery.Length,new IPEndPoint(address,settings.Port));}catch(SocketException){}
        }
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromMilliseconds(1500));
        while(!timeout.IsCancellationRequested)
        {
            try{
                var packet=await udp.ReceiveAsync(timeout.Token);var reply=LanCrypto.Open(settings,packet.Buffer);
                if(reply is not {Kind:"announce"}||!reply.Body.TryGetProperty("server",out var server)||server.ValueKind!=JsonValueKind.True)continue;
                if(!reply.Body.TryGetProperty("machine",out var machine)||string.Equals(machine.GetString(),Environment.MachineName,StringComparison.OrdinalIgnoreCase))continue;
                var port=reply.Body.GetProperty("port").GetInt32();if(port is <1024 or >65535)continue;
                RememberServer(packet.RemoteEndPoint.Address,port);return new IPEndPoint(packet.RemoteEndPoint.Address,port);
            }catch(OperationCanceledException)when(!ct.IsCancellationRequested){break;}
        }
        return null;
    }
    private static async Task<JsonElement> CallAsync(LanSettings settings,IPEndPoint server,string kind,object body,CancellationToken ct)
    {
        using var tcp=new TcpClient{NoDelay=true};
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromSeconds(8));
        await tcp.ConnectAsync(server.Address,server.Port,timeout.Token);var stream=tcp.GetStream();
        await LanFrames.WriteAsync(stream,LanCrypto.Seal(settings,kind,body),timeout.Token);
        var reply=LanCrypto.Open(settings,await LanFrames.ReadAsync(stream,timeout.Token));
        if(reply is null||reply.Kind!="result"||!reply.Body.TryGetProperty("ok",out var ok)||ok.ValueKind!=JsonValueKind.True)throw new InvalidDataException("Servidor LAN ainda não disponibilizou a release.");
        return reply.Body;
    }
    private static async Task<Remote?> ProbeAsync(string architecture,LanSettings settings,CancellationToken ct)
    {
        var server=await LocateAsync(settings,ct);if(server is null)return null;
        var info=await CallAsync(settings,server,"update_manifest",new{},ct);
        var manifest=new Manifest(info.GetProperty("version").GetString()??"",info.GetProperty("arch").GetString()??"",info.GetProperty("hash").GetString()??"",info.GetProperty("key").GetString()??"",info.GetProperty("signature").GetString()??"",info.GetProperty("size").GetInt64());
        if(manifest.Arch!=architecture||manifest.Size is <100 or >750L*1024*1024||manifest.Hash.Length!=64||manifest.Hash.Any(c=>!Uri.IsHexDigit(c)))return null;
        return new(manifest,server,info.TryGetProperty("stream",out var v)&&v.ValueKind==JsonValueKind.True);
    }
    private static bool ExpectedFailure(Exception error)=>error is IOException or InvalidDataException or SocketException or JsonException or FormatException or OperationCanceledException or InvalidOperationException or UnauthorizedAccessException or KeyNotFoundException or CryptographicException;
    public static async Task<UpdateAvailability> CheckAsync(string architecture,CancellationToken ct)
    {
        var settings=LanSettings.Load();
        if(settings.Ready)try{
            var remote=await ProbeAsync(architecture,settings,ct);
            if(remote is not null&&AppInfo.TryCompareRelease(remote.Manifest.Version,AppInfo.Version,out var comparison))
                return new(remote.Manifest.Version,comparison>0,"lan",DateTimeOffset.UtcNow.ToUnixTimeSeconds(),comparison>0?-1:0);
        }catch(OperationCanceledException)when(ct.IsCancellationRequested){throw;}
        catch(Exception error)when(ExpectedFailure(error)){lock(HintGate)_hint=null;RuntimeLog.Write("Verificação LAN: "+error.Message);}
        return new(AppInfo.Version,false,"lan",DateTimeOffset.UtcNow.ToUnixTimeSeconds(),0);
    }
    // O canal binário mantém AES-GCM e vincula cada bloco ao hash do pacote e à sua posição.
    internal static byte[] EncodeBlock(LanSettings settings,string hash,long offset,ReadOnlySpan<byte> bytes)
    {
        var frame=new byte[28+bytes.Length];RandomNumberGenerator.Fill(frame.AsSpan(0,12));
        using var aes=new AesGcm(SHA256.HashData(Encoding.UTF8.GetBytes("arcoll-update-stream-v1|"+settings.Secret)),16);
        aes.Encrypt(frame.AsSpan(0,12),bytes,frame.AsSpan(28),frame.AsSpan(12,16),Encoding.ASCII.GetBytes(hash+"|"+offset.ToString(System.Globalization.CultureInfo.InvariantCulture)));
        return frame;
    }
    internal static byte[] DecodeBlock(LanSettings settings,string hash,long offset,byte[] frame)
    {
        if(frame.Length<29||frame.Length>StreamChunkSize+28)throw new InvalidDataException("Bloco LAN inválido.");
        var bytes=new byte[frame.Length-28];
        using var aes=new AesGcm(SHA256.HashData(Encoding.UTF8.GetBytes("arcoll-update-stream-v1|"+settings.Secret)),16);
        aes.Decrypt(frame.AsSpan(0,12),frame.AsSpan(28),frame.AsSpan(12,16),bytes,Encoding.ASCII.GetBytes(hash+"|"+offset.ToString(System.Globalization.CultureInfo.InvariantCulture)));
        return bytes;
    }
    public static async Task StreamAsync(Stream stream,LanSettings settings,string expected,CancellationToken ct)
    {
        await Transfers.WaitAsync(ct);
        try
        {
            FileStream? input=null;Manifest? manifest;
            lock(Gate)
            {
                manifest=ReadManifest();
                if(manifest is not null&&manifest.Hash.Equals(expected,StringComparison.OrdinalIgnoreCase))
                    input=new FileStream(Package,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete,StreamChunkSize,FileOptions.Asynchronous|FileOptions.SequentialScan);
            }
            await using var lease=input;
            if(input is null||manifest is null){await LanFrames.WriteAsync(stream,LanCrypto.Seal(settings,"result",new{ok=false,error="A release mudou. Consulte o Servidor novamente."}),ct);return;}
            await LanFrames.WriteAsync(stream,LanCrypto.Seal(settings,"result",new{ok=true,hash=manifest.Hash,size=manifest.Size}),ct);
            var buffer=new byte[StreamChunkSize];long offset=0;
            while(offset<manifest.Size)
            {
                var count=(int)Math.Min(buffer.Length,manifest.Size-offset);
                await input.ReadExactlyAsync(buffer.AsMemory(0,count),ct);
                await LanFrames.WriteAsync(stream,EncodeBlock(settings,manifest.Hash,offset,buffer.AsSpan(0,count)),ct);offset+=count;
            }
        }
        finally{Transfers.Release();}
    }
    /// <summary>Transfere a posse do arquivo já validado ao atualizador, sem uma segunda cópia do ZIP.</summary>
    internal sealed class VerifiedPackageContent:StreamContent
    {
        private string? _path;
        internal string VerifiedHash{get;}
        internal VerifiedPackageContent(string path,string hash):base(new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete,65536,FileOptions.Asynchronous|FileOptions.SequentialScan))
        {_path=path;VerifiedHash=hash;}
        internal void MoveTo(string target)
        {
            if(_path is null)throw new InvalidOperationException("O pacote LAN já foi entregue ao atualizador.");
            try{File.Move(_path,target);}
            catch(IOException)when(!File.Exists(target)){File.Copy(_path,target,false);File.Delete(_path);}
            _path=null;
        }
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if(disposing&&_path is {} path){try{File.Delete(path);}catch(IOException){}catch(UnauthorizedAccessException){}_path=null;}
        }
    }
    /// <summary>Transfere uma release assinada pelo Servidor, sem baixar nem compilar na plataforma.</summary>
    public static async Task<HttpResponseMessage?> TryFetchAsync(string architecture,CancellationToken ct,Action<long,long>? progress=null,bool force=false)
    {
        var settings=LanSettings.Load();if(!settings.Ready)return null;
        try
        {
            var remote=await ProbeAsync(architecture,settings,ct);if(remote is null)return null;
            var m=remote.Manifest;
            if(!AppInfo.TryCompareRelease(m.Version,AppInfo.Version,out var cmp)||cmp<0||cmp==0&&!force)return null;
            var temp=Path.Combine(Path.GetTempPath(),"gesti-lan-"+Guid.NewGuid().ToString("N")+".zip");
            try
            {
                using var digest=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                await using(var output=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None,StreamChunkSize,FileOptions.Asynchronous|FileOptions.SequentialScan))
                {
                    long offset=0;
                    if(remote.Streaming)
                    {
                        using var tcp=new TcpClient{NoDelay=true};
                        using var connect=CancellationTokenSource.CreateLinkedTokenSource(ct);connect.CancelAfter(TimeSpan.FromSeconds(10));
                        await tcp.ConnectAsync(remote.Server.Address,remote.Server.Port,connect.Token);var stream=tcp.GetStream();
                        using var handshake=CancellationTokenSource.CreateLinkedTokenSource(ct);handshake.CancelAfter(TimeSpan.FromSeconds(45));
                        await LanFrames.WriteAsync(stream,LanCrypto.Seal(settings,"update_stream",new{hash=m.Hash}),handshake.Token);
                        var accepted=LanCrypto.Open(settings,await LanFrames.ReadAsync(stream,handshake.Token));
                        if(accepted is not {Kind:"result"}||!accepted.Body.TryGetProperty("ok",out var ok)||ok.ValueKind!=JsonValueKind.True||accepted.Body.GetProperty("hash").GetString()!=m.Hash||accepted.Body.GetProperty("size").GetInt64()!=m.Size)throw new InvalidDataException("O Servidor não confirmou a transferência LAN.");
                        while(offset<m.Size)
                        {
                            using var idle=CancellationTokenSource.CreateLinkedTokenSource(ct);idle.CancelAfter(TimeSpan.FromSeconds(30));
                            var bytes=DecodeBlock(settings,m.Hash,offset,await LanFrames.ReadAsync(stream,idle.Token));
                            if(offset+bytes.Length>m.Size)throw new InvalidDataException("Tamanho LAN divergente.");
                            await output.WriteAsync(bytes,ct);digest.AppendData(bytes);offset+=bytes.Length;progress?.Invoke(offset,m.Size);
                        }
                    }
                    else
                    {
                        // Compatibilidade com o Servidor anterior, até ele receber esta correção.
                        while(offset<m.Size)
                        {
                            var reply=await CallAsync(settings,remote.Server,"update_chunk",new{offset,count=(int)Math.Min(ChunkSize,m.Size-offset)},ct);
                            if(reply.GetProperty("offset").GetInt64()!=offset)throw new InvalidDataException("Sequência LAN inválida.");
                            var bytes=Convert.FromBase64String(reply.GetProperty("bytes").GetString()??"");
                            if(bytes.Length<1||bytes.Length>ChunkSize||offset+bytes.Length>m.Size)throw new InvalidDataException("Bloco LAN inválido.");
                            await output.WriteAsync(bytes,ct);digest.AppendData(bytes);offset+=bytes.Length;progress?.Invoke(offset,m.Size);
                        }
                    }
                }
                if(!Convert.ToHexString(digest.GetHashAndReset()).Equals(m.Hash,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Falha no SHA-256 da release LAN.");
                var response=new HttpResponseMessage(HttpStatusCode.OK){Content=new VerifiedPackageContent(temp,m.Hash)};
                response.Content.Headers.ContentLength=m.Size;
                response.Headers.TryAddWithoutValidation("X-Gestor-Version",m.Version);response.Headers.TryAddWithoutValidation("X-Package-SHA256",m.Hash);
                response.Headers.TryAddWithoutValidation("X-Package-Public-Key",m.Key);response.Headers.TryAddWithoutValidation("X-Package-Signature",m.Signature);
                response.Headers.TryAddWithoutValidation("X-Package-Transport","lan");
                return response;
            }
            catch{try{File.Delete(temp);}catch(IOException){}throw;}
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){throw;}
        catch(Exception error)when(ExpectedFailure(error)){lock(HintGate)_hint=null;RuntimeLog.Write("Transferência LAN: "+error.Message);return null;}
    }
}
