<?php
/* Caminho: api/gestor-topology.php — escolha de perfil pela instalação; gestão e lotes pela sessão administrativa. */
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../includes/gestor-topology.php';
header('Cache-Control: no-store, private');header('X-Content-Type-Options: nosniff');
try{
 $pdo=arc_db();$action=(string)($_GET['action']??'state');
 if($_SERVER['REQUEST_METHOD']!=='POST')throw new DomainException('Use POST.',405);
 $raw=file_get_contents('php://input',false,null,0,16385);if(!is_string($raw)||strlen($raw)>16384)throw new InvalidArgumentException('Requisição acima do limite.');$v=json_decode($raw,true,32,JSON_THROW_ON_ERROR);if(!is_array($v))throw new InvalidArgumentException('JSON inválido.');
 if(!arc_is_user()&&!arc_is_admin())throw new DomainException('Autenticação necessária.',401);arc_verify_csrf();
 $network=(int)($v['network_id']??0);$access=arc_network_team_access($pdo,$network,(int)arc_user_id());if(!$access||!in_array($access['role'],['owner','administrator','system_admin'],true))throw new DomainException('Permissão administrativa necessária.',403);
 $rights=arc_network_profile_rights($pdo,$network,(int)arc_user_id());if(!in_array($access['role'],['owner','system_admin'],true)&&$rights!==null&&!in_array('configuracoes',$rights,true)&&!in_array('preferencias',$rights,true))throw new DomainException('Seu perfil não permite configurar gestores.',403);
 $account=(int)$access['account_id'];$actor=arc_is_admin()?(int)arc_admin_id():(int)arc_user_id();
 if($action==='report'){
  if(!in_array($access['role'],['owner','system_admin'],true)&&$rights!==null&&!in_array('pentefino',$rights,true))throw new DomainException('Seu perfil não permite consultar análises.',403);
  $id=(int)($v['gestor_id']??0);$q=$pdo->prepare('SELECT id FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=?');$q->execute([$id,$account,$network]);if(!$q->fetchColumn())throw new DomainException('Computador não vinculado a esta rede.',403);
  $row=arc_pf_report_get($pdo,$id,$network,$account,'health');arc_json(['ok'=>true,'collected_at'=>$row['collected_at']??null,'report'=>$row['report']??null]);
 }
 if($action==='batch'){
  $command=(string)($v['command']??'');$cap=$command==='pentefino_scan'?'pentefino':'servidor';if(!in_array($access['role'],['owner','system_admin'],true)&&$rights!==null&&!in_array($cap,$rights,true))throw new DomainException('Operação não autorizada para seu perfil.',403);arc_billing_assert_active($pdo,$account);
  arc_json(['ok'=>true]+arc_gt_batch($pdo,$account,$network,$actor,is_array($v['gestores']??null)?$v['gestores']:[],$command,(string)($v['request_id']??'')));
 }
 if($action==='change'){
  if(isset($v['menus'])&&!is_array($v['menus']))throw new InvalidArgumentException('Seleção de menus inválida.');
  if(isset($v['background'])&&!is_bool($v['background']))throw new InvalidArgumentException('Opção de segundo plano inválida.');
  if(($v['confirmed']??false)!==true)throw new InvalidArgumentException('Confirme a alteração administrativa.');
  // Valida novamente a identidade administrativa, sem transformar o perfil de instalação em privilégio.
  $attempt=arc_login_attempt_begin($pdo,'gestor-topology:'.$network.':'.$actor);if($attempt===null)throw new DomainException('Muitas tentativas. Tente novamente mais tarde.',429);
  $password=(string)($v['password']??'');$q=$pdo->prepare('SELECT password_hash FROM '.arc_table(arc_is_admin()?'admins':'user_accounts').' WHERE id=?');$q->execute([$actor]);$hash=(string)$q->fetchColumn();
  if($password===''||strlen($password)>512||!(password_verify($password,$hash)||password_verify(base64_encode(hash('sha384',$password,true)),$hash)))throw new DomainException('Senha administrativa inválida.',403);
  arc_login_attempt_succeeded($pdo,$attempt);
  arc_gt_change($pdo,$account,$network,(int)($v['gestor_id']??0),(string)($v['operation']??''),(int)($v['mask']??31),(string)($v['role']??'collaborator'),isset($v['menus'])&&is_array($v['menus'])?$v['menus']:null,isset($v['background'])?($v['background']===true):null);arc_json(['ok'=>true]);
 }
 throw new InvalidArgumentException('Ação inválida.');
}catch(JsonException|InvalidArgumentException $e){arc_json(['ok'=>false,'error'=>$e->getMessage()],422);}catch(DomainException $e){arc_json(['ok'=>false,'error'=>$e->getMessage()],in_array($e->getCode(),[401,403,405,409,429],true)?$e->getCode():409);}catch(Throwable $e){arc_log_error('Gestores distribuídos: '.$e->getMessage());arc_json(['ok'=>false,'error'=>'Não foi possível concluir. Consulte os registros administrativos.'],503);}
