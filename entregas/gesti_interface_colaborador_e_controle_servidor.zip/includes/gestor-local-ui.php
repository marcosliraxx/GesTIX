<?php
/* Caminho: includes/gestor-local-ui.php — visibilidade local administrada; capacidades do agente permanecem separadas. */
declare(strict_types=1);
require_once __DIR__.'/workspace-menu.php';
function arc_gt_menu_catalog(): array {
 $items=[];foreach(arc_workspace_menu()['groups'] as $group)foreach($group['items'] as $item)$items[$item['key']]=$item;return $items;
}
function arc_gt_menu_capability(string $key): string {
 if(str_starts_with($key,'backup'))return 'backup';
 if(in_array($key,['files','remote','support','tickets','agenda'],true))return 'support';
 if(in_array($key,['updates','history','windows_update'],true))return 'updates';
 if(in_array($key,['panel','server','speed','devices','map','users','permissions','preferences','reports','registry_cad','release'],true))return 'inventory';
 return 'maintenance';
}
function arc_gt_local_ui(PDO $pdo,array $g,string $role,array $profile): array {
 $known=arc_gt_menu_catalog();if($role==='server')return ['menus'=>array_keys($known),'background'=>false];
 $prefix='gestor_ui_'.(int)$g['id'].'_';$q=$pdo->prepare('SELECT preference_key,preference_value FROM '.arc_table('network_user_preferences').' WHERE account_id=? AND network_id=? AND preference_key LIKE ?');$q->execute([$g['account_id'],$g['network_id'],$prefix.'%']);$enabled=[];$initialized=false;
 foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row){$name=(string)$row['preference_key'];if(!str_starts_with($name,$prefix))continue;$key=substr($name,strlen($prefix));if($key==='initialized'){$initialized=true;continue;}if(isset($known[$key])&&(string)$row['preference_value']==='1')$enabled[]=$key;}
 return ['menus'=>$initialized?array_values(array_intersect(array_keys($known),$enabled)):['remote'],'background'=>!empty($profile['background'])];
}
function arc_gt_save_local_ui(PDO $pdo,int $account,int $network,int $id,array $menus): void {
 $known=arc_gt_menu_catalog();if(count($menus)>count($known))throw new InvalidArgumentException('Quantidade de menus inválida.');
 foreach($menus as $key)if(!is_string($key)||!isset($known[$key]))throw new InvalidArgumentException('Menu não reconhecido.');
 $q=$pdo->prepare('INSERT INTO '.arc_table('network_user_preferences').' (account_id,network_id,preference_key,preference_value) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE preference_value=VALUES(preference_value)');$prefix='gestor_ui_'.$id.'_';$q->execute([$account,$network,$prefix.'initialized','1']);
 foreach($known as $key=>$_)$q->execute([$account,$network,$prefix.$key,in_array($key,$menus,true)?'1':'0']);
}
function arc_gt_local_menu_allowed(PDO $pdo,array $g,array $menus): bool {
 $p=arc_gt_profile($pdo,$g);if($p['revoked'])return false;if($p['role']==='server')return true;
 return (bool)array_intersect($menus,$p['ui']['menus']);
}
function arc_gt_assert_local_action(PDO $pdo,array $g,string $action,array $body): void {
 if($action==='gestor-pentefino-local-settings'&&!empty($body['save']))$menus=['health','options'];
 elseif($action==='gestor-terminal-local-start')$menus=['server'];
 elseif($action==='gestor-device-save')$menus=['devices','map'];
 elseif($action==='gestor-menu-favorites'&&($body['operation']??'read')!=='read')$menus=array_keys(arc_gt_menu_catalog());
 else return;
 if(!arc_gt_local_menu_allowed($pdo,$g,$menus))throw new RuntimeException('Esta ação local não foi liberada para o Colaborador.',403);
}
