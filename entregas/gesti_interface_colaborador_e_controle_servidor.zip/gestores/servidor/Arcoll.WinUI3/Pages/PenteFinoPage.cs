// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/PenteFinoPage.cs
using System.Security.Principal;
using System.Text.Json;
using System.Text.RegularExpressions;
using Arcoll.WinUI3.Services;
using Arcoll.WinUI3.Services.PenteFino;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.Web.WebView2.Core;
namespace Arcoll.WinUI3.Pages;
/// <summary>Análise geral do Pente-Fino; confirmar/corrigir ocorre no host nativo, não no JavaScript.</summary>
public sealed class PenteFinoPage:UserControl,IPageDataSource
{
 private bool _dataBridgeConfigured;
 private readonly PageDataLoad _analysisLoad=new("Abrindo o Pente-Fino",true);
 public PageDataLoad DataLoad=>_analysisLoad;
 public Task CollectDataAsync()=>InitializeAsync();
 public bool CanCancelCollection=>_busy;
 public bool HasActiveOperations=>_busy;
 public void CancelCollection()=>CancelOperations();
 public UserControl? ActiveTool=>null;
 public string ActiveTitle=>"Análise geral";
 public bool HasToolOptions=>false;
 private static readonly string[] ModuleKeys=["startup","performance","restore","security","uninstall","updater","drivers","windows_update","disk","duplicates","cloud"];
 public void OpenTool(string key){if(ModuleKeys.Contains(key))_navigate(key);}

    private const string Origin="https://pentefino.tidigital.local/";
    private static readonly JsonSerializerOptions Json=new(){PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
    private readonly GestorRuntime _runtime;private readonly Action<string> _navigate;
    private readonly WebView2 _web=new(){HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Stretch};
    private object? _outcome;private bool _auditOk=true;private ScanReport? _summaryFor;private ReportSummary? _summary;private Palette _palette=new();private ResultsStore? _store;private Settings _settings=Settings.Default;private ScanReport? _report;private FixReport? _fix;private string _settingsHash="",_phase="",_notice="",_requestId="";private bool _busy,_ready,_loading,_historical=true,_cancelRequested;private CancellationTokenSource? _operation;private readonly SemaphoreSlim _messages=new(1,1);private readonly object _storeGate=new();private Task _warm=Task.CompletedTask,_localSummary=Task.CompletedTask;
    public PenteFinoPage(GestorRuntime runtime,Action<string> navigate){_runtime=runtime;_navigate=navigate;Content=_web;Loaded+=async(_,_)=>await InitializeAsync();}
    public void ApplyPalette(Palette palette){_palette=palette;Publish();}
    public void CancelOperations(){_cancelRequested=true;_operation?.Cancel();Publish();}
    private ResultsStore Store(){lock(_storeGate){if(_store is not null)return _store;using var identity=WindowsIdentity.GetCurrent();var scope=ResultsStore.Hash(identity.User?.Value??Environment.UserName)[..24];var root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","PenteFino",scope);_store=new ResultsStore(root);_settings=_store.LoadSettings() with { Mode="detailed" };if(_settings.Preferences is null){var preferences=GeneralAnalysisEngine.Defaults(PenteFinoEngine.Catalog());_settings=_settings with{Preferences=preferences,Modules=GeneralAnalysisEngine.Modules(preferences)};_store.SaveSettings(_settings);}else {
                var normalized=GeneralAnalysisEngine.Validate(_settings.Preferences,PenteFinoEngine.Catalog());
                var modules=GeneralAnalysisEngine.Modules(normalized);
                if(!_settings.Modules.SequenceEqual(modules)||!_settings.Preferences.Equals(normalized)){
                    _settings=_settings with{Preferences=normalized,Modules=modules};_store.SaveSettings(_settings);
                }
            }_report=_store.Last();return _store;}}
    private void RefreshLocalSummary(ResultsStore store)=>_auditOk=store.VerifyAudit();
    private GeneralAnalysisEngine Analysis()=>new(_runtime.Platform.Config,_settings.Preferences!,_settings.Exclusions,_settings.CustomFolders);
    private ReportSummary? Summary(){lock(_storeGate){if(_report is null)return null;if(!ReferenceEquals(_summaryFor,_report)){_summary=Presentation.Summarize(_report,PenteFinoEngine.Catalog());_summaryFor=_report;}return _summary;}}
    private static string Text(JsonElement e,string key)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(key,out var p)&&p.ValueKind==JsonValueKind.String?p.GetString()??"":"";
    private static string[] Strings(JsonElement e,string key,int maximum)=>e.TryGetProperty(key,out var p)&&p.ValueKind==JsonValueKind.Array&&p.GetArrayLength()<=maximum?p.EnumerateArray().Select(x=>x.ValueKind==JsonValueKind.String?x.GetString()??"":throw new InvalidDataException("Lista inválida.")).ToArray():[];
    private async Task InitializeAsync(){if(_ready||_loading)return;_loading=true;_analysisLoad.Begin("Abrindo o Pente-Fino");try{if(_dataBridgeConfigured&&_web.CoreWebView2 is not null){_web.CoreWebView2.Reload();return;}await Task.Run(()=>{Store();});_warm=Task.Run(()=>{Summary();});_localSummary=Task.Run(()=>RefreshLocalSummary(Store()));var folder=Path.Combine(AppContext.BaseDirectory,"Assets","hybrid","pentefino");if(!File.Exists(Path.Combine(folder,"index.html")))throw new FileNotFoundException("Interface Pente-Fino não instalada.");var profile=Store().LocalPath("WebView2");Directory.CreateDirectory(profile);var env=await CoreWebView2Environment.CreateWithOptionsAsync(null,profile,null);await _web.EnsureCoreWebView2Async(env);var web=_web.CoreWebView2??throw new InvalidOperationException("WebView2 não inicializado.");web.Settings.AreDevToolsEnabled=false;web.Settings.AreDefaultContextMenusEnabled=false;web.Settings.AreHostObjectsAllowed=false;web.SetVirtualHostNameToFolderMapping("pentefino.tidigital.local",folder,CoreWebView2HostResourceAccessKind.DenyCors);web.NavigationStarting+=(_,e)=>{if(!e.Uri.StartsWith(Origin,StringComparison.OrdinalIgnoreCase))e.Cancel=true;};web.NewWindowRequested+=(_,e)=>e.Handled=true;
        web.WebMessageReceived+=async(_,e)=>{if(!e.Source.StartsWith(Origin,StringComparison.OrdinalIgnoreCase))return;try{using var doc=JsonDocument.Parse(e.WebMessageAsJson);var root=doc.RootElement;var action=Text(root,"action");if(action=="workspace-footer")return;if(action=="stop"){CancelOperations();return;}if(!await _messages.WaitAsync(0))return;try{await HandleAsync(action,root);}finally{_messages.Release();}}catch(Exception error){_notice=error.Message;Publish();}};
        web.NavigationCompleted+=(_,e)=>{if(!e.IsSuccess){_notice="Não foi possível abrir a interface local.";_analysisLoad.Fail(_notice);return;}_ready=true;};_dataBridgeConfigured=true;_web.Source=new Uri(Origin+"index.html");
    }catch(Exception error){_analysisLoad.Fail("Não foi possível abrir esta área: "+error.Message);_notice="Pente-Fino indisponível: "+error.Message;}finally{_loading=false;}}
    private async Task HandleAsync(string action,JsonElement body){var requestId=Text(body,"requestId");if(Regex.IsMatch(requestId,"^[a-zA-Z0-9_-]{1,64}$"))_requestId=requestId;if(action=="ready"){_ready=true;await _warm;if(_runtime.CanOpenLocalMenu("health")&&!_busy){try{if(_runtime.Allowed)await SyncAnalysisPathsAsync(false);}catch(Exception ex){RuntimeLog.Write("Pente-Fino/preferências da plataforma: "+ex.Message);}}Publish();_analysisLoad.Complete();_=_localSummary.ContinueWith(t=>DispatcherQueue.TryEnqueue(()=>Publish()),TaskScheduler.Default);return;}if(!_runtime.CanOpenLocalMenu("health"))throw new UnauthorizedAccessException("Autorize o gestor na plataforma.");if(action=="navigate"){var target=Text(body,"target");if(ModuleKeys.Contains(target)&&_runtime.CanOpenLocalMenu(target))OpenTool(target);return;}await _localSummary;var store=Store();if(_busy)return;
        if(action=="settings"){
            if(!body.TryGetProperty("preferences",out var input))throw new InvalidDataException("Configurações ausentes.");
            var preferences=GeneralAnalysisEngine.Validate(input.Deserialize<AnalysisPreferences>(new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??throw new InvalidDataException("Configurações inválidas."),PenteFinoEngine.Catalog());
            var modules=GeneralAnalysisEngine.Modules(preferences);if(modules.Length==0)throw new InvalidDataException("Ative ao menos uma verificação.");
            _settings=_settings with{Mode="detailed",Modules=modules,Preferences=preferences};store.SaveSettings(_settings);_historical=true;
            _=PushPreferencesAsync(preferences).ContinueWith(t=>RuntimeLog.Write("Pente-Fino/sincronizar preferências: "+t.Exception?.GetBaseException().Message),TaskContinuationOptions.OnlyOnFaulted);
            _notice="Preferências salvas. Faça uma nova análise antes de corrigir.";Publish();return;
        }
        if(action is not("scan" or "fix"))throw new InvalidDataException("Ação desconhecida.");
        var operationRequestId=_requestId;_operation=new CancellationTokenSource();_outcome=null;_busy=true;_phase=action;_cancelRequested=false;_notice="";Publish();
        try{
            if(action=="scan"){
                // A escolha do círculo é parte do próprio comando: evita perder o scan
                // enquanto uma mensagem separada de preferências ainda é processada.
                _historical=true;if(_runtime.Allowed)await SyncAnalysisPathsAsync(false);
                if(_settings.Preferences is null)throw new InvalidDataException("Configure as verificações da análise.");
                GeneralAnalysisEngine.Validate(_settings.Preferences,PenteFinoEngine.Catalog());
                _settings=_settings with {Mode="detailed",Modules=GeneralAnalysisEngine.Modules(_settings.Preferences)};store.SaveSettings(_settings);
                var options=new ScanOptions("detailed",_settings.Modules,_settings.Exclusions);_settingsHash=ResultsStore.Hash(JsonSerializer.Serialize(_settings));_fix=null;_report=null;
                var progress=new Progress<ProgressState>(state=>Post(new{type="progress",requestId=operationRequestId,state}));_report=await new ScanOrchestrator(store,Analysis().Checkers()).ScanAsync(options,progress,_operation.Token);_historical=_report.Cancelled;_notice=_report.Cancelled?"Análise interrompida; nenhuma correção foi aplicada.":"Análise concluída. Revise e selecione os itens antes de corrigir.";
            }else if(action=="fix"){
                if(_runtime.Allowed)await SyncAnalysisPathsAsync(true);
                if(_report is null||_historical||_report.Cancelled||_settingsHash!=ResultsStore.Hash(JsonSerializer.Serialize(store.LoadSettings())))throw new InvalidOperationException("É necessária uma nova análise com as preferências atuais.");var selectedAreas=Strings(body,"areas",64);var ids=Presentation.CorrectionIds(_report,Text(body,"reportId"),selectedAreas,PenteFinoEngine.Catalog());
                _fix=null;
                var selectedQuantity=_report.Modules.SelectMany(m=>m.Items).Where(i=>ids.Contains(i.Id)).Sum(i=>Math.Max(1,i.Quantity));var decision=await ConfirmCorrectionAsync(selectedQuantity);
                if(!decision.Confirmed||!_runtime.CanOpenLocalMenu("health")){_notice="Correção cancelada; nenhuma alteração foi iniciada.";return;}

                var modulesById=_report.Modules.SelectMany(m=>m.Items.Select(i=>new{ i.Id,Module=m.Id})).DistinctBy(i=>i.Id).ToDictionary(i=>i.Id,i=>i.Module);
                var fixProgress=new Progress<FixProgressState>(progress=>Post(new{type="fix-progress",requestId=operationRequestId,state=new{progress.Completed,progress.Total,progress.State,progress.Succeeded,progress.Failed,module=progress.Id is not null?modulesById.GetValueOrDefault(progress.Id):null}}));
                var fixEngine=Analysis();fixEngine.FixLog=new Progress<string>(text=>Post(new{type="fix-item",requestId=operationRequestId,message=text}));
                _fix=await Task.Run(()=>new FixEngine(store,fixEngine.FixAsync).FixAsync(_report,ids,_operation.Token,fixProgress,decision.RestorePoint));
                _outcome=new{kind="fix",session=_fix.Session,applied=_fix.Results.Where(r=>r.Ok).Sum(r=>_report.Modules.SelectMany(m=>m.Items).First(i=>i.Id==r.Id).Quantity),failed=_fix.Results.Where(r=>!r.Ok).Sum(r=>_report.Modules.SelectMany(m=>m.Items).First(i=>i.Id==r.Id).Quantity),pending=Math.Max(0,selectedQuantity-_fix.Results.Sum(r=>_report.Modules.SelectMany(m=>m.Items).First(i=>i.Id==r.Id).Quantity)),cancelled=_fix.Cancelled,countsPartial=_fix.CountsPartial,errors=_fix.Results.Where(r=>!r.Ok).Select(r=>r.Message).Distinct().Take(8).ToArray()};_historical=true;_notice=_fix.Cancelled?"Correção interrompida. As etapas já aplicadas permanecem concluídas.":"Correção concluída. Revise o resultado e faça nova análise quando desejar.";
            }
        }catch(OperationCanceledException){_notice="Operação interrompida. Consulte o histórico das etapas concluídas; cancelar não desfaz etapas aplicadas.";_historical=true;}
        catch(Exception error){_notice="Não foi possível concluir: "+error.Message;RuntimeLog.Write("Pente-Fino/"+action+": "+error);}
        finally{if(_report is not null){try{await SyncDistributedReportAsync();}catch(Exception error){RuntimeLog.Write("Pente-Fino/relatório pendente: "+error.Message);}}_phase="";_operation.Dispose();_operation=null;try{await Task.Run(()=>RefreshLocalSummary(store));}catch(Exception error){_auditOk=false;_notice="O histórico precisa de revisão: "+error.Message;} _busy=false;Publish();}
    }
    private async Task SyncDistributedReportAsync()
    {
        if(_report is null)return;
        var results=_fix?.Results.ToDictionary(r=>r.Id,r=>r);
        var items=_report.Modules.SelectMany(m=>m.Items).Take(5000).Select(i=>new{
            id=i.Id,module=i.Module,title=i.Title,reason=i.Reason,count=Math.Max(1,i.Quantity),bytes=Math.Max(0,i.Bytes),can_fix=i.CanFix,
            status=results is not null&&results.TryGetValue(i.Id,out var action)?(action.Ok?"fixed":"failed"):(_fix is null?"diagnosed":"not_applied")});
        var report=JsonSerializer.SerializeToElement(new{tool="health",report_id=_report.Id,captured_at=(_fix?.At??_report.At).ToUnixTimeSeconds(),incomplete=true,
            note="Resultado detalhado do gestor: diagnóstico e correção identificados por item em Configurações → Gestores e Colaboradores.",
            distributed_items=items,cancelled=_report.Cancelled||(_fix?.Cancelled??false),truncated=_report.Modules.Sum(m=>m.Items.Count)>5000});
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(20));await _runtime.SaveLocalReportAsync("health",report,timeout.Token);
    }
    /// <summary>Preferências da Análise geral compartilhadas com a plataforma (mesmos nomes JSON da web).</summary>
    private Task PushPreferencesAsync(AnalysisPreferences p)=>_runtime.Platform.PostAsync("gestor-pentefino-local-settings",_runtime.Platform.WithCredentials(("save",true),("analysis_only",true),("analysis",new{categories=p.Categories,registryChecks=Array.Empty<string>(),startupKinds=p.StartupKinds,periodDays=p.PeriodDays,softwareUpdates=p.SoftwareUpdates,windowsUpdates=p.WindowsUpdates})),CancellationToken.None,20);
    private async Task SyncAnalysisPathsAsync(bool validateOnly){
     var response=await _runtime.Platform.PostAsync("gestor-pentefino-local-settings",_runtime.Platform.WithCredentials(),_operation?.Token??CancellationToken.None,20);var settings=response.GetProperty("settings");
     var exclusions=Strings(settings,"exclusions",100);var folders=Strings(settings,"custom_folders",20);
     var combined=_settings.Exclusions.Concat(exclusions).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(s=>s,StringComparer.OrdinalIgnoreCase).ToArray();
     if(validateOnly){if(!combined.SequenceEqual(_settings.Exclusions,StringComparer.OrdinalIgnoreCase)||!folders.SequenceEqual(_settings.CustomFolders??[],StringComparer.OrdinalIgnoreCase))throw new InvalidOperationException("As exclusões ou pastas da plataforma mudaram. Faça uma nova análise.");return;}
     _settings=_settings with{Exclusions=combined,CustomFolders=folders};
     if(settings.TryGetProperty("analysis",out var remote)&&remote.ValueKind==JsonValueKind.Object){try{var prefs=GeneralAnalysisEngine.Validate(remote.Deserialize<AnalysisPreferences>(new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??throw new InvalidDataException("Preferências remotas inválidas."),PenteFinoEngine.Catalog());var mods=GeneralAnalysisEngine.Modules(prefs);if(mods.Length>0)_settings=_settings with{Preferences=prefs,Modules=mods};}catch(Exception ex)when(ex is InvalidDataException or JsonException){RuntimeLog.Write("Pente-Fino/preferências da plataforma: "+ex.Message);}}
     else if(_settings.Preferences is { } local){try{await PushPreferencesAsync(local);}catch(Exception ex){RuntimeLog.Write("Pente-Fino/sincronizar preferências: "+ex.Message);}}
     Store().SaveSettings(_settings);
    }
    private async Task<(bool Confirmed,bool RestorePoint)> ConfirmCorrectionAsync(int count){
     var restore=new CheckBox{Content="Criar ponto de restauração no Windows",IsChecked=false,FontSize=12,Foreground=_palette.Text};
     var body=new StackPanel{Spacing=12,MaxWidth=370};body.Children.Add(new TextBlock{Text=count.ToString("N0")+" ajustes selecionados. As correções não guardam cópias de recuperação. Cookies removidos podem encerrar sessões.",TextWrapping=TextWrapping.Wrap,FontSize=12,Foreground=_palette.Muted});body.Children.Add(restore);
     var dialog=new ContentDialog{XamlRoot=XamlRoot,Title="Confirma ajustes e correções?",Content=body,PrimaryButtonText="Corrigir",CloseButtonText="Cancelar",DefaultButton=ContentDialogButton.Close,Background=_palette.Surface,Foreground=_palette.Text,RequestedTheme=_palette.Light?ElementTheme.Light:ElementTheme.Dark};
     return(await dialog.ShowAsync()==ContentDialogResult.Primary,restore.IsChecked==true);
    }
    private static string Color(Brush brush)=>brush is SolidColorBrush b?$"#{b.Color.R:X2}{b.Color.G:X2}{b.Color.B:X2}":"#2563eb";
    private void Post(object data){if(!_ready)return;try{_web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(data,Json));}catch(InvalidOperationException){}}
    private void Publish(){Post(new{type="state",allowed=_runtime.CanOpenLocalMenu("health"),busy=_busy,phase=_phase,cancelRequested=_cancelRequested,notice=_notice,settings=_settings,requestId=_requestId,report=Summary(),outcome=_outcome,historical=_historical,
        catalog=PenteFinoEngine.Catalog(),auditOk=_auditOk,theme=new{light=_palette.Light,accent=Color(_palette.Accent),surface=Color(_palette.Surface),text=Color(_palette.Text),muted=Color(_palette.Muted),alt=Color(_palette.Alt),line=Color(_palette.Line)}});}
}
