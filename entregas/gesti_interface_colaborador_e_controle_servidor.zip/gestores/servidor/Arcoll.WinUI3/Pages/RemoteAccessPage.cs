// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/RemoteAccessPage.cs
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
namespace Arcoll.WinUI3.Pages;
/// <summary>Acesso remoto por código: o código temporário fica sempre visível, com contagem regressiva e renovação automática.</summary>
public sealed class RemoteAccessPage : UserControl
{
    private readonly GestorRuntime _runtime;
    private readonly Func<CancellationToken, Task<(string Code, int Seconds)>> _fetch;
    private readonly TextBlock _code = new() { Text = "— — — — —", FontSize = 56, FontWeight = Microsoft.UI.Text.FontWeights.Bold, IsTextSelectionEnabled = true, HorizontalAlignment = HorizontalAlignment.Center, CharacterSpacing = 300 };
    private readonly TextBlock _clock = new() { HorizontalAlignment = HorizontalAlignment.Center, FontSize = 14, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center };
    private readonly ProgressBar _bar = new() { Minimum = 0, Maximum = 100, Value = 0, Width = 360, HorizontalAlignment = HorizontalAlignment.Center };
    private readonly Button _copy = new() { Content = "Copiar código", HorizontalAlignment = HorizontalAlignment.Center, Padding = new Thickness(22, 10, 22, 10), IsEnabled = false };
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
    private DateTime _until = DateTime.MinValue; private int _total = 1; private string _current = ""; private bool _busy, _visible;
    public RemoteAccessPage(GestorRuntime runtime, Func<CancellationToken, Task<(string Code, int Seconds)>> fetch)
    {
        _runtime = runtime; _fetch = fetch;
        var content = new StackPanel { Spacing = 16, Padding = new Thickness(24), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, MaxWidth = 560 };
        content.Children.Add(new TextBlock { Text = "Acesso remoto", FontSize = 26, HorizontalAlignment = HorizontalAlignment.Center, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        content.Children.Add(new TextBlock { Text = "Informe este código na plataforma para permitir acesso remoto autorizado ao computador. O código é de uso único e muda automaticamente.", TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center });
        content.Children.Add(_code); content.Children.Add(_bar); content.Children.Add(_clock); content.Children.Add(_copy);
        Content = content;
        _copy.Click += (_, _) => { if (_current.Length == 0 || DateTime.UtcNow >= _until) return; var package = new DataPackage(); package.SetText(_current); try { Clipboard.SetContent(package); _clock.Text = "Código copiado."; } catch { _clock.Text = "Não foi possível copiar. Selecione o código e copie manualmente."; } };
        _timer.Tick += async (_, _) => await TickAsync();
        Loaded += async (_, _) => { _visible = true; _timer.Start(); _runtime.Changed += OnRuntimeChanged; await TickAsync(); };
        Unloaded += (_, _) => { _visible = false; _timer.Stop(); _runtime.Changed -= OnRuntimeChanged; };
    }
    private void OnRuntimeChanged() { if (_visible) DispatcherQueue.TryEnqueue(async () => await TickAsync()); }
    private async Task TickAsync()
    {
        if (!_visible) return;
        if (!_runtime.Can("support")) { _current = ""; _code.Text = "— — — — —"; _bar.Value = 0; _copy.IsEnabled = false; _clock.Text = "Conecte e autorize o gestor para exibir o código."; return; }
        var left = (int)Math.Ceiling((_until - DateTime.UtcNow).TotalSeconds);
        if (_current.Length > 0 && left > 0) { _clock.Text = "O código muda em " + left + (left == 1 ? " segundo" : " segundos"); _bar.Value = Math.Clamp(left * 100.0 / _total, 0, 100); return; }
        if (_busy||left>0) return; _busy = true;
        try
        {
            _clock.Text = "Gerando novo código…";
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(15));
            var (code, seconds) = await _fetch(timeout.Token);
            _current = code; _total = Math.Max(1, seconds); _until = DateTime.UtcNow.AddSeconds(_total);
            _code.Text = code; _copy.IsEnabled = true; _bar.Value = 100; _clock.Text = "O código muda em " + _total + " segundos";
        }
        catch (Exception ex) { _current = ""; _copy.IsEnabled = false; _clock.Text = "Não foi possível gerar o código: " + ex.Message + " Nova tentativa em instantes."; _until = DateTime.UtcNow.AddSeconds(8); _total = 8; _current = ""; }
        finally { _busy = false; }
    }
}
