// Caminho: gestores/servidor/Arcoll.WinUI3/Services/LocalUiPolicy.cs
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace Arcoll.WinUI3.Services;

/// <summary>O cache só pode ocultar a janela; nunca concede menus ou permissões sem resposta autenticada.</summary>
public static class LocalUiPolicy
{
    public static string Capability(string key)=>key.StartsWith("backup",StringComparison.Ordinal)?"backup":key switch{
        "files" or "remote" or "support" or "tickets" or "agenda"=>"support",
        "updates" or "history" or "windows_update"=>"updates",
        "panel" or "server" or "speed" or "devices" or "map" or "users" or "permissions" or "preferences" or "reports" or "registry_cad" or "release"=>"inventory",
        _=>"maintenance"};
    private static string Cache(GestorConfig config)=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","LocalInterface",Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(config.Origin+"|"+config.SiteCode+"|"+config.Fingerprint+"|"+config.DownloadKey)))+".json");
    public static bool StartsHidden(GestorConfig config){try{var path=Cache(config);return File.Exists(path)&&new FileInfo(path).Length<1024&&JsonSerializer.Deserialize<bool>(File.ReadAllText(path));}catch(Exception e)when(e is IOException or UnauthorizedAccessException or JsonException){return false;}}
    public static void CacheBackground(GestorConfig config,bool background){try{var path=Cache(config);Directory.CreateDirectory(Path.GetDirectoryName(path)!);var temp=path+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(background));File.Move(temp,path,true);}catch(Exception e)when(e is IOException or UnauthorizedAccessException){RuntimeLog.Write("Interface/segundo plano: "+e.Message);}}
}
