// Caminho: gestores/servidor/Arcoll.WinUI3/App.xaml.cs
using Microsoft.UI.Xaml;
using System.Runtime.InteropServices;

namespace Arcoll.WinUI3;

public partial class App : Application
{
    private MainWindow? _window;
    private static Mutex? _instance;
    private static EventWaitHandle? _show;
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBox(IntPtr hWnd, string text, string caption, uint type);
    private static void ReportStartupFailure(Exception error)
    {
        try { Services.RuntimeLog.Write("FALHA NA ABERTURA DO GESTOR: " + error); } catch { }
        try
        {
            MessageBox(IntPtr.Zero,
                "O Gestor não conseguiu iniciar.\n\n" + error.GetBaseException().Message +
                "\n\nDiagnóstico em: " + Services.RuntimeLog.PathName,
                "T.I Digital — Falha na inicialização", 0x10);
        }
        catch { }
    }
    public App()
    {
        InitializeComponent();
        AppDomain.CurrentDomain.UnhandledException += (_, error) =>
            Services.RuntimeLog.Write("FALHA FATAL CLR: " + (error.ExceptionObject?.ToString() ?? "sem detalhes"));
        TaskScheduler.UnobservedTaskException += (_, error) =>
        {
            Services.RuntimeLog.Write("Falha de tarefa assíncrona: " + error.Exception);
            error.SetObserved();
        };
        UnhandledException += (_, error) =>
        {
            // Preserva o diagnostico de falhas de paginas carregadas por eventos XAML/async void.
            // Apenas excecoes gerenciadas recuperaveis sao tratadas; falhas fatais nao sao ocultadas.
            Services.RuntimeLog.Write("Falha na interface WinUI: " + error.Exception);
            // Não marcar como recuperada uma exceção desconhecida de XAML/COM:
            // isso pode deixar a árvore visual em estado inválido.
            if (error.Exception is ArgumentException or InvalidOperationException)
                error.Handled = true;
        };
    }

    /// <summary>
    /// Instância única e execução em segundo plano: com --background (inicialização com o Windows e pós-atualização) a janela não é exibida,
    /// mas autorização, telemetria, presença e comandos continuam ativos. O atalho abre a mesma instância já em execução.
    /// </summary>
    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        var launchArgs=Environment.GetCommandLineArgs();
        var waitIndex=Array.IndexOf(launchArgs,"--wait-exit");
        if(waitIndex>=0&&waitIndex+1<launchArgs.Length&&int.TryParse(launchArgs[waitIndex+1],out var previousPid)&&previousPid!=Environment.ProcessId)
            try{using var previous=System.Diagnostics.Process.GetProcessById(previousPid);previous.WaitForExit(15000);}catch(ArgumentException){}
        var background = Environment.GetCommandLineArgs().Skip(1).Any(a => a.Equals("--background", StringComparison.OrdinalIgnoreCase));
        try
        {
            _instance = new Mutex(true, @"Local\TIDigital.Arcoll.Gestor", out var first);
            _show = new EventWaitHandle(false, EventResetMode.AutoReset, @"Local\TIDigital.Arcoll.Show");
            if (!first)
            {
                // A instância iniciada com o Windows deve exibir a interface quando o atalho for aberto.
                if (!background)
                {
                    Services.RuntimeLog.Write("Atalho acionado: solicitando abertura da instância existente.");
                    _show.Set();
                }
                Environment.Exit(0);
                return;
            }
            Services.RuntimeLog.Write("Inicialização do gestor: criando MainWindow");
            _window = new MainWindow();
            Services.RuntimeLog.Write("Inicialização do gestor: MainWindow criada");
            if (launchArgs.Contains("--pentefino", StringComparer.OrdinalIgnoreCase)) _window.OpenPenteFino();
            if (!background) _window.ShowFromBackground();
            var window = _window;
            var signal = _show;
            _ = Task.Run(() =>
            {
                while (true)
                {
                    try
                    {
                        if (!signal.WaitOne()) continue;
                        if (!window.DispatcherQueue.TryEnqueue(() =>
                        {
                            try { window.ShowFromBackground(); }
                            catch (Exception ex) { Services.RuntimeLog.Write("Falha ao restaurar janela: " + ex); }
                        })) Services.RuntimeLog.Write("Não foi possível encaminhar abertura para a interface.");
                    }
                    catch (ObjectDisposedException) { break; }
                    catch (Exception ex)
                    {
                        Services.RuntimeLog.Write("Canal de abertura: " + ex);
                        break;
                    }
                }
            });
        }
        catch (Exception error)
        {
            ReportStartupFailure(error);
            try { _instance?.Dispose(); _show?.Dispose(); } catch { }
            Environment.Exit(1);
        }
    }
}
