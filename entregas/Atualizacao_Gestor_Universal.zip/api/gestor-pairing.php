<?php
// Caminho: api/gestor-pairing.php
// Esta rota não recebe comandos nem telemetria; o segredo privado autentica a consulta do vínculo.
declare(strict_types=1);
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../includes/gestor-pairing.php';
header('Cache-Control: no-store');
try {
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')arc_json(['ok'=>false,'error'=>'Use POST.'],405);
    if((int)($_SERVER['CONTENT_LENGTH']??0)>4096)arc_json(['ok'=>false,'error'=>'Pedido excessivo.'],413);
    $d=json_decode(file_get_contents('php://input',false,null,0,4097),true);
    if(!is_array($d))arc_json(['ok'=>false,'error'=>'JSON inválido.'],400);
    $token=(string)($d['token']??'');$fp=(string)($d['fingerprint']??'');$action=(string)($d['action']??'');
    if(!preg_match('/^[a-f0-9]{64}$/D',$token)||!preg_match('/^[a-f0-9]{64}$/D',$fp))arc_json(['ok'=>false,'error'=>'Identidade inválida.'],400);
    $pdo=arc_db();arc_ensure_user_schema($pdo);arc_pair_schema($pdo);$hash=hash('sha256',$token);
    if($action==='create') {
        $ip=hash('sha256',(string)($_SERVER['REMOTE_ADDR']??''));
        $limit=max(1,min(1000,(int)arc_platform_setting($pdo,'platform_gestor_pair_limit','20')));
        $q=$pdo->prepare('SELECT COUNT(*) FROM '.arc_table('gestor_pairings').' WHERE ip_hash=? AND created_at>DATE_SUB(NOW(),INTERVAL 1 HOUR)');$q->execute([$ip]);
        if((int)$q->fetchColumn()>=$limit)arc_json(['ok'=>false,'error'=>'Limite de códigos atingido. Tente mais tarde.'],429);
        $pdo->exec('DELETE FROM '.arc_table('gestor_pairings').' WHERE gestor_id IS NULL AND expires_at<DATE_SUB(NOW(),INTERVAL 1 DAY)');
        $ttl=max(60,min(3600,(int)arc_platform_setting($pdo,'platform_gestor_pair_seconds','600')));
        $code=strtoupper(bin2hex(random_bytes(8)));
        $q=$pdo->prepare('INSERT INTO '.arc_table('gestor_pairings').' (token_hash,code_hash,fingerprint,machine_name,platform,ip_hash,created_at,expires_at) VALUES (?,?,?,?,?,?,NOW(),DATE_ADD(NOW(),INTERVAL ? SECOND))');
        $q->execute([$hash,hash('sha256',$code),$fp,mb_substr(trim((string)($d['machine_name']??'Computador')),0,190),mb_substr((string)($d['platform']??'Windows'),0,190),$ip,$ttl]);
        arc_json(['ok'=>true,'code'=>implode('-',str_split($code,4)),'expires_seconds'=>$ttl]);
    }
    if($action!=='status')arc_json(['ok'=>false,'error'=>'Ação inválida.'],400);
    $q=$pdo->prepare('SELECT p.*,(p.expires_at<=NOW()) AS expired,g.site_code FROM '.arc_table('gestor_pairings').' p LEFT JOIN '.arc_table('network_gestores').' g ON g.id=p.gestor_id WHERE p.token_hash=? AND p.fingerprint=? LIMIT 1');$q->execute([$hash,$fp]);$p=$q->fetch(PDO::FETCH_ASSOC);
    if(!$p)arc_json(['ok'=>false,'error'=>'Vínculo não encontrado.'],404);
    if((int)$p['revoked'] || ($p['gestor_id'] && !$p['site_code']))arc_json(['ok'=>true,'status'=>'unlinked']);
    if($p['gestor_id'])arc_json(['ok'=>true,'status'=>'linked','site_code'=>$p['site_code']]);
    arc_json(['ok'=>true,'status'=>(int)$p['expired']?'expired':'pending']);
}catch(Throwable $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();arc_log_error('[gestor-pairing] '.$e->getMessage());arc_json(['ok'=>false,'error'=>'Não foi possível processar o vínculo.'],500);}
