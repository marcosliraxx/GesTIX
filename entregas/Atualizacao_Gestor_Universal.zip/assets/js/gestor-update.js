/* Caminho: assets/js/gestor-update.js
 * Gestor Windows no cabeçalho da rede: ícone fixo; atividade é exibida no rodapé.
 * - O botão do cabeçalho abre instalador universal / desinstalador; o estado do ícone vem de data-gestor-state.
 * - Nova versão: o aviso chega como notificação no sino, com o botão Atualizar (atualização remota do gestor).
 * - Autônomo: funciona em qualquer página com o cabeçalho de rede. Sem animações de alerta.
 */
(function () {
  'use strict';
  var dialog = document.getElementById('arc-gestor-update-confirm');
  var header = document.getElementById('arc-header-gestor-update');
  if (!dialog || dialog.dataset.arcUpdateInitialized==='1') return;
  dialog.dataset.arcUpdateInitialized='1';

  var cfg = {
    network: Number(dialog.dataset.network || 0),
    base: String(dialog.dataset.base || '/'),
    csrf: String(dialog.dataset.csrf || ''),
    canManage: dialog.dataset.canManage === '1'
  };
  var pollMs = 3000, pollTimer = null, presence = {server:0, received:0, timeout:45, valid:false};
  var state = { loaded: false, gestor: null, published: '', releaseMode: '', platformVersion: '', publicationPending: false, loading: null };
  var sending = false, notice = '', queueBusy = false, localBusyUntil = 0, queueLoading = false, noticeMessage = '';
  var el = {
    version: dialog.querySelector('[data-update-modal-version]'),
    status: dialog.querySelector('[data-update-status]'),
    connection: dialog.querySelector('[data-update-connection]'),
    hint: dialog.querySelector('[data-update-hint]'),
    cancel: dialog.querySelector('[data-update-cancel]'),
    reinstall: dialog.querySelector('[data-update-reinstall]'),
    publish: dialog.querySelector('[data-update-publish]'),
    update: dialog.querySelector('[data-update-confirm]'),
    pick: dialog.querySelector('[data-update-target]'),
    pickWrap: dialog.querySelector('[data-update-target-wrap]')
  };

  var overrideId = 0;
  function target() { return document.getElementById('arc-gestor-target'); }
  function gestorId() { if (overrideId) return overrideId; var t = target(); return t ? Number(t.value || 0) : 0; }

  /* fetch com tempo limite e mensagens legíveis. */
  function request(url, options, timeoutMs) {
    var controller = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, timeoutMs) : null;
    var init = Object.assign({ credentials: 'same-origin', cache: 'no-store' }, options || {});
    if (controller) init.signal = controller.signal;
    return fetch(url, init).then(function (response) {
      return response.text().then(function (text) {
        var data = null;
        try { data = JSON.parse(text); } catch (e) { /* resposta não-JSON */ }
        if (!data) throw new Error(response.ok ? 'Resposta inesperada do servidor.' : 'O servidor respondeu HTTP ' + response.status + '.');
        if (!response.ok || data.ok === false) {
          var failure = new Error(data.error || ('Falha (HTTP ' + response.status + ').'));
          failure.code = data.error_code || ''; throw failure;
        }
        return data;
      });
    }, function (e) {
      if (e && e.name === 'AbortError') throw new Error('Tempo esgotado ao falar com o servidor. Tente novamente.');
      throw new Error('Sem conexão com o servidor.');
    }).finally(function () { if (timer) clearTimeout(timer); });
  }

  /* Ícone do cabeçalho: com qualquer comando em trânsito (na fila ou executando) troca o power pelas duas setas girando. */
  function paintBusy() {
    if (!header) return;
    var busy = sending || queueBusy || Date.now() < localBusyUntil;
    if (header.dataset.busy === (busy ? '1' : '0')) return;
    header.dataset.busy = busy ? '1' : '0';
    if (busy) { header.dataset.idleTitle = header.title; header.title = 'Comando em andamento…'; }
    else if (header.dataset.idleTitle) { header.title = header.dataset.idleTitle; }
    header.setAttribute('aria-busy', busy ? 'true' : 'false');
  }
  function pollQueue() {
    if (queueLoading || document.hidden || !cfg.network) return;
    queueLoading = true;
    fetch(cfg.base + 'api/api.php?action=network-queue', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data || !data.ok || !Array.isArray(data.commands)) return;
        var id = gestorId();
        queueBusy = data.commands.some(function (x) {
          return x && (x.status === 'running' || x.status === 'pending') && (!x.gestor_id || !id || Number(x.gestor_id) === id);
        });
      })
      .catch(function () { /* mantém o último estado */ })
      .then(function () { queueLoading = false; paintBusy(); paintNotification(); });
  }
  function markBusy() { localBusyUntil = Date.now() + 8000; paintBusy(); pollQueue(); }

  function paintPresence() {
    var selected=gestorId()>0, g=state.gestor;
    var elapsed=Math.max(0,(performance.now()-presence.received)/1000);
    var fresh=g&&g.approved&&Number(g.last_seen_unix)>0&&presence.server+elapsed-Number(g.last_seen_unix)<presence.timeout;
    if(g)g.online=presence.valid&&!!fresh;
    var current=!selected?'none':!presence.valid?'unknown':fresh?'online':'offline';
    if(header){header.dataset.gestorState=current;if(header.dataset.busy!=='1')header.title=({none:'Nenhum gestor instalado',unknown:'Comunicação com a plataforma não confirmada',online:'Gestor conectado',offline:'Gestor sem comunicação'})[current]+' — baixar, atualizar ou reinstalar';header.setAttribute('aria-label',header.title);}
    if(el.connection){var connectionLabels={none:'Nenhum gestor selecionado',unknown:'Conexão não confirmada',online:'Gestor conectado',offline:'Gestor sem comunicação'};el.connection.dataset.state=current;el.connection.innerHTML='<i class="fa fa-circle" aria-hidden="true"></i> '+connectionLabels[current];}
    if(el.hint){el.hint.textContent=current==='online'?'Pronto para verificar ou atualizar. As configurações e a identidade serão preservadas.':current==='offline'?'O gestor precisa estar aberto e conectado para receber a atualização.':current==='none'?'Selecione um gestor para continuar.':'Aguarde a confirmação da conexão antes de iniciar.';}
    if(header&&header.dataset.busy==='1')header.dataset.idleTitle=header.title;
    document.dispatchEvent(new CustomEvent('arc:gestor-presence',{detail:{state:current,gestor_id:gestorId(),timeout_seconds:presence.timeout}}));
    render();
  }
  function scheduleRefresh(){clearTimeout(pollTimer);pollTimer=setTimeout(function(){if(document.hidden){scheduleRefresh();return;}refresh();},pollMs);}
  function outdated() { return !!(state.gestor && state.gestor.outdated); }
  function noticeId() { return 'gestor-update-' + gestorId() + '-' + state.published; }

  /* Notificação de nova versão no sino, com o botão Atualizar. */
  function paintNotification() {
    var list = document.querySelector('[data-arc-notify-list]');
    if (!list) return;
    var id = noticeId(), current = list.querySelector('[data-update-notice]');
    if (!outdated()) {
      if (current) { current.remove(); if (window.arcNotifications) window.arcNotifications.refresh(); }
      return;
    }
    var installed = String(state.gestor.version || '').replace(/^v\.?\s*/i, '') || 'desconhecida';
    var detail = 'Instalada: ' + installed + ' · Nova: ' + String(state.published).replace(/^v\.?\s*/i, '') + '.';
    if (current && current.dataset.noticeId === id) {
      var btn = current.querySelector('.button'), msg = current.querySelector('span');
      btn.disabled = !cfg.canManage || sending || queueBusy;
      btn.classList.toggle('is-working', sending || queueBusy);
      btn.lastChild.textContent = sending ? ' Solicitando…' : queueBusy ? ' Atualizando…' : ' Atualizar';
      if (noticeMessage) msg.textContent = noticeMessage; else msg.textContent = current.dataset.noticeDetail;
      return;
    }
    if (current) current.remove();
    var item = document.createElement('div');
    item.className = 'arc-notify-item arc-update-notice-item';
    item.dataset.updateNotice = '1'; item.dataset.noticeId = id;
    item.dataset.noticeTitle = 'Nova versão do gestor'; item.dataset.noticeDetail = detail;
    var title = document.createElement('b'); title.textContent = 'Nova versão do gestor';
    var text = document.createElement('span'); text.textContent = detail;
    var button = document.createElement('button');
    button.type = 'button'; button.className = 'button'; button.disabled = !cfg.canManage || sending;
    button.title = cfg.canManage ? 'Atualizar o gestor remotamente' : 'A atualização remota exige permissão administrativa';
    button.innerHTML = '<i class="fa fa-refresh" aria-hidden="true"></i> Atualizar';
    button.dataset.updateNoticeAction = '1';
    item.addEventListener('click', function () { if (window.arcNotifications) { window.arcNotifications.read(id); window.arcNotifications.refresh(); } });
    item.append(title, text, button);
    list.prepend(item);
    if (window.arcNotifications) window.arcNotifications.refresh();
  }

  function paintOutside() {
    var installed = state.gestor && state.gestor.version ? String(state.gestor.version) : '';
    var versionInfo = document.getElementById('arc-gestor-version-info');
    if (versionInfo) versionInfo.textContent = installed ? 'v. ' + installed.replace(/^v\.?\s*/i, '') : 'v. --';
    document.querySelectorAll('[data-tile-version]').forEach(function (n) {
      var type = n.dataset.tileVersion;
      if (type === 'gestor' || type === 'update') n.textContent = 'v' + (state.published || '--');
    });
    document.querySelectorAll('[data-arc-command="gestor_update"]').forEach(function (btn) {
      btn.title = outdated() ? 'Atualizar o gestor: ' + installed + ' → ' + state.published : 'Atualizar os arquivos do gestor';
      btn.disabled = !cfg.canManage || !gestorId();
    });
    paintNotification();
  }

  function render() {
    if (!el.update && !el.reinstall) {
      if(el.version)el.version.textContent=state.platformVersion?'· '+state.platformVersion:'';
      if(el.hint)el.hint.textContent='Instale para uso independente no computador e na rede local. Vincule à plataforma pelo código do Gestor quando desejar gestão remota.';
      if(el.status)el.status.hidden=true;
      return;
    }
    var selected = gestorId() > 0;
    if (el.version) el.version.textContent = state.published ? '· publicada ' + state.published : '· consultando versão';
    var text = notice;
    if (el.status) { el.status.textContent = text; el.status.hidden = !text; el.status.classList.toggle('is-error', !!text && /não foi possível|falha|erro/i.test(text)); }
    // A ação deve permanecer identificável para o administrador, inclusive
    // quando o computador selecionado não foi reconhecido como Servidor.
    // A publicação continua bloqueada pelo perfil e pela validação da API.
    var canPublish = !!state.gestor && state.gestor.role === 'server';
    if (el.publish) {
      el.publish.hidden = false;
      el.publish.disabled = !cfg.canManage || !canPublish || !state.gestor.online || sending;
      el.publish.title = !cfg.canManage
        ? 'A publicação exige permissão administrativa.'
        : !canPublish
          ? 'Selecione o computador com perfil Gestor Servidor.'
          : !state.gestor.online
            ? 'O Gestor Servidor precisa estar conectado para publicar.'
            : 'Publicar executáveis instalados no Gestor Servidor; não compila uma nova versão.';
    }
    // As três versões são informações diferentes. Uma instalação acima da
    // publicação não é 'em dia' e não deve receber um downgrade automático.
    var installed = state.gestor && state.gestor.version ? String(state.gestor.version) : 'não identificada';
    var versionState = state.gestor && state.gestor.version_state || '';
    var versionSummary = 'Instalada: ' + installed + ' · Publicada para Windows: ' + (state.published || 'não disponível') + ' · Plataforma: ' + (state.platformVersion || 'não disponível') + '.';
    if (!text && versionState === 'ahead') {
      text = versionSummary + ' A instalação é mais recente que a publicação. Publique uma versão Windows válida antes de atualizar; não faça downgrade.';
    } else if (!text && state.publicationPending) {
      text = versionSummary + ' Existem mudanças na plataforma que não foram publicadas como executáveis Windows. Atualizar a plataforma não compila o Gestor.';
    } else if (!text && versionState === 'unknown') {
      text = versionSummary + ' A versão instalada não foi identificada; confira a conexão antes de atualizar.';
    } else if (!text && versionState === 'unpublished') {
      text = versionSummary + ' Não existe uma release Windows válida para comparação.';
    }
    if(el.status){el.status.textContent=text;el.status.hidden=!text;}
    var noRelease = state.releaseMode === 'source' && !!state.gestor && state.gestor.role !== 'server';
    if (noRelease && !text) { text = 'Nenhuma release binária publicada para os Colaboradores. No computador do Servidor, execute PUBLICAR_RELEASE_DO_SERVIDOR.ps1 e depois atualize este Colaborador.'; if (el.status) { el.status.textContent = text; el.status.hidden = false; } }
    if(el.reinstall)el.reinstall.disabled=!cfg.canManage||!selected||sending||!state.gestor?.online||noRelease;
    if (el.update) {
      var publicationBehind = versionState === 'ahead' || versionState === 'unpublished';
      el.update.disabled = !cfg.canManage || !selected || sending || !state.gestor?.online || !!state.gestor?.requires_reinstall || noRelease || publicationBehind;
      el.update.title = publicationBehind ? 'A versão Windows publicada precisa estar atualizada antes desta operação' : !cfg.canManage ? 'Disponível apenas para administradores' : !selected ? 'Nenhum gestor instalado neste computador' : 'Atualizar o gestor remotamente';
    }
  }

  /* Consulta de versões: deduplicada, com tempo limite e repetida enquanto a página estiver aberta. */
  function refresh() {
    if (state.loading) return state.loading;
    state.loading = request(cfg.base + 'api/api.php?action=network-gestor-versions&network_id=' + cfg.network, {}, 15000).then(function (r) {
      state.loaded = true;
      presence={server:Number(r.server_time)||0,received:performance.now(),timeout:Number(r.presence_timeout_seconds)||45,valid:true};
      pollMs=Math.max(1000,Number(r.presence_poll_seconds||3)*1000);
      cfg.canManage = r.can_update === true;
      state.published = String(r.target_version || r.platform_version || r.published_version || '');
      state.releaseMode = String(r.release_mode || '');
      state.platformVersion = String(r.platform_version || '');
      state.publicationPending = r.release_publication_pending === true;
      var id = gestorId();
      state.all = (r.gestores || []).filter(function (a) { return a.approved; });
      if (overrideId && !state.all.some(function (a) { return Number(a.id) === overrideId; })) { overrideId = 0; id = gestorId(); }
      state.gestor = (r.gestores || []).find(function (a) { return Number(a.id) === id; }) || null;
      fillPicker();
    }).catch(function (error) {
      state.loaded = true; presence.valid=false;
      // Nunca esconder um 401/403/erro de rede: o operador deve conhecer o
      // motivo de o botão Atualizar estar indisponível.
      notice = 'Não foi possível verificar a autorização e a versão: ' +
        (error && error.message ? error.message : 'falha ao consultar o servidor');
    }).then(function () {
      state.loading = null; paintPresence(); paintOutside(); render(); scheduleRefresh();
    });
    return state.loading;
  }

  /* Seletor de computador: permite atualizar o Servidor ou qualquer Colaborador, independentemente do computador escolhido no cabeçalho. */
  function fillPicker() {
    if (!el.pick || !el.pickWrap) return;
    var list = state.all || [];
    el.pickWrap.hidden = list.length < 2;
    var current = String(gestorId()), html = '';
    list.forEach(function (g) {
      var label = (g.role === 'server' ? 'Servidor' : 'Colaborador') + ' · ' + g.name + (g.version ? ' · v' + String(g.version).replace(/^v\.?\s*/i, '') : '') + (g.online ? ' · online' : ' · sem comunicação');
      html += '<option value="' + Number(g.id) + '"' + (String(g.id) === current ? ' selected' : '') + '></option>';
    });
    if (el.pick.dataset.sig !== html + current) {
      el.pick.replaceChildren();
      list.forEach(function (g) {
        var o = document.createElement('option'); o.value = String(g.id);
        o.textContent = (g.role === 'server' ? 'Servidor' : 'Colaborador') + ' · ' + g.name + (g.version ? ' · v' + String(g.version).replace(/^v\.?\s*/i, '') : '') + (g.online ? ' · online' : ' · sem comunicação');
        if (String(g.id) === current) o.selected = true; el.pick.appendChild(o);
      });
      el.pick.dataset.sig = html + current;
    }
  }
  if (el.pick) el.pick.addEventListener('change', function () {
    overrideId = Number(el.pick.value || 0); notice = '';
    state.gestor = (state.all || []).find(function (a) { return Number(a.id) === overrideId; }) || null;
    paintPresence(); paintOutside(); render();
  });

  function open() {
    notice = '';
    if (!dialog.open && typeof dialog.showModal === 'function') dialog.showModal();
    if(header)header.setAttribute('aria-expanded',String(dialog.open));
    render(); refresh();
  }
  function close() { if (dialog.open) dialog.close(); }
  dialog.addEventListener('close',function(){if(header)header.setAttribute('aria-expanded','false');});
  function setStatus(text) { notice = text; render(); }

  /* Atualização remota: o servidor valida permissão, gestor online e versão. */
  function queue(force) {
    force=force===true;
    if(force&&!window.confirm('Reinstalar os arquivos do gestor selecionado? As configurações e a identidade serão preservadas.'))return Promise.resolve(false);
    if (sending) return Promise.resolve(false);
    var id = gestorId();
    if (!id) { setStatus('Nenhum gestor instalado neste computador. Use Instalar.'); if (!dialog.open) open(); return Promise.resolve(false); }
    if (!force && state.gestor && (state.gestor.version_state === 'ahead' || state.gestor.version_state === 'unpublished')) {
      setStatus('Não é possível atualizar: a publicação Windows está ausente ou é mais antiga que a versão instalada. Publique uma release válida primeiro.');
      if (!dialog.open) open();
      return Promise.resolve(false);
    }
    sending = true; notice = ''; noticeMessage = ''; render(); paintBusy(); paintNotification();
    return request(cfg.base + 'api/api.php?action=network-command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': cfg.csrf },
      body: JSON.stringify({ network_id: cfg.network, gestor_id: id, command: 'gestor_update', force_update: force, _csrf: cfg.csrf })
    }, 25000).then(function (data) {
      var commandId = Number(data.command_id || 0);
      document.dispatchEvent(new CustomEvent('arc:gestor-update-queued', { detail: { command_id: commandId, gestor_id: id, mode: force?'force':'normal' } }));
      document.dispatchEvent(new CustomEvent('arc:command-queued', { detail: { command: 'gestor_update', command_id: commandId, gestor_id: id } }));
      sending = false; noticeMessage = 'Atualização solicitada. Acompanhe pelo ícone do cabeçalho.';
      markBusy();
      if (dialog.open) close();
      render(); paintNotification();
      setTimeout(function () { noticeMessage = ''; paintNotification(); }, 8000);
      return true;
    }).catch(function (e) {
      sending = false; paintBusy();
      var message = 'Não foi possível solicitar a atualização: ' + e.message;
      noticeMessage = message;
      if (e.code === 'release_not_published') message = e.message;
      if (e.code === 'gestor_reinstall_required') message = 'A versão do gestor não foi identificada. Reinstale pelo botão Instalar.';
      setStatus(message); paintNotification();
      if (!dialog.open&&typeof dialog.showModal==='function')dialog.showModal();render();
      return false;
    });
  }

  function publishRelease(){
    var g=state.gestor;
    if(!cfg.canManage || sending || !g || g.role!=='server' || !g.online){setStatus('Selecione o Gestor Servidor conectado para publicar.');return;}
    if(!window.confirm('Publicar os executáveis já instalados neste Gestor Servidor? A publicação não compila nem altera a versão instalada.'))return;
    sending=true;notice='Solicitando publicação da versão instalada no Servidor…';render();
    request(cfg.base+'api/api.php?action=network-command',{
      method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':cfg.csrf},
      body:JSON.stringify({network_id:cfg.network,gestor_id:Number(g.id),command:'gestor_update',publish_release:true,_csrf:cfg.csrf})
    },25000).then(function(){notice='Publicação solicitada ao Gestor Servidor. Após concluir, verifique novamente a versão publicada.';})
      .catch(function(e){notice='Falha na solicitação de publicação: '+e.message;})
      .then(function(){sending=false;render();refresh();});
  }
  if(el.publish)el.publish.addEventListener('click',publishRelease);

  /* Ouvintes únicos. */
  if (header) header.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); open(); });
  if (el.cancel) el.cancel.addEventListener('click', function (e) { e.preventDefault(); close(); });
  if(el.reinstall)el.reinstall.addEventListener('click',function(e){e.preventDefault();queue(true);});
  if (el.update) el.update.addEventListener('click', function (e) { e.preventDefault(); queue(); });
  dialog.addEventListener('click', function (e) { if (e.target === dialog) close(); });
  var installLink = dialog.querySelector('[data-update-install]');
  if (installLink) installLink.addEventListener('click', function () { setStatus('Gerando o instalador. O download começa em instantes; execute-o no computador de destino.'); });
  var t = target();
  if (t) t.addEventListener('change', function () { overrideId = 0; state.gestor = null; refresh(); });

  /* Botão Atualizar da notificação: ouvinte delegado em captura, imune a outros ouvintes do sino. */
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-update-notice-action]') : null;
    if (!b) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    if (b.disabled) return;
    var item = b.closest('[data-update-notice]');
    if (window.arcNotifications && item) window.arcNotifications.read(item.dataset.noticeId);
    queue(true);
  }, true);
  document.addEventListener('arc:command-queued', markBusy);
  document.addEventListener('arc:gestor-update-queued', markBusy);
  document.addEventListener('arc:command-finished', function () { localBusyUntil = 0; pollQueue(); });
  window.addEventListener('arc-queue-refresh', pollQueue);

  /* Botões do painel (mosaicos) que também pedem atualização. */
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-arc-command="gestor_update"]') : null;
    if (!b || b.disabled || e.defaultPrevented) return;
    if (!gestorId()) return;
    e.preventDefault(); e.stopImmediatePropagation();
    queue(true);
  }, true);

  window.arcGestorUpdate = { open: open, refresh: refresh, queue: queue };
  refresh();
  pollQueue(); setInterval(pollQueue, 4000); setInterval(paintBusy, 1000);
  setInterval(paintPresence,1000);
  document.addEventListener('visibilitychange',function(){if(!document.hidden){paintPresence();refresh();}});
  window.addEventListener('online',refresh);
  window.addEventListener('offline',function(){presence.valid=false;paintPresence();});
})();
