// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Pairing.cs
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Arcoll.WinUI3.Services;
namespace Arcoll.WinUI3;
public sealed partial class MainWindow
{
    private async void PlatformPair_Click(object sender,RoutedEventArgs e)
    {
        if(!_runtime.Platform.Config.IsStandalone)return;
        PlatformPairButton.IsEnabled=false;
        var text=new TextBlock{Text="Preparando código…",TextWrapping=TextWrapping.Wrap,IsTextSelectionEnabled=true};
        var dialog=new ContentDialog{Title="Vincular à plataforma online",Content=text,CloseButtonText="Fechar",XamlRoot=RootGrid.XamlRoot};
        using var stop=new CancellationTokenSource();
        dialog.Closed+=(_,_)=>stop.Cancel();
        try{
            var cfg=_runtime.Platform.Config;
            var pair=await PairingService.BeginAsync(cfg,stop.Token);
            text.Text="Código: "+pair.Code+"\n\nNa plataforma, abra Redes → Liberação, crie ou selecione um vínculo vazio e informe este código.\nVálido por "+pair.Seconds+" segundos. O vínculo habilita a gestão remota conforme as permissões da rede.";
            var shown=dialog.ShowAsync();
            while(!stop.IsCancellationRequested){
                await Task.Delay(3000,stop.Token);
                var status=await PairingService.StatusAsync(cfg,pair.Token,stop.Token);
                if(status=="linked"){await _runtime.RecheckAsync();dialog.Hide();break;}
                if(status is "expired" or "unlinked"){text.Text="Código expirado ou cancelado. Feche e abra novamente para gerar outro código.";break;}
            }
            await shown;
        }catch(OperationCanceledException){}catch(Exception ex){dialog.Hide();StatusBar.Title="Vinculação";StatusBar.Message=ex.Message;StatusBar.IsOpen=true;}
        finally{PlatformPairButton.IsEnabled=true;}
    }
}
