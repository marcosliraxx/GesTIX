# Caminho: gestores/servidor/Arcoll.WinUI3/INSTALAR_WINUI3.ps1
# Instalacao e atualizacao, POR MAQUINA (ProgramData, todos os usuarios), do gestor Windows nativo (C# WinUI 3): atalhos, execucao em segundo plano e progresso em porcentagem.
# -Update: troca silenciosa disparada pelo proprio gestor (atualizacao remota); -ForceRebuild: reinstalacao integral (build limpo).
[CmdletBinding()]
param([switch]$Update,[int]$ParentPid=0,[switch]$ForceRebuild,[switch]$Unattended,[string]$UpdateId,[switch]$Integrated,[string]$InstallProgressPath='',[ValidateSet('Machine','User')][string]$InstallScope='Machine')
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
# Implantacao por ferramenta de TI: nao abre UAC nem qualquer confirmacao local.
# Falha antes de alterar arquivos se a ferramenta nao forneceu token administrativo.
if ($Unattended) {
    $isDeploymentAdmin = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isDeploymentAdmin) {
        [Console]::Error.WriteLine('Implantacao sem interacao exige contexto administrativo fornecido pela ferramenta de TI. Nenhuma janela UAC sera aberta.')
        exit 5
    }
}

# Instalacao por maquina: grava em ProgramData, atalhos publicos e inicializacao para qualquer usuario. Pede elevacao (UAC) uma unica vez.
$isAdminNow = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($InstallScope -eq 'User' -and ($Update -or $Unattended)) { throw 'Instalacao por usuario requer uma instalacao interativa.' }
if (-not $isAdminNow -and $InstallScope -eq 'Machine' -and -not $Update -and -not $Unattended -and $PSCommandPath) {
    try {
        $relaunch = @('-NoProfile','-ExecutionPolicy','Bypass','-File','"'+$PSCommandPath+'"')
        if ($ForceRebuild) { $relaunch += '-ForceRebuild' }
        if ($Integrated) { $relaunch += '-Integrated' }
        $relaunch += @('-InstallScope', $InstallScope)
        if ($InstallProgressPath) { $relaunch += @('-InstallProgressPath', '"'+$InstallProgressPath+'"') }
        Write-Output '[36] Aguardando autorização administrativa do Windows...'
        $p = Start-Process -FilePath (Get-Process -Id $PID).Path -ArgumentList $relaunch -Verb RunAs -PassThru
        # Aguarda apenas o PowerShell elevado; -Wait acompanhava o Gestor filho (persistente).
        $p.WaitForExit()
        exit $p.ExitCode
    } catch { throw ('Instalacao por maquina exige aprovacao administrativa; nenhuma instalacao por usuario sera iniciada automaticamente. ' + $_.Exception.Message) }
}
$root = $PSScriptRoot
# Mensagens do MSBuild/.NET em ingles e UTF-8: evita texto corrompido nos logs e facilita a busca por erros.
$env:DOTNET_CLI_UI_LANGUAGE = 'en'
$env:VSLANG = '1033'
$env:DOTNET_NOLOGO = '1'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$publish = $null
$swapped = $false
$inPlace = $false
$previous = $null
$bootStatus = $null
$taskWasSuspended = $false
$taskNameToResume = 'TI-Digital Gestor Windows'
$updateOperationId = $UpdateId
$machineRoot = Join-Path $env:ProgramData 'TI-Digital'
$destination = if ($InstallScope -eq 'User') { Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3' } else { Join-Path $machineRoot 'WinUI3' }
if ($Update) { $destination = if (Test-Path -LiteralPath (Join-Path $machineRoot 'WinUI3\Arcoll.WinUI3.exe')) { Join-Path $machineRoot 'WinUI3' } else { Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3' } }
if ($Update -and $destination -eq (Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3')) { $InstallScope = 'User' }
$legacyDestination = Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3'
if ($InstallScope -eq 'Machine') {
 New-Item -ItemType Directory -Path $machineRoot -Force -ErrorAction SilentlyContinue | Out-Null
 try { & icacls.exe $machineRoot '/grant' '*S-1-5-32-545:(OI)(CI)M' '/T' '/C' '/Q' | Out-Null } catch { }
}
$appName = 'Arcoll.WinUI3.exe'
function Step([int]$Percent,[string]$Message,[int]$Shown=-1) {
    Write-Host ('[' + $Percent + '] ' + $Message)
    if (-not $Update -and $InstallProgressPath) {
        try {
            $line='['+$Percent+'] '+($Message -replace '[\r\n]',' ')
            [IO.File]::AppendAllText($InstallProgressPath,$line+[Environment]::NewLine,(New-Object Text.UTF8Encoding($false)))
        } catch { }
    }
    if ($Update) {
        # Etapas do instalador com porcentagens individuais, sem manter 55% durante a compilacao.
        $shown = switch ($Percent) {
            36 { 55 } 38 { 57 } 45 { 60 } 50 { 63 } 62 { 66 } 82 { 84 } 88 { 89 } 93 { 93 } 96 { 96 } 98 { 98 } 99 { 99 } default { [Math]::Min(99,[Math]::Max(55,$Percent)) }
        }
        if ($Shown -ge 0) { $shown = $Shown }
        try {
            $progressPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\update-progress.json'
            $state = @{ update_id = $updateOperationId; percent = $shown; message = $Message; when = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }
            [IO.File]::WriteAllText($progressPath, ($state | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
        } catch { }
        # O processo anterior deve fechar para substituir os arquivos. O instalador
        # continua informando o progresso pela mesma fila autenticada do gestor.
        try {
            $pendingPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\update-pending.json'
            if (-not (Test-Path -LiteralPath $pendingPath)) { return }
            $pending = Get-Content -LiteralPath $pendingPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([int64]$pending.command_id -le 0) { return }
            $cfgFile = Join-Path $destination 'gestor-config.json'
            $migrating = Join-Path $root 'gestor-config.json'
            if (Test-Path -LiteralPath $migrating) { $cfgFile = $migrating }
            if (-not (Test-Path -LiteralPath $cfgFile)) { return }
            $cfg = Get-Content -LiteralPath $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json
            $endpoint = ([string]$cfg.origin).TrimEnd('/') + '/api/api.php?action=gestor-command-ack'
            $uri = $null
            if (-not [Uri]::TryCreate($endpoint, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo -ne '') { return }
            $body = @{ fingerprint = [string]$cfg.fingerprint; site_code = [string]$cfg.site_code;
                       download_key = [string]$cfg.download_key; command_id = [int64]$pending.command_id;
                       status = 'running'; result = 'WinUI 3 ' + $shown + '%: ' + $Message } | ConvertTo-Json -Compress
            Invoke-RestMethod -Uri $endpoint -Method Post -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 8 -MaximumRedirection 0 -ErrorAction Stop | Out-Null
        } catch { } # Desconexao nao interrompe instalacao: o aplicativo retomara o recibo.
    }
}
function Write-UpdateState([string]$Path, [object]$Value) {
    $temp = $Path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temp, ($Value | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
        for ($attempt = 0; $attempt -lt 5; $attempt++) {
            try { Move-Item -LiteralPath $temp -Destination $Path -Force; return }
            catch { if ($attempt -eq 4) { throw }; Start-Sleep -Milliseconds 100 }
        }
    } finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue } }
}
function Write-UpdateResult([bool]$Ok,[string]$Message) {
    if (-not $Update) { return }
    $o = [ordered]@{ update_id = $updateOperationId; ok = $Ok; message = $Message; finished = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }
    # A janela usa um recibo duravel: o gestor pode consumir update-result.json rapidamente.
    try { Write-UpdateState (Join-Path $env:LOCALAPPDATA 'TI-Digital\update-ui-result.json') $o } catch { Write-Warning $_.Exception.Message }
    try { Write-UpdateState (Join-Path $env:LOCALAPPDATA 'TI-Digital\update-result.json') $o } catch { Write-Warning $_.Exception.Message }
}

# Encerra tudo que mantem a pasta da instalacao ocupada: o gestor, o worker de presenca e os processos
# do WebView2 (msedgewebview2.exe), que sobrevivem ao gestor por alguns segundos e usam o painel local.
function Stop-GestorHolders([string]$Folder) {
    $prefix = $Folder.TrimEnd('\') + '\'
    $webProfile = Join-Path $env:LOCALAPPDATA 'TI-Digital\HybridWebView2'
    foreach ($proc in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
        if ([int]$proc.ProcessId -eq $PID) { continue }
        $hit = $false
        if ($proc.ExecutablePath -and $proc.ExecutablePath.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { $hit = $true }
        elseif ($proc.Name -eq 'msedgewebview2.exe' -and $proc.CommandLine -and
            ($proc.CommandLine.IndexOf($webProfile, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
             $proc.CommandLine.IndexOf($Folder, [StringComparison]::OrdinalIgnoreCase) -ge 0)) { $hit = $true }
        if ($hit) { try { Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop } catch { } }
    }
}
# Sincroniza as fontes recebidas com um cache persistente: o MSBuild reaproveita obj/ e so recompila o que mudou.
# A comparacao e por conteudo (SHA-256), pois o pacote traz datas fixas nos arquivos.
function Sync-BuildSource([string]$From, [string]$To) {
    New-Item -ItemType Directory -Path $To -Force | Out-Null
    $fromFull = (Resolve-Path -LiteralPath $From).Path.TrimEnd('\')
    $toFull = (Resolve-Path -LiteralPath $To).Path.TrimEnd('\')
    $keep = @{}
    foreach ($file in Get-ChildItem -LiteralPath $fromFull -Recurse -File -Force -ErrorAction SilentlyContinue) {
        $rel = $file.FullName.Substring($fromFull.Length + 1)
        if ($rel -match '(^|\\)(bin|obj)\\' -or $rel -ieq 'gestor-config.json') { continue }
        $keep[$rel.ToLowerInvariant()] = $true
        $dst = Join-Path $toFull $rel
        $same = $false
        if (Test-Path -LiteralPath $dst -PathType Leaf) {
            $existing = Get-Item -LiteralPath $dst
            if ($existing.Length -eq $file.Length -and
                (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash) { $same = $true }
        }
        if (-not $same) {
            New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $dst -Force
            (Get-Item -LiteralPath $dst).LastWriteTimeUtc = [DateTime]::UtcNow
        }
    }
    foreach ($old in Get-ChildItem -LiteralPath $toFull -Recurse -File -Force -ErrorAction SilentlyContinue) {
        $rel = $old.FullName.Substring($toFull.Length + 1)
        if ($rel -match '(^|\\)(bin|obj)\\') { continue }
        if (-not $keep.ContainsKey($rel.ToLowerInvariant())) { Remove-Item -LiteralPath $old.FullName -Force -ErrorAction SilentlyContinue }
    }
}
# Executa um comando longo (compilacao) mostrando andamento real: a porcentagem avanca a cada poucos segundos
# em vez de ficar parada, e a plataforma recebe o mesmo andamento pela fila de operacoes.
function Invoke-WithBeat([string]$Exe, [string[]]$ArgList, [string]$LogPath, [int]$From, [int]$To, [string]$Label, [bool]$Append = $false) {
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $started = Get-Date; $lastBeat = Get-Date
    if (-not $Append -and (Test-Path -LiteralPath $LogPath)) { Remove-Item -LiteralPath $LogPath -Force -ErrorAction SilentlyContinue }
    try {
        & $Exe @ArgList 2>&1 | ForEach-Object {
            $line = [string]$_
            try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 } catch { }
            Write-Host $line
            $now = Get-Date
            if (($now - $lastBeat).TotalSeconds -ge 12) {
                $lastBeat = $now
                $elapsed = ($now - $started).TotalSeconds
                $pct = [int]($From + ($To - $From) * (1 - [Math]::Exp(-$elapsed / 120)))
                Step $From ($Label + ' (' + [TimeSpan]::FromSeconds([int]$elapsed).ToString('mm\:ss') + ')') $(if($Integrated){$From}else{[Math]::Min($To, [Math]::Max($From, $pct))})
            }
        }
    } finally { $ErrorActionPreference = $previousPreference }
    return $LASTEXITCODE
}

# Two-way handoff: a running UI explicitly acknowledges staging before any file replacement.
function Invoke-IntegratedHandoff([string]$Id,[int]$GestorPid,[string]$StateRoot) {
    if($Id -notmatch '^[a-f0-9]{32}$' -or $GestorPid -le 0){throw 'Identificacao da atualizacao integrada invalida.'}
    $gestor=Get-Process -Id $GestorPid -ErrorAction Stop
    $expected=Join-Path $StateRoot 'WinUI3\Arcoll.WinUI3.exe'
    if($gestor.ProcessName -ne 'Arcoll.WinUI3' -or $gestor.Path -ne $expected){throw 'Processo pai nao pertence ao gestor instalado.'}
    $file=Join-Path $StateRoot 'update-handoff.json'
    $temp=$file+'.'+[guid]::NewGuid().ToString('N')
    [IO.File]::WriteAllText($temp,(@{update_id=$Id;ready=$true}|ConvertTo-Json -Compress),(New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $file -Force
    $ack=Join-Path $StateRoot 'update-handoff-ack.json'
    $until=(Get-Date).AddSeconds(45);$approved=$false
    while((Get-Date) -lt $until){
        if(Test-Path -LiteralPath $ack){try{$value=Get-Content -LiteralPath $ack -Raw -Encoding UTF8|ConvertFrom-Json;if([string]$value.update_id -eq $Id){$approved=$true;break}}catch{}}
        if($gestor.HasExited){throw 'O gestor encerrou sem confirmar a troca; instalacao anterior preservada.'}
        Start-Sleep -Milliseconds 200
    }
    if(-not $approved){throw 'A interface nao confirmou a troca; instalacao anterior preservada.'}
    if(-not $gestor.WaitForExit(25000)){Stop-Process -Id $GestorPid -Force -ErrorAction Stop;if(-not $gestor.WaitForExit(10000)){throw 'O executavel anterior nao foi liberado.'}}
}

# Mantem estado e historico mesmo em instalacoes novas, sem pasta TI-Digital anterior.
New-Item -ItemType Directory -Path (Join-Path $env:LOCALAPPDATA 'TI-Digital') -Force | Out-Null
$logs = Join-Path $env:LOCALAPPDATA 'TI-Digital\logs'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$log = Join-Path $logs ('Instalar-WinUI3-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Start-Transcript -Path $log -Force | Out-Null
try {
    Write-Host ('T.I Digital - ' + $(if ($Update) { 'Atualizacao' } else { 'Instalacao' }) + ' do Gestor Windows') -ForegroundColor Cyan
    if ($Update) {
        $pendingPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\update-pending.json'
        $pending = $null
        if (Test-Path -LiteralPath $pendingPath) { $pending = Get-Content -LiteralPath $pendingPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        if (-not $updateOperationId -and $pending) { $updateOperationId = [string]$pending.update_id }
        if (-not $updateOperationId) { $updateOperationId = [guid]::NewGuid().ToString('N') }
        if ($pending) {
            $pending | Add-Member -NotePropertyName update_id -NotePropertyValue $updateOperationId -Force
            Write-UpdateState $pendingPath $pending
        }
        $viewer = Join-Path $root 'ATUALIZACAO_VISUAL.ps1'
        if (-not $Integrated -and -not $Unattended -and [Environment]::UserInteractive -and (Get-Process -Id $PID).SessionId -ne 0 -and (Test-Path -LiteralPath $viewer)) {
            try {
                $viewerArgs = '-NoLogo -NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $viewer + '" -UpdateId "' + $updateOperationId + '"'
                Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $viewerArgs -WindowStyle Hidden | Out-Null
            } catch { Write-Warning ('Janela de progresso indisponivel: ' + $_.Exception.Message) }
        }
    }
    Step 36 'Verificando requisitos do Windows...'
    if ($Update -and -not $Integrated -and $ParentPid -gt 0) {
        Step 38 'Aguardando o gestor encerrar...'
        $parent = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
        if ($parent -and $parent.ProcessName -eq 'Arcoll.WinUI3') {
            if (-not $parent.WaitForExit(25000)) {
                Stop-Process -Id $ParentPid -Force -ErrorAction SilentlyContinue
                try { $parent.WaitForExit(15000) | Out-Null } catch { }
            }
        }
    }
    if ([Environment]::OSVersion.Version.Build -lt 19041) { throw 'Necessario Windows 10 2004 (build 19041) ou superior.' }
    $project = Join-Path $root 'Arcoll.WinUI3.csproj'
    # O servidor publica VERSION automaticamente; os .csproj nao possuem versao fixa.
    $versionPath = Join-Path $root 'VERSION'
    if (-not (Test-Path -LiteralPath $versionPath)) { throw 'Pacote sem VERSION publicado pela plataforma.' }
    $publishedVersion = (Get-Content -LiteralPath $versionPath -Raw -Encoding UTF8).Trim()
    if ($publishedVersion -notmatch '^\d+(\.\d+){1,4}$') { throw 'VERSION do pacote e invalido.' }
    $assemblyVersion = (($publishedVersion.Split('.') | Select-Object -First 4) -join '.')
    $buildVersionArg = "-p:Version=$publishedVersion;AssemblyVersion=$assemblyVersion;FileVersion=$assemblyVersion;InformationalVersion=$publishedVersion"

    $required = @('App.xaml', 'MainWindow.xaml', 'app.manifest', 'PreLogin-Setup.ps1'); if (-not $Update) { $required += 'gestor-config.json' }
    foreach ($file in $required) {
        if (-not (Test-Path -LiteralPath (Join-Path $root $file))) { throw "Arquivo ausente: $file" }
    }
    # Detectar SDK 8 sem depender do PATH de uma sessao antiga.
    $dotnetExe = (Get-Command dotnet.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
    $defaultDotnet = Join-Path ${env:ProgramFiles} 'dotnet\dotnet.exe'
    if (-not $dotnetExe -and (Test-Path -LiteralPath $defaultDotnet)) { $dotnetExe = $defaultDotnet }
    $hasSdk = $false
    if ($dotnetExe) {
        $sdkList = @(& $dotnetExe --list-sdks 2>&1)
        $hasSdk = [bool](@($sdkList | Where-Object { $_ -match '^8\.' }).Count)
    }
    if (-not $hasSdk) {
        Write-Host 'SDK .NET 8 nao encontrado. Instalando pelo WinGet (Microsoft)...' -ForegroundColor Yellow
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) {
            throw 'WinGet indisponivel. Instale o SDK .NET 8 em https://dotnet.microsoft.com/download/dotnet/8.0 e execute o BAT novamente.'
        }
        # Instalacao solicitada pelo proprio usuario ao executar o BAT.
        # Sem Read-Host, pois o bootstrap funciona em modo nao interativo.
        & $winget.Source install --id Microsoft.DotNet.SDK.8 --exact --source winget --silent --disable-interactivity --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -ne 0) { throw ('Instalacao do SDK .NET 8 pelo WinGet falhou (codigo ' + $LASTEXITCODE + '). Instale-o em https://dotnet.microsoft.com/download/dotnet/8.0 e execute o BAT novamente.') }
        if (Test-Path -LiteralPath $defaultDotnet) {
            $dotnetExe = $defaultDotnet
            $env:PATH = (Split-Path -Parent $defaultDotnet) + ';' + $env:PATH
        }
        if (-not $dotnetExe) { throw 'SDK instalado, mas dotnet.exe nao foi localizado. Reabra o terminal e execute o BAT novamente.' }
        $sdkList = @(& $dotnetExe --list-sdks 2>&1)
        if (-not @($sdkList | Where-Object { $_ -match '^8\.' }).Count) {
            throw 'SDK .NET 8 ainda nao detectado. Reabra o terminal e execute o BAT novamente.'
        }
    }
    Step 45 'SDK .NET 8 disponivel.'
    if ($ForceRebuild) { foreach ($d in 'bin','obj','BootWorker\bin','BootWorker\obj') { $path = Join-Path $root $d; if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue } } }
    # Cache persistente de compilacao: a primeira atualizacao compila tudo; as seguintes recompilam apenas o que mudou.
    $buildRoot = $root
    if ($Update) {
        $cacheRoot = Join-Path $env:LOCALAPPDATA 'TI-Digital\BuildCache\src'
        try {
            if ($ForceRebuild -and (Test-Path -LiteralPath $cacheRoot)) { Remove-Item -LiteralPath $cacheRoot -Recurse -Force -ErrorAction Stop }
            Step 46 'Preparando compilacao incremental...'
            Sync-BuildSource $root $cacheRoot
            $buildRoot = $cacheRoot
            $project = Join-Path $buildRoot 'Arcoll.WinUI3.csproj'
            if (-not (Test-Path -LiteralPath $project)) { throw 'Projeto ausente no cache.' }
        } catch {
            Write-Warning ('Cache de compilacao indisponivel (' + $_.Exception.Message + '); compilando a partir do pacote recebido.')
            $buildRoot = $root
            $project = Join-Path $root 'Arcoll.WinUI3.csproj'
        }
    }
    $arch = if ([Environment]::Is64BitOperatingSystem) { 'win-x64' } else { '' }
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'win-arm64' }
    if (-not $arch) { throw 'Windows de 32 bits nao suportado.' }
    $platform = if ($arch -eq 'win-arm64') { 'ARM64' } else { 'x64' }
    $publish = Join-Path $env:TEMP ('ti-digital-winui-build-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $publish | Out-Null
    # Nao instalar uma interface incompleta que quebraria o Painel apos a troca.
    foreach ($asset in @('index.html', 'styles.css', 'app.js')) {
        $assetPath = Join-Path $buildRoot ('Assets\hybrid\dashboard\' + $asset)
        if (-not (Test-Path -LiteralPath $assetPath -PathType Leaf)) {
            throw ('Pacote de distribuicao incompleto: Assets\hybrid\dashboard\' + $asset)
        }
        if ((Get-Item -LiteralPath $assetPath).Length -eq 0) {
            throw ('Recurso visual vazio: ' + $asset)
        }
    }
    Step 50 'Restaurando pacotes assinados da Microsoft pelo NuGet...'
    & $dotnetExe restore $project $buildVersionArg "-p:Platform=$platform" "-p:RuntimeIdentifier=$arch"
    if ($LASTEXITCODE -ne 0) { throw 'Restauracao do projeto falhou. Consulte o log.' }
    # Validacao previa: o App.xaml deve constar uma unica vez como ApplicationDefinition.
    # Duplicidade faz o XamlCompiler.exe encerrar com codigo 1 sem mensagem.
    $appDefs = $null
    try {
        $rawItems = & $dotnetExe msbuild $project $buildVersionArg -nologo -getItem:ApplicationDefinition "-p:Platform=$platform" "-p:RuntimeIdentifier=$arch" 2>$null | Out-String
        $appDefs = @(($rawItems | ConvertFrom-Json).Items.ApplicationDefinition)
    } catch { $appDefs = $null }
    if ($appDefs -and $appDefs.Count -gt 1) { throw ('Projeto invalido: App.xaml declarado ' + $appDefs.Count + ' vezes no .csproj.') }
    Step 62 'Compilando a interface nativa C#...'
    # Preferir o MSBuild do Visual Studio quando presente.
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    $msbuild = $null
    if (Test-Path -LiteralPath $vswhere) {
        $foundMsbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' 2>$null
        if ($foundMsbuild) { $msbuild = @($foundMsbuild)[0] }
    }
    $buildLog = Join-Path $logs ('Compilacao-WinUI3-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
    $binLog = [System.IO.Path]::ChangeExtension($buildLog, '.binlog')
    $baseMsbuild = @('/nologo','/m:1','/t:Build','/p:Configuration=Release',"/p:Platform=$platform", "/p:RuntimeIdentifier=$arch",'/p:WindowsPackageType=None','/p:WindowsAppSDKSelfContained=true','/v:normal',"/bl:$binLog")
    if ($msbuild) {
        Write-Host ('Compilando com Visual Studio MSBuild: ' + $msbuild)
        $result = Invoke-WithBeat $msbuild (@($project, $buildVersionArg) + $baseMsbuild) $buildLog 66 82 'Compilando a interface nativa' $false
    } else {
        Write-Host 'MSBuild do Visual Studio nao encontrado; usando MSBuild do SDK .NET.'
        $result = Invoke-WithBeat $dotnetExe (@('msbuild', $project, $buildVersionArg) + $baseMsbuild) $buildLog 66 82 'Compilando a interface nativa' $false
    }
    if ($result -ne 0) {
        Write-Host ('Compilacao falhou (codigo ' + $result + ').') -ForegroundColor Red
        if (Test-Path -LiteralPath $buildLog) { Get-Content -LiteralPath $buildLog -Tail 35 | ForEach-Object { Write-Host $_ } }
        Write-Host ('Log: ' + $buildLog)
        Write-Host ('Diagnostico MSBuild: ' + $binLog)
        # Preservar a resposta estruturada do compilador XAML para obter o erro original.
        $objDir = Join-Path $buildRoot 'obj'
        if (Test-Path -LiteralPath $objDir) {
            # Exibe no proprio log a resposta do compilador XAML (erros reais de XAML).
            Get-ChildItem -LiteralPath $objDir -Recurse -File -Filter 'output.json' -ErrorAction SilentlyContinue | ForEach-Object {
                $txt = Get-Content -LiteralPath $_.FullName -Raw -ErrorAction SilentlyContinue
                if ($txt) { Write-Host ('XamlCompiler output.json: ' + $txt.Substring(0, [Math]::Min(3000, $txt.Length))) }
            }
            $diagnosticDir = Join-Path $logs ('Xaml-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
            New-Item -ItemType Directory -Path $diagnosticDir -Force | Out-Null
            Get-ChildItem -LiteralPath $objDir -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -in @('input.json','output.json') } | ForEach-Object {
                    $relative = $_.FullName.Substring($objDir.Length).TrimStart('\')
                    $destFile = Join-Path $diagnosticDir $relative
                    New-Item -ItemType Directory -Path (Split-Path -Parent $destFile) -Force | Out-Null
                    Copy-Item -LiteralPath $_.FullName -Destination $destFile -Force
                }
            Write-Host ('Diagnosticos XAML: ' + $diagnosticDir)
        }
        # A etapa XamlPreCompile tambem compila C#: nao rotular todo erro como XAML.
        # Mostrar no resultado o primeiro erro real, com arquivo e linha quando disponiveis.
        $diagnosis = $null
        if (Test-Path -LiteralPath $buildLog) {
            $errorLines = @(Get-Content -LiteralPath $buildLog -ErrorAction SilentlyContinue |
                Where-Object { $_ -match '(?i)(: error (CS[0-9]+|XLS[0-9]+|MC[0-9]+|MSB[0-9]+|NETSDK[0-9]+)|\berror [A-Z]+[0-9]+:)' -and $_ -notmatch '(?i)error MSB3073:.*XamlCompiler\.exe' } |
                Select-Object -Unique -First 8)
            foreach ($line in $errorLines) { Write-Host ('ERRO DE COMPILACAO: ' + $line) -ForegroundColor Red }
            if ($errorLines.Count -gt 0) { $diagnosis = ($errorLines[0] -replace '^\s+', '').Trim() }
        }
        if (-not $diagnosis) {
            $diagnosis = 'Compilacao WinUI falhou sem erro especifico no log; consulte output.json, input.json e Compilacao-WinUI3-*.binlog.'
        }
        # A mensagem precisa chegar ao AGestor e ao historico de atualizacoes.
        # A compilacao interrompida nao substitui a instalacao anterior.
        throw ('Falha na compilacao do Gestor (codigo ' + $result + '): ' + $diagnosis)

    }
    Step 82 'Compilacao concluida. Publicando arquivos...'
    $publishCode = Invoke-WithBeat $dotnetExe @('publish', $project, $buildVersionArg, '-c', 'Release', '-r', $arch, '--self-contained', 'true', '-p:WindowsPackageType=None', '-p:WindowsAppSDKSelfContained=true', "-p:Platform=$platform", '-p:PublishReadyToRun=false', '-p:PublishTrimmed=false', '-o', $publish, '--no-restore') $buildLog 84 88 'Publicando arquivos' $true
    if ($publishCode -ne 0) { throw ('Publicacao falhou, codigo ' + $publishCode + '. Veja ' + $buildLog) }
    # A publicacao do SDK nem sempre transporta arquivos Content para a pasta final.
    # Copiar explicitamente o catalogo usado na inicializacao e validar antes de trocar a instalacao.
    $menuSource = Join-Path $buildRoot 'Assets\workspace-menu.json'
    $menuPublished = Join-Path $publish 'Assets\workspace-menu.json'
    if (-not (Test-Path -LiteralPath $menuSource -PathType Leaf)) {
        throw 'Pacote incompleto: Assets\workspace-menu.json ausente da origem. Instalacao existente preservada.'
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $menuPublished) -Force | Out-Null
    Copy-Item -LiteralPath $menuSource -Destination $menuPublished -Force
    if (-not (Test-Path -LiteralPath $menuPublished -PathType Leaf)) {
        throw 'Publicacao incompleta: catalogo de navegacao ausente. Instalacao existente preservada.'
    }
    $exe = Join-Path $publish 'Arcoll.WinUI3.exe'
    if (-not (Test-Path $exe)) { throw 'Executavel nao encontrado apos a compilacao.' }
    foreach ($asset in @('index.html', 'styles.css', 'app.js')) {
        $publishedAsset = Join-Path $publish ('Assets\hybrid\dashboard\' + $asset)
        if (-not (Test-Path -LiteralPath $publishedAsset -PathType Leaf)) {
            throw ('Publicacao incompleta: painel hibrido sem ' + $asset + '. A instalacao anterior nao sera alterada.')
        }
    }
    # Compila somente a presenca de boot (sem UI e sem comandos remotos).
    # Instalada em Program Files pela etapa administrativa; nunca execute WinUI em Session 0.
    $bootProject = Join-Path $buildRoot 'BootWorker\BootWorker.csproj'
    $bootPublish = Join-Path $env:TEMP ('ti-digital-boot-build-' + [guid]::NewGuid().ToString('N'))
    if (-not (Test-Path -LiteralPath $bootProject)) { throw 'Projeto BootWorker ausente no pacote.' }
    try {
        & $dotnetExe publish $bootProject $buildVersionArg -c Release -r $arch --self-contained true -p:PublishTrimmed=false -p:PublishReadyToRun=false -o $bootPublish
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $bootPublish 'TIDigital.BootPresence.exe'))) {
            throw 'Falha na compilacao do worker de inicializacao antes do login.'
        }
        Copy-Item -LiteralPath (Join-Path $root 'ATUALIZACAO_VISUAL.ps1') -Destination (Join-Path $publish 'ATUALIZACAO_VISUAL.ps1') -Force
        Copy-Item -LiteralPath (Join-Path $root 'PreLogin-Setup.ps1') -Destination (Join-Path $publish 'PreLogin-Setup.ps1') -Force
        Copy-Item -LiteralPath (Join-Path $root 'HABILITAR_PRELOGIN.ps1') -Destination (Join-Path $publish 'HABILITAR_PRELOGIN.ps1') -Force
        Copy-Item -Path $bootPublish -Destination (Join-Path $publish 'BootWorker') -Recurse -Force
    } finally {
        if (Test-Path -LiteralPath $bootPublish) { Remove-Item -LiteralPath $bootPublish -Recurse -Force -ErrorAction SilentlyContinue }
    }
    # Backup independente: publica binarios, mas a tarefa SYSTEM exige instalacao explicita.
    $backupProject = Join-Path $buildRoot 'BackupWorker\BackupWorker.csproj'
    $backupPublish = Join-Path $env:TEMP ('ti-digital-backup-build-' + [guid]::NewGuid().ToString('N'))
    try {
        & $dotnetExe publish $backupProject $buildVersionArg -c Release -r $arch --self-contained true -p:PublishTrimmed=false -o $backupPublish
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $backupPublish 'TIDigital.BackupWorker.exe'))) { throw 'Falha ao publicar executor de backup.' }
        Copy-Item -Path $backupPublish -Destination (Join-Path $publish 'BackupWorker') -Recurse -Force
        Copy-Item -LiteralPath (Join-Path $root 'INSTALAR_BACKUP_SERVICO.ps1') -Destination $publish -Force
    } finally { if (Test-Path -LiteralPath $backupPublish) { Remove-Item -LiteralPath $backupPublish -Recurse -Force -ErrorAction SilentlyContinue } }
    if($Update -and $Integrated){Step 87 'Arquivos preparados; reiniciando o gestor...';Invoke-IntegratedHandoff $updateOperationId $ParentPid (Join-Path $env:LOCALAPPDATA 'TI-Digital')}
    Step 88 'Instalando arquivos do gestor...'
    # A configuracao (origem, codigo e chave) do computador ja instalado e preservada na atualizacao.
    $installedConfig = Join-Path $destination 'gestor-config.json'
    # A ponte de migracao do Python fornece a mesma identidade revogavel no pacote ja
    # autenticado. Em atualizacoes WinUI normais nao ha config no ZIP; preserve a instalada.
    # Dar prioridade ao cadastro migrado evita reativar uma rede antiga instalada em paralelo.
    $migratedConfig = Join-Path $root 'gestor-config.json'
    if ($Update -and (Test-Path -LiteralPath $migratedConfig)) { Copy-Item -LiteralPath $migratedConfig -Destination (Join-Path $publish 'gestor-config.json') -Force }
    elseif ($Update -and (Test-Path -LiteralPath $installedConfig)) { Copy-Item -LiteralPath $installedConfig -Destination (Join-Path $publish 'gestor-config.json') -Force }
    elseif (Test-Path -LiteralPath $migratedConfig) { Copy-Item -LiteralPath $migratedConfig -Destination (Join-Path $publish 'gestor-config.json') -Force }
    else { throw 'gestor-config.json ausente: reinstale pelo painel da plataforma.' }
    # Encerrar apenas instâncias desta instalação; o worker pode manter arquivos da pasta abertos.
    $running = @(Get-Process -Name 'Arcoll.WinUI3','TIDigital.BootPresence' -ErrorAction SilentlyContinue | Where-Object {
        try { $_.Path -and $_.Path.StartsWith(($destination.TrimEnd('\') + '\'),[StringComparison]::OrdinalIgnoreCase) } catch { $false }
    })
    foreach ($process in $running) {
        try { $process.CloseMainWindow() | Out-Null } catch { }
    }
    Start-Sleep -Seconds 2
    foreach ($process in $running) {
        try { if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force -ErrorAction Stop } } catch { Write-Warning ('Não foi possível encerrar ' + $process.ProcessName + ': ' + $_.Exception.Message) }
        try { $process.WaitForExit(15000) | Out-Null } catch { }
    }
    Stop-GestorHolders $destination
    Start-Sleep -Milliseconds 700
    $stage = Join-Path $env:LOCALAPPDATA ('TI-Digital\WinUI3-stage-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    Copy-Item -Path (Join-Path $publish '*') -Destination $stage -Recurse -Force
    if (-not (Test-Path (Join-Path $stage $appName))) { throw 'Falha ao preparar os arquivos.' }
    if (-not (Test-Path -LiteralPath (Join-Path $stage 'Assets\workspace-menu.json') -PathType Leaf)) { throw 'Catalogo de navegacao nao foi incluido no pacote preparado.' }
    # Nao mexe em tarefas, servicos ou credenciais do gestor antigo.
    # Um backup antigo pode estar bloqueado: nao impedir a nova instalacao por isso.
    $previous = $destination + '.anterior-' + [guid]::NewGuid().ToString('N')
    if ($Update -and (Test-Path $destination)) {
        # Evita que a inicializacao agendada relance o WinUI durante a troca de pasta.
        try {
            $scheduled = Get-ScheduledTask -TaskName $taskNameToResume -ErrorAction SilentlyContinue
            if ($scheduled -and $scheduled.State -ne 'Disabled' -and @($scheduled.Actions | Where-Object { ([string]$_.Execute).Trim('"') -eq (Join-Path $destination $appName) }).Count) {
                Disable-ScheduledTask -TaskName $taskNameToResume -ErrorAction Stop | Out-Null
                $taskWasSuspended = $true
                Write-Host 'Tarefa do proprio gestor suspensa durante a troca.'
            }
        } catch { Write-Warning ('Nao foi possivel suspender a tarefa do gestor: '+$_.Exception.Message) }
    }
    if (Test-Path $destination) {
        $moved = $false
        for ($retry = 0; $retry -lt 6; $retry++) {
            # O WebView2 e o worker de presenca podem reaparecer durante a compilacao: encerrar de novo antes de cada tentativa.
            Stop-GestorHolders $destination
            try { Move-Item -LiteralPath $destination -Destination $previous -ErrorAction Stop; $moved = $true; break }
            catch { Write-Host ('Aguardando liberar a pasta do gestor, tentativa ' + ($retry + 1) + '/6: ' + $_.Exception.Message); Start-Sleep -Milliseconds 1200 }
        }
        if ($moved) { $swapped = $true }
        else {
            # Plano B: Explorer aberto na pasta, antivirus ou handle residual impedem RENOMEAR a pasta, mas nao impedem
            # trocar os ARQUIVOS. Copia de seguranca primeiro; qualquer falha restaura a instalacao anterior.
            Write-Host 'A pasta continua ocupada; trocando os arquivos diretamente (instalacao anterior copiada para seguranca).' -ForegroundColor Yellow
            Step 90 'Pasta em uso; trocando arquivos diretamente...'
            $robocopy = Join-Path $env:SystemRoot 'System32\robocopy.exe'
            if (-not (Test-Path -LiteralPath $robocopy)) { throw 'Atualização impedida: pasta em uso e robocopy indisponível. Instalação anterior preservada.' }
            & $robocopy $destination $previous /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) { throw ('Atualização impedida: não foi possível copiar a instalação anterior (robocopy ' + $LASTEXITCODE + '). Instalação anterior preservada.') }
            Stop-GestorHolders $destination
            $inPlace = $true
            & $robocopy $stage $destination /E /IS /IT /R:5 /W:2 /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) { throw ('Falha ao gravar os arquivos do gestor (robocopy ' + $LASTEXITCODE + '). Verifique permissões e antivírus.') }
            Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
            $swapped = $true
        }
    }
    if (-not $inPlace) {
        Move-Item -LiteralPath $stage -Destination $destination
        $swapped = $true
    }
    if (-not (Test-Path -LiteralPath (Join-Path $destination 'Assets\workspace-menu.json') -PathType Leaf)) { throw 'Catalogo de navegacao ausente da pasta instalada; restaurando instalacao anterior.' }
    $target = Join-Path $destination $appName
    Step 93 'Criando atalhos...'
    $brandIcon = Join-Path $destination 'Assets\system.ico'
    $shortcutIcon = $target + ',0'
    if (Test-Path -LiteralPath $brandIcon) {
        $iconHash = (Get-FileHash -LiteralPath $brandIcon -Algorithm SHA256).Hash.Substring(0,16)
        $cachedIcon = Join-Path $destination ('system-' + $iconHash + '.ico')
        Copy-Item -LiteralPath $brandIcon -Destination $cachedIcon -Force
        $shortcutIcon = $cachedIcon + ',0'
    }
    $shell = New-Object -ComObject WScript.Shell
    $isAdminInstall = ($InstallScope -eq 'Machine')
    $programs = if ($isAdminInstall) { [Environment]::GetFolderPath('CommonPrograms') } else { Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs' }
    $desktopFolder = if ($isAdminInstall) { [Environment]::GetFolderPath('CommonDesktopDirectory') } else { [Environment]::GetFolderPath('Desktop') }
    # Remove atalhos e inicializacao da instalacao antiga por usuario (LocalAppData).
    if ($legacyDestination -ne $destination -and (Test-Path -LiteralPath (Join-Path $legacyDestination 'Arcoll.WinUI3.exe'))) {
        foreach ($oldFolder in @((Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'), [Environment]::GetFolderPath('Desktop'))) {
            Get-ChildItem -LiteralPath $oldFolder -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
                try { if ($shell.CreateShortcut($_.FullName).TargetPath -eq (Join-Path $legacyDestination 'Arcoll.WinUI3.exe')) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue } } catch { }
            }
        }
        try { Get-Process -Name 'Arcoll.WinUI3' -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq (Join-Path $legacyDestination 'Arcoll.WinUI3.exe') } catch { $false } } | Stop-Process -Force -ErrorAction SilentlyContinue } catch { }
    }
    # Nome e ícone do gestor (Admin > Configuracoes): usa o ultimo estado gravado pelo proprio gestor; sem ele, nome padrao.
    $shortcutName = 'T.I Digital - Gestor Windows'
    $brandState = Join-Path $env:LOCALAPPDATA 'Arcoll\brand-shell.json'
    if (Test-Path -LiteralPath $brandState) {
        try {
            $bs = Get-Content -LiteralPath $brandState -Raw -Encoding UTF8 | ConvertFrom-Json
            $bn = ([string]$bs.title) -replace '[\\/:*?"<>|]', ''
            if (-not [string]::IsNullOrWhiteSpace($bn)) { $shortcutName = $bn.Trim() }
            if ($bs.icon -and (Test-Path -LiteralPath ([string]$bs.icon))) { $shortcutIcon = ([string]$bs.icon) + ',0' }
        } catch { Write-Warning 'Identidade anterior do gestor ignorada.' }
    }
    foreach ($legacy in @('T.I Digital - WinUI3 (Teste).lnk', 'T.I Digital - Gestor Windows.lnk')) {
        if ($legacy -eq ($shortcutName + '.lnk')) { continue }
        foreach ($folder in @($programs, $desktopFolder)) {
            $oldShortcut = Join-Path $folder $legacy
            if ($folder -and (Test-Path -LiteralPath $oldShortcut)) { Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue }
        }
    }
    foreach ($folder in @($programs, $desktopFolder)) {
        if (-not $folder -or -not (Test-Path -LiteralPath $folder)) { continue }
        if ($Update -and -not $isAdminInstall) { continue }
        $link = $shell.CreateShortcut((Join-Path $folder ($shortcutName + '.lnk')))
        $link.TargetPath = $target; $link.WorkingDirectory = $destination; $link.IconLocation = $shortcutIcon
        $link.Description = $shortcutName; $link.Save()
    }
    Step 96 'Configurando execucao em segundo plano...'
    $taskName = if ($isAdminInstall) { 'TI-Digital Gestor Windows' } else { 'TI-Digital Gestor Windows - Usuario' }
    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    try {
        $action = New-ScheduledTaskAction -Execute $target -Argument '--background' -WorkingDirectory $destination
        if ($isAdminInstall) {
            # Maquina: dispara no logon de QUALQUER usuario, executando na sessao de quem entrou.
            $trigger = New-ScheduledTaskTrigger -AtLogOn
            $principal = New-ScheduledTaskPrincipal -GroupId 'S-1-5-32-545' -RunLevel Limited
        } else {
            $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
            $trigger = New-ScheduledTaskTrigger -AtLogOn -User $me
            $principal = New-ScheduledTaskPrincipal -UserId $me -LogonType Interactive -RunLevel Limited
        }
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
        Remove-ItemProperty -Path $runKey -Name 'TIDigitalGestor' -ErrorAction SilentlyContinue
    } catch {
        $runKey = if ($isAdminInstall) { 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run' } else { $runKey }
        Write-Host ('Tarefa agendada indisponivel (' + $_.Exception.Message + '); usando a inicializacao ' + $(if ($isAdminInstall) { 'da maquina' } else { 'do usuario' }) + '.')
        if (-not $isAdminInstall -and @(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue | Where-Object { @($_.Actions | Where-Object { ([string]$_.Execute).Trim('"') -eq $target }).Count }).Count) { Write-Host 'Tarefa da maquina ja existente; mantida.' } else {
        New-ItemProperty -Path $runKey -Name 'TIDigitalGestor' -Value ('"' + $target + '" --background') -PropertyType String -Force | Out-Null }
    }
    # Eleva somente a instalacao do componente de boot; preserva o perfil da interface.
    Step 98 'Verificando componente de presenca antes do login...'
    # Resolve a configuracao ainda no perfil original, antes de eventual UAC
    # com credenciais de outro administrador (mesma prioridade de GestorConfig.Load).
    $effectiveConfig = @{}
    foreach ($cfgPath in @((Join-Path $env:APPDATA 'Arcoll\gestor.json'), (Join-Path $destination 'gestor-config.json'), (Join-Path $legacyDestination 'gestor-config.json'))) {
        if (-not (Test-Path -LiteralPath $cfgPath)) { continue }
        try {
            $cfgObject = Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($field in @('origin','site_code','download_key','fingerprint','system_name','mode')) {
                $value = [string]$cfgObject.$field
                if (-not $effectiveConfig.ContainsKey($field) -and -not [string]::IsNullOrWhiteSpace($value)) { $effectiveConfig[$field] = $value.Trim() }
            }
        } catch { Write-Warning ('Configuracao ignorada: ' + $cfgPath) }
    }
    [IO.File]::WriteAllText((Join-Path $destination 'gestor-config.json'), ($effectiveConfig | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    if ($isAdminInstall) {
      . (Join-Path $root 'PreLogin-Setup.ps1')
      $elevated = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
      $bootStatus = Invoke-PreLoginSetup -GestorFolder $destination -LogFolder $logs -Update $Update.IsPresent -Unattended $Unattended.IsPresent -Elevated $elevated
    } else { $bootStatus = @{pending=$false;message='Instalacao por usuario: inicializacao no login, sem componente antes do login.'} }
    [IO.File]::WriteAllText((Join-Path $env:LOCALAPPDATA 'TI-Digital\boot-status.json'), ($bootStatus | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    if ($bootStatus.pending) { Write-Host ('BOOT-PENDING: ' + $bootStatus.message) -ForegroundColor Yellow }
    else { Write-Host $bootStatus.message }
    Step 99 'Iniciando o gestor...'
    $readyPath = Join-Path $env:LOCALAPPDATA 'TI-Digital\native-ready.json'
    if ($Update -and (Test-Path -LiteralPath $readyPath)) { Remove-Item -LiteralPath $readyPath -Force -ErrorAction SilentlyContinue }
    $launched = Start-Process -FilePath $target -WorkingDirectory $destination -PassThru
    if (-not $launched) { throw 'A inicializacao do gestor falhou.' }
    Start-Sleep -Seconds 3
    $active = Get-Process -Id $launched.Id -ErrorAction SilentlyContinue
    if (-not $active -or $active.HasExited) { throw 'O executavel encerrou imediatamente apos a instalacao.' }
    if ($Update) {
        Step 99 'Validando versao e autorizacao do gestor... '
        # Nao basta a janela abrir: a nova instancia precisa estar APROVADA pela
        # plataforma, possuir a mesma identidade e informar a versao publicada.
        $expected = $publishedVersion
        $installedIdentity = Get-Content -LiteralPath (Join-Path $destination 'gestor-config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        $verified = $false
        for ($attempt = 0; $attempt -lt 60; $attempt++) {
            $active = Get-Process -Id $launched.Id -ErrorAction SilentlyContinue
            if (-not $active -or $active.HasExited) { throw 'O gestor encerrou antes de validar a autorizacao.' }
            if (Test-Path -LiteralPath $readyPath) {
                try {
                    $receipt = Get-Content -LiteralPath $readyPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    # Instalações antigas podem não guardar o fingerprint em
                    # gestor-config.json; nesses casos, o próprio gestor o deriva
                    # do MachineGuid e o servidor já validou a identidade.
                    $identityOk = (-not [string]$installedIdentity.fingerprint) -or
                        ([string]$receipt.fingerprint -eq [string]$installedIdentity.fingerprint)
                    if ([int]$receipt.pid -eq $launched.Id -and
                        [string]$receipt.version -eq $expected -and $identityOk -and
                        [int64]$receipt.approved_at -ge ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - 100)) {
                        $verified = $true; break
                    }
                } catch { }
            }
            Start-Sleep -Seconds 2
        }
        if (-not $verified) { throw 'O novo gestor nao confirmou autorizacao e versao na plataforma em 120 segundos. Revertendo a instalacao.' }
    }
    $successMessage = 'Versao e autorizacao confirmadas pela plataforma; gestor atualizado.'
    if ($bootStatus -and $bootStatus.pending) { $successMessage += ' AVISO: ' + $bootStatus.message }
    Write-UpdateResult $true $successMessage
    # Remove sobras de atualizacoes anteriores (copias .anterior/.falhou/.backup/.stage), sem falhar se ainda estiverem ocupadas.
    try {
        $parentFolder = Split-Path -Parent $destination; $leaf = Split-Path -Leaf $destination
        foreach ($left in @(Get-ChildItem -LiteralPath $parentFolder -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like ($leaf + '.*') })) {
            Remove-Item -LiteralPath $left.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
        foreach ($left in @(Get-ChildItem -LiteralPath $parentFolder -Directory -Filter 'WinUI3-stage-*' -ErrorAction SilentlyContinue)) {
            Remove-Item -LiteralPath $left.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    } catch { }
    Write-Host "Instalado em $destination" -ForegroundColor Green
    Step 100 'Instalacao finalizada.'
} catch {
    $failure = $_.Exception.Message
    if ($inPlace -and $previous -and (Test-Path -LiteralPath $previous)) {
        try {
            $robocopy = Join-Path $env:SystemRoot 'System32\robocopy.exe'
            Stop-GestorHolders $destination
            & $robocopy $previous $destination /E /IS /IT /R:5 /W:2 /NFL /NDL /NJH /NJS /NP | Out-Null
            Write-Host 'Reversao: versao anterior restaurada.' -ForegroundColor Yellow
            $failure += ' A versao anterior foi restaurada.'
        } catch { $failure += ' Falha na reversao automatica: ' + $_.Exception.Message }
    } elseif ($swapped -and $previous -and (Test-Path -LiteralPath $previous)) {
        try {
            $failedDestination = $destination + '.falhou-' + (Get-Date -Format 'yyyyMMddHHmmss')
            Get-Process -Name 'Arcoll.WinUI3' -ErrorAction SilentlyContinue |
                Where-Object { $_.Path -eq (Join-Path $destination $appName) } |
                Stop-Process -Force -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $destination) { Move-Item -LiteralPath $destination -Destination $failedDestination }
            Move-Item -LiteralPath $previous -Destination $destination
            $restored = Join-Path $destination $appName
            if (Test-Path -LiteralPath $restored) { Start-Process -FilePath $restored -ArgumentList '--background' -WorkingDirectory $destination }
            Write-Host 'Reversao: versao anterior restaurada.' -ForegroundColor Yellow
            $failure += ' A versao anterior foi restaurada.'
        } catch { $failure += ' Falha na reversao automatica: ' + $_.Exception.Message }
    } elseif ($Update -and $swapped -and $previous -and -not (Test-Path -LiteralPath $previous)) {
        # Primeira migracao Python -> WinUI: nao existia uma instalacao nativa
        # anterior. Retire somente a nova instancia incompleta. O atualizador
        # Python reiniciara o gestor antigo preservado quando receber este erro.
        try {
            if ($launched) { Stop-Process -Id $launched.Id -Force -ErrorAction SilentlyContinue }
            $nativeTask = Get-ScheduledTask -TaskName 'TI-Digital Gestor Windows' -ErrorAction SilentlyContinue
            if ($nativeTask -and @($nativeTask.Actions | Where-Object { $_.Execute -eq (Join-Path $destination $appName) }).Count) {
                Unregister-ScheduledTask -TaskName 'TI-Digital Gestor Windows' -Confirm:$false -ErrorAction SilentlyContinue
            }
            Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'TIDigitalGestor' -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction Stop }
            $failure += ' Nova instalacao descartada; gestor anterior disponivel.'
        } catch { $failure += ' Falha na limpeza do nativo incompleto: ' + $_.Exception.Message }
    }
    # Nunca deixar o computador sem gestor: se a atualizacao falhou e nenhuma instancia esta ativa, reabre a instalacao existente.
    if ($Update) {
        try {
            $oldExe = Join-Path $destination $appName
            $alive = @(Get-Process -Name 'Arcoll.WinUI3' -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $oldExe } catch { $false } })
            if (-not $alive.Count -and (Test-Path -LiteralPath $oldExe)) {
                Start-Process -FilePath $oldExe -ArgumentList '--background' -WorkingDirectory $destination | Out-Null
                $failure += ' O gestor anterior foi reaberto.'
            }
        } catch { }
    }
    Write-UpdateResult $false $failure
    Write-Host ('ERRO: ' + $failure) -ForegroundColor Red
    Write-Host ('Diagnostico: ' + $log)
    exit 1
} finally {
    if ($taskWasSuspended) {
        try { Enable-ScheduledTask -TaskName $taskNameToResume -ErrorAction Stop | Out-Null }
        catch { Write-Warning ('Reative manualmente a tarefa do gestor: '+$_.Exception.Message) }
    }
    if ($publish -and (Test-Path -LiteralPath $publish)) { Remove-Item -LiteralPath $publish -Recurse -Force -ErrorAction SilentlyContinue }
    Stop-Transcript | Out-Null
}
