// Caminho: gestores/servidor/Arcoll.WinUI3/Services/WorkspaceService.cs
using System.Text.Json;
namespace Arcoll.WinUI3.Services;
public static class WorkspaceService
{
    public static Task<JsonElement> GetAsync(GestorRuntime runtime, string op, CancellationToken ct, params (string Key, object? Value)[] values)
    {
        if (!runtime.Allowed) throw new UnauthorizedAccessException("Autorize este computador na plataforma.");
        if(runtime.Platform.Config.IsStandalone && op=="dashboard")
        {
            var all=InventoryService.LocalLoad(runtime.Platform.Config).Where(d=>!d.Hidden).ToList();var now=DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            var devices=all.Select(d=>new{id=d.Id,n=d.Name,t=d.Type,o=d.Online?1:0,x=now-d.LastSeen>300?1:0,state=now-d.LastSeen>300?"unknown":d.Status,ip=d.Ip,m=d.Mac,g=d.Group,s=d.LastChange,l=d.LastSeen,f=d.FirstSeen,c=d.LastChange,gestor_id=0,source=d.Source,observers=1});
            return Task.FromResult(JsonSerializer.SerializeToElement(new{ok=true,now,updated=all.Select(d=>d.LastSeen).DefaultIfEmpty().Max(),limited=false,events=Array.Empty<object>(),gestores=Array.Empty<object>(),devices}));
        }
        var body = runtime.Platform.WithCredentials(values); body["op"] = op;
        return runtime.Platform.PostAsync("gestor-workspace", body, ct, 15);
    }
}
