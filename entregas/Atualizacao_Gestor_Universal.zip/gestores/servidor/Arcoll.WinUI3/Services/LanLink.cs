// Caminho: gestores/servidor/Arcoll.WinUI3/Services/LanLink.cs
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace Arcoll.WinUI3.Services;

/// <summary>Configuração do canal de rede local, entregue pela plataforma (gestor-config) e guardada localmente para funcionar sem internet.</summary>
public sealed record LanSettings(bool Enabled, int Port, string Secret, int CodeSeconds)
{
    // Ponte HTTP limitada ao loopback, não expõe o canal LAN na internet.
    public bool WebReady => Ready;
    public int WebPort => Port < 65535 ? Port + 1 : Port - 1;
    public bool Ready => Enabled && Secret.Length >= 32 && Port is >= 1024 and <= 65535;
    private static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Arcoll", "lan.json");
    public static LanSettings Load()
    {
        if(GestorConfig.Load().IsStandalone)return new LanSettings(false,47831,"",60);
        try
        {
            if (File.Exists(FilePath))
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(FilePath));
                var r = doc.RootElement;
                return new LanSettings(r.GetProperty("enabled").GetBoolean(), r.GetProperty("port").GetInt32(), r.GetProperty("secret").GetString() ?? "", Math.Clamp(r.GetProperty("code_seconds").GetInt32(), 15, 300));
            }
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or KeyNotFoundException or InvalidOperationException) { RuntimeLog.Write("Configuração de rede local: " + ex.Message); }
        return new LanSettings(false, 47831, "", 60);
    }
    /// <summary>Atualiza o cache a partir do bloco "lan" de gestor-config; alteração só grava quando algo mudou.</summary>
    public static void Apply(JsonElement lan)
    {
        if (lan.ValueKind != JsonValueKind.Object) return;
        var next = new LanSettings(lan.TryGetProperty("enabled", out var e) && e.ValueKind == JsonValueKind.True,
            lan.TryGetProperty("port", out var p) && p.TryGetInt32(out var port) ? port : 47831,
            lan.TryGetProperty("secret", out var s) && s.ValueKind == JsonValueKind.String ? s.GetString() ?? "" : "",
            lan.TryGetProperty("code_seconds", out var c) && c.TryGetInt32(out var seconds) ? Math.Clamp(seconds, 15, 300) : 60);
        if (next == Load()) return;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(new { enabled = next.Enabled, port = next.Port, secret = next.Secret, code_seconds = next.CodeSeconds }));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { RuntimeLog.Write("Não foi possível guardar a rede local: " + ex.Message); }
    }
}

/// <summary>Bilhete curto emitido pela plataforma a um operador autorizado.</summary>
public static class LanWebTicket
{
    public static bool Verify(LanSettings settings, string ticket)
    {
        var parts = ticket.Split('.');
        if (!settings.WebReady || parts.Length != 2 || !long.TryParse(parts[0], out var expires)) return false;
        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        if (expires < now || expires > now + 90 || parts[1].Length != 64) return false;
        var expected = HMACSHA256.HashData(Encoding.UTF8.GetBytes(settings.Secret), Encoding.UTF8.GetBytes("arcoll-web-lan-v1|" + parts[0]));
        try { return CryptographicOperations.FixedTimeEquals(expected, Convert.FromHexString(parts[1])); }
        catch (FormatException) { return false; }
    }
}

/// <summary>Mensagens LAN protegidas por AES-256-GCM.</summary>
public static class LanCrypto
{
    private static byte[] Key(string secret) => SHA256.HashData(Encoding.UTF8.GetBytes("arcoll-lan-v1|" + secret));
    private static readonly byte[] Aad = Encoding.ASCII.GetBytes("arcoll-lan");
    public static byte[] Seal(LanSettings settings, string kind, object body)
    {
        var plain = JsonSerializer.SerializeToUtf8Bytes(new { ts = DateTimeOffset.UtcNow.ToUnixTimeSeconds(), n = Convert.ToHexString(RandomNumberGenerator.GetBytes(12)), k = kind, b = body });
        var nonce = RandomNumberGenerator.GetBytes(12); var tag = new byte[16]; var cipher = new byte[plain.Length];
        using (var aes = new AesGcm(Key(settings.Secret), 16)) aes.Encrypt(nonce, plain, cipher, tag, Aad);
        var output = new byte[12 + 16 + cipher.Length];
        nonce.CopyTo(output, 0); tag.CopyTo(output, 12); cipher.CopyTo(output, 28);
        return output;
    }
    /// <summary>Retorna null quando a mensagem não pertence a esta rede, está adulterada ou fora do prazo.</summary>
    public static LanMessage? Open(LanSettings settings, byte[] data)
    {
        if (data.Length < 29) return null;
        try
        {
            var plain = new byte[data.Length - 28];
            using (var aes = new AesGcm(Key(settings.Secret), 16)) aes.Decrypt(data.AsSpan(0, 12), data.AsSpan(28), data.AsSpan(12, 16), plain, Aad);
            using var doc = JsonDocument.Parse(plain); var root = doc.RootElement;
            var ts = root.GetProperty("ts").GetInt64();
            if (Math.Abs(DateTimeOffset.UtcNow.ToUnixTimeSeconds() - ts) > 120) return null;
            return new LanMessage(root.GetProperty("k").GetString() ?? "", root.GetProperty("n").GetString() ?? "", root.GetProperty("b").Clone());
        }
        catch (Exception ex) when (ex is CryptographicException or JsonException or KeyNotFoundException or InvalidOperationException) { return null; }
    }
    public static string Code(LanSettings settings, string machine, long window)
    {
        var hash = HMACSHA256.HashData(Encoding.UTF8.GetBytes(settings.Secret), Encoding.UTF8.GetBytes("code|" + machine.ToUpperInvariant() + "|" + window));
        return (BitConverter.ToUInt32(hash, 0) % 100000000).ToString("D8");
    }
}
public sealed record LanMessage(string Kind, string Nonce, JsonElement Body);

public static class LanFrames
{
    private const int Max = 8 * 1024 * 1024;
    public static async Task WriteAsync(Stream stream, byte[] data, CancellationToken ct)
    {
        var header = new byte[] { (byte)(data.Length >> 24), (byte)(data.Length >> 16), (byte)(data.Length >> 8), (byte)data.Length };
        await stream.WriteAsync(header, ct); await stream.WriteAsync(data, ct); await stream.FlushAsync(ct);
    }
    public static async Task<byte[]> ReadAsync(Stream stream, CancellationToken ct)
    {
        var header = new byte[4]; await stream.ReadExactlyAsync(header, ct);
        var length = (header[0] << 24) | (header[1] << 16) | (header[2] << 8) | header[3];
        if (length is < 1 or > Max) throw new InvalidDataException("Quadro de rede local inválido.");
        var data = new byte[length]; await stream.ReadExactlyAsync(data, ct); return data;
    }
}

/// <summary>
/// Captura as respostas que um comando enviaria à plataforma (confirmação, relatórios) para devolvê-las ao Servidor pela rede local.
/// O comando executa no mesmo código da fila da plataforma; apenas o destino das respostas muda.
/// </summary>
public sealed class LanCapture : IDisposable
{
    private static readonly AsyncLocal<LanCapture?> Active = new();
    public static LanCapture? Current => Active.Value;
    public string Command { get; }
    public List<(string Action, JsonElement Body)> Posts { get; } = new();
    private LanCapture(string command) { Command = command; }
    public static LanCapture Begin(string command) { var capture = new LanCapture(command); Active.Value = capture; return capture; }
    public void Dispose() { Active.Value = null; }
    public JsonElement Respond(string action, object body)
    {
        string reply = action switch
        {
            // A autorização vem do canal assinado do Servidor; o consentimento local do computador continua valendo nos comandos.
            "gestor-command-authorize" or "gestor-power-authorize" or "gestor-remote-authorize" => JsonSerializer.Serialize(new { ok = true, command = Command, headless = false }),
            _ => "{\"ok\":true}",
        };
        if (action is not ("gestor-command-cancel-state" or "gestor-command-authorize" or "gestor-power-authorize" or "gestor-remote-authorize") && Posts.Count < 40)
        {
            var element = JsonSerializer.SerializeToElement(body);
            var clean = new Dictionary<string, JsonElement>();
            if (element.ValueKind == JsonValueKind.Object)
                foreach (var property in element.EnumerateObject()) if (property.Name is not ("fingerprint" or "site_code" or "download_key")) clean[property.Name] = property.Value.Clone();
            Posts.Add((action, JsonSerializer.SerializeToElement(clean)));
        }
        using var doc = JsonDocument.Parse(reply); return doc.RootElement.Clone();
    }
}
