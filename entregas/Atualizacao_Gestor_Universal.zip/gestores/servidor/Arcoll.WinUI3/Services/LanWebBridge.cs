// Caminho: gestores/servidor/Arcoll.WinUI3/Services/LanWebBridge.cs
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace Arcoll.WinUI3.Services;

/// <summary>
/// Ponte entre a plataforma web e a rede local: o Gestor Servidor escuta somente em 127.0.0.1 e repassa ao Colaborador, pelo mesmo canal
/// criptografado de <see cref="LanClientService"/>, o código, a imagem da tela e a entrada de mouse/teclado. O navegador testa a ponte
/// automaticamente; quando ela responde e o Colaborador está na rede local, o acesso remoto não passa pela internet.
/// Segurança: só loopback, Host e Origin exatos (plataforma configurada no Gestor) e bilhete assinado pela plataforma para iniciar sessões.
/// </summary>
public sealed class LanWebBridge : IDisposable
{
    private sealed class Session { public required LanPeer Peer; public required string Token; public DateTime Last; }
    private sealed record Http(string Method, string Path, Dictionary<string, string> Headers, byte[] Body)
    {
        public string Header(string name) => Headers.TryGetValue(name, out var value) ? value : "";
    }

    private const int MaxBody = 65536, MaxSessions = 4;
    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private readonly GestorRuntime _runtime;
    private readonly LanClientService _lan;
    private readonly CancellationTokenSource _stop = new();
    private readonly Dictionary<string, Session> _sessions = new();
    private readonly object _gate = new();
    private TcpListener? _listener; private int _port, _failedPort; private string _origin = "";
    private Task _warm = Task.CompletedTask;

    public LanWebBridge(GestorRuntime runtime, LanClientService lan) { _runtime = runtime; _lan = lan; }
    public void Start() => _ = Task.Run(() => LoopAsync(_stop.Token));

    private async Task LoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var settings = LanSettings.Load();
                var configuredOrigin = GestorConfig.Load().Origin;
                _origin = Uri.TryCreate(configuredOrigin, UriKind.Absolute, out var platformUri)
                    ? platformUri.GetLeftPart(UriPartial.Authority) : "";
                var want = _runtime.IsServer && settings.WebReady && _origin.Length > 0;
                if (!want || settings.WebPort != _port) Close();
                if (want && _listener is null && settings.WebPort != _failedPort) Open(settings.WebPort);
                await ReapAsync();
            }
            catch (Exception ex) when (ex is IOException or ObjectDisposedException) { RuntimeLog.Write("Ponte da rede local: " + ex.Message); Close(); }
            try { await Task.Delay(TimeSpan.FromSeconds(5), ct); } catch (OperationCanceledException) { break; }
        }
        Close();
    }

    private void Open(int port)
    {
        try
        {
            var listener = new TcpListener(IPAddress.Loopback, port); listener.Start();
            _listener = listener; _port = port; _failedPort = 0;
            _ = Task.Run(() => AcceptAsync(listener, _stop.Token));
            RuntimeLog.Write("Rede local: ponte do navegador ativa em 127.0.0.1:" + port + ".");
        }
        catch (SocketException ex) { _failedPort = port; RuntimeLog.Write("Ponte da rede local indisponível na porta " + port + ": " + ex.Message); }
    }

    private void Close()
    {
        try { _listener?.Stop(); } catch (SocketException) { /* já encerrado */ }
        _listener = null; _port = 0;
        List<Session> open; lock (_gate) { open = _sessions.Values.ToList(); _sessions.Clear(); }
        foreach (var session in open) _ = EndPeerAsync(session);
    }

    private async Task ReapAsync()
    {
        List<Session> idle;
        lock (_gate)
        {
            // A ponte local encerra o acesso quando o navegador deixa de renovar a sessão.
            var limit = DateTime.UtcNow.AddSeconds(-15);
            var keys = _sessions.Where(x => x.Value.Last < limit).Select(x => x.Key).ToList();
            idle = keys.Select(k => _sessions[k]).ToList(); foreach (var key in keys) _sessions.Remove(key);
        }
        foreach (var session in idle) await EndPeerAsync(session);
    }

    private async Task EndPeerAsync(Session session)
    {
        try { await _lan.CallAsync(session.Peer, "remote_end", new { token = session.Token }, CancellationToken.None, 4); }
        catch (InvalidOperationException) { /* o Colaborador encerra sozinho pelo prazo */ }
    }

    private async Task AcceptAsync(TcpListener listener, CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { var client = await listener.AcceptTcpClientAsync(ct); _ = Task.Run(() => HandleAsync(client, ct), ct); }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) when (ex is SocketException or ObjectDisposedException) { break; }
        }
    }

    private async Task WarmAsync()
    {
        try { await _lan.DiscoverAsync(_stop.Token); }
        catch (Exception ex) when (ex is OperationCanceledException or InvalidOperationException or SocketException or ObjectDisposedException) { /* sem rede local no momento */ }
    }

    private async Task HandleAsync(TcpClient client, CancellationToken ct)
    {
        if(_runtime.Platform.Config.IsStandalone){client.Dispose();return;}
        using var lease = client;
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromSeconds(40));
            client.NoDelay = true;
            var stream = client.GetStream();
            var request = await ReadAsync(stream, timeout.Token);
            if (request is null) return;
            var host = request.Header("host"); var origin = request.Header("origin");
            var hostOk = host == "127.0.0.1:" + _port || host == "localhost:" + _port;
            if (!hostOk || _origin.Length == 0 || !string.Equals(origin, _origin, StringComparison.OrdinalIgnoreCase))
            {
                await WriteAsync(stream, 403, "application/json", Json(new { ok = false, error = "Origem não autorizada." }), null, timeout.Token); return;
            }
            if (request.Method == "OPTIONS") { await WriteAsync(stream, 204, "text/plain", [], _origin, timeout.Token); return; }
            var (status, type, body) = await RouteAsync(request, timeout.Token);
            await WriteAsync(stream, status, type, body, _origin, timeout.Token);
        }
        catch (Exception ex) when (ex is IOException or SocketException or OperationCanceledException or ObjectDisposedException or JsonException) { /* navegador desconectou */ }
    }

    private static byte[] Json(object value) => JsonSerializer.SerializeToUtf8Bytes(value);
    private static string Text(JsonElement body, string name) => body.ValueKind == JsonValueKind.Object && body.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";

    private async Task<(int Status, string Type, byte[] Body)> RouteAsync(Http request, CancellationToken ct)
    {
        const string json = "application/json";
        var settings = LanSettings.Load();
        if (!_lan.Available || !settings.WebReady) return (503, json, Json(new { ok = false, error = "Rede local indisponível." }));
        if (request.Path == "/v1/ping")
        {
            if (_warm.IsCompleted) _warm = WarmAsync();
            return (200, json, Json(new { ok = true, bridge = true, peers = _lan.Peers.Count, version = Models.AppInfo.Version }));
        }
        if (request.Method != "POST") return (404, json, Json(new { ok = false, error = "Rota inexistente." }));
        JsonElement body;
        try { using var doc = JsonDocument.Parse(request.Body.Length == 0 ? "{}"u8.ToArray() : request.Body); body = doc.RootElement.Clone(); }
        catch (JsonException) { return (400, json, Json(new { ok = false, error = "JSON inválido." })); }

        switch (request.Path)
        {
            case "/v1/begin":
            {
                var code = Text(body, "code").Trim().ToUpperInvariant();
                if (!LanWebTicket.Verify(settings, Text(body, "ticket"))) return (403, json, Json(new { ok = false, error = "Bilhete inválido ou expirado." }));
                if (code.Length != 5 || code.Any(c => !Alphabet.Contains(c))) return (422, json, Json(new { ok = false, error = "Código inválido." }));
                lock (_gate) if (_sessions.Count >= MaxSessions) return (429, json, Json(new { ok = false, error = "Sessões locais em excesso." }));
                using var limit = CancellationTokenSource.CreateLinkedTokenSource(ct); limit.CancelAfter(TimeSpan.FromSeconds(20));
                try
                {
                    await _warm.WaitAsync(limit.Token);
                    var (peer, token) = await _lan.BeginRemoteAsync(code, limit.Token);
                    if (token.Length == 0) return (422, json, Json(new { ok = false, error = "Colaborador não retornou a sessão." }));
                    var id = Convert.ToHexString(RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();
                    lock (_gate) _sessions[id] = new Session { Peer = peer, Token = token, Last = DateTime.UtcNow };
                    return (200, json, Json(new { ok = true, session = id, machine = peer.Machine }));
                }
                catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException or KeyNotFoundException or OperationCanceledException && !ct.IsCancellationRequested)
                {
                    return (422, json, Json(new { ok = false, error = ex is OperationCanceledException ? "Colaborador não respondeu na rede local." : ex.Message }));
                }
            }
            case "/v1/frame":
            case "/v1/input":
            case "/v1/end":
            {
                var id = Text(body, "session"); Session? session;
                lock (_gate) { _sessions.TryGetValue(id, out session); if (session is not null) session.Last = DateTime.UtcNow; }
                if (session is null) return (410, json, Json(new { ok = false, ended = true, error = "Sessão remota encerrada." }));
                if (request.Path == "/v1/end")
                {
                    lock (_gate) _sessions.Remove(id);
                    await EndPeerAsync(session); return (200, json, Json(new { ok = true }));
                }
                try
                {
                    if (request.Path == "/v1/input")
                    {
                        if (!body.TryGetProperty("events", out var events) || events.ValueKind != JsonValueKind.Array) return (400, json, Json(new { ok = false, error = "Eventos inválidos." }));
                        await _lan.CallAsync(session.Peer, "input", new { token = session.Token, events }, ct, 8);
                        return (200, json, Json(new { ok = true }));
                    }
                    var profile = Text(body, "profile"); if (profile is not ("low" or "balanced" or "high")) profile = "balanced";
                    var reply = await _lan.CallAsync(session.Peer, "frame", new { token = session.Token, profile }, ct, 12);
                    return (200, "image/jpeg", Convert.FromBase64String(reply.GetProperty("jpeg").GetString() ?? ""));
                }
                catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException or FormatException or KeyNotFoundException)
                {
                    var ended = ex.Message.Contains("encerrada", StringComparison.OrdinalIgnoreCase) || ex.Message.Contains("não respondeu", StringComparison.OrdinalIgnoreCase);
                    if (ended) lock (_gate) _sessions.Remove(id);
                    return (ended ? 410 : 502, json, Json(new { ok = false, ended, error = ex.Message }));
                }
            }
            default:
                return (404, json, Json(new { ok = false, error = "Rota inexistente." }));
        }
    }

    private static async Task<Http?> ReadAsync(NetworkStream stream, CancellationToken ct)
    {
        var buffer = new byte[16384]; var length = 0; var end = -1;
        while (end < 0)
        {
            if (length == buffer.Length) return null;
            var read = await stream.ReadAsync(buffer.AsMemory(length), ct); if (read == 0) return null;
            length += read;
            for (var i = Math.Max(0, length - read - 3); i + 3 < length; i++)
                if (buffer[i] == 13 && buffer[i + 1] == 10 && buffer[i + 2] == 13 && buffer[i + 3] == 10) { end = i; break; }
        }
        var lines = Encoding.ASCII.GetString(buffer, 0, end).Split("\r\n");
        var first = lines[0].Split(' '); if (first.Length < 3) return null;
        var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in lines.Skip(1)) { var colon = line.IndexOf(':'); if (colon > 0) headers[line[..colon].Trim()] = line[(colon + 1)..].Trim(); }
        var size = headers.TryGetValue("content-length", out var text) && int.TryParse(text, out var parsed) ? parsed : 0;
        if (size < 0 || size > MaxBody) return null;
        var body = new byte[size]; var have = Math.Min(size, length - (end + 4));
        if (have > 0) Array.Copy(buffer, end + 4, body, 0, have);
        while (have < size) { var read = await stream.ReadAsync(body.AsMemory(have), ct); if (read == 0) return null; have += read; }
        return new Http(first[0].ToUpperInvariant(), first[1].Split('?')[0], headers, body);
    }

    private static async Task WriteAsync(Stream stream, int status, string type, byte[] body, string? origin, CancellationToken ct)
    {
        var reason = status switch { 200 => "OK", 204 => "No Content", 400 => "Bad Request", 403 => "Forbidden", 404 => "Not Found", 410 => "Gone", 422 => "Unprocessable Entity", 429 => "Too Many Requests", 502 => "Bad Gateway", 503 => "Service Unavailable", _ => "Error" };
        var head = new StringBuilder("HTTP/1.1 " + status + " " + reason + "\r\n");
        if (origin is not null)
            head.Append("Access-Control-Allow-Origin: ").Append(origin).Append("\r\nVary: Origin\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type\r\nAccess-Control-Allow-Private-Network: true\r\nAccess-Control-Max-Age: 600\r\n");
        head.Append("Content-Type: ").Append(type).Append("\r\nContent-Length: ").Append(body.Length).Append("\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n");
        await stream.WriteAsync(Encoding.ASCII.GetBytes(head.ToString()), ct);
        if (body.Length > 0) await stream.WriteAsync(body, ct);
        await stream.FlushAsync(ct);
    }

    public void Dispose() { _stop.Cancel(); Close(); _stop.Dispose(); }
}
