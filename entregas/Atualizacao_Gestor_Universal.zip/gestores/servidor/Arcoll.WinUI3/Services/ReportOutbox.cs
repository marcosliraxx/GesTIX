// Caminho: gestores/servidor/Arcoll.WinUI3/Services/ReportOutbox.cs
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
namespace Arcoll.WinUI3.Services;

/// <summary>Reenvia somente resultados locais; nunca repete comandos nem correções.</summary>
public static class ReportOutbox
{
    private sealed record Envelope(string Id,string Tool,long Expires,JsonElement Report);
    private static readonly SemaphoreSlim Gate=new(1,1);
    private static string DirectoryFor(GestorConfig config)=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","PendingReports",Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(config.Origin+"|"+config.SiteCode+"|"+config.Fingerprint+"|"+config.DownloadKey))));
    public static async Task SaveAsync(PlatformClient platform,string tool,JsonElement report,int ttl,CancellationToken ct)
    {
        if(!Regex.IsMatch(tool,"^[a-z_]{1,24}$"))throw new InvalidDataException("Tipo de relatório inválido.");
        if(platform.Config.IsStandalone){ct.ThrowIfCancellationRequested();LocalDatabase.AddResult(tool,report.GetRawText());return;}
        var value=new Envelope(Guid.NewGuid().ToString("N"),tool,DateTimeOffset.UtcNow.ToUnixTimeSeconds()+Math.Clamp(ttl,60,604800),report.Clone());
        var json=JsonSerializer.Serialize(value);if(Encoding.UTF8.GetByteCount(json)>5900000)throw new InvalidDataException("Relatório excede o limite de sincronização.");
        var config=platform.Config;var directory=DirectoryFor(config);Directory.CreateDirectory(directory);var path=Path.Combine(directory,tool+".json");var temporary=path+"."+value.Id+".tmp";
        await Gate.WaitAsync(ct);try{await File.WriteAllTextAsync(temporary,json,ct);File.Move(temporary,path,true);}finally{try{if(File.Exists(temporary))File.Delete(temporary);}catch(IOException){}Gate.Release();}
        await FlushAsync(platform,ct);
    }
    public static async Task FlushAsync(PlatformClient platform,CancellationToken ct)
    {
        if(!await Gate.WaitAsync(0,ct))return;
        try{var config=platform.Config;var directory=DirectoryFor(config);if(!Directory.Exists(directory))return;using var sender=new PlatformClient(config);
            foreach(var path in Directory.EnumerateFiles(directory,"*.json").OrderBy(File.GetLastWriteTimeUtc).Take(2)){
                if(new FileInfo(path).Length>6000000){File.Delete(path);continue;}
                Envelope? value;try{value=JsonSerializer.Deserialize<Envelope>(await File.ReadAllTextAsync(path,ct));}catch(JsonException){File.Move(path,path+".corrupt",true);continue;}
                if(value is null||value.Expires<DateTimeOffset.UtcNow.ToUnixTimeSeconds()){File.Delete(path);continue;}
                if(!Regex.IsMatch(value.Tool,"^[a-z_]{1,24}$"))throw new InvalidDataException("Relatório pendente inválido.");
                await sender.PostAsync("gestor-pentefino-local-result",sender.WithCredentials(("mode","tool"),("tool",value.Tool),("report",value.Report),("result_id",value.Id)),ct,15);
                File.Delete(path); // UPSERT por máquina/ferramenta torna um reenvio após falha de resposta idempotente.
            }
        }finally{Gate.Release();}
    }
}
