// Caminho: gestores/servidor/Arcoll.WinUI3/Services/PairingService.cs
using System.Security.Cryptography;
using System.Text.Json;
namespace Arcoll.WinUI3.Services;

public static class PairingService
{
    private static string ConfigPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Arcoll","gestor.json");
    private static string PendingPath => Path.Combine(Path.GetDirectoryName(ConfigPath)!,"pairing.json");
    private static readonly HttpClient Http = CreateHttp();
    private static HttpClient CreateHttp(){var h=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(12)};PlatformClient.ApplyDefaults(h);return h;}
    private static async Task<JsonElement> Request(GestorConfig config,string action,string token,CancellationToken ct)
    {
        if(!Uri.TryCreate(config.Origin,UriKind.Absolute,out var uri)||uri.Scheme!="https")throw new InvalidOperationException("Origem HTTPS não configurada.");
        using var body=PlatformClient.JsonBody(new{action,token,fingerprint=config.Fingerprint,machine_name=Environment.MachineName,platform=Environment.OSVersion.ToString()});
        using var response=await Http.PostAsync(config.Origin+"/api/gestor-pairing.php",body,ct);
        using var doc=JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));var r=doc.RootElement.Clone();
        if(!response.IsSuccessStatusCode||!r.TryGetProperty("ok",out var ok)||ok.ValueKind!=JsonValueKind.True)throw new InvalidOperationException(r.TryGetProperty("error",out var e)?e.GetString():"Falha no pareamento.");
        return r;
    }
    private static void Write(string path,object value){Directory.CreateDirectory(Path.GetDirectoryName(path)!);var tmp=path+".tmp";File.WriteAllText(tmp,JsonSerializer.Serialize(value));File.Move(tmp,path,true);}
    public static void Save(GestorConfig config,string site,string token)
    {
        Write(ConfigPath,new{origin=config.Origin,site_code=site,download_key=token,fingerprint=config.Fingerprint,system_name=config.SystemName,mode=site.Length==0?"standalone":"paired"});
    }
    public static async Task<(string Code,string Token,int Seconds)> BeginAsync(GestorConfig config,CancellationToken ct)
    {
        // Reabrir o modal recupera o pedido vigente, inclusive após reiniciar o aplicativo.
        try{
            if(File.Exists(PendingPath)){
                using var doc=JsonDocument.Parse(File.ReadAllText(PendingPath));var p=doc.RootElement;
                var token=p.GetProperty("token").GetString()!;
                var remaining=p.GetProperty("expires").GetInt64()-DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                if(remaining>0){var status=await StatusAsync(config,token,ct);if(status is "pending" or "linked")return(p.GetProperty("code").GetString()!,token,(int)remaining);}
            }
        }catch(Exception e)when(e is IOException or JsonException or KeyNotFoundException){RuntimeLog.Write("Pareamento local: "+e.Message);}
        var key=Convert.ToHexString(RandomNumberGenerator.GetBytes(32)).ToLowerInvariant();
        var result=await Request(config,"create",key,ct);var code=result.GetProperty("code").GetString()!;var seconds=result.GetProperty("expires_seconds").GetInt32();
        Write(PendingPath,new{token=key,code,expires=DateTimeOffset.UtcNow.ToUnixTimeSeconds()+seconds});
        return(code,key,seconds);
    }
    public static async Task<string> StatusAsync(GestorConfig config,string token,CancellationToken ct)
    {
        var r=await Request(config,"status",token,ct);var status=r.GetProperty("status").GetString()??"pending";
        if(status=="linked"&&config.IsStandalone)Save(config,r.GetProperty("site_code").GetString()!,token);
        if(status=="unlinked"&&!config.IsStandalone)Save(config,"","");
        return status;
    }
}
