// Caminho: gestores/servidor/Arcoll.WinUI3/Services/LanAgentService.cs
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text.Json;
using Arcoll.WinUI3.Models;
namespace Arcoll.WinUI3.Services;

/// <summary>
/// Agente do Gestor Colaborador na rede local: responde à descoberta do Servidor e executa, neste computador, os comandos e
/// o acesso remoto pedidos por ele. Não depende de internet; usa o segredo da rede guardado em %APPDATA%\Arcoll\lan.json.
/// </summary>
public sealed class LanAgentService : IDisposable
{
    private readonly GestorRuntime _runtime;
    private readonly CancellationTokenSource _stop = new();
    private readonly Dictionary<string, DateTime> _seen = new();
    private readonly object _gate = new();
    private TcpListener? _tcp; private UdpClient? _udp; private int _port; private string _secret = "";
    private string _token = ""; private DateTime _tokenUntil = DateTime.MinValue; private int _failures; private DateTime _blockedUntil = DateTime.MinValue;
    /// <summary>Verdadeiro enquanto um Servidor controla a tela deste computador pela rede local.</summary>
    public bool RemoteActive { get { lock (_gate) return _token.Length > 0 && DateTime.UtcNow < _tokenUntil; } }
    public event Action<bool>? RemoteChanged;

    public LanAgentService(GestorRuntime runtime) { _runtime = runtime; }
    public void Start() => _ = Task.Run(() => LoopAsync(_stop.Token));

    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private readonly Dictionary<string, DateTime> _codes = new();
    private string _offlineCode = ""; private DateTime _offlineUntil = DateTime.MinValue;
    private static string Normalize(string code) => code.Trim().ToUpperInvariant();
    /// <summary>Registra o código exibido ao usuário (o mesmo da plataforma): o Servidor o usa pela rede local ou pela plataforma, sem escolher.</summary>
    public void AcceptCode(string code, int seconds)
    {
        code = Normalize(code); if (code.Length != 5) return;
        lock (_gate)
        {
            foreach (var old in _codes.Where(x => x.Value < DateTime.UtcNow).Select(x => x.Key).ToList()) _codes.Remove(old);
            _codes[code] = DateTime.UtcNow.AddSeconds(Math.Max(10, seconds) + 20);
        }
    }
    /// <summary>Sem plataforma: gera localmente um código no mesmo formato (5 caracteres) e o mantém válido pelo tempo configurado.</summary>
    public (string Code, int Seconds)? OfflineCode()
    {
        var settings = LanSettings.Load();
        if (!settings.Ready || _runtime.IsServer) return null;
        if (_offlineCode.Length == 0 || DateTime.UtcNow >= _offlineUntil)
        {
            _offlineCode = new string(Enumerable.Range(0, 5).Select(_ => Alphabet[RandomNumberGenerator.GetInt32(Alphabet.Length)]).ToArray());
            _offlineUntil = DateTime.UtcNow.AddSeconds(settings.CodeSeconds);
        }
        AcceptCode(_offlineCode, (int)Math.Ceiling((_offlineUntil - DateTime.UtcNow).TotalSeconds));
        return (_offlineCode, Math.Max(1, (int)Math.Ceiling((_offlineUntil - DateTime.UtcNow).TotalSeconds)));
    }

    private async Task LoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var settings = LanSettings.Load();
                var want = settings.Ready; // Servidor oferece somente a release assinada aos Colaboradores; acesso remoto continua restrito ao Colaborador.
                if (!want || settings.Port != _port || settings.Secret != _secret) Close();
                if (want && _tcp is null) Open(settings);
            }
            catch (Exception ex) when (ex is SocketException or IOException or ObjectDisposedException) { RuntimeLog.Write("Rede local (agente): " + ex.Message); Close(); }
            try { await Task.Delay(TimeSpan.FromSeconds(10), ct); } catch (OperationCanceledException) { break; }
        }
        Close();
    }

    private void Open(LanSettings settings)
    {
        EnsureFirewall(settings.Port);
        _port = settings.Port; _secret = settings.Secret;
        _tcp = new TcpListener(IPAddress.Any, _port); _tcp.Start();
        _udp = new UdpClient(new IPEndPoint(IPAddress.Any, _port)) { EnableBroadcast = true };
        var tcp = _tcp; var udp = _udp;
        _ = Task.Run(() => AcceptAsync(tcp, settings, _stop.Token));
        _ = Task.Run(() => DiscoveryAsync(udp, settings, _stop.Token));
        RuntimeLog.Write("Rede local: serviço autenticado ativo na porta " + _port + ".");
        _=Task.Run(async()=>{
            // Aviso oportunista: quando o Servidor reinicia após atualizar, colaboradores
            // elegíveis verificam o pacote local imediatamente (não contém credenciais).
            try{
                while(!_stop.IsCancellationRequested){
                    await Task.Delay(TimeSpan.FromSeconds(15),_stop.Token);
                    if(!_runtime.IsServer||!_runtime.Allowed)continue;
                    var version=LanUpdateCache.CurrentVersion();if(version is null)continue;
                    var notice=LanCrypto.Seal(settings,"update_notice",new {version});
                    await udp.SendAsync(notice,notice.Length,new IPEndPoint(IPAddress.Broadcast,settings.Port));
                }
            }
            catch(Exception ex) when(ex is SocketException or ObjectDisposedException or OperationCanceledException){}
        });
    }

    private void Close()
    {
        try { _tcp?.Stop(); } catch (SocketException) { /* já encerrado */ }
        try { _udp?.Close(); } catch (SocketException) { /* já encerrado */ }
        _tcp = null; _udp = null; _port = 0; _secret = "";
        EndRemote();
    }

    private static void EnsureFirewall(int port)
    {
        try
        {
            var name = "Arcoll Rede Local " + port;
            foreach (var protocol in new[] { "TCP", "UDP" })
            {
                using var process = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("netsh", $"advfirewall firewall add rule name=\"{name} {protocol}\" dir=in action=allow protocol={protocol} localport={port} profile=private,domain") { CreateNoWindow = true, UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true });
                process?.WaitForExit(8000);
            }
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException) { RuntimeLog.Write("Firewall da rede local: " + ex.Message); }
    }

    private async Task DiscoveryAsync(UdpClient udp, LanSettings settings, CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var packet = await udp.ReceiveAsync(ct);
                var message = LanCrypto.Open(settings, packet.Buffer);
                if(message is null||!Fresh(message.Nonce))continue;
                if(message.Kind=="update_notice"){
                    if(!_runtime.IsServer&&message.Body.TryGetProperty("version",out var v)&&v.ValueKind==JsonValueKind.String)
                        {LanUpdateCache.RememberServer(packet.RemoteEndPoint.Address,settings.Port);_runtime.SignalLanUpdate(v.GetString()??"");}
                    continue;
                }
                if(message.Kind!="discover")continue;
                var reply = LanCrypto.Seal(settings, "announce", new { machine = Environment.MachineName, version = AppInfo.Version, port = settings.Port, server = _runtime.IsServer });
                await udp.SendAsync(reply, reply.Length, packet.RemoteEndPoint);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) when (ex is SocketException or ObjectDisposedException) { break; }
        }
    }

    private async Task AcceptAsync(TcpListener listener, LanSettings settings, CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { var client = await listener.AcceptTcpClientAsync(ct); _ = Task.Run(() => HandleAsync(client, settings, ct), ct); }
            catch (OperationCanceledException) { break; }
            catch (Exception ex) when (ex is SocketException or ObjectDisposedException) { break; }
        }
    }

    private bool Fresh(string nonce)
    {
        lock (_gate)
        {
            var now = DateTime.UtcNow;
            foreach (var old in _seen.Where(x => now - x.Value > TimeSpan.FromMinutes(5)).Select(x => x.Key).ToList()) _seen.Remove(old);
            return nonce.Length > 0 && _seen.TryAdd(nonce, now);
        }
    }

    private async Task HandleAsync(TcpClient client, LanSettings settings, CancellationToken ct)
    {
        if(_runtime.Platform.Config.IsStandalone){client.Dispose();return;}
        using var lease = client;
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromMinutes(20));
            client.NoDelay=true;
            var stream = client.GetStream();
            var message = LanCrypto.Open(settings, await LanFrames.ReadAsync(stream, timeout.Token));
            if (message is null || !Fresh(message.Nonce)) return;
            if(message.Kind=="update_stream"&&_runtime.IsServer&&_runtime.Allowed)
            {
                var hash=message.Body.TryGetProperty("hash",out var h)&&h.ValueKind==JsonValueKind.String?h.GetString()??"":"";
                await LanUpdateCache.StreamAsync(stream,settings,hash,timeout.Token);return;
            }
            object reply;
            try { reply = await DispatchAsync(message, timeout.Token); }
            catch (Exception ex) when (ex is not OperationCanceledException) { reply = new { ok = false, error = ErrorDiagnostic.Sanitize(ex.Message, 300) }; }
            await LanFrames.WriteAsync(stream, LanCrypto.Seal(settings, "result", reply), timeout.Token);
        }
        catch (Exception ex) when (ex is IOException or SocketException or InvalidDataException or OperationCanceledException or ObjectDisposedException) { /* conexão encerrada pelo Servidor */ }
    }

    private static readonly HashSet<string> Blocked = new() { "remote_assistance", "gestor_update", "gestor_update_check", "support_code_prompt" };

    private async Task<object> DispatchAsync(LanMessage message, CancellationToken ct)
    {
        var body = message.Body;
        // Um Colaborador jamais pode executar comandos administrativos no Servidor pela LAN.
        if(_runtime.IsServer&&message.Kind is not ("hello" or "update_manifest" or "update_chunk"))
            return new {ok=false,error="Operação não permitida no Gestor Servidor."};
        switch (message.Kind)
        {
            case "update_manifest":
                if(!_runtime.IsServer||!_runtime.Allowed)return new {ok=false,error="Servidor não autorizado."};
                return LanUpdateCache.Availability();
            case "update_chunk":
                if(!_runtime.IsServer||!_runtime.Allowed)return new {ok=false,error="Servidor não autorizado."};
                return LanUpdateCache.ReadChunk(
                    body.TryGetProperty("offset",out var o)&&o.TryGetInt64(out var offset)?offset:-1,
                    body.TryGetProperty("count",out var c)&&c.TryGetInt32(out var count)?count:0);
            case "hello":
                return new { ok = true, machine = Environment.MachineName, version = AppInfo.Version, busy = _runtime.LanBusy, remote = RemoteActive };
            case "command":
            {
                var name = Text(body, "name");
                if (Blocked.Contains(name) || !_runtime.LanSupports(name)) return new { ok = false, error = "Comando não disponível pela rede local." };
                var result = await _runtime.RunLanCommandAsync(name, Text(body, "request"), ct);
                return new { ok = true, status = result.Status, message = result.Message, reports = result.Reports };
            }
            case "remote_reconnect":
            {
                if(_runtime.IsServer)return new {ok=false,error="Este computador é o Gestor Servidor."};
                // Reconnect is never authorized by a previous screen-control token.
                // The LAN packet has already been authenticated by LanCrypto; each new
                // session requires express consent in the receiver's own Windows UI.
                if ((!_runtime.LocalAllowed && !_runtime.LanOfflineCapable) || (!_runtime.Can("support") && !_runtime.LanOfflineCapable))
                    return new { ok = false, error = "Colaborador não autorizado a receber acesso remoto." };
                lock (_gate)
                {
                    if (DateTime.UtcNow < _blockedUntil)
                        return new { ok = false, error = "Aguarde antes de solicitar outro acesso." };
                    if (RemoteActive)
                        return new { ok = false, error = "Já existe uma sessão remota neste computador." };
                    _blockedUntil = DateTime.UtcNow.AddSeconds(20);
                }
                if (_runtime.Consent is null || !await _runtime.Consent("O Gestor Servidor da rede local solicita acesso remoto à tela e aos controles deste computador. Permitir esta nova sessão?"))
                    return new { ok = false, error = "Acesso remoto não autorizado pelo Colaborador." };
                lock (_gate)
                {
                    if (RemoteActive) return new { ok = false, error = "Outra sessão remota foi iniciada." };
                    _token = Convert.ToHexString(RandomNumberGenerator.GetBytes(24));
                    _tokenUntil = DateTime.UtcNow.AddMinutes(30);
                }
                RemoteChanged?.Invoke(true);
                return new { ok = true, token = _token, machine = Environment.MachineName, seconds = 1800 };
            }
            case "remote_begin":
            {
                if(_runtime.IsServer)return new {ok=false,error="Este computador é o Gestor Servidor."};
                lock (_gate)
                {
                    if (DateTime.UtcNow < _blockedUntil) return new { ok = false, error = "Muitas tentativas. Aguarde alguns segundos." };
                    if (RemoteActive) return new { ok = false, error = "Já existe uma sessão remota em andamento neste computador." };
                }
                var entered = Normalize(Text(body, "code")); bool valid;
                lock (_gate) valid = entered.Length == 5 && _codes.Any(x => x.Value >= DateTime.UtcNow && Same(x.Key, entered));
                lock (_gate)
                {
                    if (!valid) { if (++_failures >= 5) { _failures = 0; _blockedUntil = DateTime.UtcNow.AddSeconds(30); } return new { ok = false, error = "Código inválido ou expirado." }; }
                    _failures = 0; _codes.Remove(entered); _token = Convert.ToHexString(RandomNumberGenerator.GetBytes(24)); _tokenUntil = DateTime.UtcNow.AddMinutes(30);
                }
                RemoteChanged?.Invoke(true);
                return new { ok = true, token = _token, machine = Environment.MachineName, seconds = 1800 };
            }
            case "frame":
            {
                if (!Authorized(Text(body, "token"))) return new { ok = false, stop = true, error = "Sessão remota encerrada." };
                var profile = Text(body, "profile"); if (profile is not ("low" or "balanced" or "high")) profile = "balanced";
                var jpeg = await Task.Run(() => RemoteScreenService.CaptureJpeg(profile), ct);
                return new { ok = true, jpeg = Convert.ToBase64String(jpeg) };
            }
            case "input":
            {
                if (!Authorized(Text(body, "token"))) return new { ok = false, stop = true, error = "Sessão remota encerrada." };
                if (body.TryGetProperty("events", out var events) && events.ValueKind == JsonValueKind.Array) await Task.Run(() => RemoteScreenService.ApplyInput(events), ct);
                return new { ok = true };
            }
            case "remote_end":
                if (Authorized(Text(body, "token"))) EndRemote();
                return new { ok = true };
            default:
                return new { ok = false, error = "Operação desconhecida." };
        }
    }

    private static string Text(JsonElement body, string name) => body.ValueKind == JsonValueKind.Object && body.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";
    private static bool Same(string a, string b) => CryptographicOperations.FixedTimeEquals(System.Text.Encoding.ASCII.GetBytes(a), System.Text.Encoding.ASCII.GetBytes(b));
    private bool Authorized(string token)
    {
        lock (_gate) return _token.Length > 0 && DateTime.UtcNow < _tokenUntil && token.Length == _token.Length && Same(token, _token);
    }
    private void EndRemote()
    {
        bool was; lock (_gate) { was = _token.Length > 0; _token = ""; _tokenUntil = DateTime.MinValue; }
        if (was) RemoteChanged?.Invoke(false);
    }
    /// <summary>Permite ao usuário deste computador interromper imediatamente o controle remoto ativo.</summary>
    public bool EndRemoteLocally()
    {
        if (!RemoteActive) return false;
        EndRemote();
        return true;
    }
    public void Dispose() { _stop.Cancel(); Close(); _stop.Dispose(); }
}
