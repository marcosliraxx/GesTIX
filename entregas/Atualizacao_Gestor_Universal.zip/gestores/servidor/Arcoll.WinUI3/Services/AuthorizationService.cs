// Caminho: gestores/servidor/Arcoll.WinUI3/Services/AuthorizationService.cs
namespace Arcoll.WinUI3.Services;

public enum AuthState { Checking, Approved, UiLocked, Pending, Blocked, Rejected, Unauthorized, Uninstall, Unavailable }

/// <summary>
/// Estado de autorização do computador perante a plataforma (verify_installation_status do gestor Python).
/// Sem registro, uma chave válida cria apenas uma solicitação PENDENTE; somente o gestor aprova em Redes &gt; Liberação.
/// </summary>
public sealed class AuthorizationService
{
    private readonly PlatformClient _platform;
    private DateTime _nextRegistration = DateTime.MinValue;
    public AuthState State { get; private set; } = AuthState.Checking;
    public string Detail { get; private set; } = "";
    public string NetworkName { get; private set; } = "";
    public string InstallationProfile => InstallationRole;
    /// <summary>Verdadeiro depois da primeira aprovação: uma queda de rede passageira não bloqueia a interface.</summary>
    public bool EverApproved { get; private set; }
    /// <summary>Estados em que a interface fica bloqueada (falha fechada, como no gestor Python).</summary>
    public bool Gated => State is AuthState.Pending or AuthState.UiLocked or AuthState.Blocked or AuthState.Rejected or AuthState.Unauthorized or AuthState.Uninstall
        || (State == AuthState.Unavailable && !LocalAllowed);
    public bool Allowed => State is AuthState.Approved or AuthState.UiLocked;

    public string InstallationRole { get; private set; }="collaborator";
    public bool InstallationConfirmed { get; private set; }
    public int ReportTtlSeconds { get;private set; }=604800;
    public long PrimaryGestorId { get; private set; }
    public HashSet<string> VisibleMenus { get; }=new(StringComparer.Ordinal);
    public bool AlwaysBackground { get;private set; }
    private readonly Dictionary<string,bool> _permissions=new(StringComparer.Ordinal);
    private DateTime _approvedAt=DateTime.MinValue;
    private int _offlineSeconds;
    private string _identity="";
    public bool LocalAllowed=>Allowed||(State==AuthState.Unavailable&&EverApproved&&DateTime.UtcNow-_approvedAt<TimeSpan.FromSeconds(_offlineSeconds));
    public bool Can(string capability)=>LocalAllowed&&(_permissions.TryGetValue(capability,out var allowed)&&allowed);
    public bool CanOpenMenu(string key)=>!(_platform.Config.IsStandalone && key is "remote" or "support" or "tickets" or "agenda" or "updates" or "users" or "permissions" or "preferences" or "reports" or "registry_cad" or "release")&&LocalAllowed&&Can(LocalUiPolicy.Capability(key))&&(InstallationRole=="server"||VisibleMenus.Contains(key));
    public bool CanUseLocalCapability(string capability)=>Can(capability)&&(InstallationRole=="server"||VisibleMenus.Any(key=>LocalUiPolicy.Capability(key)==capability));
    private void ApplyInstallation(System.Text.Json.JsonElement response)
    {
        if(!response.TryGetProperty("installation",out var profile))return;
        InstallationRole=profile.GetProperty("role").GetString()??"collaborator";
        InstallationConfirmed=profile.GetProperty("confirmed").GetBoolean();PrimaryGestorId=profile.GetProperty("primary_id").GetInt64();
        _offlineSeconds=Math.Clamp(profile.GetProperty("offline_seconds").GetInt32(),0,86400);
        if(profile.TryGetProperty("report_ttl_seconds",out var ttl))ReportTtlSeconds=Math.Clamp(ttl.GetInt32(),60,604800);
        _permissions.Clear();foreach(var item in profile.GetProperty("permissions").EnumerateObject())_permissions[item.Name]=item.Value.ValueKind==System.Text.Json.JsonValueKind.True;
        VisibleMenus.Clear();AlwaysBackground=false;
        if(profile.TryGetProperty("ui",out var ui)){if(ui.TryGetProperty("menus",out var menus)&&menus.ValueKind==System.Text.Json.JsonValueKind.Array)foreach(var menu in menus.EnumerateArray())if(menu.ValueKind==System.Text.Json.JsonValueKind.String)VisibleMenus.Add(menu.GetString()!);AlwaysBackground=InstallationRole!="server"&&ui.TryGetProperty("background",out var hide)&&hide.ValueKind==System.Text.Json.JsonValueKind.True;}
        else VisibleMenus.Add("remote");
        LocalUiPolicy.CacheBackground(_platform.Config,AlwaysBackground);
    }
    public async Task ChooseInstallationAsync(string role,CancellationToken ct)
    {
        var result=await _platform.PostAsync("gestor-installation-choice",_platform.WithCredentials(("role",role)),ct,12);
        ApplyInstallation(result);Detail="Perfil solicitado. Aguarde a confirmação administrativa na plataforma.";
    }

    public AuthorizationService(PlatformClient platform) { _platform = platform; }

    public static string Notice(AuthState state, string detail) => state switch
    {
        AuthState.UiLocked => "TELA BLOQUEADA\nEste gestor está autorizado, mas a tela local exige a liberação administrativa configurada na plataforma.",
        AuthState.Blocked or AuthState.Rejected or AuthState.Unauthorized => "ACESSO BLOQUEADO\nEste gestor não está autorizado pelo gestor da rede." + (detail.Length > 0 ? "\n" + detail : ""),
        AuthState.Pending => "AGUARDANDO LIBERAÇÃO\nEste computador ainda não foi autorizado pelo gestor (Redes › Liberação).",
        AuthState.Uninstall => "DESINSTALAÇÃO SOLICITADA\nO gestor da rede solicitou a remoção deste gestor.",
        AuthState.Checking => "Verificando autorização…",
        _ => "ACESSO INDISPONÍVEL\nNão foi possível confirmar a autorização. Verifique a conexão." + (detail.Length > 0 ? "\n" + detail : ""),
    };

    public async Task<AuthState> RefreshAsync(CancellationToken ct)
    {
        _platform.Reload();
        var cfg = _platform.Config;
        if(cfg.Standalone && cfg.IsComplete)
        {
            try { await PairingService.StatusAsync(cfg,cfg.DownloadKey,ct);_platform.Reload();cfg=_platform.Config; }
            catch(Exception ex)when(ex is not OperationCanceledException || !ct.IsCancellationRequested){RuntimeLog.Write("Consulta do vínculo: "+ex.Message);}
        }
        var identity=cfg.Origin+"|"+cfg.SiteCode+"|"+cfg.Fingerprint+"|"+cfg.DownloadKey;
        if(_identity!=identity){_identity=identity;EverApproved=false;_approvedAt=DateTime.MinValue;_permissions.Clear();VisibleMenus.Clear();AlwaysBackground=false;_offlineSeconds=0;State=AuthState.Checking;}
        Detail = "";
        if (cfg.IsStandalone)
        {
            InstallationRole="server"; InstallationConfirmed=true; PrimaryGestorId=0;
            NetworkName="Uso independente · rede local"; AlwaysBackground=false;
            _permissions.Clear();
            foreach(var cap in new[]{"maintenance","inventory","updates","support","network_scan"}) _permissions[cap]=true;
            return Set(AuthState.Approved);
        }
        if (!cfg.IsComplete)
        {
            var missing = string.Join(", ", new[] { cfg.Origin.Length == 0 ? "origem HTTPS" : "", cfg.SiteCode.Length == 0 ? "código do local" : "", cfg.DownloadKey.Length == 0 ? "chave" : "" }.Where(x => x.Length > 0));
            RuntimeLog.Write("Configuração incompleta (" + missing + ").");
            return Set(AuthState.Unavailable, "Configuração incompleta (" + (missing.Length > 0 ? missing : "formato inválido") + "). Reinstale pelo painel de Redes.");
        }
        try
        {
            var r = await _platform.PostAsync("gestor-poll", cfg.Credentials(), ct, 8);
            ApplyInstallation(r);
            NetworkName = r.TryGetProperty("network_name", out var n) && n.ValueKind == System.Text.Json.JsonValueKind.String ? n.GetString() ?? "" : "";

            if (r.TryGetProperty("uninstall", out var u) && u.ValueKind == System.Text.Json.JsonValueKind.True) return Set(AuthState.Uninstall);
            var status = r.TryGetProperty("status", out var s) && s.ValueKind == System.Text.Json.JsonValueKind.String ? (s.GetString() ?? "").ToLowerInvariant() : "";
            var locked = r.TryGetProperty("ui_locked", out var l) && l.ValueKind == System.Text.Json.JsonValueKind.True;
            return status switch
            {
                "approved" => Set(locked ? AuthState.UiLocked : AuthState.Approved),
                "pending" => Set(AuthState.Pending),
                "blocked" => Set(AuthState.Blocked),
                "rejected" => Set(AuthState.Rejected),
                "removed" => Set(AuthState.Uninstall),
                _ => Set(AuthState.Unavailable),
            };
        }
        catch (PlatformException ex) when (ex.Status is System.Net.HttpStatusCode.Forbidden or System.Net.HttpStatusCode.NotFound)
        {
            // Sem registro a API não cria a solicitação sozinha: uma chave válida registra o computador como PENDENTE.
            return await RegisterAsync(ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
        {
            // Qualquer falha vira um estado visível com motivo, nunca um bloqueio mudo.
            var reason = ex is TaskCanceledException or OperationCanceledException ? "Tempo esgotado ao consultar a plataforma." : ex.Message;
            RuntimeLog.Write("gestor-poll falhou: " + ex.GetType().Name + ": " + reason);
            return Set(AuthState.Unavailable, reason);
        }
    }

    private async Task<AuthState> RegisterAsync(CancellationToken ct)
    {
        if (DateTime.UtcNow < _nextRegistration) return Set(AuthState.Unauthorized);
        _nextRegistration = DateTime.UtcNow.AddSeconds(60);
        try
        {
            var body = _platform.WithCredentials(("machine_name", Environment.MachineName), ("platform", "Windows"), ("version", Models.AppInfo.Version));
            var r = await _platform.PostAsync("gestor-register", body, ct, 10);

            var status = r.TryGetProperty("status", out var s) && s.ValueKind == System.Text.Json.JsonValueKind.String ? (s.GetString() ?? "pending").ToLowerInvariant() : "pending";
            ApplyInstallation(r);
            RuntimeLog.Write("gestor-register: " + status);
            return status switch
            {
                "approved" => Set(AuthState.Approved), "blocked" => Set(AuthState.Blocked), "rejected" => Set(AuthState.Rejected), _ => Set(AuthState.Pending),
            };
        }
        catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
        {
            var reason = ex is TaskCanceledException or OperationCanceledException ? "Tempo esgotado no cadastro." : ex.Message;
            RuntimeLog.Write("gestor-register falhou: " + ex.GetType().Name + ": " + reason);
            return Set(AuthState.Unauthorized, reason);
        }
    }

    private AuthState Set(AuthState state, string detail = "") { State = state; Detail = detail; if(Allowed){EverApproved=true;_approvedAt=DateTime.UtcNow;}else if(state is AuthState.Blocked or AuthState.Rejected or AuthState.Unauthorized or AuthState.Uninstall){EverApproved=false;_approvedAt=DateTime.MinValue;} return state; }
}
