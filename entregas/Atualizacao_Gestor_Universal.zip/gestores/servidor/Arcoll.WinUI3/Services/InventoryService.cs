// Caminho: gestores/servidor/Arcoll.WinUI3/Services/InventoryService.cs
using System.Text.Json;

namespace Arcoll.WinUI3.Services;

/// <summary>Registro do inventário da plataforma (mesma tabela do painel web: nome, tipo, grupo, fixado e situação).</summary>
public sealed class DeviceRecord
{
    public long Id { get; set; }
    public string Mac { get; set; } = "";
    public string Ip { get; set; } = "";
    public string DetectedName { get; set; } = "";
    public string DetectedType { get; set; } = "device";
    public string CustomName { get; set; } = "";
    public string CustomType { get; set; } = "";
    public string Group { get; set; } = "";
    public string Status { get; set; } = "offline";
    public string Source { get; set; } = "";
    public bool Hidden { get; set; }
    public bool Pinned { get; set; }
    public long FirstSeen { get; set; }
    public long LastSeen { get; set; }
    public long LastChange { get; set; }
    public bool GestorInstalled { get; set; }
    public double? LatencyMs { get; set; }
    public string Name => CustomName.Length > 0 ? CustomName : DetectedName.Length > 0 ? DetectedName : Ip;
    public string Type => (CustomType.Length > 0 ? CustomType : DetectedType.Length > 0 ? DetectedType : "device").ToLowerInvariant();
    public bool Online => Status == "online";
}

/// <summary>Leitura e gravação do inventário pelas ações gestor-devices / gestor-device-save (autenticadas pela identidade do gestor).</summary>
public static class InventoryService
{
    public static readonly (string Key, string Label)[] Types =
    {
        ("", "Identificação automática"), ("computer", "Computador"), ("phone", "Celular"), ("tablet", "Tablet"), ("tv", "TV"), ("router", "Roteador"),
        ("printer", "Impressora"), ("server", "Servidor"), ("camera", "Câmera"), ("iot", "IoT"), ("console", "Console"), ("speaker", "Caixa de som"),
        ("switch", "Switch"), ("ap", "Ponto de acesso"), ("nas", "NAS"), ("device", "Outro"),
    };

    public static string TypeLabel(string key) => Types.FirstOrDefault(t => t.Key == key).Label is { Length: > 0 } l ? l : "Outro";

    public static async Task<IReadOnlyList<DeviceRecord>> LoadAsync(PlatformClient platform, CancellationToken ct)
    {
        if(platform.Config.IsStandalone)return LocalLoad(platform.Config).Where(d=>!d.Hidden).ToArray();
        var root = await platform.PostAsync("gestor-devices", platform.Config.Credentials(), ct, 15);
        var list = new List<DeviceRecord>();
        if (!root.TryGetProperty("devices", out var arr) || arr.ValueKind != JsonValueKind.Array) return list;
        foreach (var e in arr.EnumerateArray())
        {
            var d = new DeviceRecord
            {
                Id = Int(e, "id"), Mac = Str(e, "mac"), Ip = Str(e, "ip"), DetectedName = Str(e, "detected_name"), DetectedType = Str(e, "detected_type"),
                CustomName = Str(e, "custom_name"), CustomType = Str(e, "custom_type"), Group = Str(e, "group_name"), Status = Str(e, "status"),
                Source = Str(e, "source"), Pinned = Int(e, "pinned") == 1, FirstSeen = Int(e, "first_seen"), LastSeen = Int(e, "last_seen"), LastChange = Int(e, "last_change"),
            };
            if (e.TryGetProperty("payload", out var p) && p.ValueKind == JsonValueKind.Object)
            {
                d.GestorInstalled = p.TryGetProperty("gestor_installed", out var a) && a.ValueKind == JsonValueKind.True;
                if (p.TryGetProperty("latency_ms", out var l) && l.ValueKind == JsonValueKind.Number) d.LatencyMs = l.GetDouble();
            }
            list.Add(d);
        }
        return list;
    }

    private static string LocalKey(GestorConfig c)=>"independent_inventory_"+LocalDatabase.Scope(c)+"_"+NetworkEngine.Local().Network;
    public static List<DeviceRecord> LocalLoad(GestorConfig c)
    {
        try{return JsonSerializer.Deserialize<List<DeviceRecord>>(LocalDatabase.GetValue(LocalKey(c))??"[]")??new();}
        catch(JsonException){return new();}
    }
    public static void ApplyLocalScan(GestorConfig c,IReadOnlyList<Arcoll.WinUI3.Models.DeviceInfo> scan)
    {
        var all=LocalLoad(c);var now=DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var seen=new HashSet<long>();var next=all.Select(d=>d.Id).DefaultIfEmpty().Max()+1;
        foreach(var item in scan){
            var d=all.FirstOrDefault(d=>item.Mac.Length>0?string.Equals(d.Mac,item.Mac,StringComparison.OrdinalIgnoreCase):d.Ip==item.Ip);
            if(d is null){d=new DeviceRecord{Id=next++,FirstSeen=now,LastChange=now};all.Add(d);}
            if(!d.Online)d.LastChange=now;
            d.DetectedName=item.Name;d.DetectedType=item.Kind;d.Ip=item.Ip;d.Mac=item.Mac;d.Status="online";d.LastSeen=now;
            d.Source="Gestor independente";d.LatencyMs=item.LatencyMs;d.GestorInstalled=item.Ip==NetworkEngine.Local().Ip;seen.Add(d.Id);
        }
        foreach(var d in all.Where(d=>!seen.Contains(d.Id))){if(d.Online)d.LastChange=now;d.Status="offline";}
        LocalDatabase.SetValue(LocalKey(c),JsonSerializer.Serialize(all.Where(d=>d.Pinned||d.LastSeen>=DateTimeOffset.UtcNow.AddDays(-LocalDatabase.RetentionDays).ToUnixTimeSeconds())));
    }
    public static Task SaveAsync(PlatformClient platform, DeviceRecord d, bool hidden, CancellationToken ct)
    {
        if(platform.Config.IsStandalone){ct.ThrowIfCancellationRequested();var rows=LocalLoad(platform.Config);d.Hidden=hidden;var at=rows.FindIndex(x=>x.Id==d.Id);if(at<0)throw new InvalidOperationException("Dispositivo local não encontrado.");rows[at]=d;LocalDatabase.SetValue(LocalKey(platform.Config),JsonSerializer.Serialize(rows));return Task.CompletedTask;}
        return platform.PostAsync("gestor-device-save", platform.WithCredentials(("id", d.Id), ("custom_name", d.CustomName.Trim()), ("custom_type", d.CustomType),
            ("group_name", d.Group.Trim()), ("pinned", d.Pinned ? 1 : 0), ("hidden", hidden ? 1 : 0)), ct, 15);
    }

    private static string Str(JsonElement e, string name) => e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";
    private static long Int(JsonElement e, string name) =>
        e.TryGetProperty(name, out var v) ? v.ValueKind == JsonValueKind.Number && v.TryGetInt64(out var n) ? n : v.ValueKind == JsonValueKind.String && long.TryParse(v.GetString(), out var m) ? m : 0 : 0;
}
