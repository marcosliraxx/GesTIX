# Caminho: gestores/servidor/Arcoll.WinUI3/Assets/Desinstalar_Arcoll.ps1
# T.I. Digital - Desinstalador completo do Gestor (WPF, Windows PowerShell 5.1).
# Remoção do aplicativo com opções independentes para resíduos locais e dados desta instalação na plataforma.
param([switch]$Elevated,[switch]$Authorized,[switch]$Detached,[switch]$Silent,[switch]$AutoStart,[switch]$RemovePlatform,[switch]$RemoveResidues,[int]$Delay = 0)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$themeBase64 = '__INSTALLER_THEME_BASE64__'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Windows.Forms

function Show-Box([string]$text,[string]$icon='Error') {
    [void][System.Windows.Forms.MessageBox]::Show($text,'T.I. Digital · Desinstalação','OK',$icon)
}

# O desinstalador nunca apaga a pasta de onde ele próprio roda: executa uma cópia em TEMP, já elevada.
if (-not $Detached) {
    $stageDir = Join-Path $env:TEMP ('Arcoll-Uninstall-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
    $stageFile = Join-Path $stageDir 'Desinstalar_Arcoll.ps1'
    Copy-Item -LiteralPath $PSCommandPath -Destination $stageFile -Force
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $admin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $argList = @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-STA','-WindowStyle','Hidden','-File',('"' + $stageFile + '"'),'-Elevated','-Detached')
    if ($Silent) { $argList += @('-Silent','-Delay',[string]$Delay) }
    if ($Authorized) { $argList += '-Authorized' }
    if ($AutoStart) { $argList += '-AutoStart' }
    if ($RemovePlatform) { $argList += '-RemovePlatform' }
    if ($RemoveResidues) { $argList += '-RemoveResidues' }
    $startArgs = @{ FilePath = 'powershell.exe'; WorkingDirectory = $stageDir; WindowStyle = 'Hidden'; ArgumentList = $argList }
    if (-not $admin) { $startArgs.Verb = 'RunAs' }
    try { Start-Process @startArgs | Out-Null }
    catch {
        if ($Silent) { exit 1 }
        Show-Box ('O Windows não autorizou a desinstalação. ' + $_.Exception.Message)
        exit 1
    }
    exit 0
}
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    if ($Silent) { exit 1 }
    Show-Box 'Permissão de administrador necessária para concluir a desinstalação.'
    exit 1
}
$script:stageRoot = Split-Path -Parent $PSCommandPath
$script:failed = $false
$script:warnings = New-Object System.Collections.Generic.List[string]

# ---------- Utilidades de limpeza ----------
function Get-UserProfiles {
    @(Get-ChildItem -LiteralPath (Join-Path $env:SystemDrive 'Users') -Directory -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notin @('Public','Default','Default User','All Users') } | ForEach-Object { $_.FullName })
}
function Remove-Tree([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return }
    for ($i = 1; $i -le 6; $i++) {
        try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return }
        catch {
            if ($i -eq 3) {
                # Pastas protegidas (ProgramData\TI-Digital): assume a posse e libera para administradores.
                try { & takeown.exe /F "$path" /R /D Y *> $null; & icacls.exe "$path" /grant '*S-1-5-32-544:(OI)(CI)F' /T /C *> $null } catch {}
            }
            if ($i -eq 6) { throw }
            Start-Sleep -Milliseconds 700
        }
    }
}
function Remove-GestorShortcuts([string]$folder) {
    if (-not $folder -or -not (Test-Path -LiteralPath $folder)) { return }
    $shell = $null; try { $shell = New-Object -ComObject WScript.Shell } catch {}
    Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        $remove = $_.Name -match '(?i)^(T\.?\s?I\.?\s?Digital|Arcoll)'
        if (-not $remove -and $shell) {
            try {
                $sc = $shell.CreateShortcut($_.FullName)
                $blob = (([string]$sc.TargetPath) + ' ' + ([string]$sc.Arguments) + ' ' + ([string]$sc.WorkingDirectory)).ToLowerInvariant()
                if ($blob.Contains('ti-digital') -or $blob.Contains('arcoll.winui3') -or $blob.Contains('c:\arcoll')) { $remove = $true }
            } catch {}
        }
        if ($remove) { try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } catch {} }
    }
}
function Get-InstallationConfig {
    $files = @(
        (Join-Path $env:APPDATA 'Arcoll\gestor.json'),
        (Join-Path $env:LOCALAPPDATA 'TI-Digital\WinUI3\gestor-config.json'),
        (Join-Path $env:ProgramData 'TI-Digital\WinUI3\gestor-config.json'),
        (Join-Path $env:ProgramData 'TI-Digital\Boot\gestor-config.json'),
        'C:\Arcoll\gestor-config.json'
    )
    foreach ($profile in Get-UserProfiles) {
        $files += (Join-Path $profile 'AppData\Roaming\Arcoll\gestor.json')
        $files += (Join-Path $profile 'AppData\Local\TI-Digital\WinUI3\gestor-config.json')
    }
    $values = @{}
    foreach ($file in $files) {
        if (-not (Test-Path -LiteralPath $file)) { continue }
        try {
            $cfg = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $values.ContainsKey('mode') -and $cfg.mode -eq 'standalone') {$values['site_code']='';$values['download_key']=''}
            foreach ($key in @('origin','site_code','fingerprint','download_key','system_name','mode')) {
                if (-not $values.ContainsKey($key) -and $cfg.$key) { $values[$key] = [string]$cfg.$key }
            }
        } catch {}
    }
    if (-not ($values['fingerprint'] -match '^[a-fA-F0-9]{64}$')) {
        try {
            $guid = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
            $sha = [Security.Cryptography.SHA256]::Create()
            $values['fingerprint'] = (($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('arcoll-speed-connection|' + $guid)) | ForEach-Object { $_.ToString('x2') }) -join '')
        } catch {}
    }
    return $values
}
function Remove-PlatformData {
    # Autenticação exclusivamente pela chave vinculada a ESTA instalação. Sem confirmar a exclusão dos dados
    # coletados na plataforma, os arquivos locais NÃO são apagados (evita deixar dados órfãos no banco).
    $v = Get-InstallationConfig
    if ($v['mode'] -eq 'standalone' -and -not $v['site_code'] -and -not $v['download_key']) { return }
    if (-not ($v['origin'] -match '^https://[^/]+') -or -not ($v['site_code'] -match '^[A-Za-z0-9]{5}$') -or
        -not ($v['fingerprint'] -match '^[a-fA-F0-9]{64}$') -or -not ($v['download_key'] -match '^[a-fA-F0-9]{64}$')) {
        $script:warnings.Add('Credenciais desta instalação não encontradas neste computador: os dados na plataforma não puderam ser removidos automaticamente (peça a exclusão ao administrador da rede).')
        return
    }
    $endpoint = $v['origin'].TrimEnd('/') + '/api/api.php?action=gestor-uninstall-self'
    $body = @{ fingerprint = $v['fingerprint'].ToLowerInvariant(); site_code = $v['site_code'].ToUpperInvariant(); download_key = $v['download_key'].ToLowerInvariant() } | ConvertTo-Json -Compress
    try {
        $response = Invoke-RestMethod -Uri $endpoint -Method Post -Body ([Text.Encoding]::UTF8.GetBytes($body)) -ContentType 'application/json' -TimeoutSec 30 -ErrorAction Stop
        if (-not $response.ok -or -not $response.revoked) { throw 'A plataforma não confirmou a exclusão dos dados.' }
    } catch [System.Net.WebException] {
        $status = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
        if ($status -in 403,409) { throw 'A plataforma não autorizou a exclusão. Os dados remotos não foram apagados; confira com o administrador da rede.' }
        throw ('Sem conexão com a plataforma para excluir os dados coletados. Conecte-se à internet e tente novamente. ' + $_.Exception.Message)
    }
}

# ---------- Identidade da plataforma: credenciais exclusivamente desta instalação ----------
function Get-Branding {
    $identity = @{ Name='Gestor'; Tagline='Desinstalação'; Logo=''; Mark='' }
    $cache = Join-Path $env:LOCALAPPDATA 'Arcoll\winui-brand.json'
    try {
        if (Test-Path -LiteralPath $cache) {
            $c = Get-Content -LiteralPath $cache -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($c.server.title) { $identity.Name = [string]$c.server.title }
            if ($c.server.logo) { $identity.Logo = [string]$c.server.logo }
            if ($c.loader_mark) { $identity.Mark = [string]$c.loader_mark }
        }
    } catch {}
    try {
        $v = Get-InstallationConfig
        if (($v['origin'] -match '^https://[^/]+') -and ($v['site_code'] -match '^[A-Za-z0-9]{5}$') -and ($v['download_key'] -match '^[a-fA-F0-9]{64}$') -and ($v['fingerprint'] -match '^[a-fA-F0-9]{64}$')) {
            $endpoint = $v['origin'].TrimEnd('/') + '/api/api.php?action=gestor-config'
            $payload = @{fingerprint=$v['fingerprint'];site_code=$v['site_code'];download_key=$v['download_key']} | ConvertTo-Json -Compress
            $response = Invoke-RestMethod -Uri $endpoint -Method Post -Body ([Text.Encoding]::UTF8.GetBytes($payload)) -ContentType 'application/json' -TimeoutSec 6
            if ($response.ok) {
                if ($response.system_name) { $identity.Name = [string]$response.system_name }
                if ($response.system_description) { $identity.Tagline = [string]$response.system_description }
                if ($response.gestor_brand.server.logo_data) { $identity.Logo = [string]$response.gestor_brand.server.logo_data }
                if ($response.loader_mark) { $identity.Mark = [string]$response.loader_mark }
            }
        }
    } catch { $script:warnings.Add('Identidade visual em cache/local: não foi possível consultar a plataforma.') }
    return $identity
}
function Set-DataImage([string]$value,$target,[bool]$asMask=$false) {
    if ($value -notmatch '^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$' -or $value.Length -gt 400000) { return }
    try {
        $bytes = [Convert]::FromBase64String($Matches[2]); $stream = New-Object IO.MemoryStream(,$bytes)
        $bitmap = New-Object Windows.Media.Imaging.BitmapImage
        $bitmap.BeginInit(); $bitmap.CacheOption=[Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bitmap.StreamSource=$stream; $bitmap.EndInit(); $bitmap.Freeze(); $stream.Dispose()
        if ($asMask) { $brush = New-Object Windows.Media.ImageBrush -ArgumentList $bitmap; $brush.Stretch='Uniform';$target.OpacityMask=$brush }
        else { $target.Source=$bitmap; $target.Visibility='Visible' }
    } catch {}
}
# ---------- Interface ----------
function Get-UninstallTheme([string]$Base64) {
    $t = @{ Bg='#16191f'; Surface='#242a34'; Alt='#303744'; Text='#f1f4fa'; Muted='#b0bbc9'; Accent='#9aaee5'; Line='#485364' }
    try {
        $d = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Base64)) | ConvertFrom-Json
        foreach ($pair in @(@('bg','Bg'),@('surface','Surface'),@('alt','Alt'),@('text','Text'),@('muted','Muted'),@('accent','Accent'),@('border','Line'))) {
            $val = [string]$d.($pair[0]); if ($val -match '^#[a-fA-F0-9]{6}$') { $t[$pair[1]] = $val }
        }
    } catch {}
    return $t
}
$t = Get-UninstallTheme $themeBase64
$brand = Get-Branding
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Desinstalação do Gestor" Width="760" Height="700" MinWidth="560" MinHeight="640" WindowStartupLocation="CenterScreen" ResizeMode="CanMinimize" FontFamily="Segoe UI">
 <Window.Resources>
  <SolidColorBrush x:Key="Bg" Color="#16191f"/><SolidColorBrush x:Key="Surface" Color="#242a34"/><SolidColorBrush x:Key="Alt" Color="#303744"/><SolidColorBrush x:Key="Text" Color="#f1f4fa"/><SolidColorBrush x:Key="Muted" Color="#b0bbc9"/><SolidColorBrush x:Key="Accent" Color="#9aaee5"/><SolidColorBrush x:Key="Line" Color="#485364"/>
  <Style TargetType="Button"><Setter Property="Foreground" Value="{DynamicResource Text}"/><Setter Property="Background" Value="{DynamicResource Alt}"/><Setter Property="BorderBrush" Value="{DynamicResource Line}"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="22,10"/><Setter Property="FontSize" Value="13"/><Setter Property="Cursor" Value="Hand"/>
   <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="Bd" CornerRadius="10" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
    <ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Opacity" Value="0.88"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.45"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
 </Window.Resources>
 <Border Background="{DynamicResource Bg}" Padding="30,22,30,0">
  <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
   <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
    <Border Width="40" Height="40" CornerRadius="10" Background="{DynamicResource Alt}"><Image x:Name="BrandIcon" Width="36" Height="36" Stretch="Uniform" Visibility="Collapsed"/></Border>
    <StackPanel Margin="12,0,0,0" VerticalAlignment="Center"><TextBlock x:Name="BrandName" Text="Gestor" Foreground="{DynamicResource Text}" FontWeight="Bold" FontSize="13"/><TextBlock x:Name="StageLabel" Text="Desinstalação" Foreground="{DynamicResource Muted}" FontSize="10"/></StackPanel>
   </StackPanel>
   <StackPanel Grid.Row="1" VerticalAlignment="Center">
    <TextBlock x:Name="TitleText" Text="Remover o Gestor deste computador" Foreground="{DynamicResource Text}" FontSize="26" FontWeight="SemiBold" HorizontalAlignment="Center" TextAlignment="Center" TextWrapping="Wrap"/>
    <TextBlock x:Name="SubText" Text="A remoção do aplicativo é local. Você pode escolher separadamente se deseja remover resíduos locais e dados vinculados a este computador na plataforma." Foreground="{DynamicResource Muted}" FontSize="13" Margin="20,8,20,0" HorizontalAlignment="Center" TextAlignment="Center" TextWrapping="Wrap"/>
    <Grid Width="240" Height="240" Margin="0,22,0,0">
     <Ellipse Width="220" Height="220" Stroke="{DynamicResource Line}" StrokeThickness="14" Opacity="0.55"/>
     <Ellipse x:Name="Ring" Width="220" Height="220" Stroke="{DynamicResource Accent}" StrokeThickness="14" StrokeDashCap="Flat" RenderTransformOrigin="0.5,0.5"><Ellipse.RenderTransform><RotateTransform Angle="-90"/></Ellipse.RenderTransform></Ellipse><Canvas Width="250" Height="250" IsHitTestVisible="False"><Border x:Name="ProgressBadge" CornerRadius="10" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Accent}" BorderThickness="1" Padding="4,2"><TextBlock x:Name="Percent" Text="0%" Foreground="{DynamicResource Text}" FontSize="11" FontWeight="Bold"/></Border></Canvas>
     <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center"><Border x:Name="LoaderMark" Width="56" Height="56" Background="{DynamicResource Text}" Opacity="0" Margin="0,0,0,6"/><TextBlock x:Name="CircleTag" Text="AGUARDANDO" Foreground="{DynamicResource Muted}" FontSize="11" HorizontalAlignment="Center"/></StackPanel>
    </Grid>
    <CheckBox x:Name="ResidueOption" Content="Remover também configurações, cache, históricos e resíduos locais deste Gestor" Foreground="{DynamicResource Text}" IsChecked="False" Margin="20,10,10,4"/>
    <CheckBox x:Name="PlatformOption" Content="Excluir na plataforma os dados coletados por ESTE computador (irreversível)" Foreground="{DynamicResource Text}" IsChecked="False" Margin="20,0,10,6"/>
    <TextBlock x:Name="StatusText" Text="Confirme para iniciar a desinstalação." Foreground="{DynamicResource Text}" FontSize="14" Margin="10,16,10,0" TextAlignment="Center" TextWrapping="Wrap"/>
    <TextBlock x:Name="DetailText" Text="" Foreground="{DynamicResource Muted}" FontSize="11" Margin="20,6,20,0" TextAlignment="Center" TextWrapping="Wrap"/>
   </StackPanel>
   <Grid Grid.Row="2" Margin="-30,12,-30,0" Background="{DynamicResource Surface}"><StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Margin="30,14">
    <Button x:Name="CancelButton" Content="Cancelar" Margin="0,0,10,0"/>
    <Button x:Name="StartButton" Content="Desinstalar agora" Background="#c0392b" Foreground="#ffffff" BorderBrush="#c0392b"/>
   </StackPanel></Grid>
  </Grid>
 </Border>
</Window>
'@
foreach ($key in @('Bg','Surface','Alt','Text','Muted','Accent','Line')) {
    $xaml = [regex]::Replace($xaml, ('(<SolidColorBrush x:Key="' + $key + '" Color=")[^"]+("/>)'), ('${1}' + $t[$key] + '${2}'))
}
$window = [Windows.Markup.XamlReader]::Parse($xaml)
$ui = @{}
foreach ($n in @('StageLabel','TitleText','SubText','Ring','Percent','ProgressBadge','CircleTag','StatusText','DetailText','CancelButton','StartButton','BrandIcon','BrandName','LoaderMark','ResidueOption','PlatformOption')) { $ui[$n] = $window.FindName($n) }
$localConfig=Get-InstallationConfig
if ($localConfig['mode'] -eq 'standalone' -and -not $localConfig['site_code']) {$ui.PlatformOption.IsEnabled=$false;$ui.PlatformOption.Content='Uso independente: sem dados vinculados na plataforma'}
$window.Title = $brand.Name + ' · Desinstalação do Gestor'
$ui.BrandName.Text = $brand.Name
if ($brand.Tagline) { $ui.StageLabel.Text = $brand.Tagline }
Set-DataImage $brand.Logo $ui.BrandIcon
Set-DataImage $brand.Mark $ui.LoaderMark $true
if ($brand.Mark -match '^data:image/') {
    $anim = New-Object Windows.Media.Animation.DoubleAnimation
    $anim.From=0.25; $anim.To=1.0
    $anim.Duration=New-Object Windows.Duration([TimeSpan]::FromMilliseconds(1000))
    $anim.AutoReverse=$true
    $anim.RepeatBehavior=[Windows.Media.Animation.RepeatBehavior]::Forever
    $ui.LoaderMark.BeginAnimation([Windows.UIElement]::OpacityProperty,$anim)
}
$circumference = [Math]::PI * (220 - 14) / 14
$initialDash = New-Object Windows.Media.DoubleCollection; [void]$initialDash.Add(0); [void]$initialDash.Add(1000); $ui.Ring.StrokeDashArray = $initialDash
function Pump { try { $window.Dispatcher.Invoke([Action]{}, [Windows.Threading.DispatcherPriority]::Background) } catch {} }
function Stage([int]$progress,[string]$message) {
    $p = [Math]::Min(100,[Math]::Max(0,$progress))
    $dash = New-Object Windows.Media.DoubleCollection
    [void]$dash.Add($circumference * $p / 100.0); [void]$dash.Add(1000)
    $ui.Ring.StrokeDashArray = $dash
    $ui.Percent.Text = "$p%"; $angle=2*[Math]::PI*$p/100.0; [Windows.Controls.Canvas]::SetLeft($ui.ProgressBadge,125+110*[Math]::Sin($angle)-16);[Windows.Controls.Canvas]::SetTop($ui.ProgressBadge,125-110*[Math]::Cos($angle)-11); $ui.StatusText.Text = $message; $ui.CircleTag.Text = 'DESINSTALANDO'
    Pump
}
function Finish([bool]$ok,[string]$message) {
    $brush = New-Object Windows.Media.SolidColorBrush([Windows.Media.ColorConverter]::ConvertFromString($(if ($ok) { '#22b78a' } else { '#e26d7b' })))
    $ui.Ring.Stroke = $brush
    $ui.CircleTag.Text = $(if ($ok) { 'CONCLUÍDO' } else { 'ATENÇÃO' })
    $ui.StatusText.Text = $message
    if ($script:warnings.Count) { $ui.DetailText.Text = ($script:warnings -join ' ') }
    $ui.TitleText.Text = $(if ($ok) { 'Gestor removido' } else { 'Desinstalação interrompida' })
    $ui.CancelButton.Visibility = 'Collapsed'; $ui.StartButton.Content = 'Fechar'; $ui.StartButton.IsEnabled = $true
    $ui.StartButton.Background = $window.Resources['Accent']; $ui.StartButton.BorderBrush = $window.Resources['Accent']
    $script:finished = $true
    Pump
}

function Invoke-Removal {
    try {
        Stage 6 'Conferindo a instalação deste computador...'
        if ($RemovePlatform -and -not $Authorized) {
            Stage 12 'Excluindo somente os dados desta instalação na plataforma...'
            Remove-PlatformData
        } else { Stage 12 'Preservando os dados existentes na plataforma...' }

        Stage 28 'Encerrando os processos do Gestor...'
        foreach ($name in @('Arcoll.WinUI3','TIDigital.BootPresence','TIDigital.BackupWorker')) {
            Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $PID } | Stop-Process -Force -ErrorAction SilentlyContinue
        }
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
            $_.ProcessId -ne $PID -and $_.ExecutablePath -and $_.ExecutablePath -match '(?i)\\(TI-Digital|Arcoll)\\'
        } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
            $_.ProcessId -ne $PID -and $_.CommandLine -and $_.CommandLine -match '(?i)arcoll_(gestor|desktop|app|secure_helper)\.py'
        } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

        Stage 42 'Removendo tarefas agendadas e inicialização automática...'
        foreach ($task in @('TI-Digital Gestor Windows','TIDigital-BackupCenter','TI-Digital Presenca PreLogin','ArcollLocalCore','ArcollSecureDesktop')) {
            try { Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue } catch {}
            try { Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue } catch {}
        }
        foreach ($runKey in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run')) {
            foreach ($value in @('TIDigitalGestor','ArcollGestor')) { try { Remove-ItemProperty -Path $runKey -Name $value -ErrorAction SilentlyContinue } catch {} }
        }
        try {
            if (-not (Get-PSDrive -Name HKU -ErrorAction SilentlyContinue)) { New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null }
            Get-ChildItem 'HKU:\' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^S-1-5-21-[\d-]+$' } | ForEach-Object {
                foreach ($value in @('TIDigitalGestor','ArcollGestor')) { try { Remove-ItemProperty -Path ('HKU:\' + $_.PSChildName + '\Software\Microsoft\Windows\CurrentVersion\Run') -Name $value -ErrorAction SilentlyContinue } catch {} }
            }
        } catch {}

        Stage 58 'Removendo atalhos do Desktop, Menu Iniciar e Inicialização...'
        $folders = @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('CommonDesktopDirectory'),[Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('CommonStartup'),[Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('CommonPrograms'))
        foreach ($profile in Get-UserProfiles) {
            $folders += (Join-Path $profile 'Desktop'); $folders += (Join-Path $profile 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs')
        }
        foreach ($folder in ($folders | Select-Object -Unique)) { Remove-GestorShortcuts $folder }

        Stage 72 'Removendo arquivos do aplicativo...'
        if ($RemoveResidues) {
        foreach ($profile in Get-UserProfiles) {
            Remove-Tree (Join-Path $profile 'AppData\Local\TI-Digital')
            Remove-Tree (Join-Path $profile 'AppData\Local\Arcoll')
            Remove-Tree (Join-Path $profile 'AppData\Roaming\Arcoll')
        }
        Remove-Tree (Join-Path $env:LOCALAPPDATA 'TI-Digital'); Remove-Tree (Join-Path $env:LOCALAPPDATA 'Arcoll'); Remove-Tree (Join-Path $env:APPDATA 'Arcoll')
        }
        Stage 86 'Removendo componentes do sistema (ProgramData e Arquivos de Programas)...'
        foreach ($p in @((Join-Path $env:ProgramFiles 'Arcoll'),(Join-Path $env:ProgramFiles 'TI-Digital'),'C:\Arcoll')) { Remove-Tree $p }
        if ($RemoveResidues) { foreach ($p in @((Join-Path $env:ProgramData 'TI-Digital'),(Join-Path $env:ProgramData 'Arcoll'))) { Remove-Tree $p } }
        try { Remove-Item -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ArcollGestor' -Recurse -Force -ErrorAction SilentlyContinue } catch {}

        Stage 95 'Conferindo a limpeza final...'
        $left = @((Join-Path $env:ProgramFiles 'Arcoll'),(Join-Path $env:ProgramFiles 'TI-Digital'),'C:\Arcoll') | Where-Object { Test-Path -LiteralPath $_ }
        if ($left) { throw ('Ainda existem arquivos do gestor em: ' + ($left -join ', ') + '. Reinicie o computador e execute o desinstalador novamente.') }
        try {
            Add-Type -Namespace Arcoll -Name Native -MemberDefinition '[System.Runtime.InteropServices.DllImport("shell32.dll")] public static extern void SHChangeNotify(int e,uint f,System.IntPtr a,System.IntPtr b);'
            [Arcoll.Native]::SHChangeNotify(0x08000000,0,[IntPtr]::Zero,[IntPtr]::Zero)
        } catch {}
        Stage 100 'Aplicativo removido. Resíduos e dados remotos conforme suas opções.'
        return $true
    } catch {
        $script:failed = $true
        $script:errorText = $_.Exception.Message
        return $false
    }
}
function Start-Cleanup {
    try { Start-Process cmd.exe -ArgumentList ('/c ping 127.0.0.1 -n 4 >nul & rd /s /q "' + $script:stageRoot + '"') -WindowStyle Hidden } catch {}
}

if ($Silent) {
    if ($Delay -gt 0) { Start-Sleep -Seconds ([Math]::Min($Delay,60)) }
    $ok = Invoke-Removal
    Start-Cleanup
    if ($ok) { exit 0 } else { exit 1 }
}

$script:finished = $false; $script:running = $false
function Begin-Removal {
    if ($script:running) { return }
    $script:running = $true
    $script:RemoveResidues = [bool]$ui.ResidueOption.IsChecked
    $script:RemovePlatform = [bool]$ui.PlatformOption.IsChecked
    if ($script:RemovePlatform) {
        $answer=[System.Windows.Forms.MessageBox]::Show('Excluir permanentemente na plataforma SOMENTE os dados desta instalação? Outros computadores e seus dados não serão afetados.','Confirmar exclusão remota','YesNo','Warning')
        if ($answer -ne 'Yes') { $script:running=$false; return }
    }
    $ui.ResidueOption.IsEnabled=$false; $ui.PlatformOption.IsEnabled=$false
    $ui.StartButton.IsEnabled = $false; $ui.CancelButton.IsEnabled = $false
    $ui.TitleText.Text = 'Desinstalando…'; $ui.SubText.Text = 'O programa será removido, respeitando as opções selecionadas.'
    $ok = Invoke-Removal
    if ($ok) { Finish $true 'Aplicativo removido com as opções selecionadas.' }
    else { Finish $false ('Não foi possível concluir. ' + $script:errorText) }
}
$ui.CancelButton.Add_Click({ if (-not $script:running) { $window.Close() } })
$ui.StartButton.Add_Click({ if ($script:finished) { $window.Close() } else { Begin-Removal } })
$window.Add_Closing({ param($s,$e) if ($script:running -and -not $script:finished) { $e.Cancel = $true } })
if ($AutoStart) { $window.Add_ContentRendered({ if (-not $script:running) { Begin-Removal } }) }
[void]$window.ShowDialog()
Start-Cleanup
if ($script:failed) { exit 1 }
exit 0
