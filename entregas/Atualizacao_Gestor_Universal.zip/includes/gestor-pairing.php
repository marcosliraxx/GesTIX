<?php
// Caminho: includes/gestor-pairing.php
// Pareamento universal: código temporário público, segredo privado do computador e vagas por rede.
declare(strict_types=1);
require_once __DIR__.'/gestor-topology.php';
function arc_pair_schema(PDO $pdo): void {
    static $ready=false;if($ready)return;
    $pdo->exec('CREATE TABLE IF NOT EXISTS '.arc_table('gestor_pairings')." (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        token_hash CHAR(64) NOT NULL, code_hash CHAR(64) NOT NULL, fingerprint CHAR(64) NOT NULL,
        machine_name VARCHAR(190) NOT NULL, platform VARCHAR(190) NOT NULL, ip_hash CHAR(64) NOT NULL,
        created_at DATETIME NOT NULL, expires_at DATETIME NOT NULL,
        gestor_id BIGINT UNSIGNED NULL, revoked TINYINT NOT NULL DEFAULT 0,
        UNIQUE KEY token_unique(token_hash), UNIQUE KEY code_unique(code_hash), KEY ip_created(ip_hash,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec('CREATE TABLE IF NOT EXISTS '.arc_table('gestor_slots')." (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        account_id BIGINT UNSIGNED NOT NULL, network_id BIGINT UNSIGNED NOT NULL,
        name VARCHAR(160) NOT NULL, gestor_id BIGINT UNSIGNED NULL, created_at DATETIME NOT NULL,
        UNIQUE KEY gestor_unique(gestor_id), KEY network_slots(account_id,network_id),
        FOREIGN KEY (gestor_id) REFERENCES ".arc_table('network_gestores')." (id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");$ready=true;
}
function arc_pair_claim(PDO $pdo,int $account,int $network,int $slot,string $code,string $role): int {
    if(!preg_match('/^[A-F0-9]{16}$/D',$code)||!in_array($role,['server','collaborator'],true))throw new DomainException('Código ou perfil inválido.');
    arc_pair_schema($pdo);$pdo->beginTransaction();
    try {
        $q=$pdo->prepare('SELECT id FROM '.arc_table('user_accounts').' WHERE id=? FOR UPDATE');$q->execute([$account]);
        arc_gt_lock($pdo,$account,$network);
        $q=$pdo->prepare('SELECT * FROM '.arc_table('gestor_slots').' WHERE id=? AND account_id=? AND network_id=? FOR UPDATE');$q->execute([$slot,$account,$network]);$s=$q->fetch(PDO::FETCH_ASSOC);
        if(!$s||$s['gestor_id'])throw new DomainException('Selecione um vínculo vazio desta rede.');
        $q=$pdo->prepare('SELECT * FROM '.arc_table('gestor_pairings').' WHERE code_hash=? AND expires_at>NOW() AND gestor_id IS NULL AND revoked=0 FOR UPDATE');$q->execute([hash('sha256',$code)]);$p=$q->fetch(PDO::FETCH_ASSOC);
        if(!$p)throw new DomainException('Código inválido, expirado ou já utilizado. Abra um novo código no Gestor.');
        if($role==='server'&&(int)arc_gt_state($pdo,$account,$network)['primary']>0)throw new DomainException('A rede já possui servidor. Use Colaborador e transfira o perfil nas permissões.');
        $q=$pdo->prepare('SELECT id FROM '.arc_table('network_gestores').' WHERE fingerprint=? FOR UPDATE');$q->execute([$p['fingerprint']]);
        if($q->fetchColumn())throw new DomainException('Este computador já possui vínculo. Desvincule-o na rede anterior.');
        $q=$pdo->prepare('SELECT site_code FROM '.arc_table('managed_networks').' WHERE id=? AND account_id=? AND monitoring_enabled=1');$q->execute([$network,$account]);$site=$q->fetchColumn();
        if(!$site)throw new DomainException('Monitoramento da rede desativado.');
        arc_billing_enforce($pdo,$account,'gestores');
        $q=$pdo->prepare('INSERT INTO '.arc_table('network_gestores')." (fingerprint,account_id,network_id,site_code,machine_name,platform,status,installation_profile,approved_at) VALUES (?,?,?,?,?,?,'approved',?,NOW())");
        $q->execute([$p['fingerprint'],$account,$network,$site,$p['machine_name'],$p['platform'],$role]);$id=(int)$pdo->lastInsertId();
        $q=$pdo->prepare('INSERT INTO '.arc_table('gestor_download_keys').' (token_hash,account_id,network_id,site_code,fingerprint,used_at) VALUES (?,?,?,?,?,NOW())');$q->execute([$p['token_hash'],$account,$network,$site,$p['fingerprint']]);
        arc_gt_write($pdo,$account,$network,'gestor_profile_'.$id,['mask'=>$role==='server'?127:31,'confirmed'=>true,'requested'=>$role,'revoked'=>false]);
        arc_gt_approve_locked($pdo,$account,$network,$id);
        $pdo->prepare('UPDATE '.arc_table('gestor_pairings').' SET gestor_id=? WHERE id=?')->execute([$id,$p['id']]);
        $pdo->prepare('UPDATE '.arc_table('gestor_slots').' SET gestor_id=? WHERE id=?')->execute([$id,$slot]);
        $pdo->commit();return $id;
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
