<?php
/* Caminho: redes/liberacao.php — cores visuais vinculadas ao tema ativo. */
// Caminho: redes/liberacao.php
/** Tela de instalação/liberação de gestores da rede com grade pesquisável e ordenação por coluna. */
declare(strict_types=1);
require_once __DIR__ . '/../includes/error-logging.php';

require_once dirname(__DIR__) . '/includes/bootstrap.php';

// Salvamento do modal "Perfil e permissões": sempre responde JSON, mesmo em erro fatal ou aviso do PHP.
// Sem isto a hospedagem devolvia a própria página HTML de erro e o modal só mostrava "Erro HTTP do servidor".
$arcProfileSaveRequest = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && (string)($_POST['action'] ?? '') === 'release_profile_save';
if ($arcProfileSaveRequest) {
    @ini_set('display_errors', '0');
    @set_time_limit(60);
    ob_start();
    register_shutdown_function(static function (): void {
        $last = error_get_last();
        if (!$last || !in_array($last['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) return;
        $ref = substr(hash('sha256', $last['message'] . '|' . $last['file'] . ':' . $last['line']), 0, 10);
        arc_log_error('[redes/liberacao.php] Erro fatal (' . $ref . '): ' . $last['message'] . ' em ' . $last['file'] . ':' . $last['line']);
        while (ob_get_level() > 0) @ob_end_clean();
        if (!headers_sent()) { http_response_code(500); header('Content-Type: application/json; charset=utf-8'); }
        echo json_encode(['ok' => false, 'message' => 'Não foi possível salvar as permissões. Referência: ' . $ref], JSON_UNESCAPED_UNICODE);
    });
}
$pdo = arc_db();
arc_ensure_user_schema($pdo);
header('Cache-Control: private, no-store, max-age=0');

if (!arc_is_user() && !arc_is_admin()) {
    header('Location: ' . arc_workspace_base_url() . 'index.php', true, 303);
    exit;
}

$networkId = (int)($_GET['network'] ?? $_POST['network'] ?? 0);
$access = arc_network_team_access($pdo, $networkId, (int)arc_user_id());
if (!$access) {
    http_response_code(403);
    exit('Rede não autorizada.');
}

if (!in_array($access['role'], ['owner', 'system_admin'], true)) { $rights=arc_network_profile_rights($pdo,$networkId,(int)arc_user_id());if($rights!==null&&!in_array('liberacao',$rights,true)){http_response_code(403);exit('Seu perfil não permite abrir Liberações.');} }
$account = (int)$access['account_id'];
$isOwner = in_array($access['role'], ['owner', 'system_admin'], true);
$isNetworkOwner = $isOwner;
$q = $pdo->prepare('SELECT id,name,site_code,logo_file,monitoring_enabled,is_active FROM ' . arc_table('managed_networks') . ' WHERE id=? AND account_id=? LIMIT 1');
$q->execute([$networkId, $account]);
$network = $q->fetch(PDO::FETCH_ASSOC);
if (!$network || !(int)$network['is_active']) {
    http_response_code(404);
    exit('Rede indisponível.');
}

require_once dirname(__DIR__) . '/includes/gestor-pairing.php';
arc_pair_schema($pdo);
$csrf = arc_csrf_token();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isOwner) {
        http_response_code(403);
        exit('Somente o proprietário da rede pode liberar gestores.');
    }
    arc_verify_csrf();
    $action = (string)($_POST['action'] ?? '');
    $profileAjax = $action === 'release_profile_save' && ((string)($_GET['ajax'] ?? '') === '1' || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest' || stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false);
    // O modal sempre usa fetch; alguns proxies do cPanel removem X-Requested-With,
    // portanto Accept: application/json também identifica o fluxo sem redirecionamento.

    if (in_array($action, ['slot_create','slot_delete','gestor_block','gestor_archive'], true)) {
        try {
            $pdo->beginTransaction();arc_gt_lock($pdo,$account,$networkId);
            if ($action==='slot_create') {
                $limit=max(1,min(10000,(int)arc_platform_setting($pdo,'platform_gestor_slots_limit','100')));
                $q=$pdo->prepare('SELECT COUNT(*) FROM '.arc_table('gestor_slots').' WHERE account_id=? AND network_id=?');$q->execute([$account,$networkId]);
                if((int)$q->fetchColumn()>=$limit)throw new DomainException('Limite administrativo de vínculos atingido.');
                $name=mb_substr(trim((string)($_POST['slot_name']??'')),0,160);if($name==='')$name='Novo computador';
                $pdo->prepare('INSERT INTO '.arc_table('gestor_slots').' (account_id,network_id,name,created_at) VALUES (?,?,?,NOW())')->execute([$account,$networkId,$name]);
            } elseif ($action==='slot_delete') {
                $q=$pdo->prepare('DELETE FROM '.arc_table('gestor_slots').' WHERE id=? AND account_id=? AND network_id=? AND gestor_id IS NULL');$q->execute([(int)($_POST['slot_id']??0),$account,$networkId]);
                if(!$q->rowCount())throw new DomainException('Somente vínculos vazios podem ser excluídos.');
            } else {
                $id=(int)($_POST['gestor_id']??0);
                $q=$pdo->prepare('SELECT id FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=? FOR UPDATE');$q->execute([$id,$account,$networkId]);
                if(!$q->fetchColumn())throw new DomainException('Computador não encontrado.');
                if($action==='gestor_archive') {
                    arc_gt_revoke_locked($pdo,$account,$networkId,$id);
                    $pdo->prepare('UPDATE '.arc_table('network_gestores')." SET notes='EXCLUIDO|Cadastro removido da grade; histórico preservado' WHERE id=? AND account_id=? AND network_id=?")->execute([$id,$account,$networkId]);
                } else {
                    $pdo->prepare('UPDATE '.arc_table('network_gestores')." SET status='blocked' WHERE id=? AND account_id=? AND network_id=?")->execute([$id,$account,$networkId]);
                    $pdo->prepare('UPDATE '.arc_table('gestor_commands')." SET status='failed',result_text='Gestor bloqueado',completed_at=NOW() WHERE gestor_id=? AND account_id=? AND network_id=? AND status IN ('pending','running')")->execute([$id,$account,$networkId]);
                }
            }
            $pdo->commit();arc_user_audit($pdo,$action,'Vínculos da rede '.$networkId,$account);
            header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.$networkId,true,303);exit;
        }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e instanceof DomainException?$e->getMessage():'Não foi possível alterar o vínculo.';arc_log_error('[vínculos] '.$e->getMessage());}
    }
    if($action==='gestor_pair_code' && (int)($_POST['slot_id']??0)>0) {
        try {
            $code=strtoupper(preg_replace('/[\s-]+/','',(string)($_POST['pair_code']??'')));
            arc_pair_claim($pdo,$account,$networkId,(int)$_POST['slot_id'],$code,(string)($_POST['pair_role']??'collaborator'));
            header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.$networkId,true,303);exit;
        }catch(Throwable $e){$error=$e instanceof DomainException?$e->getMessage():'Não foi possível vincular o Gestor.';arc_log_error('[vínculos] '.$e->getMessage());}
        $action=''; // Não executar o pareamento legado depois de uma falha no vínculo universal.
    }
    // Pareamento validado com a credencial criptográfica já registrada no download.
    // O código não contém o segredo e nunca autoriza outra rede/conta.
    if ($action === 'gestor_pair_code') {
        try {
            $code = strtoupper(preg_replace('/[\s-]+/', '', (string)($_POST['pair_code'] ?? '')));
            $role = (string)($_POST['pair_role'] ?? 'collaborator');
            if (!preg_match('/^[A-F0-9]{16}$/D', $code) || !in_array($role, ['server','collaborator'], true)) {
                throw new DomainException('Informe o código de 16 caracteres e o perfil desejado.');
            }
            $pdo->beginTransaction();
            arc_gt_lock($pdo, $account, $networkId);
            $q = $pdo->prepare('SELECT g.id,g.fingerprint,k.token_hash FROM '.arc_table('network_gestores').' g INNER JOIN '.arc_table('gestor_download_keys').' k ON k.account_id=g.account_id AND k.network_id=g.network_id AND k.fingerprint=g.fingerprint WHERE g.account_id=? AND g.network_id=? AND g.status=\'pending\' FOR UPDATE');
            $q->execute([$account,$networkId]);
            $found = 0;
            foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $candidate) {
                try { $match = hash_equals(arc_gt_pair_code((string)$candidate['fingerprint'], (string)$candidate['token_hash']), $code); }
                catch (InvalidArgumentException $ignored) { continue; }
                if ($match) { $found=(int)$candidate['id']; break; }
            }
            if (!$found) throw new DomainException('Código não localizado entre os Gestores aguardando liberação desta rede.');
            if ($role==='server' && (int)arc_gt_state($pdo,$account,$networkId)['primary']>0) {
                throw new DomainException('Esta rede já possui um Servidor. Selecione Colaborador ou transfira o perfil no controle existente.');
            }
            arc_billing_enforce($pdo,$account,'gestores');
            $q=$pdo->prepare('UPDATE '.arc_table('network_gestores')." SET installation_profile=?,status='approved',ui_locked=0,approved_at=NOW() WHERE id=? AND account_id=? AND network_id=? AND status='pending'");
            $q->execute([$role,$found,$account,$networkId]);
            if ($q->rowCount()!==1) throw new DomainException('Este código já foi utilizado.');
            arc_gt_write($pdo,$account,$networkId,'gestor_profile_'.$found,[
                'mask'=>$role==='server'?127:31,'confirmed'=>true,'requested'=>$role,'revoked'=>false
            ]);
            // Mesma coordenação transacional usada na aprovação atual.
            arc_gt_approve_locked($pdo,$account,$networkId,$found);
            $pdo->commit();
            arc_user_audit($pdo,'gestor_code_paired','Gestor '.$found.' vinculado como '.$role.' à rede '.$networkId,$account);
            header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.$networkId,true,303); exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e instanceof DomainException || $e instanceof InvalidArgumentException ? $e->getMessage() : 'Falha na vinculação. Confira o código e consulte o log do servidor.';
            if (!($e instanceof DomainException) && !($e instanceof InvalidArgumentException)) arc_log_error('[liberacao/pareamento] '.$e->getMessage());
        }
    }
    // Ações nativas de Liberações: sessão autenticada, proprietário e CSRF, sem pedir a senha novamente.
    if (in_array($action, ['release_profile_save', 'release_unlink'], true)) {
        try {
            $id = (int)($_POST['gestor_id'] ?? 0);
            $q = $pdo->prepare('SELECT id,account_id,network_id,status,machine_name FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=? LIMIT 1');
            $q->execute([$id,$account,$networkId]);
            $target=$q->fetch(PDO::FETCH_ASSOC);
            if (!$target) throw new DomainException('Computador não encontrado nesta rede.');
            if ($action==='release_unlink') {
                if (($_POST['confirmed']??'')!=='1') throw new DomainException('Confirme a desvinculação.');
                arc_gt_change($pdo,$account,$networkId,$id,'revoke',0,'collaborator');
            } else {
                if ((string)$target['status']!=='approved') throw new DomainException('Somente gestores aprovados podem ser configurados.');
                $role=(string)($_POST['role']??'collaborator');
                if (!in_array($role,['server','collaborator'],true)) throw new DomainException('Perfil inválido.');
                $caps=array_keys(arc_gt_capabilities());
                $selected=(array)($_POST['capability']??[]);
                // Formato compacto (um único campo): evita regras de WAF/limite de campos da hospedagem.
                if(isset($_POST['caps'])&&is_string($_POST['caps']))$selected=array_merge($selected,array_values(array_filter(explode(',',$_POST['caps']),'strlen')));
                $selected=array_values(array_unique(array_map('strval',$selected)));
                if (count($selected)>count($caps) || array_diff($selected,$caps)) throw new DomainException('Permissões inválidas.');
                if ($role==='collaborator') $selected=array_values(array_diff($selected,['network_scan','coordinate']));
                $mask=0;foreach($selected as $cap)$mask|=arc_gt_capabilities()[$cap];
                $menuGroups=arc_workspace_menu()['groups'];$validMenus=[];
                foreach($menuGroups as $group)if(($group['key']??'')!=='management')foreach(($group['items']??[]) as $menu)$validMenus[]=(string)$menu['key'];
                $menus=(array)($_POST['ui_menu']??[]);
                if(isset($_POST['ui_menus'])&&is_string($_POST['ui_menus']))$menus=array_merge($menus,array_values(array_filter(explode(',',$_POST['ui_menus']),'strlen')));
                $menus=array_values(array_unique(array_map('strval',$menus)));
                if(count($menus)>count($validMenus)||array_diff($menus,$validMenus))throw new DomainException('Menus inválidos.');
                $profile=arc_gt_profile($pdo,$target);
                $oldRole=(string)$profile['role'];
                $operation=!empty($profile['confirmed'])?'permissions':'confirm';
                if($role!==$oldRole){
                    if($role==='server'){
                        if(($_POST['confirmed']??'')!=='1')throw new DomainException('Confirme a transferência de servidor.');
                        $operation='transfer';
                    }else{$operation='confirm';}
                }
                if($operation==='transfer'&&($_POST['confirmed']??'')!=='1')throw new DomainException('Confirme a transferência.');
                // O Servidor sempre enxerga o catálogo completo; só o Colaborador tem menus próprios gravados.
                $menusToSave=$role==='server'?null:$menus;
                for($attempt=1;;$attempt++){
                    try{arc_gt_change($pdo,$account,$networkId,$id,$operation,$mask,$role,$menusToSave,isset($_POST['background']));break;}
                    catch(PDOException $lockError){
                        $driverCode=(int)($lockError->errorInfo[1]??0);
                        if(in_array($driverCode,[1205,1213],true)&&$attempt<4){usleep(300000*$attempt);continue;}
                        throw $lockError;
                    }
                }
            }
            if ($profileAjax) {while(ob_get_level()>0)@ob_end_clean();header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'message'=>'Perfil e permissões salvos. O Gestor Servidor ou Colaborador aplicará as alterações na próxima verificação automática.'],JSON_UNESCAPED_UNICODE);exit;}
            header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.$networkId,true,303);exit;
        }catch(Throwable $e){
            $diagnostic=substr(hash('sha256',get_class($e).'|'.$e->getMessage().'|'.gmdate('Y-m-d H:i')),0,10);
            arc_log_error('[redes/liberacao.php] Falha de persistência ('.$diagnostic.'): '.get_class($e).' '.$e->getMessage().' em '.$e->getFile().':'.$e->getLine());
            $error=$e instanceof DomainException||$e instanceof InvalidArgumentException?$e->getMessage():'Falha ao salvar configurações. Referência: '.$diagnostic.'. Verifique o error_log do cPanel.';
            if ($profileAjax) {while(ob_get_level()>0)@ob_end_clean();http_response_code($e instanceof DomainException||$e instanceof InvalidArgumentException?422:500);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'message'=>$error],JSON_UNESCAPED_UNICODE);exit;}
        }
    }
    if (in_array($action,['rebind_approve','rebind_reject'],true)) {
        $id=(int)($_POST['request_id']??0);
        try {
            $pdo->beginTransaction();
            $q=$pdo->prepare('SELECT * FROM '.arc_table('gestor_rebind_requests')." WHERE id=? AND account_id=? AND network_id=? AND status='pending' FOR UPDATE");
            $q->execute([$id,$account,$networkId]);$candidate=$q->fetch(PDO::FETCH_ASSOC);
            if (!$candidate) throw new RuntimeException('Solicitação de vinculação não encontrada.');
            if ($action==='rebind_approve') {
                $q=$pdo->prepare('SELECT id,account_id,network_id,status FROM '.arc_table('network_gestores').' WHERE fingerprint=? FOR UPDATE');
                $q->execute([(string)$candidate['fingerprint']]);$existing=$q->fetch(PDO::FETCH_ASSOC);
                if ($existing && (int)$existing['account_id']!==$account) {
                    throw new RuntimeException('O computador já pertence a outra conta.');
                }
                // Computador vindo de outra rede da mesma conta: o cadastro antigo é preservado como
                // histórico (bloqueado/transferido) e um novo cadastro aprovado é criado nesta rede.
                if ($existing && (int)$existing['network_id']!==$networkId) {
                    $historic=hash('sha256','historico:'.(string)$candidate['fingerprint'].':'.$existing['id']);
                    $q=$pdo->prepare('UPDATE '.arc_table('network_gestores')." SET fingerprint=?,status='blocked',ui_locked=0,uninstall_requested=0,notes=? WHERE id=?");
                    $q->execute([$historic,mb_substr('TRANSFERIDO|'.date('Y-m-d H:i:s').'|Novo local: '.(string)$candidate['site_code'],0,500),(int)$existing['id']]);
                    // As chaves da rede anterior deixam de valer para este computador.
                    $q=$pdo->prepare('UPDATE '.arc_table('gestor_download_keys').' SET fingerprint=? WHERE fingerprint=? AND network_id=? AND account_id=?');
                    $q->execute([$historic,(string)$candidate['fingerprint'],(int)$existing['network_id'],$account]);
                    $existing=false;
                }
                if (!$existing) {
                    arc_billing_enforce($pdo,$account,'gestores');
                    $q=$pdo->prepare('INSERT INTO '.arc_table('network_gestores')." (fingerprint,account_id,network_id,site_code,machine_name,platform,status,approved_at) VALUES (?,?,?,?,?,'Windows','approved',NOW())");
                    $q->execute([(string)$candidate['fingerprint'],$account,$networkId,(string)$candidate['site_code'],(string)$candidate['machine_name']]);
                    $approvedGestorId=(int)$pdo->lastInsertId();
                } else {
                    if ((string)$existing['status']!=='approved')arc_billing_enforce($pdo,$account,'gestores');
                    $q=$pdo->prepare('UPDATE '.arc_table('network_gestores')." SET installation_profile=CASE WHEN status='approved' THEN installation_profile ELSE 'collaborator' END,status='approved',uninstall_requested=0,ui_locked=0,notes='',approved_at=NOW(),machine_name=?,site_code=? WHERE id=?");
                    $q->execute([(string)$candidate['machine_name'],(string)$candidate['site_code'],(int)$existing['id']]);
                    $approvedGestorId=(int)$existing['id'];
                }
                arc_gestor_assign_profile($pdo,$networkId,$account,$approvedGestorId);
                // Rotação da chave revogável apenas após a aprovação expressa do gestor.
                $q=$pdo->prepare('DELETE FROM '.arc_table('gestor_download_keys').' WHERE fingerprint=? AND network_id=? AND account_id=? AND token_hash<>?');
                $q->execute([(string)$candidate['fingerprint'],$networkId,$account,(string)$candidate['token_hash']]);
                // A chave pode já existir (pacote baixado pelo painel e usado no pedido automático do instalador).
                $q=$pdo->prepare('SELECT id,fingerprint,network_id,account_id FROM '.arc_table('gestor_download_keys').' WHERE token_hash=? LIMIT 1 FOR UPDATE');
                $q->execute([(string)$candidate['token_hash']]);$keyRow=$q->fetch(PDO::FETCH_ASSOC);
                if ($keyRow) {
                    $keyFp=strtolower(trim((string)($keyRow['fingerprint']??'')));
                    if ((int)$keyRow['network_id']!==$networkId || (int)$keyRow['account_id']!==$account ||
                        ($keyFp!=='' && !hash_equals($keyFp,(string)$candidate['fingerprint']))) {
                        throw new RuntimeException('Esta solicitação já foi utilizada.');
                    }
                    $q=$pdo->prepare('UPDATE '.arc_table('gestor_download_keys').' SET fingerprint=?,used_at=COALESCE(used_at,NOW()) WHERE id=?');
                    $q->execute([(string)$candidate['fingerprint'],(int)$keyRow['id']]);
                } else {
                    $q=$pdo->prepare('INSERT INTO '.arc_table('gestor_download_keys').' (token_hash,account_id,network_id,site_code,fingerprint,used_at) VALUES (?,?,?,?,?,NOW())');
                    $q->execute([(string)$candidate['token_hash'],$account,$networkId,(string)$candidate['site_code'],(string)$candidate['fingerprint']]);
                }
            }
            $q=$pdo->prepare('UPDATE '.arc_table('gestor_rebind_requests').' SET status=?,reviewed_at=NOW() WHERE id=?');
            $q->execute([$action==='rebind_approve'?'approved':'rejected',$id]);
            $pdo->commit();
            arc_user_audit($pdo,$action==='rebind_approve'?'gestor_rebind_approved':'gestor_rebind_rejected','Recuperação de credencial: '.(string)$candidate['machine_name'].' ('.(string)$candidate['site_code'].')');
            header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.$networkId,true,303);exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction())$pdo->rollBack();
            $error=$e instanceof RuntimeException?$e->getMessage():'Não foi possível concluir a liberação.';
        }
    }
    if ($action === 'monitoring_enable') {
        $q = $pdo->prepare('UPDATE ' . arc_table('managed_networks') . ' SET monitoring_enabled=1 WHERE id=? AND account_id=? AND is_active=1');
        $q->execute([$networkId, $account]);
        arc_user_audit($pdo, 'network_monitoring_enabled', 'Monitoramento ativado na liberação da rede ID ' . $networkId);
        header('Location: ' . arc_workspace_base_url() . 'redes/liberacao.php?network=' . $networkId, true, 303);
        exit;
    }

    if($action==='gestor_promote_server'){
        header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.(int)$networkId.'&transfer='.(int)($_POST['gestor_id']??0),true,303);exit;
    }
    if (in_array($action, ['gestor_reject','gestor_lock_toggle','gestor_headless_toggle','gestor_uninstall_toggle'], true)) {
        $id = (int)($_POST['gestor_id'] ?? 0);
        $q = $pdo->prepare('SELECT id,machine_name,status,headless_mode,ui_locked,uninstall_requested,notes FROM ' . arc_table('network_gestores') . ' WHERE id=? AND network_id=? AND account_id=? LIMIT 1');
        $q->execute([$id,$networkId,$account]);
        $item=$q->fetch(PDO::FETCH_ASSOC);
        if (!$item) { $error='Gestor não encontrado nesta rede.'; }
        else {
            $oldStatus=(string)$item['status'];
            $alreadyRemoved=str_starts_with((string)($item['notes']??''),'DESINSTALADO|');
            $uninstallPending=(int)$item['uninstall_requested']===1;
            $valid=($action==='gestor_reject' && $oldStatus==='pending')
                || ($action==='gestor_lock_toggle' && $oldStatus==='approved' && !$uninstallPending)
                || ($action==='gestor_headless_toggle' && $oldStatus==='approved')
                || ($action==='gestor_uninstall_toggle' && !$alreadyRemoved && ($uninstallPending || $oldStatus==='approved'));
            if (!$valid) {
                $error='Esta ação não está disponível para o estado atual do gestor.';
            } elseif ($action === 'gestor_headless_toggle') {
                $next=(int)$item['headless_mode']===1?0:1;
                $q=$pdo->prepare('UPDATE '.arc_table('network_gestores').' SET headless_mode=? WHERE id=? AND network_id=? AND account_id=?');
                $q->execute([$next,$id,$networkId,$account]);
                arc_user_audit($pdo,$next?'network_gestor_headless_enabled':'network_gestor_headless_disabled','Modo sem monitor modificado para o gestor '.$id);
            } elseif ($action === 'gestor_lock_toggle') {
                // Bloquear não derruba o gestor: ele segue ativo e monitorando; só a tela local passa a exigir login.
                $next=(int)$item['ui_locked']===1?0:1;
                $pdo->beginTransaction();
                try {
                    $g=$pdo->prepare('SELECT * FROM '.arc_table('network_gestores')." WHERE id=? AND network_id=? AND account_id=? AND status='approved' FOR UPDATE");
                    $g->execute([$id,$networkId,$account]);$gestorRow=$g->fetch(PDO::FETCH_ASSOC);
                    if (!$gestorRow) throw new DomainException('O computador não está aprovado.');
                    if ($next===1) {
                        arc_gt_require($pdo,$gestorRow,'support');
                        require_once dirname(__DIR__).'/includes/support.php';
                        $pending=$pdo->prepare('SELECT id FROM '.arc_table('gestor_commands')." WHERE gestor_id=? AND account_id=? AND network_id=? AND command_name='screen_lock' AND status IN ('pending','running') LIMIT 1");
                        $pending->execute([$id,$account,$networkId]);
                        if (!$pending->fetchColumn()) arc_support_queue_service($pdo,$account,$networkId,$id,'screen_lock',(int)arc_user_id());
                    }
                    $pdo->prepare('UPDATE '.arc_table('network_gestores').' SET ui_locked=? WHERE id=? AND network_id=? AND account_id=?')->execute([$next,$id,$networkId,$account]);
                    $pdo->commit();
                } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
                arc_user_audit($pdo,$next?'network_gestor_locked':'network_gestor_unlocked','Tela do gestor '.($next?'protegida e bloqueio Windows solicitado':'liberada na interface (sem desbloquear a sessão Windows)').': gestor '.$id);
            } elseif ($action === 'gestor_uninstall_toggle') {
                $next=$uninstallPending?0:1;
                $q=$pdo->prepare('UPDATE '.arc_table('network_gestores').' SET uninstall_requested=?,ui_locked=0 WHERE id=? AND network_id=? AND account_id=?');
                $q->execute([$next,$id,$networkId,$account]);
                arc_user_audit($pdo,$next?'network_gestor_uninstall_requested':'network_gestor_uninstall_cancelled','Desinstalação '.($next?'solicitada':'cancelada').' para o gestor '.$id);
            } else {
                $q=$pdo->prepare('UPDATE '.arc_table('network_gestores').' SET status=\'rejected\' WHERE id=? AND network_id=? AND account_id=?');
                $q->execute([$id,$networkId,$account]);
                arc_user_audit($pdo,'network_gestor_rejected','Estado alterado para rejected no gestor '.$id);
            }
            header('Location: '.arc_workspace_base_url().'redes/liberacao.php?network='.$networkId,true,303);exit;
        }
    }
    if ($action === 'gestor_approve') {
        $id = (int)($_POST['gestor_id'] ?? 0);
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare('SELECT id FROM ' . arc_table('user_accounts') . ' WHERE id=? FOR UPDATE');
            $lock->execute([$account]);
            arc_gt_lock($pdo,(int)$account,(int)$networkId);
            $get = $pdo->prepare('SELECT id,machine_name,status,notes FROM ' . arc_table('network_gestores') . ' WHERE id=? AND account_id=? AND network_id=? FOR UPDATE');
            $get->execute([$id, $account, $networkId]);
            $candidate = $get->fetch(PDO::FETCH_ASSOC);
            if (!$candidate || !in_array((string)$candidate['status'], ['pending', 'blocked'], true) || str_starts_with((string)($candidate['notes'] ?? ''),'DESINSTALADO|')) {
                throw new RuntimeException('O gestor não está disponível para liberação.');
            }
            arc_billing_enforce($pdo, $account, 'gestores');
            $approve = $pdo->prepare("UPDATE " . arc_table('network_gestores') . " SET installation_profile='collaborator',status='approved',ui_locked=0,approved_at=NOW() WHERE id=? AND account_id=? AND network_id=? AND status IN ('pending','blocked')");
            $approve->execute([$id, $account, $networkId]);
            if ($approve->rowCount() !== 1) {
                throw new RuntimeException('Não foi possível confirmar a liberação.');
            }
            arc_gestor_assign_profile($pdo,$networkId,$account,$id);
            $pdo->commit();
            arc_user_audit($pdo, 'network_gestor_approved', 'Gestor liberado: ' . (string)$candidate['machine_name'] . ' (Rede ID ' . $networkId . ')');
            header('Location: ' . arc_workspace_base_url() . 'redes/liberacao.php?network=' . $networkId, true, 303);
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível liberar o gestor.';
        }
    }
}

$getGestores = $pdo->prepare('SELECT id,account_id,network_id,fingerprint,machine_name,platform,local_ip,gestor_version,status,first_seen_at,last_seen_at,approved_at,machine_details,headless_mode,ui_locked,uninstall_requested,installation_profile,notes FROM ' . arc_table('network_gestores') . ' WHERE network_id=? AND account_id=? ORDER BY first_seen_at DESC,id DESC');
$getGestores->execute([$networkId, $account]);
$gestores = array_values(array_filter($getGestores->fetchAll(PDO::FETCH_ASSOC),static fn($g)=>!str_starts_with((string)($g['notes']??''),'EXCLUIDO|')&&!str_starts_with((string)($g['notes']??''),'DESVINCULADO|')));
$slotQuery=$pdo->prepare('SELECT id,name FROM '.arc_table('gestor_slots').' WHERE account_id=? AND network_id=? AND gestor_id IS NULL ORDER BY id');$slotQuery->execute([$account,$networkId]);$emptySlots=$slotQuery->fetchAll(PDO::FETCH_ASSOC);
$rebindStmt=$pdo->prepare('SELECT id,machine_name,fingerprint,requested_at,status FROM '.arc_table('gestor_rebind_requests')." WHERE network_id=? AND account_id=? AND status='pending' ORDER BY requested_at DESC");
$rebindStmt->execute([$networkId,$account]);
$rebindRequests=$rebindStmt->fetchAll(PDO::FETCH_ASSOC);
// Solicitações de recuperação entram na própria grade. O cadastro existente é
// aproveitado quando há fingerprint correspondente, evitando linhas duplicadas.
$rebindByFingerprint=[];
$existingFingerprints=[];
foreach ($gestores as $gestor) {
    $existingFingerprints[(string)$gestor['fingerprint']]=true;
}
foreach ($rebindRequests as $request) {
    $fingerprint=(string)$request['fingerprint'];
    $rebindByFingerprint[$fingerprint]=$request;
    if (!isset($existingFingerprints[$fingerprint])) {
        $gestores[]=[
            'id'=>0,'fingerprint'=>$fingerprint,'machine_name'=>(string)$request['machine_name'],
            'platform'=>'Windows','local_ip'=>'','gestor_version'=>'',
            'status'=>'pending','first_seen_at'=>(string)$request['requested_at'],
            'last_seen_at'=>null,'approved_at'=>null,'machine_details'=>null,
            'headless_mode'=>0,'ui_locked'=>0,'uninstall_requested'=>0,'installation_profile'=>'collaborator','notes'=>''
        ];
    }
}

// O Servidor principal fica primeiro também nos seletores que reutilizam esta lista.
usort($gestores, static function(array $a,array $b): int {
    $serverA=(string)($a['installation_profile']??'')==='server'?1:0;
    $serverB=(string)($b['installation_profile']??'')==='server'?1:0;
    return ($serverB<=>$serverA)
        ?: strcmp((string)($b['first_seen_at']??''),(string)($a['first_seen_at']??''))
        ?: ((int)$b['id']<=>(int)$a['id']);
});


$gestoresSignature = hash('sha256', json_encode(array_map(static fn(array $a): array => [(int)$a['id'], (string)$a['status'], (string)($a['installation_profile'] ?? ''), str_starts_with((string)($a['notes'] ?? ''), 'DESINSTALADO|'), (int)$a['ui_locked'], (int)$a['uninstall_requested']], $gestores)));
$gestoresSignature = hash('sha256', $gestoresSignature . json_encode(array_map(static fn(array $r): array => [(int)$r['id'],(string)$r['status']],$rebindRequests)));
$approved = array_values(array_filter($gestores, static fn(array $a): bool => (string)$a['status'] === 'approved' && !isset($rebindByFingerprint[(string)$a['fingerprint']])));
$pending = array_values(array_filter($gestores, static fn(array $a): bool => in_array((string)$a['status'], ['pending', 'blocked', 'rejected'], true)));
$stage = $approved ? 'approved' : (($pending || $rebindRequests) ? 'pending' : 'install');

if (($_GET['status'] ?? '') === '1') {
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode([
        'ok' => true,
        'stage' => $stage,
        'signature' => $gestoresSignature,
        'pending' => array_map(static fn(array $a): array => [
            'id' => (int)$a['id'],
            'name' => (string)$a['machine_name'],
            'status' => (string)$a['status'],
        ], $pending),
    ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}

$statusMap = [
    'pending' => ['label' => 'Aguardando liberação', 'class' => 'is-pending'],
    'rebind_pending' => ['label' => 'Aguardando nova vinculação', 'class' => 'is-pending'],
    'blocked' => ['label' => 'Acesso bloqueado', 'class' => 'is-blocked'],
    'rejected' => ['label' => 'Aguardando nova liberação', 'class' => 'is-rejected'],
    'approved' => ['label' => 'Liberado', 'class' => 'is-approved'],
    'uninstalled' => ['label' => 'GESTOR DESINSTALADO', 'class' => 'is-uninstalled'],
    'locked' => ['label' => 'Bloqueado (exige login)', 'class' => 'is-locked'],
    'uninstalling' => ['label' => 'Desinstalação pendente', 'class' => 'is-uninstalling'],
];

$rows = [];
foreach ($gestores as $gestor) {
    $details = [];
    if (!empty($gestor['machine_details'])) {
        try {
            $decoded = json_decode((string)$gestor['machine_details'], true, 512, JSON_THROW_ON_ERROR);
            if (is_array($decoded)) {
                $details = $decoded;
            }
        } catch (Throwable $e) {
            $details = [];
        }
    }
    $machine = trim((string)($gestor['machine_name'] ?? '')) !== '' ? (string)$gestor['machine_name'] : 'Computador detectado';
    $platform = trim((string)($details['os_caption'] ?? $details['os_name'] ?? $gestor['platform'] ?? ''));
    if ($platform === '') {
        $platform = 'Windows';
    }
    $version = trim((string)($gestor['gestor_version'] ?? '')) !== '' ? (string)$gestor['gestor_version'] : '—';
    $localIp = trim((string)($gestor['local_ip'] ?? ''));
    $isRemoved = str_starts_with((string)($gestor['notes'] ?? ''), 'DESINSTALADO|');
    $isUninstalling = !$isRemoved && (int)($gestor['uninstall_requested'] ?? 0) === 1;
    $isLocked = !$isRemoved && !$isUninstalling && (string)$gestor['status'] === 'approved' && (int)($gestor['ui_locked'] ?? 0) === 1;
    $effective = $isRemoved ? 'uninstalled' : ($isUninstalling ? 'uninstalling' : ($isLocked ? 'locked' : (string)$gestor['status']));
    $rebindRequest=$rebindByFingerprint[(string)$gestor['fingerprint']] ?? null;
    if ($rebindRequest!==null) $effective='rebind_pending';
    $rows[] = [
        'id' => (int)$gestor['id'],
        'rebind_id' => $rebindRequest!==null ? (int)$rebindRequest['id'] : 0,
        'machine' => $machine,
        'status' => $effective,
        'details' => $details,
        'notes' => (string)($gestor['notes'] ?? ''),
        'status_label' => $statusMap[$effective]['label'] ?? 'Pendente',
        'status_class' => $statusMap[$effective]['class'] ?? 'is-pending',
        'platform' => $platform,
        'version' => $version,
        'installed' => arc_when($gestor['first_seen_at'] ?? null),
        'installed_ts' => $gestor['first_seen_at'] ? (int)(strtotime((string)$gestor['first_seen_at']) ?: 0) : 0,
        'last_seen' => arc_when($gestor['last_seen_at'] ?? null),
        'last_seen_ts' => $gestor['last_seen_at'] ? (int)(strtotime((string)$gestor['last_seen_at']) ?: 0) : 0,
        'local_ip' => $localIp !== '' ? $localIp : '—',
        'uninstalled' => $isRemoved,
        'uninstalling' => $isUninstalling,
        'locked' => $isLocked,
        'raw_status' => (string)$gestor['status'],
        'headless' => (int)($gestor['headless_mode']??0) === 1,
        'is_server' => (string)($gestor['installation_profile']??'') === 'server',
        'installation_profile' => in_array((string)($gestor['installation_profile']??''), ['server','collaborator'], true) ? (string)$gestor['installation_profile'] : 'collaborator',
    ];
}

$releaseProfiles=[];
if($isOwner){foreach($gestores as $g)if((string)$g['status']==='approved')$releaseProfiles[(int)$g['id']]=arc_gt_profile($pdo,$g);}
$networkLogoUrl = !empty($network['logo_file']) ? arc_workspace_base_url() . 'api/network-logo.php?network=' . $networkId : '';
$download = arc_workspace_base_url() . 'api/download-gestor.php?network=' . $networkId;
$poll = arc_workspace_base_url() . 'redes/liberacao.php?network=' . $networkId . '&status=1';
$pendingCount = count($rows);
$basePath = arc_workspace_base_url();
$searchHint = 'Buscar computador, sistema, IP ou versão';

// Integração com o header e as abas nativas da gestão de rede.
$arcSectionFile = 'liberacao';
$ARCPageBodyClass = 'arc-page-redes';
$teamRole = (string)$access['role'];
$networkGestores = $gestores;
$selectedGestorId = 0;
$requestedGestorId = (int)($_GET['gestor'] ?? 0);
foreach ($gestores as $candidate) {
    if ((string)$candidate['status'] !== 'approved') continue;
    if ($selectedGestorId === 0) $selectedGestorId = (int)$candidate['id'];
    if ($requestedGestorId === (int)$candidate['id']) {
        $selectedGestorId = $requestedGestorId;
        break;
    }
}
require __DIR__ . '/_topo_config.php';
?>
<section class="arc-release-page" aria-label="Liberação da rede">
    <section class="arc-release-shell">
        <div class="arc-release-toolbar">
            <div class="arc-release-network">
                <span class="arc-release-logo" aria-hidden="true">
                    <?php if ($networkLogoUrl !== ''): ?>
                        <img src="<?= arc_h($networkLogoUrl) ?>" alt="<?= arc_h((string)$network['name']) ?>" onerror="this.hidden=true;this.nextElementSibling.hidden=false">
                        <i class="fa fa-sitemap" hidden></i>
                    <?php else: ?>
                        <i class="fa fa-sitemap"></i>
                    <?php endif; ?>
                </span>
                <div class="arc-release-network-copy">
                    <small>Liberação do Gestor Windows</small>
                    <strong><?= arc_h((string)$network['name']) ?></strong>
                </div>
            </div>

            <div class="arc-release-toolbar-actions">

                <button class="arc-release-download" type="button" id="arcReleaseRefresh" title="Atualizar a lista de computadores" aria-label="Atualizar a lista de computadores"><i class="fa fa-refresh"></i><span>Atualizar</span></button>
                <label class="arc-release-search" aria-label="Buscar gestor">
                    <i class="fa fa-search" aria-hidden="true"></i>
                    <input id="releaseSearch" type="search" placeholder="<?= arc_h($searchHint) ?>">
                </label>
                <label class="arc-release-filter" aria-label="Filtrar por situação">
                    <i class="fa fa-filter" aria-hidden="true"></i>
                    <select id="releaseFilter">
                        <option value="all">Todos</option>
                        <option value="pending">Aguardando liberação</option>
                        <option value="rebind_pending">Nova vinculação solicitada</option>
                        <option value="locked">Bloqueados (exige login)</option>
                        <option value="blocked">Acesso bloqueado (antigo)</option>
                        <option value="uninstalling">Desinstalação pendente</option>
                        <option value="uninstalled">Desinstalados</option>
                        <option value="rejected">Aguardando nova liberação</option>
                    </select>
                </label>

                <?php if ((int)$network['monitoring_enabled'] === 1): ?>
                    <a class="arc-release-download" href="<?= arc_h($download) ?>" title="Baixar o instalador universal do Gestor Windows"><i class="fa fa-download"></i><span>Baixar instalador Gestor</span></a>
                <?php elseif ($isOwner): ?>
                    <form method="post" class="arc-release-inline-form">
                        <input type="hidden" name="network" value="<?= $networkId ?>">
                        <input type="hidden" name="_csrf" value="<?= arc_h($csrf) ?>">
                        <input type="hidden" name="action" value="monitoring_enable">
                        <button class="arc-release-download" type="submit"><i class="fa fa-power-off"></i><span>Ativar monitoramento</span></button>
                    </form>
                <?php else: ?>
                    <button class="arc-release-download is-disabled" type="button" disabled><i class="fa fa-ban"></i><span>Monitoramento desativado</span></button>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($error !== ''): ?><div class="arc-release-feedback is-error" role="alert"><?= arc_h($error) ?></div><?php endif; ?>

        
        <div class="arc-release-grid-wrap">
            <div class="arc-release-grid-scroll">
                <?php if($isOwner): ?>
<div class="arc-slot-toolbar"><form method="post"><input type="hidden" name="network" value="<?=$networkId?>"><input type="hidden" name="_csrf" value="<?=arc_h($csrf)?>"><input type="hidden" name="action" value="slot_create"><input name="slot_name" maxlength="160" placeholder="Nome do computador" aria-label="Nome do novo vínculo"><button type="submit"><i class="fa fa-plus"></i> Criar vínculo</button></form></div>
<div class="arc-empty-slots"><?php foreach($emptySlots as $slot): ?><article class="arc-slot-card"><button type="button" class="arc-slot-open" data-slot="<?=(int)$slot['id']?>"><i class="fa fa-desktop"></i><strong><?=arc_h($slot['name'])?></strong><span>Aguardando vínculo · inserir código</span></button><form method="post" data-confirm="Excluir este vínculo vazio?"><input type="hidden" name="network" value="<?=$networkId?>"><input type="hidden" name="_csrf" value="<?=arc_h($csrf)?>"><input type="hidden" name="action" value="slot_delete"><input type="hidden" name="slot_id" value="<?=(int)$slot['id']?>"><button type="submit">Excluir vínculo</button></form></article><?php endforeach; ?></div>
<?php endif; ?>
<table class="arc-release-grid" id="releaseTable">
                    <thead>
                    <tr>
                        <th><button type="button" class="arc-sort" data-sort="machine">Computador <i class="fa fa-sort"></i></button></th>
                                                <th><button type="button" class="arc-sort" data-sort="platform">Sist. op. <i class="fa fa-sort"></i></button></th>
                        <th><button type="button" class="arc-sort" data-sort="version">Versão <i class="fa fa-sort"></i></button></th>
                        <th><button type="button" class="arc-sort" data-sort="installed_ts">Instalado <i class="fa fa-sort"></i></button></th>
                        <th><button type="button" class="arc-sort" data-sort="last_seen_ts">Último acesso <i class="fa fa-sort"></i></button></th>
                        <th>Perfil</th>
                        <th><button type="button" class="arc-sort" data-sort="status">Status <i class="fa fa-sort"></i></button></th>
                        <th class="is-actions">Ações</th>
                    </tr>
                    </thead>
                    <tbody id="releaseRows" class="arc-computer-cards">
                    <?php if ($rows): ?>
                        <?php foreach ($rows as $row): ?>
                            <tr
                                data-row tabindex="0" role="button" aria-label="Abrir detalhes e ações do computador"
                                data-server="<?= $row['is_server'] ? '1' : '0' ?>"
                                class="<?= $row['is_server'] ? 'arc-release-server-row' : '' ?>"
                                data-machine="<?= arc_h(mb_strtolower($row['machine'], 'UTF-8')) ?>"
                                data-status="<?= arc_h($row['status']) ?>"
                                data-details="<?= arc_h(json_encode($row, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP)) ?>"
                                data-platform="<?= arc_h(mb_strtolower($row['platform'], 'UTF-8')) ?>"
                                data-version="<?= arc_h(mb_strtolower($row['version'], 'UTF-8')) ?>"
                                data-installed_ts="<?= (int)$row['installed_ts'] ?>"
                                data-last_seen_ts="<?= (int)$row['last_seen_ts'] ?>"
                                data-search="<?= arc_h(mb_strtolower(trim($row['machine'] . ' ' . $row['platform'] . ' ' . $row['version'] . ' ' . $row['local_ip']), 'UTF-8')) ?>"
                            >
                                <td>
                                    <div class="arc-gestor-cell-main">
                                        <strong><?= arc_h($row['machine']) ?></strong>
                                        <small><?= arc_h($row['local_ip']) ?></small>
                                    </div>
                                </td>
                                <td><?= arc_h($row['platform']) ?></td>
                                <td><?= arc_h($row['version']) ?></td>
                                <td><?= arc_h($row['installed']) ?></td>
                                <td><?= arc_h($row['last_seen']) ?></td>
                                <td><span class="arc-gestor-status <?= $row['installation_profile'] === 'server' ? 'is-approved' : 'is-pending' ?>"><i class="fa <?= $row['installation_profile'] === 'server' ? 'fa-server' : 'fa-users' ?>" aria-hidden="true"></i> <?= $row['installation_profile'] === 'server' ? 'Servidor' : 'Colaborador' ?></span></td>
                                <td><span class="arc-gestor-status <?= arc_h($row['status_class']) ?>"><?= arc_h($row['status_label']) ?></span></td>
                                <td class="is-actions">
                                    <?php if ($isOwner): ?>
                                    <?php
                                    $btnForm = static function (string $op, int $gestorId, int $netId, string $csrfToken, string $icon, string $tip, string $label, string $confirmText = '', string $cls = ''): string {
                                        return '<form method="post" class="arc-release-action-form"' . ($confirmText !== '' ? ' data-confirm="' . arc_h($confirmText) . '"' : '') . '>'
                                            . '<input type="hidden" name="network" value="' . $netId . '"><input type="hidden" name="_csrf" value="' . arc_h($csrfToken) . '">'
                                            . '<input type="hidden" name="action" value="' . arc_h($op) . '"><input type="hidden" name="gestor_id" value="' . $gestorId . '">'
                                            . '<button type="submit" class="arc-release-icon-btn ' . arc_h($cls) . '" title="' . arc_h($tip) . '" aria-label="' . arc_h($tip . ' — ' . $label) . '"><i class="fa ' . arc_h($icon) . '"></i></button></form>';
                                    };
                                    $rid = (int)$row['id'];
                                    $isApprovedRow = $row['raw_status'] === 'approved' && !$row['uninstalled'] && $row['rebind_id'] === 0;
                                    ?>
                                    <div class="arc-release-row-actions">
                                        <?php if($rid>0): ?>
                                        <?= $btnForm('gestor_block',$rid,$networkId,$csrf,'fa-ban','Bloquear Gestor',$row['machine'],'Bloquear a gestão deste computador?') ?>
                                        <?= $btnForm('gestor_archive',$rid,$networkId,$csrf,'fa-times','Excluir vínculo e cadastro',$row['machine'],'Excluir o vínculo? O aplicativo permanece no computador e perde a gestão remota. O histórico será preservado.') ?>
                                        <?php endif; ?>
                                        <?php if ($row['rebind_id'] > 0): ?>
                                            <form method="post" class="arc-release-action-form" data-confirm="Autorizar uma nova credencial para este computador? A credencial anterior será revogada.">
                                                <input type="hidden" name="network" value="<?= $networkId ?>"><input type="hidden" name="_csrf" value="<?= arc_h($csrf) ?>">
                                                <input type="hidden" name="request_id" value="<?= (int)$row['rebind_id'] ?>"><input type="hidden" name="action" value="rebind_approve">
                                                <button type="submit" class="arc-release-icon-btn" title="Liberar nova vinculação" aria-label="Liberar nova vinculação — <?= arc_h($row['machine']) ?>"><i class="fa fa-check-circle"></i></button>
                                            </form>
                                            <form method="post" class="arc-release-action-form" data-confirm="Rejeitar o pedido de nova vinculação deste computador?">
                                                <input type="hidden" name="network" value="<?= $networkId ?>"><input type="hidden" name="_csrf" value="<?= arc_h($csrf) ?>">
                                                <input type="hidden" name="request_id" value="<?= (int)$row['rebind_id'] ?>"><input type="hidden" name="action" value="rebind_reject">
                                                <button type="submit" class="arc-release-icon-btn is-danger" title="Rejeitar nova vinculação" aria-label="Rejeitar nova vinculação — <?= arc_h($row['machine']) ?>"><i class="fa fa-times-circle"></i></button>
                                            </form>
                                        <?php elseif (in_array($row['raw_status'], ['pending', 'blocked'], true)): ?>
                                            <?= $btnForm('gestor_approve', $rid, $networkId, $csrf, $row['raw_status'] === 'blocked' ? 'fa-unlock-alt' : 'fa-check-circle', $row['raw_status'] === 'blocked' ? 'Desbloquear gestor' : 'Liberar gestor', $row['machine'], $row['raw_status'] === 'blocked' ? 'Desbloquear este gestor e liberar novamente o acesso?' : '') ?>
                                            <?= $btnForm('gestor_reject', $rid, $networkId, $csrf, 'fa-times-circle', 'Rejeitar autorização', $row['machine'], 'Rejeitar este computador?', 'is-danger') ?>
                                        <?php endif; ?>

                                        <?php if ($isApprovedRow): ?>
                                            <button type="button" class="arc-release-icon-btn arc-release-update-trigger" data-gestor-id="<?= $rid ?>" data-machine="<?= arc_h($row['machine']) ?>" title="Atualizar este gestor Windows" aria-label="Atualizar <?= arc_h($row['machine']) ?>"><i class="fa fa-refresh"></i></button>
                                            <?php if ($row['installation_profile'] === 'server'): ?>
                                            <button type="button" class="arc-release-icon-btn arc-release-primary-trigger is-selected" data-machine="<?= arc_h($row['machine']) ?>" data-ip="<?= arc_h($row['local_ip']) ?>" data-version="<?= arc_h($row['version']) ?>" data-gestor-id="<?= $rid ?>" title="Identificar Gestor Servidor principal" aria-label="Mostrar Gestor Servidor principal"><i class="fa fa-server"></i></button>
                                            <?php endif; ?>
                                            <button type="button" class="arc-release-icon-btn arc-release-profile-trigger" data-gestor-id="<?= $rid ?>" data-machine="<?= arc_h($row['machine']) ?>" title="Perfil e permissões" aria-label="Editar perfil e permissões de <?= arc_h($row['machine']) ?>"><i class="fa fa-shield"></i></button>
                                        <?php endif; ?>
                                        <?php if ($row['rebind_id']===0 && $rid>0 && !$row['uninstalled'] && $row['raw_status']!=='rejected'): ?>
                                            <button type="button" class="arc-release-icon-btn is-danger arc-release-unlink-trigger" data-gestor-id="<?= $rid ?>" data-machine="<?= arc_h($row['machine']) ?>" title="Desvincular computador" aria-label="Desvincular <?= arc_h($row['machine']) ?>"><i class="fa fa-chain-broken"></i></button>
                                        <?php endif; ?>
                                        <?php if ($isApprovedRow && !$row['uninstalling']): ?>
                                            <?php if ($row['installation_profile'] !== 'server'): ?>
                                                <?= $btnForm('gestor_promote_server', $rid, $networkId, $csrf, 'fa-exchange', 'Tornar servidor principal', $row['machine'], 'Transferir o servidor principal para este computador? O vínculo anterior será revogado após a confirmação administrativa.', 'is-selected') ?>
                                            <?php endif; ?>
                                            <?php if ($row['locked']): ?>
                                                <?= $btnForm('gestor_lock_toggle', $rid, $networkId, $csrf, 'fa-lock', 'Bloqueado — clique para desbloquear (liberar a tela sem login)', $row['machine'], 'Liberar a tela do gestor neste computador sem pedir usuário e senha?', 'is-locked') ?>
                                            <?php else: ?>
                                                <?= $btnForm('gestor_lock_toggle', $rid, $networkId, $csrf, 'fa-unlock-alt', 'Desbloqueado — clique para bloquear (exigir login para abrir a tela)', $row['machine'], 'O gestor continuará em execução, mas para abrir a tela do gestor será exigido usuário e senha. Bloquear agora?') ?>
                                            <?php endif; ?>
                                            <?= $btnForm('gestor_headless_toggle', $rid, $networkId, $csrf, 'fa-television', ($row['headless'] ? 'Desativar' : 'Ativar') . ' modo sem monitor', $row['machine'], 'Alterar o modo sem monitor deste computador? Essa opção modifica as exigências de confirmação do acesso remoto.', $row['headless'] ? 'is-selected' : '') ?>
                                        <?php endif; ?>

                                        <?php if ($row['uninstalling']): ?>
                                            <?= $btnForm('gestor_uninstall_toggle', $rid, $networkId, $csrf, 'fa-hourglass-half', 'Desinstalação pendente — clique para cancelar', $row['machine'], 'Cancelar a desinstalação pendente deste gestor?', 'is-uninstalling') ?>
                                        <?php elseif ($isApprovedRow): ?>
                                            <?= $btnForm('gestor_uninstall_toggle', $rid, $networkId, $csrf, 'fa-trash', 'Desinstalar gestor deste computador', $row['machine'], 'Desinstalar o gestor deste computador? O gestor será removido da máquina (inclusive os dados locais) assim que ela estiver online. Esta ação não pode ser desfeita pela plataforma.', 'is-danger') ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php else: ?><span class="arc-gestor-awaiting">Aguardando proprietário</span><?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr class="arc-release-empty-row" id="releaseEmptyRow">
                            <td colspan="7">
                                <div class="arc-release-empty">
                                    <i class="fa fa-desktop"></i>
                                    <strong>Nenhum gestor cadastrado nesta rede.</strong>
                                    <span>Se instalou o gestor, verifique na tela de instalação se o cadastro foi aceito pela plataforma. Caso haja erro, baixe um novo instalador desta rede e confira o código do local.</span>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</section>

<?php if($isOwner): ?>
<dialog id="arcReleaseProfileModal" class="arc-rp-dialog" aria-labelledby="arcReleaseProfileTitle">
<form method="post" id="arcReleaseProfileForm">
<input type="hidden" name="network" value="<?= (int)$networkId ?>"><input type="hidden" name="_csrf" value="<?= arc_h($csrf) ?>"><input type="hidden" name="action" value="release_profile_save"><input type="hidden" name="gestor_id" value="">
<div class="arc-rp-head"><i class="fa fa-shield"></i><div><h3 id="arcReleaseProfileTitle">Perfil e permissões</h3><small id="arcReleaseProfileMachine"></small></div><button type="button" class="arc-rp-close" data-arc-rp-close aria-label="Fechar"><i class="fa fa-times"></i></button></div>
<div class="arc-rp-body"><section><h4>Tipo da instalação</h4><div class="arc-rp-profiles"><label class="arc-rp-choice"><input type="radio" name="role" value="collaborator"><span><b><i class="fa fa-users"></i> Colaborador</b><small>Operações conforme permissões</small></span></label><label class="arc-rp-choice"><input type="radio" name="role" value="server"><span><b><i class="fa fa-server"></i> Servidor</b><small>Único principal da rede</small></span></label></div></section>
<section><h4>Operações permitidas <small id="arcRpCapsCount" aria-live="polite"></small></h4><div class="arc-rp-tools"><button type="button" data-rp-caps="all">Marcar tudo</button><button type="button" data-rp-caps="none">Desmarcar tudo</button></div><div class="arc-rp-checks"><?php foreach(arc_gt_labels() as $key=>$label): ?><label><input type="checkbox" name="capability[]" value="<?=arc_h($key)?>"> <?=arc_h($label)?></label><?php endforeach; ?></div></section>
<section id="arcRpInterface"><h4>Menus e submenus disponíveis no Gestor <small id="arcRpMenusCount" aria-live="polite"></small></h4><p class="arc-rp-help">Selecione os menus principais e os submenus que o Colaborador poderá abrir. Desmarcar um submenu impede seu acesso pela navegação local.</p><input id="arcRpMenuSearch" class="arc-rp-search" type="search" placeholder="Buscar menu ou submenu…" autocomplete="off" aria-label="Buscar menus e submenus"><div class="arc-rp-tools"><button type="button" data-rp-menus="all">Marcar tudo</button><button type="button" data-rp-menus="none">Desmarcar tudo</button><button type="button" data-rp-menus="remote">Somente acesso remoto</button></div><div class="arc-rp-menu-groups"><?php foreach(arc_workspace_menu()['groups'] as $group):if($group['key']==='management')continue; ?><details class="arc-rp-group" data-menu-group><summary><span class="arc-rp-menu-heading"><input type="checkbox" class="arc-rp-parent" aria-label="Selecionar todos os submenus de <?=arc_h($group['label'])?>" data-rp-parent><b><?=arc_h($group['label'])?></b><small data-rp-group-count></small></span><i class="fa fa-chevron-down" aria-hidden="true"></i></summary><div class="arc-rp-menu-items"><?php foreach($group['items'] as $menu):?><label data-rp-menu-label><input type="checkbox" name="ui_menu[]" value="<?=arc_h($menu['key'])?>"> <span><?=arc_h($menu['label'])?></span></label><?php endforeach;?></div></details><?php endforeach;?></div><label class="arc-rp-confirm u-mt-13"><input type="checkbox" name="background" value="1"> Manter em segundo plano (não exibir a janela principal ao iniciar)</label></section>
<div id="arcRpTransferNotice" class="arc-rp-notice" hidden>Ao atribuir o perfil Servidor, o Servidor principal anterior será convertido em Colaborador, preservando seu vínculo e aplicando as permissões de Colaborador.</div>
<label id="arcRpTransferConfirm" class="arc-rp-confirm" hidden><input type="checkbox" name="confirmed" value="1"> Confirmo a transferência do servidor principal.</label></div>
<div id="arcRpFeedback" class="arc-rp-feedback" role="status" aria-live="polite" hidden></div><div class="arc-rp-footer"><button type="button" data-arc-rp-close>Cancelar</button><button type="submit"><i class="fa fa-check"></i> Salvar alterações</button></div></form></dialog>
<dialog id="arcReleaseUnlinkModal" class="arc-rp-dialog u-dialog-480" aria-labelledby="arcReleaseUnlinkTitle"><form method="post" id="arcReleaseUnlinkForm"><input type="hidden" name="network" value="<?= (int)$networkId ?>"><input type="hidden" name="_csrf" value="<?= arc_h($csrf) ?>"><input type="hidden" name="action" value="release_unlink"><input type="hidden" name="gestor_id" value=""><div class="arc-rp-head"><i class="fa fa-unlink"></i><div><h3 id="arcReleaseUnlinkTitle">Desvincular computador</h3><small id="arcReleaseUnlinkMachine"></small></div><button type="button" class="arc-rp-close" data-arc-rp-close aria-label="Fechar"><i class="fa fa-times"></i></button></div><div class="arc-rp-body"><div class="arc-rp-notice">A credencial desta instalação será revogada e os comandos pendentes serão cancelados. Se for o servidor principal, a rede ficará sem servidor até uma nova atribuição. Isso não desinstala o aplicativo do Windows.</div><label class="arc-rp-confirm"><input type="checkbox" name="confirmed" value="1" required> Confirmo a desvinculação deste computador.</label></div><div class="arc-rp-footer"><button type="button" data-arc-rp-close>Cancelar</button><button class="arc-rp-danger" type="submit"><i class="fa fa-unlink"></i> Desvincular</button></div></form></dialog>
<script>
/* Caminho: redes/liberacao.php — modais próprios de permissões e desvinculação. */
(()=>{'use strict';const profiles=<?=json_encode($releaseProfiles,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_INVALID_UTF8_SUBSTITUTE)?>;
const dialog=document.getElementById('arcReleaseProfileModal'),form=document.getElementById('arcReleaseProfileForm'),unlink=document.getElementById('arcReleaseUnlinkModal'),unlinkForm=document.getElementById('arcReleaseUnlinkForm');if(!dialog||!unlink)return;
function close(d){if(d.open&&d.getAttribute('aria-busy')!=='true')d.close();}
document.querySelectorAll('[data-arc-rp-close]').forEach(b=>b.addEventListener('click',()=>close(b.closest('dialog'))));[dialog,unlink].forEach(d=>{d.addEventListener('click',e=>{if(e.target===d)close(d);});d.addEventListener('cancel',e=>{if(d.getAttribute('aria-busy')==='true')e.preventDefault();});});
function setChecked(name,keys){form.querySelectorAll('input[name="'+name+'"]') .forEach(el=>{el.checked=keys.includes(el.value);});}
function selected(name){return [...form.querySelectorAll('input[name="'+name+'"]:checked')].map(el=>el.value);}
const feedback=document.getElementById('arcRpFeedback');
function message(value,success=false){feedback.textContent=value;feedback.hidden=!value;feedback.classList.toggle('is-success',success);}
function refresh(){
 const role=form.querySelector('[name=role]:checked')?.value||'collaborator';
 const previous=form.dataset.previous||'collaborator';
 const transfer=role==='server'&&previous!=='server';
 const interfaceArea=document.getElementById('arcRpInterface');
 interfaceArea.hidden=role==='server'; // O Servidor conserva seu menu administrativo integral.
 document.getElementById('arcRpTransferNotice').hidden=!transfer;
 document.getElementById('arcRpTransferConfirm').hidden=!transfer;
 form.querySelector('[name=confirmed]').required=transfer;
 form.querySelectorAll('[name="capability[]"]').forEach(i=>{
   const limited=role==='collaborator'&&['network_scan','coordinate'].includes(i.value);
   i.disabled=limited;if(limited)i.checked=false;
 });
 document.getElementById('arcRpCapsCount').textContent='('+selected('capability[]').length+' selecionadas)';
 document.getElementById('arcRpMenusCount').textContent='('+selected('ui_menu[]').length+' submenus selecionados)';
 form.querySelectorAll('[data-menu-group]').forEach(group=>{
   const children=[...group.querySelectorAll('input[name="ui_menu[]"]')];
   const checked=children.filter(c=>c.checked).length;
   const parent=group.querySelector('[data-rp-parent]');
   parent.checked=children.length>0&&checked===children.length;
   parent.indeterminate=checked>0&&checked<children.length;
   group.querySelector('[data-rp-group-count]').textContent=checked+'/'+children.length;
 });
}
form.querySelectorAll('[name=role]').forEach(i=>i.addEventListener('change',refresh));
form.querySelectorAll('[data-rp-parent]').forEach(parent=>{
 parent.addEventListener('click',e=>e.stopPropagation());
 parent.addEventListener('change',()=>{
   const group=parent.closest('[data-menu-group]');
   group.querySelectorAll('input[name="ui_menu[]"]').forEach(child=>child.checked=parent.checked);
   refresh();
 });
});
const menuSearch=document.getElementById('arcRpMenuSearch');
menuSearch?.addEventListener('input',()=>{
 const query=menuSearch.value.trim().toLocaleLowerCase('pt-BR');
 form.querySelectorAll('[data-menu-group]').forEach(group=>{
  const groupTitle=group.querySelector('.arc-rp-menu-heading b').textContent.toLocaleLowerCase('pt-BR');
  const groupMatch=groupTitle.includes(query);
  let visible=0;
  group.querySelectorAll('[data-rp-menu-label]').forEach(label=>{
   const matches=groupMatch||label.textContent.toLocaleLowerCase('pt-BR').includes(query);
   label.hidden=!matches;if(matches)visible++;
  });
  group.hidden=visible===0;
  if(query&&visible)group.open=true;
 });
});
form.querySelectorAll('[name="capability[]"],[name="ui_menu[]"]').forEach(i=>i.addEventListener('change',refresh));
document.querySelectorAll('[data-rp-caps]').forEach(b=>b.addEventListener('click',()=>{form.querySelectorAll('[name="capability[]"]').forEach(i=>i.checked=!i.disabled&&b.dataset.rpCaps==='all');refresh();}));
document.querySelectorAll('[data-rp-menus]').forEach(b=>b.addEventListener('click',()=>{const mode=b.dataset.rpMenus;form.querySelectorAll('[name="ui_menu[]"]').forEach(i=>i.checked=mode==='all'||mode==='remote'&&i.value==='remote');refresh();}));
document.querySelectorAll('.arc-release-profile-trigger').forEach(b=>b.addEventListener('click',e=>{
 e.preventDefault();e.stopPropagation();
 const id=Number(b.dataset.gestorId),p=profiles[id];
 if(!p){return;}
 form.reset();form.elements.namedItem('gestor_id').value=String(id);
 form.dataset.previous=p.role;
 const roleRadio=form.querySelector('[name=role][value="'+(p.role==='server'?'server':'collaborator')+'"]');
 if(roleRadio)roleRadio.checked=true;
 setChecked('capability[]',Object.keys(p.permissions||{}).filter(k=>p.permissions[k]));
 setChecked('ui_menu[]',Array.isArray(p.ui?.menus)?p.ui.menus:['remote']);
 form.elements.namedItem('background').checked=!!p.ui?.background;
 document.getElementById('arcReleaseProfileMachine').textContent=b.dataset.machine;
 message('');if(menuSearch){menuSearch.value='';menuSearch.dispatchEvent(new Event('input'));}refresh();dialog.showModal();
}));
form.addEventListener('submit',async e=>{
 e.preventDefault();
 if(!form.reportValidity())return;
 const btn=form.querySelector('button[type=submit]');btn.disabled=true;dialog.setAttribute('aria-busy','true');
 message('Salvando alterações...',true);
 // Envio compacto em application/x-www-form-urlencoded: menus e permissões vão em UM campo cada.
 // (27 campos ui_menu[] em multipart eram barrados/limitados pela hospedagem compartilhada.)
 const fields=new FormData(form);
 const payload=new URLSearchParams();
 fields.forEach((value,key)=>{if(key==='ui_menu[]'||key==='capability[]'||typeof value!=='string')return;payload.append(key,value);});
 payload.set('ui_menus',selected('ui_menu[]').join(','));
 payload.set('caps',selected('capability[]').join(','));
 const ajaxUrl=new URL(location.href);ajaxUrl.searchParams.set('network',form.elements.namedItem('network').value);ajaxUrl.searchParams.set('ajax','1');ajaxUrl.searchParams.delete('gestor');
 const transient=code=>code===0||code===429||code===502||code===503||code===504||code===508||code===500;
 let lastError='';
 try{
  for(let attempt=1;attempt<=3;attempt++){
   let response=null,raw='',result=null;
   try{
    response=await fetch(ajaxUrl.toString(),{method:'POST',body:payload,credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'},redirect:'manual'});
    if(response.type==='opaqueredirect'||(response.status>=300&&response.status<400))throw Error('A sessão expirou e o servidor redirecionou a requisição. Atualize a página (F5), abra o modal novamente e salve.');
    raw=await response.text();
    try{result=JSON.parse(raw)}catch(_){result=null}
   }catch(networkError){
    if(networkError.message&&networkError.message.startsWith('A sessão'))throw networkError;
    lastError='Sem conexão com o servidor ('+(networkError.message||'falha de rede')+').';
    if(attempt<3){message('Conexão instável, tentando novamente ('+(attempt+1)+'/3)...',true);await new Promise(r=>setTimeout(r,700*attempt));continue;}
    throw Error(lastError);
   }
   if(result&&result.ok){
    message(result.message||'Alterações salvas.',true);
    setTimeout(()=>location.reload(),650);
    return;
   }
   if(result){ // JSON do próprio sistema: mensagem definitiva (validação, permissão, falha de banco com referência)
    throw Error(result.message||result.error||'Falha ao salvar as permissões.');
   }
   // Resposta que não é JSON: página de erro da hospedagem (HTML) ou saída inesperada.
   const title=(raw.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1]||'';
   const plain=raw.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,160);
   lastError='O servidor respondeu HTTP '+response.status+' com uma página que não é do sistema'+((title||plain)?' ("'+(title||plain).trim().slice(0,110)+'")':'')+'.';
   if(transient(response.status)&&attempt<3){message('O servidor da hospedagem recusou a requisição (HTTP '+response.status+'). Tentando novamente ('+(attempt+1)+'/3)...',true);await new Promise(r=>setTimeout(r,900*attempt));continue;}
   throw Error(lastError+' Isso vem da hospedagem (limite de recursos, firewall ou erro PHP) e não de uma permissão inválida. Consulte o error_log do cPanel.');
  }
 }catch(err){message(err.message||'Não foi possível salvar. Verifique sua conexão.');btn.disabled=false;dialog.removeAttribute('aria-busy');}
});
document.querySelectorAll('.arc-release-unlink-trigger').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();unlinkForm.reset();unlinkForm.elements.gestor_id.value=Number(b.dataset.gestorId);document.getElementById('arcReleaseUnlinkMachine').textContent=b.dataset.machine;unlink.showModal();}));
unlinkForm.addEventListener('submit',()=>{unlink.setAttribute('aria-busy','true');});
})();
</script>
<?php endif; ?>
<?php if ($isOwner): ?>
<dialog id="arcReleasePairDialog" class="arc-gestor-modal arc-pair-dialog" aria-labelledby="arcPairTitle">
 <div class="arc-modal-head"><i class="fa fa-link"></i><h3 id="arcPairTitle">Vincular novo Gestor</h3><button type="button" class="arc-modal-close" id="arcReleasePairClose" aria-label="Fechar"><i class="fa fa-times"></i></button></div>
 <form method="post" class="arc-pair-form">
  <input type="hidden" name="network" value="<?= $networkId ?>"><input type="hidden" name="_csrf" value="<?= arc_h($csrf) ?>"><input type="hidden" name="action" value="gestor_pair_code"><input type="hidden" name="slot_id" value="0">
  <p>Informe o código exibido ao finalizar a instalação. No vínculo vazio, use o código da barra “Vincular à plataforma online” do Gestor independente.</p>
  <label>Código de instalação<input type="text" name="pair_code" inputmode="text" autocomplete="off" spellcheck="false" maxlength="19" placeholder="0000-0000-0000-0000" required pattern="[A-Fa-f0-9 -]{16,19}"></label>
  <label>Tipo do Gestor<select name="pair_role"><option value="collaborator">Colaborador</option><option value="server">Servidor (único na rede)</option></select></label>
  <div class="arc-pair-actions"><button type="button" id="arcPairCancel">Cancelar</button><button type="submit"><i class="fa fa-check"></i> Vincular</button></div>
 </form>
</dialog>
<script>(function(){const d=document.getElementById('arcReleasePairDialog'),b=document.getElementById('arcReleasePairOpen');if(!d)return; b?.addEventListener('click',()=>{d.querySelector('[name=slot_id]').value='0';d.showModal();});document.querySelectorAll('.arc-slot-open').forEach(btn=>btn.addEventListener('click',()=>{d.querySelector('[name=slot_id]').value=btn.dataset.slot;d.showModal();}));for(const id of ['arcReleasePairClose','arcPairCancel'])document.getElementById(id).addEventListener('click',()=>d.close());d.addEventListener('click',e=>{if(e.target===d)d.close()});})();</script>
<?php endif; ?>
<dialog id="arcGestorDetailModal" class="arc-gestor-modal" aria-labelledby="arcGestorModalTitle"><div class="arc-modal-head"><i class="fa fa-desktop"></i><h3 id="arcGestorModalTitle">Detalhes do computador</h3><button type="button" class="arc-modal-close" id="arcGestorModalClose" aria-label="Fechar detalhes"><i class="fa fa-times"></i></button></div><div class="arc-modal-content" id="arcGestorModalBody"></div></dialog>
<script>
(function(){
    'use strict';
    const endpoint = <?= json_encode($poll) ?>;
    const approvedUrl = <?= json_encode(arc_workspace_base_url() . 'redes/painel.php?network=' . $networkId) ?>;
    let signature = <?= json_encode($gestoresSignature) ?>;
    let current = <?= json_encode($stage) ?>;
    let busy = false;

    const tbody = document.getElementById('releaseRows');
    const searchInput = document.getElementById('releaseSearch');
    const filterSelect = document.getElementById('releaseFilter');
    const rows = () => Array.from(tbody.querySelectorAll('tr[data-row]'));

    const sortState = { key: 'last_seen_ts', dir: 'desc' };
    const heads = Array.from(document.querySelectorAll('.arc-sort'));

    function compare(a,b,key,dir){
        const av = a.dataset[key] ?? '';
        const bv = b.dataset[key] ?? '';
        const na = Number(av), nb = Number(bv);
        let result;
        if(!Number.isNaN(na) && !Number.isNaN(nb) && av !== '' && bv !== ''){
            result = na === nb ? 0 : (na > nb ? 1 : -1);
        }else{
            result = String(av).localeCompare(String(bv), 'pt-BR', {numeric:true, sensitivity:'base'});
        }
        return dir === 'asc' ? result : result * -1;
    }

    function applySortIndicators(){
        heads.forEach((button)=>{
            if(button.dataset.sort === sortState.key){
                button.dataset.dir = sortState.dir;
            }else{
                button.removeAttribute('data-dir');
            }
        });
    }

    function updateEmptyRow(visibleCount){
        let empty = document.getElementById('releaseEmptyRow');
        if(!empty){
            empty = document.createElement('tr');
            empty.className = 'arc-release-empty-row';
            empty.id = 'releaseEmptyRow';
            empty.innerHTML = '<td colspan="7"><div class="arc-release-empty"><i class="fa fa-search"></i><strong>Nenhum gestor encontrado.</strong><span>Ajuste a busca ou o filtro para localizar outro gestor.</span></div></td>';
            tbody.appendChild(empty);
        }
        empty.style.display = visibleCount ? 'none' : '';
    }

    function renderRows(){
        const term = (searchInput.value || '').trim().toLocaleLowerCase('pt-BR');
        const filter = filterSelect.value || 'all';
        const allRows = rows();
        const filtered = allRows.filter((row)=>{
            const okSearch = !term || (row.dataset.search || '').includes(term);
            const okFilter = filter === 'all' || row.dataset.status === filter;
            row.hidden = !(okSearch && okFilter);
            return okSearch && okFilter;
        });
        filtered.sort((a,b)=>{
            const serverOrder=Number(b.dataset.server||0)-Number(a.dataset.server||0);
            return serverOrder||compare(a,b,sortState.key,sortState.dir);
        });
        filtered.forEach((row)=>tbody.appendChild(row));
        allRows.filter((row)=>row.hidden).forEach((row)=>tbody.appendChild(row));
        updateEmptyRow(filtered.length);
        applySortIndicators();
    }

    heads.forEach((button)=>{
        button.addEventListener('click', ()=>{
            const key = button.dataset.sort;
            if(sortState.key === key){
                sortState.dir = sortState.dir === 'asc' ? 'desc' : 'asc';
            }else{
                sortState.key = key;
                sortState.dir = key.endsWith('_ts') ? 'desc' : 'asc';
            }
            renderRows();
        });
    });

    searchInput.addEventListener('input', renderRows);
    filterSelect.addEventListener('change', renderRows);
    renderRows();
    const modal = document.getElementById('arcGestorDetailModal');
    const modalBody = document.getElementById('arcGestorModalBody');
    const safe = v => String(v ?? '—').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const field = (name, value, wide=false) => `<div class="arc-modal-info${wide?' arc-modal-wide':''}"><small>${safe(name)}</small><strong>${safe(value)}</strong></div>`;
    tbody.addEventListener('keydown',e=>{if(e.target.matches('tr[data-row]')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();e.target.click();}});
    tbody.addEventListener('click', e => {
        if(e.target.closest('button,form,a,input,select')) return;
        const tr = e.target.closest('tr[data-row]'); if(!tr) return;
        let data; try {data = JSON.parse(tr.dataset.details);} catch(e){return;}
        const detail=data.details && typeof data.details === 'object' ? data.details : {};
        document.getElementById('arcGestorModalTitle').textContent = data.machine || 'Detalhes do computador';
        let html = field('Status',data.status_label)+field('Versão do gestor',data.version)+field('Sistema operacional',data.platform,true)+field('IP local',data.local_ip)+field('Instalado em',data.installed)+field('Último acesso',data.last_seen)+field('Código do gestor',data.id);
        for(const [k,v] of Object.entries(detail)){if(v===null || typeof v==='object') continue;html+=field(k,v);}
        if(data.notes) html+=field('Observações do registro',data.notes,true);
        modalBody.innerHTML=html;
        const actions=tr.querySelector('.arc-release-row-actions');
        if(actions){const bar=document.createElement('div');bar.className='arc-release-row-actions';actions.querySelectorAll('button').forEach(original=>{const b=original.cloneNode(true);b.type='button';b.addEventListener('click',()=>{modal.close();original.click();});bar.appendChild(b);});modalBody.appendChild(bar);}
        if(typeof modal.showModal === 'function') modal.showModal(); else modal.setAttribute('open','');
    });
    document.getElementById('arcGestorModalClose').addEventListener('click',()=>modal.close());
    modal.addEventListener('click',e=>{if(e.target===modal)modal.close()});
    document.querySelectorAll('form[data-confirm]').forEach(form=>form.addEventListener('submit',ev=>{if(!confirm(form.dataset.confirm||'Confirmar esta ação?'))ev.preventDefault()}));

    async function check(){
        if(busy) return;
        busy = true;
        try{
            const response = await fetch(endpoint,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}});
            if(!response.ok) return;
            const value = await response.json();
            if(!value.ok) return;
            if(value.signature && value.signature !== signature){
                location.reload();
                return;
            }
        }catch(e){}
        finally{ busy = false; }
    }

    check();
    setInterval(()=>{if(!document.hidden)check();}, 2500);
    document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) check(); });
})();
</script>
</div></div></main>
<style>
/* Caminho: redes/liberacao.php — cards reaproveitam as linhas e os controles existentes. */
table:has(> .arc-computer-cards){display:block;width:100%}table:has(> .arc-computer-cards)>thead{display:none}
.arc-computer-cards,.arc-empty-slots{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px;width:100%}
.arc-computer-cards>tr[data-row],.arc-slot-card{display:block;padding:14px;border:1px solid var(--border,#ccd);border-radius:12px;background:var(--surface,#fff);cursor:pointer}
.arc-computer-cards>tr[hidden]{display:none}.arc-computer-cards>tr>td{display:block;border:0;padding:4px 0;white-space:normal}.arc-computer-cards>tr>td:nth-child(2)::before{content:'Sistema: '}.arc-computer-cards>tr>td:nth-child(3)::before{content:'Versão: '}.arc-computer-cards>tr>td:nth-child(4)::before{content:'Instalação: '}.arc-computer-cards>tr>td:nth-child(5)::before{content:'Último acesso: '}
.arc-slot-open{display:flex;flex-direction:column;align-items:center;gap:12px;width:100%;padding:16px}.arc-slot-open>i{font-size:30px}.arc-slot-toolbar{margin:12px 0}.arc-empty-slots{margin-bottom:14px}.arc-computer-cards .arc-release-row-actions{flex-wrap:wrap}
</style>
<?php if(!empty($networkId)) require __DIR__.'/_gestor_update_dialog.php'; ?>

<!-- Caminho: redes/liberacao.php — ações nativas de atualização e identificação do servidor. -->
<dialog id="arcReleaseServerInfo" class="arc-rp-dialog u-dialog-440" aria-labelledby="arcReleaseServerInfoTitle">
<div class="arc-rp-head"><i class="fa fa-server"></i><div><h3 id="arcReleaseServerInfoTitle">Gestor Servidor principal</h3><small>Identificação da instalação selecionada</small></div><button type="button" class="arc-rp-close" id="arcReleaseServerClose" aria-label="Fechar"><i class="fa fa-times"></i></button></div>
<div class="arc-rp-body"><p class="u-pre-line" id="arcReleaseServerIdentity"></p></div>
<div class="arc-rp-footer"><button type="button" id="arcReleaseServerOkay">Concluir</button></div>
</dialog>
<div class="arc-toast-fixed" id="arcReleaseUpdateNotice" role="status" aria-live="polite" hidden></div>
<script>
/* Caminho: redes/liberacao.php — atualização pela fila administrativa existente. */
(()=>{'use strict';
const network=<?= (int)$networkId ?>,csrf=<?=json_encode($csrf)?>,base=<?=json_encode(arc_workspace_base_url())?>;
const refresh=document.getElementById('arcReleaseRefresh'),info=document.getElementById('arcReleaseServerInfo'),identity=document.getElementById('arcReleaseServerIdentity'),notice=document.getElementById('arcReleaseUpdateNotice');
if(refresh)refresh.addEventListener('click',()=>window.location.reload());
const close=()=>{if(info?.open)info.close();};
document.getElementById('arcReleaseServerClose')?.addEventListener('click',close);
document.getElementById('arcReleaseServerOkay')?.addEventListener('click',close);
document.querySelectorAll('.arc-release-primary-trigger').forEach(b=>b.addEventListener('click',()=>{identity.textContent='Computador: '+b.dataset.machine+'\nIP local: '+b.dataset.ip+'\nVersão: '+b.dataset.version+'\nIdentificador: '+b.dataset.gestorId;info.showModal();}));
const alert=(message)=>{notice.textContent=message;notice.hidden=false;};
document.querySelectorAll('.arc-release-update-trigger').forEach(b=>b.addEventListener('click',async()=>{
 if(b.disabled)return;
 if(!window.confirm('Solicitar atualização do Gestor '+b.dataset.machine+'? Se for o Servidor principal, os colaboradores da mesma rede local serão atualizados após a conclusão confirmada.'))return;
 b.disabled=true;alert('Solicitando atualização do gestor '+b.dataset.machine+'...');
 try{const response=await fetch(base+'api/api.php?action=network-command',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({network_id:network,gestor_id:Number(b.dataset.gestorId),command:'gestor_update'})});
 const data=await response.json();if(!response.ok||!data.ok)throw Error(data.error||'A solicitação foi recusada.');alert('Atualização solicitada para '+b.dataset.machine+' (comando #'+data.command_id+'). Acompanhe a fila de atividades.');window.dispatchEvent(new Event('arc-queue-refresh'));
 }catch(e){alert(e.message);}finally{b.disabled=false;}
}));
})();
</script>
<?php require dirname(__DIR__) . '/includes/footer.php';
