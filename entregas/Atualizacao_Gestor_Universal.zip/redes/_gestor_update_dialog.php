<?php
/* Caminho: redes/_gestor_update_dialog.php
 * Modal do Gestor Windows: instalador universal e desinstalador (o aviso de nova versão chega pelo sino de notificações).
 * Renderizado junto ao cabeçalho de rede. Inclusões antigas são idempotentes.S
 * O controlador é servido do arquivo-fonte local, sem uma segunda requisição de script.
 * Exige $networkId. Usa $teamRole e $csrf quando existirem. */
declare(strict_types=1);
require_once __DIR__ . '/../includes/error-logging.php';

if (!empty($GLOBALS['arc_gestor_update_dialog_rendered'])) return;
$GLOBALS['arc_gestor_update_dialog_rendered'] = true;
$arcUpdRole = (string)($teamRole ?? ($access['role'] ?? ''));
$arcUpdCsrf = (string)($csrf ?? arc_csrf_token());
$arcUpdBase = arc_workspace_base_url();
$arcUpdJs = dirname(__DIR__) . '/assets/js/gestor-update.js';
?>
<dialog id="arc-gestor-update-confirm" class="arc-gestor-update-confirm arc-service-dialog" aria-labelledby="arc-gestor-update-title"
        data-network="<?= (int)$networkId ?>" data-base="<?= arc_h($arcUpdBase) ?>" data-csrf="<?= arc_h($arcUpdCsrf) ?>"
        data-can-manage="<?= in_array($arcUpdRole, ['owner', 'administrator', 'system_admin'], true) ? '1' : '0' ?>">
<div class="arc-gestor-update-card">
 <div class="arc-update-modal-header"><div><strong id="arc-gestor-update-title">Gestor</strong> <small data-update-modal-version></small></div><button class="arc-update-modal-close" type="button" data-update-cancel aria-label="Fechar"><i class="fa fa-times" aria-hidden="true"></i></button></div>
 <div class="arc-update-modal-summary" role="status" aria-live="polite"><span class="arc-update-connection" data-update-connection><i class="fa fa-circle" aria-hidden="true"></i> Consultando conexão…</span><span data-update-hint>Instale para uso local independente. Vincule à plataforma depois, pelo código exibido no Gestor.</span></div>
 <p data-update-status class="arc-update-state" role="status" hidden></p>
 <div class="arc-gestor-update-actions arc-service-actions" role="group" aria-label="Ações do Gestor Windows">
 <?php if (in_array($arcUpdRole, ['owner', 'administrator', 'system_admin'], true)): ?>
 <a class="button arc-power-tile arc-power-tile--download" data-update-install rel="noopener" href="<?= arc_h($arcUpdBase . 'api/download-gestor.php?network=' . (int)$networkId) ?>" title="Baixar instalador do Gestor Windows">
  <i class="fa-brands fa-windows" aria-hidden="true"></i><strong>Baixar instalador Gestor</strong><small>Instalador Windows</small>
 </a>
 <?php else: ?>
 <button type="button" class="button arc-power-tile arc-power-tile--download" disabled title="Permissão administrativa necessária">
  <i class="fa-brands fa-windows" aria-hidden="true"></i><strong>Baixar instalador Gestor</strong><small>Permissão necessária</small>
 </button>
 <?php endif; ?>
 <?php if (in_array($arcUpdRole, ['owner', 'administrator', 'system_admin'], true)): ?>
 <a class="button arc-power-tile" href="<?= arc_h($arcUpdBase . 'api/download-gestor.php?mode=uninstaller&network=' . (int)$networkId) ?>"><i class="fa fa-trash" aria-hidden="true"></i><strong>Baixar desinstalador Gestor</strong><small>Remoção com confirmação local</small></a>
 <?php endif; ?>
 </div>
</div></dialog>
<?php
$arcUpdScript=is_readable($arcUpdJs)?file_get_contents($arcUpdJs):false;
if(is_string($arcUpdScript)&&$arcUpdScript!==''){
 echo '<script data-arc-src="assets/js/gestor-update.js">'.str_ireplace('</script','<\/script',$arcUpdScript).'</script>';
}else{
 arc_log_error('Controlador do modal do gestor indisponível: assets/js/gestor-update.js');
}
?>
