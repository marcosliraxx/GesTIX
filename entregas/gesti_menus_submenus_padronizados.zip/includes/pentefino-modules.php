<?php
/* Caminho: includes/pentefino-modules.php — módulos derivados do catálogo compartilhado. */
declare(strict_types=1);
require_once __DIR__.'/workspace-menu.php';
function arc_pf_modules(): array {
 $modules=[];
 foreach(arc_workspace_menu()['groups'] as $group)foreach($group['items'] as $item){
  if(!isset($item['module']))continue;
  $modules[$item['module']]=['file'=>$item['file'],'label'=>$item['label'],'icon'=>$item['icon'],'native'=>$item['key']];
 }
 return $modules;
}
