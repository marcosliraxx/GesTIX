<?php
/* Caminho: includes/workspace-menu.php — catálogo compartilhado pelo ribbon web e pelo gestor. */
declare(strict_types=1);
function arc_workspace_menu(): array {
    static $catalog=null;
    if($catalog!==null)return $catalog;
    $file=dirname(__DIR__).'/gestores/servidor/Arcoll.WinUI3/Assets/workspace-menu.json';
    $data=json_decode((string)file_get_contents($file),true,64,JSON_THROW_ON_ERROR);
    if(!is_array($data['groups']??null)||!is_array($data['icons']??null))throw new RuntimeException('Catálogo de navegação inválido.');
    foreach($data['groups'] as $group)foreach($group['items'] as $item){
        if(!preg_match('/^[a-z][a-z0-9_-]*$/D',$item['file'])||!isset($data['icons'][$item['icon']]))throw new RuntimeException('Item de navegação inválido.');
    }
    return $catalog=$data;
}
function arc_workspace_menu_icon(string $name,int $size=24): string {
    $path=arc_workspace_menu()['icons'][$name]??'';$size=max(12,min(32,$size));
    return '<svg viewBox="0 0 24 24" width="'.$size.'" height="'.$size.'" fill="currentColor" aria-hidden="true" focusable="false"><path d="'.htmlspecialchars($path,ENT_QUOTES,'UTF-8').'"></path></svg>';
}

function arc_workspace_section_permission(string $section): string {
    foreach(arc_workspace_menu()['groups'] as $group)foreach($group['items'] as $item)if($item['file']===$section)return $item['permission'];
    return $section;
}
