// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/PlatformManagementPage.cs
using System.Diagnostics;
using Arcoll.WinUI3.Services;
namespace Arcoll.WinUI3.Pages;

/// <summary>Abre as áreas administrativas existentes na plataforma, com a rede autorizada do gestor.</summary>
public sealed class PlatformManagementPage : MaintenancePage
{
    private readonly string _file;
    public PlatformManagementPage(GestorRuntime runtime,Func<string,string,string,Task<bool>> confirm,string key,string label,string file)
        : base(runtime,confirm,key,label,"Gerencie esta ferramenta na plataforma com sua conta e suas permissões da rede.") { _file=file; }
    protected override void Build()
    {
        Actions(Action("Abrir na plataforma",async()=>{
            using var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(20));
            var scope=await Runtime.Platform.PostAsync("gestor-workspace",Runtime.Platform.WithCredentials(("op","info")),cancel.Token);
            var target=new Uri(Runtime.Platform.Config.Origin.TrimEnd('/')+"/redes/"+_file+".php?network="+scope.GetProperty("network_id").GetInt64()+"&gestor="+scope.GetProperty("gestor_id").GetInt64());
            Process.Start(new ProcessStartInfo(target.AbsoluteUri){UseShellExecute=true});
            Status("Página aberta no navegador. Entre na plataforma se solicitado.");
        }));
    }
}
