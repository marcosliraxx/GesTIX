<?php
/* Caminho: redes/seguranca.php — diagnóstico de segurança sincronizado pelo gestor Windows. */
declare(strict_types=1);
require_once __DIR__.'/../includes/error-logging.php';
$arcSectionFile='servidor';$arcMenuSection='seguranca';
require __DIR__.'/_base.php';
if(!in_array($teamRole,['owner','administrator','system_admin'],true)){http_response_code(403);exit('Permissão administrativa necessária.');}
require_once __DIR__.'/../includes/network-pentefino.php';
$report=null;$collected=null;
if($selectedGestorId>0){
 $q=$pdo->prepare('SELECT id FROM '.arc_table('network_gestores')." WHERE id=? AND network_id=? AND account_id=? AND status='approved'");
 $q->execute([(int)$selectedGestorId,(int)$networkId,(int)$account]);
 if($q->fetchColumn()){$saved=arc_pf_report_get($pdo,(int)$selectedGestorId,(int)$networkId,(int)$account,'security');$report=$saved['report']??null;$collected=$saved['collected_at']??null;}
}
require __DIR__.'/_topo.php';
$state=static fn(mixed $value):string=>$value===true?'Ativo':($value===false?'Inativo':'Indisponível');
?>
<section class="card" data-command-results-inline aria-labelledby="network-security-title">
 <h2 id="network-security-title">Segurança do Windows</h2>
 <p>Microsoft Defender, firewall, antivírus registrados e TPM do computador selecionado.</p>
 <a class="button secondary" href="<?=arc_h(arc_workspace_base_url().'redes/seguranca.php?'.http_build_query(['network'=>(int)$networkId,'gestor'=>(int)$selectedGestorId]))?>">Recarregar relatório</a>
 <?php if(!is_array($report)): ?>
 <p role="status">Nenhum diagnóstico sincronizado para este computador. No gestor instalado, abra Manutenção → Segurança e clique em Verificar proteção.</p>
 <?php else: ?>
 <p>Última sincronização: <?=arc_h($collected??'não informada')?>. Estes dados refletem a última consulta no Windows.</p>
 <h3>Microsoft Defender</h3>
 <dl><dt>Antivírus</dt><dd><?=arc_h($state($report['defender']['antivirus_enabled']??null))?></dd><dt>Proteção em tempo real</dt><dd><?=arc_h($state($report['defender']['real_time_enabled']??null))?></dd><dt>Definições desatualizadas</dt><dd><?=arc_h(($report['defender']['signatures_outdated']??null)===true?'Sim':(($report['defender']['signatures_outdated']??null)===false?'Não':'Indisponível'))?></dd><dt>Atualização das definições</dt><dd><?=arc_h($report['defender']['signatures_updated']??'Indisponível')?></dd></dl>
 <h3>Perfis do firewall</h3>
 <?php foreach(($report['firewall']??[]) as $profile): ?><p><?=arc_h($profile['name']??'Perfil')?> — <?=arc_h($state($profile['enabled']??null))?> · Entrada: <?=arc_h($profile['inbound']??'Indisponível')?> · Saída: <?=arc_h($profile['outbound']??'Indisponível')?></p><?php endforeach; ?>
 <?php if(empty($report['firewall'])): ?><p>Consulta de firewall indisponível.</p><?php endif; ?>
 <h3>Antivírus registrados</h3>
 <?php foreach(($report['antivirus']??[]) as $product): ?><p><?=arc_h($product['name']??'Produto')?> · Estado informado pelo Windows: <?=(int)($product['product_state']??0)?></p><?php endforeach; ?>
 <?php if(empty($report['antivirus'])): ?><p>Nenhum produto retornado pela consulta; isso não confirma ausência de proteção.</p><?php endif; ?>
 <h3>TPM</h3><p>Presente: <?=arc_h($state($report['tpm']['present']??null))?> · Pronto: <?=arc_h($state($report['tpm']['ready']??null))?> · Habilitado: <?=arc_h($state($report['tpm']['enabled']??null))?></p>
 <?php foreach(($report['errors']??[]) as $message): ?><p role="status"><?=arc_h($message)?></p><?php endforeach; ?>
 <?php endif; ?>
</section>
<?php require __DIR__.'/_rodape.php'; ?>
