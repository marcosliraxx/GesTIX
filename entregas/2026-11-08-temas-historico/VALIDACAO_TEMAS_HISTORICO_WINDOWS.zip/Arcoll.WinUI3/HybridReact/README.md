# Frontend React (fonte de desenvolvimento) — Etapa 1

`src/main.tsx` é a implementação em React/TypeScript do painel híbrido. A implantação **não depende de Node.js no computador do usuário**: o compilador Vite gera arquivos estáticos servidos localmente por WebView2.

Em uma estação de desenvolvimento Windows com Node.js LTS e acesso ao registro npm:

```powershell
npm install
npm run build
```

O `vite.config.ts` grava o frontend compilado em `../Assets/hybrid/dashboard/`, usado pelo agente WinUI 3.

O pacote entregue também inclui nesta pasta `Assets/hybrid/dashboard/` uma versão de execução estática **sem React**, autocontida, pois não há acesso ao registro npm no ambiente em que o pacote foi preparado. Essa versão executa o mesmo contrato `state`/`navigate` e não exige internet. Para ativar o frontend React, compile-o antes de compilar o agente. Não classifique esta entrega como build React homologado enquanto a compilação no Windows não for executada.
