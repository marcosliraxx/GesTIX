<?php
declare(strict_types=1);
// Fixture exclusiva de testes. Não distribuir sob includes/ em produção.
const ARC_CLOUD_DEFAULT_ROOT='TI Digital';
function arc_table(string $name):string{return '`t_'.$name.'`';}
function arc_db():PDO{static $p;return $p??=new PDO(getenv('BC_TEST_DSN')?:'mysql:host=127.0.0.1;port=3306;dbname=bc_test;charset=utf8mb4','root','root',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);}
function arc_ensure_user_schema(PDO $p):void{}
function arc_cloud_ensure_schema(PDO $p):void{}
function arc_is_user():bool{return ($_SERVER['HTTP_X_TEST_USER']??'')==='valid';}
function arc_user_id():int{return (int)($_SERVER['HTTP_X_TEST_USER_ID']??1);}
function arc_csrf_token():string{return 'test-csrf';}
function arc_network_team_access(PDO $p,int $n,int $u):?array{return $n===$u*10?['role'=>$_SERVER['HTTP_X_TEST_ROLE']??'owner','account_id'=>$u]:null;}
function arc_network_profile_rights(PDO $p,int $n,int $u):?array{return isset($_SERVER['HTTP_X_TEST_RIGHTS'])?explode(',',$_SERVER['HTTP_X_TEST_RIGHTS']):null;}
function arc_billing_assert_active(PDO $p,int $a):void{}
function arc_cloud_agent_row(PDO $p,int $id,int $n,int $a):array{$q=$p->prepare("SELECT * FROM t_network_agents WHERE id=? AND network_id=? AND account_id=? AND status='approved'");$q->execute([$id,$n,$a]);return $q->fetch(PDO::FETCH_ASSOC)?:throw new RuntimeException('Agente fora da conta/rede.',403);}
function arc_agent_authenticate(PDO $p,array $b):array{if(($b['fingerprint']??'')!=='test-fp'||($b['site_code']??'')!=='TEST1'||($b['download_key']??'')!=='test-key')throw new RuntimeException('Credencial revogada/inválida.',401);return arc_cloud_agent_row($p,100,10,1);}
function arc_cloud_connections_list(PDO $p,int $n,int $a):array{return [];}
function arc_cloud_available_providers(PDO $p):array{return [];}
function arc_cloud_policy(PDO $p):array{return ['own'=>false,'platform'=>true];}
function arc_cloud_job_get(PDO $p,int $id,int $n,int $a):array{return ['settings'=>['vdrive'=>false],'enabled'=>false,'connection_id'=>null];}
function arc_user_audit(PDO $p,string $a,string $b):void{}
function arc_cloud_max_file_bytes(PDO $p):int{return 104857600;}
function arc_cloud_state_sign(array $p):string{return base64_encode(json_encode($p));}
function arc_cloud_state_verify(string $v):?array{$p=json_decode(base64_decode($v),true);return is_array($p)&&($p['exp']??0)>time()?$p:null;}
function arc_json(array $v,int $status=200):never{http_response_code($status);header('Content-Type: application/json');echo json_encode($v);exit;}
