<?php
/* Caminho: redes/painel.php — mesmo Painel de dispositivos utilizado pelo agente Windows. */
declare(strict_types=1);
$arcSectionFile = 'painel';
require __DIR__ . '/_base.php';
require __DIR__ . '/_topo.php';
$inventoryUrl = arc_workspace_base_url() . 'pages/painel.php?ajax=network_devices&network=' . (int)$networkId;
$panelAssetBase = arc_workspace_base_url() . 'assets/network-panel/';
?>
<link rel="stylesheet" href="<?=arc_h($panelAssetBase)?>panel.css?v=20261107-panel1">
<section id="network-panel" class="np-panel" data-url="<?=arc_h($inventoryUrl)?>" aria-label="Painel de dispositivos da rede"></section>
<script src="<?=arc_h($panelAssetBase)?>panel.js?v=20261107-panel1" defer></script>
<?php require __DIR__ . '/_rodape.php'; ?>
