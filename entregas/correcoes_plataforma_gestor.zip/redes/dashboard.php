<?php
/* Caminho: redes/dashboard.php — visão consolidada independente das redes da conta.
 * Mantém autorização, cadastro, inventário e presença nas implementações oficiais. */
declare(strict_types=1);
require_once __DIR__.'/../includes/error-logging.php';
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../includes/network-inventory.php';
/* Acesso após login sem parâmetro de rede: recuperar rede atual ou primeira autorizada. */
if ((int)($_GET['network']??0)===0) {
    $bootstrapPdo=arc_db();$pdo=$bootstrapPdo;
    $destination=arc_authenticated_home($bootstrapPdo);
    if($destination && preg_match('/network=(\d+)/',$destination,$match)) {
        header('Location: '.arc_workspace_base_url().$destination,true,303);exit;
    }
    /* Primeira instalação: nenhuma rede cadastrada ainda. */
    if(!arc_is_user() && !arc_is_admin()) {header('Location: '.arc_workspace_base_url().'index.php',true,303);exit;}
    $ARCMode='app';$ARCPageTitle='Dashboard de redes';$ARCActiveNav='network';$ARCHeaderActions='';
    require dirname(__DIR__).'/includes/header.php';
    require dirname(__DIR__).'/includes/sidebar.php';
    require_once dirname(__DIR__).'/includes/workspace-menu.php';
    $base=arc_workspace_base_url();
    echo '<main class="app-main arc-redes-page"><div class="container-wide arc-redes-shell u-mw-none">';
    echo '<nav class="arc-empty-network-nav" aria-label="Ferramentas indisponíveis sem rede"><div class="arc-empty-network-groups">';
    foreach(arc_workspace_menu()['groups'] as $group){
        echo '<div class="arc-empty-network-group"><strong>'.arc_h((string)$group['label']).'</strong><div class="arc-empty-network-links">';
        foreach($group['items'] as $item){
            if(($item['key']??'')==='dashboard'){
                echo '<a class="arc-empty-network-link active" href="'.arc_h($base).'redes/dashboard.php" aria-current="page">'.arc_workspace_menu_icon((string)$item['icon'],18).'<span>Dashboard</span></a>';
            }else{
                echo '<button type="button" class="arc-empty-network-link" aria-disabled="true" data-needs-network title="Cadastre uma rede para liberar">'.arc_workspace_menu_icon((string)$item['icon'],18).'<span>'.arc_h((string)$item['label']).'</span><i class="fa fa-lock" aria-hidden="true"></i></button>';
            }
        }
        echo '</div></div>';
    }
    echo '</div></nav><section class="arc-empty-network-content"><h1>Dashboard</h1><p>Cadastre sua primeira rede para liberar as ferramentas de gestão.</p><button type="button" class="button primary" data-open-register><i class="fa fa-plus"></i> Nova rede</button></section></div></main>';
    require dirname(__DIR__).'/includes/network-register-modal.php';
    echo '<script>document.addEventListener("click",function(e){if(e.target.closest("[data-needs-network]")){e.preventDefault();alert("Cadastre uma rede para ter acesso a esta ferramenta.");}});</script>';
    require dirname(__DIR__).'/includes/footer.php';
    exit;
}
/* O dashboard participa da gestão da rede ativa; não modifica a seleção. */
$arcSectionFile = 'dashboard';
require __DIR__.'/_base.php';
$admin=arc_is_admin();$uid=(int)arc_user_id();
$base=arc_workspace_base_url();
/* Os cartões incluem redes próprias, compartilhadas ativas e, para o administrador,
 * todas as redes ativas; cada operação de inventário verifica autorização novamente. */
if(isset($_GET['ajax'])){
 try {
  if($_GET['ajax']==='states'){
   $items=[];foreach(arc_dashboard_networks($pdo,$admin,$uid) as $n){$total=(int)$n['gestores_total'];$on=(int)$n['gestores_online'];$items[(string)$n['id']]=['online'=>$on,'total'=>$total,'active'=>(int)$n['is_active']];}
   arc_json(['ok'=>true,'states'=>$items]);
  }
  if($_GET['ajax']==='computers'){
   arc_json(arc_dashboard_computers($pdo,(int)($_GET['id']??0),$uid));
  }
  arc_json(['ok'=>false,'error'=>'Operação não encontrada.'],404);
 }catch(DomainException $e){arc_json(['ok'=>false,'error'=>$e->getMessage()],in_array($e->getCode(),[403,404],true)?$e->getCode():422);}
 catch(Throwable $e){arc_log_error('Dashboard redes: '.$e->getMessage());arc_json(['ok'=>false,'error'=>'Não foi possível carregar as informações.'],503);}
}
$error='';try{$networks=arc_dashboard_networks($pdo,$admin,$uid);}catch(Throwable $e){$networks=[];$error='Falha ao consultar as redes cadastradas.';arc_log_error('Dashboard redes: '.$e->getMessage());}
$total=count($networks);$online=0;foreach($networks as $n)if((int)$n['is_active']===1&&(int)$n['gestores_online']>0)$online++;
$ARCMode='app';$ARCPageTitle='Dashboard de redes';$ARCActiveNav='network';$ARCHeaderActions='';
require __DIR__.'/_topo.php';
?>

<section class="nd-content" aria-label="Visão rápida das redes">
<div class="nd-toolbar" role="toolbar" aria-label="Buscar, filtrar e registrar redes">
 <label class="nd-search"><i class="fa fa-search" aria-hidden="true"></i><input id="nd-search" type="search" placeholder="Buscar rede..." aria-label="Buscar redes"></label>
 <select id="nd-filter" aria-label="Filtrar situação"><option value="all">Todas</option><option value="online">Online</option><option value="offline">Offline</option></select>
 <div class="nd-kpis" role="group" aria-label="Indicadores; clique para filtrar">
 <button type="button" class="nd-kpi" data-nd-filter="all" title="Todas as redes" aria-pressed="true"><i class="fa fa-sitemap"></i><b id="nd-total"><?=$total?></b></button>
 <button type="button" class="nd-kpi nd-kpi-on" data-nd-filter="online" title="Redes online" aria-pressed="false"><i class="fa fa-signal"></i><b id="nd-online"><?=$online?></b></button>
 <button type="button" class="nd-kpi nd-kpi-off" data-nd-filter="offline" title="Redes offline" aria-pressed="false"><i class="fa fa-exclamation-circle"></i><b id="nd-offline"><?=$total-$online?></b></button>
 </div>
 <button type="button" class="nd-new" data-open-register <?= $admin?'disabled title="Cadastro restrito ao titular"':'' ?>><i class="fa fa-plus"></i><span>Nova rede</span></button>
</div>
<?php if($error):?><p class="nd-alert" role="alert"><?=arc_h($error)?></p><?php endif; ?>
<div class="nd-grid" id="nd-grid">
<?php foreach($networks as $n): $id=(int)$n['id'];$connected=(int)$n['is_active']===1&&(int)$n['gestores_online']>0;$hasLogo=is_string($n['logo_file'])&&preg_match('/^[a-f0-9]{40}\.(png|jpg|webp)$/',$n['logo_file']); ?>
<button type="button" class="nd-card" data-network="<?=$id?>" data-online="<?=$connected?1:0?>" data-name="<?=arc_h(mb_strtolower(implode(' ',[(string)$n['name'],(string)$n['client_name'],(string)$n['site_code']])))?>" aria-label="Ver computadores da rede <?=arc_h($n['name'])?>">
<div class="nd-card-top"><span class="nd-logo"><?php if($hasLogo):?><img width="43" height="43" style="display:block;max-width:43px;max-height:43px;object-fit:contain" src="<?=arc_h($base)?>api/network-logo.php?network=<?=$id?>" alt="" loading="lazy" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><i class="fa fa-sitemap" hidden></i><?php else:?><i class="fa fa-sitemap"></i><?php endif;?></span><span class="nd-status <?=$connected?'nd-is-online':'nd-is-offline'?>"><i class="fa fa-circle"></i> <span><?=$connected?'Online':'Offline'?></span></span></div>
<h2><?=arc_h($n['name'])?></h2><p class="nd-company"><?=arc_h($n['trade_name']?:($n['client_name']?:'Rede registrada'))?></p>
<div class="nd-card-meta"><span><i class="fa fa-map-marker"></i> <?=arc_h(trim((string)$n['city_name'].' / '.(string)$n['state_code'],' /')?:'Local não informado')?></span><span><i class="fa fa-code"></i> <?=arc_h($n['site_code']?:'—')?></span></div>
<div class="nd-card-foot"><span><i class="fa fa-desktop"></i> <b class="nd-live-count"><?=(int)$n['gestores_online']?></b> de <?=(int)$n['gestores_total']?> gestores online</span><i class="fa fa-chevron-right"></i></div>
</button>
<?php endforeach; ?>
<?php if(!$admin):?><button class="nd-card nd-card-add" type="button" data-open-register><span class="nd-add-icon"><i class="fa fa-plus"></i></span><strong>Adicionar nova rede</strong><span>Cadastre uma empresa pelo CNPJ ou informe os dados manualmente</span></button><?php endif;?>
</div><p class="nd-none" id="nd-empty" hidden>Nenhuma rede corresponde à busca.</p>
</section>
<dialog class="nd-dialog" id="nd-devices" aria-labelledby="nd-devices-title">
 <div class="nd-dialog-head"><div class="nd-dialog-heading"><h2 id="nd-devices-title">Dispositivos da rede</h2><div class="nd-device-counts" role="group" aria-label="Filtrar computadores"><button type="button" data-dev-filter="all" aria-pressed="true"><i class="nd-dot nd-dot-all"></i>Todos <b id="nd-device-all">0</b></button><button type="button" data-dev-filter="online" aria-pressed="false"><i class="nd-dot nd-dot-on"></i>Online <b id="nd-device-on">0</b></button><button type="button" data-dev-filter="offline" aria-pressed="false"><i class="nd-dot nd-dot-off"></i>Offline <b id="nd-device-off">0</b></button></div></div><select id="nd-device-sort" aria-label="Ordenar computadores"><option value="name">Nome</option><option value="online">Online primeiro</option></select><button type="button" class="nd-x" id="nd-device-refresh" title="Atualizar computadores" aria-label="Atualizar"><i class="fa fa-refresh"></i></button><button type="button" class="nd-x" data-close-devices aria-label="Fechar"><i class="fa fa-times"></i></button></div>
 <div class="nd-dialog-body"><div class="nd-device-grid" id="nd-device-list" aria-live="polite"></div><p id="nd-device-stats" class="nd-device-stat" role="status">Carregando computadores...</p></div>
 <footer class="nd-dialog-foot"><span>Consulta rápida · rede atual permanece selecionada</span><button type="button" class="nd-x" data-close-devices aria-label="Fechar modal"><i class="fa fa-check"></i></button></footer>
</dialog>
<dialog class="nd-device-detail" id="nd-device-detail" aria-labelledby="nd-device-detail-name"><div class="nd-detail-header"><strong id="nd-device-detail-name">Computador</strong><button type="button" class="nd-x" data-close-detail aria-label="Fechar"><i class="fa fa-times"></i></button></div><div class="nd-detail-status" id="nd-device-detail-status"></div><dl id="nd-device-detail-fields"></dl></dialog>
<div class="modal-overlay" id="modal-register" role="dialog" aria-modal="true" aria-labelledby="register-modal-title" aria-hidden="true">
    <div class="modal">
        <div class="modal-header">
            <h2 id="register-modal-title">Registrar nova rede</h2>
            <button class="modal-dismiss" type="button" data-close-modal><i class="fa fa-times" aria-hidden="true"></i></button>
        </div>
        <div class="modal-content">
            <form method="post" enctype="multipart/form-data" id="form-register" action="<?=arc_h(arc_workspace_base_url())?>api/network-dashboard-actions.php">
                <input type="hidden" name="_csrf" value="<?= arc_h(arc_csrf_token()) ?>">
                <input type="hidden" name="action" value="network_create"><input type="hidden" name="return_dashboard_network" value="<?=(int)$networkId?>"><input type="hidden" name="return_dashboard" value="1">

                <div class="arc-register-grid">
                    <div class="arc-register-primary">
                        <label class="arc-logo-picker" title="Selecionar a logo da rede">
                            <span id="arc-logo-preview"><i class="fa fa-image" aria-hidden="true"></i></span>
                            <span class="arc-logo-caption">Logo da rede</span>
                            <input id="reg-logo" type="file" name="network_logo" accept="image/png,image/jpeg,image/webp" aria-label="Selecionar logo (até 2 MB)">
                        </label>
                        <div class="arc-register-identify">
                            <label class="arc-field">CPF ou CNPJ <span class="arc-doc-wrap"><input name="doc_number" id="doc-number" inputmode="numeric" maxlength="18" autocomplete="off" placeholder="CPF ou CNPJ"><span class="doc-badge" id="doc-badge">Documento</span></span></label>
                            <label class="arc-field">Nome da rede<input name="network_name" id="reg-name" maxlength="100" required placeholder="Matriz, filial, escritório..."></label>
                        </div>
                    </div>
                    <p class="doc-status span2" id="doc-status" role="status" aria-live="polite">CNPJ: consulta automática ao completar os 14 dígitos.</p>
                    <label class="arc-field">Razão social / cliente<input name="client_name" id="reg-client" maxlength="160" required></label>
                    <label class="arc-field">Nome fantasia<input name="trade_name" id="reg-fantasy" maxlength="160"></label>
                    <label class="arc-field">Responsável<input name="contact_name" id="reg-contact" maxlength="160"></label>
                    <label class="arc-field">Telefone<input name="contact_phone" id="reg-phone" maxlength="40" inputmode="tel"></label>
                    <label class="arc-field">E-mail da empresa<input name="company_email" id="reg-email" type="email" maxlength="160"></label>
                    <label class="arc-field">CEP<input name="zip_code" id="reg-cep" inputmode="numeric" maxlength="9"></label>
                    <label class="arc-field">UF<input name="state_code" id="reg-uf" maxlength="2"></label>
                    <label class="arc-field">Município<input name="city_name" id="reg-city" maxlength="100"></label>
                    <label class="arc-field span2">Endereço completo<input name="address" id="reg-address" maxlength="255"></label>
                    <details class="arc-register-more span2"><summary><i class="fa fa-sliders" aria-hidden="true"></i> Mais detalhes do cadastro (opcional)</summary>
                        <div class="arc-register-more-grid">
                            <label class="arc-field">Logradouro<input name="street_name" id="reg-street" maxlength="160"></label>
                            <label class="arc-field">Número<input name="street_number" id="reg-number" maxlength="20"></label>
                            <label class="arc-field">Complemento<input name="address_extra" id="reg-complement" maxlength="100"></label>
                            <label class="arc-field">Bairro<input name="district_name" id="reg-district" maxlength="100"></label>
                            <label class="arc-field">Situação cadastral<input name="registration_status" id="reg-status" readonly></label>
                            <label class="arc-field">CNAE principal<input name="main_activity" id="reg-cnae" readonly></label>
                            <label class="arc-field">Natureza jurídica<input name="legal_nature" id="reg-legal" readonly></label>
                            <label class="arc-field">Data de abertura<input name="opening_date" id="reg-opening" readonly></label>
                            <label class="arc-field span2">Observações<textarea name="notes" id="reg-notes" maxlength="5000" rows="2"></textarea></label>
                        </div>
                    </details>
                </div>
                <div class="arc-register-footer"><span>O código da rede será gerado automaticamente.</span><button class="button primary" type="submit"><i class="fa fa-check" aria-hidden="true"></i> Registrar rede</button></div>

            </form>
        </div>
    </div>
</div>

<script>
(function(){
'use strict';
var modal=document.getElementById('modal-register');
if(!modal)return;
/* Delegação: o botão do footer é renderizado depois deste script. */
var previousFocus=null;
function open(){previousFocus=document.activeElement;modal.classList.add('open');modal.setAttribute('aria-hidden','false');document.body.classList.add('arc-modal-active');document.getElementById('doc-number')?.focus();}
function close(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('arc-modal-active');previousFocus?.focus();}
document.addEventListener('click',function(e){
    if(e.target.closest('[data-open-register]')) { e.preventDefault(); open(); }
});
modal.querySelector('[data-close-modal]')?.addEventListener('click',close);
modal.addEventListener('click',e=>{if(e.target===modal)close();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))close();});
if(new URLSearchParams(location.search).get('nova_rede')==='1')open();
    /* Documento com reconhecimento progressivo e consulta de CNPJ. */
    var docInput = document.getElementById('doc-number');
    var docBadge = document.getElementById('doc-badge');
    var docStatus = document.getElementById('doc-status');
    var lastCnpj = '', requestController = null, lookupTimer = null;
    function digits(value) { return String(value || '').replace(/\D/g, ''); }
    function maskDocument(value) {
        var d = digits(value).slice(0,14);
        if (d.length <= 11) return d.replace(/^(\d{3})(\d)/,'$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/,'$1.$2.$3').replace(/(\d{3})(\d{1,2})$/,'$1-$2');
        return d.replace(/^(\d{2})(\d)/,'$1.$2').replace(/^(\d{2})\.(\d{3})(\d)/,'$1.$2.$3').replace(/\.(\d{3})(\d)/,'.$1/$2').replace(/(\d{4})(\d{1,2})$/,'$1-$2');
    }
    function put(id, value) { var el = document.getElementById(id); if (el) el.value = value == null ? '' : String(value); }
    function status(message, type) { docStatus.textContent = message; docStatus.className = 'doc-status span2' + (type ? ' ' + type : ''); }
    function addressFromFields() {
        var get = function(id){ return (document.getElementById(id)?.value || '').trim(); };
        put('reg-address', [get('reg-street'), get('reg-number'), get('reg-complement'), get('reg-district'), [get('reg-city'),get('reg-uf')].filter(Boolean).join('/'), get('reg-cep') ? 'CEP ' + get('reg-cep') : ''].filter(Boolean).join(', ').slice(0,255));
    }
    ['reg-street','reg-number','reg-complement','reg-district','reg-city','reg-uf','reg-cep'].forEach(function(id) {
        var el=document.getElementById(id); if (el) el.addEventListener('change', addressFromFields);
    });
    function applyCnpj(data) {
        put('reg-client', data.razao_social || '');
        put('reg-fantasy', data.nome_fantasia || '');
        put('reg-name', data.nome_fantasia || data.razao_social || '');
        put('reg-contact', data.nome_fantasia || data.razao_social || '');
        put('reg-phone', data.ddd_telefone_1 || data.ddd_telefone_2 || '');
        put('reg-email', data.email || '');
        put('reg-cep', String(data.cep || '').replace(/^(\d{5})(\d{3})$/,'$1-$2'));
        put('reg-uf', data.uf || '');
        put('reg-street', data.logradouro || '');
        put('reg-number', data.numero || '');
        put('reg-complement', data.complemento || '');
        put('reg-district', data.bairro || '');
        put('reg-city', data.municipio || '');
        put('reg-status', data.descricao_situacao_cadastral || '');
        var cnae = data.cnae_fiscal_descricao || data.cnae_fiscal || '';
        put('reg-cnae', cnae);
        put('reg-legal', data.natureza_juridica || '');
        put('reg-opening', data.data_inicio_atividade || '');
        addressFromFields();
        status('Dados públicos do CNPJ preenchidos. Confira as informações antes de salvar.', 'success');
    }
    async function lookupCnpj(cnpj) {
        if (requestController) requestController.abort();
        requestController = new AbortController();
        status('Consultando dados públicos do CNPJ...', 'busy');
        try {
            var response = await fetch(<?=json_encode($base)?> + 'api/network-dashboard-actions.php?ajax=cnpj_lookup&cnpj=' + encodeURIComponent(cnpj), {signal:requestController.signal,credentials:'same-origin',headers:{'Accept':'application/json'}});
            var payload=await response.json();
            if (!response.ok || !payload.ok) throw new Error(payload.error || 'Consulta indisponível');
            var data = payload.data;
            if (digits(docInput.value) !== cnpj) return;
            if (!data || !data.razao_social) throw new Error('CNPJ não encontrado');
            applyCnpj(data);
        } catch (error) {
            if (error.name === 'AbortError') return;
            if (digits(docInput.value) === cnpj) status(error.message || 'Consulta indisponível. Preencha os campos manualmente.', 'error');
            lastCnpj = '';
        }
    }
    var logoFile=document.getElementById('reg-logo'), logoPreview=document.getElementById('arc-logo-preview');
    if(logoFile&&logoPreview)logoFile.addEventListener('change',function(){
        var file=this.files&&this.files[0];if(!file)return;
        if(file.size>2097152||!/^image\/(png|jpeg|webp)$/.test(file.type)){
            this.value='';status('A logo deve ser PNG, JPG ou WEBP, com até 2 MB.','error');return;
        }
        var reader=new FileReader();reader.onload=function(){var image=document.createElement('img');image.src=String(reader.result);image.alt='Prévia da logo';logoPreview.replaceChildren(image);};reader.readAsDataURL(file);
    });
    if (docInput) docInput.addEventListener('input', function() {
        var caret=docInput.selectionStart||0;
        var before=digits(docInput.value.slice(0,caret)).length;
        var d=digits(docInput.value).slice(0,14);
        var formatted=maskDocument(d);
        if(docInput.value!==formatted){
            docInput.value=formatted;
            var pos=0,count=0;
            while(pos<formatted.length&&count<before){if(/\d/.test(formatted.charAt(pos)))count++;pos++;}
            docInput.setSelectionRange(pos,pos);
        }
        var type=d.length>11?'CNPJ':d.length===11?'CPF':'CPF/CNPJ';
        docBadge.textContent=type;
        docBadge.className='doc-badge '+(type==='CNPJ'?'cnpj':type==='CPF'?'cpf':'');
        if(lookupTimer)clearTimeout(lookupTimer);
        if(d.length!==14&&requestController){requestController.abort();requestController=null;}
        if(!d.length)status('Digite CPF ou CNPJ para identificar o documento.');
        else if(d.length===11)status('CPF identificado. Para CNPJ, continue digitando até 14 dígitos.');
        else if(d.length<14)status('Documento: '+d.length+' dígitos informados.');
        if(d.length===14&&d!==lastCnpj){
            lookupTimer=setTimeout(function(){if(digits(docInput.value)===d){lastCnpj=d;lookupCnpj(d);}},450);
        }
    });


})();
</script>
<script src="<?=arc_h($base)?>assets/js/network-dashboard.js?v=2" defer></script>
<?php require __DIR__.'/_rodape.php'; ?>
