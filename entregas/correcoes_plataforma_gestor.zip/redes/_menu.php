<?php
/* Caminho: redes/_menu.php — navegação por áreas alinhada ao gestor WinUI 3.
 * Origem das rotas, nomes, ícones e permissões: menu administrativo já existente.
 * Os grupos apenas organizam itens autorizados, sem criar permissões ou rotas.
 */
require_once __DIR__ . '/../includes/error-logging.php';
require_once __DIR__ . '/../includes/menu-favorites.php';
require_once __DIR__.'/../includes/pentefino-modules.php';
$arcNetworkLinks = arc_navigation_items($pdo, 'header', (int)$networkId);
$arcAllowedMenu = in_array(($teamRole ?? ''), ['owner', 'system_admin'], true)
    ? null : arc_network_profile_rights($pdo, (int)$networkId, (int)arc_user_id());
// Ordem, rótulos, faixas e desenhos são os mesmos arquivos usados pelo aplicativo Windows.
require_once __DIR__.'/../includes/workspace-menu.php';
$arcWorkspaceGroups=[];$arcCatalog=[];$arcMenuPermissions=[];
foreach(arc_workspace_menu()['groups'] as $group){
 $groupKey=$group['web'];$arcWorkspaceGroups[$groupKey]=['label'=>$group['label'],'icon'=>$group['icon']];
 foreach($group['items'] as $item){
  $arcCatalog[$item['key']]=[$groupKey,$item['label'],$item['icon'],$item['band'],$item['file'],$item['query']??''];
  $arcMenuPermissions[$item['file']]=$item['permission'];
 }
}
$arcFavoriteKeyMap = [];
$arcFavAllowed = function_exists('arc_menu_favorites_allowed') ? arc_menu_favorites_allowed() : [];
$arcAvailable = [];
foreach ($arcNetworkLinks as $item) {
    $path = (string)parse_url((string)($item['url'] ?? ''), PHP_URL_PATH);
    if (!preg_match('~^redes/([a-z0-9_-]+)\.php$~iD', $path, $m)) continue;
    if ($arcAllowedMenu !== null && !in_array($arcMenuPermissions[$m[1]]??$m[1], $arcAllowedMenu, true)) continue;
    $arcAvailable[$m[1]] = true;
}
// Configurações explícitas do administrador sempre prevalecem, inclusive itens desativados.
$arcConfigured=[];$arcConfiguredTabs=[];$arcAllowedTabs=[];
$arcMenuRows=$pdo->query('SELECT target_url FROM '.arc_table('navigation_items')." WHERE context='network' AND placement='header'")->fetchAll(PDO::FETCH_COLUMN);
foreach($arcMenuRows as $url){$path=(string)parse_url((string)$url,PHP_URL_PATH);$arcConfigured[basename($path,'.php')]=true;}
foreach($arcMenuRows as $url){parse_str((string)parse_url((string)$url,PHP_URL_QUERY),$query);if(isset($query['tab'])&&is_string($query['tab']))$arcConfiguredTabs[basename((string)parse_url((string)$url,PHP_URL_PATH),'.php').'|'.$query['tab']]=true;}
foreach($arcNetworkLinks as $item){$url=(string)($item['url']??'');parse_str((string)parse_url($url,PHP_URL_QUERY),$query);if(isset($query['tab'])&&is_string($query['tab']))$arcAllowedTabs[basename((string)parse_url($url,PHP_URL_PATH),'.php').'|'.$query['tab']]=true;}
foreach($arcCatalog as [$groupKey,$label,$icon,$band,$section,$query]){
 if(isset($arcConfigured[$section])||isset($arcAvailable[$section]))continue;
 $permission=$arcMenuPermissions[$section]??$section;
 if($arcAllowedMenu!==null&&!in_array($permission,$arcAllowedMenu,true))continue;
 if(in_array($groupKey,['pentefino','backup'],true)&&!in_array($teamRole,['owner','administrator','system_admin'],true))continue;
 $parent=($permission==='pentefino'?'pentefino':($section==='seguranca'?'servidor':(in_array($section,['atualizacoes','historico'],true)?'servidor':$section)));
 if(isset($arcConfigured[$parent])&&empty($arcAvailable[$parent]))continue;
 if((in_array($teamRole,['owner','system_admin'],true)||($arcAllowedMenu!==null&&in_array($permission,$arcAllowedMenu,true))||!empty($arcAvailable[$parent]))&&is_file(__DIR__.'/'.$section.'.php'))$arcAvailable[$section]=true;
}
if($arcAllowedMenu!==null&&!in_array('programas',$arcAllowedMenu,true))unset($arcAvailable['pentefino-desinstalar']);
$arcGroupedLinks = [];
foreach ($arcCatalog as $key => [$groupKey, $label, $icon, $band, $section, $query]) {
    if ($key === 'remote') continue; // Acesso remoto é ação fixa do ícone de olho, não submenu.
    if (empty($arcAvailable[$section]) || $section==='permissoes') continue;
    parse_str($query,$arcItemQuery);$arcTabKey=$section.'|'.($arcItemQuery['tab']??'');
    if(isset($arcConfiguredTabs[$arcTabKey])&&!isset($arcAllowedTabs[$arcTabKey]))continue;
    if(($groupKey==='pentefino'||in_array($section,['seguranca'],true))&&!in_array($teamRole,['owner','administrator','system_admin'],true))continue;
    $url = arc_workspace_base_url() . 'redes/' . $section . '.php?network=' . (int)$networkId
         . ($query !== '' ? '&' . $query : '') . ($selectedGestorId>0 ? '&gestor=' . (int)$selectedGestorId : '');
    $arcGroupedLinks[$groupKey][] = ['section'=>$key,'label'=>$label,'icon'=>$icon,'band'=>$band,'href'=>$url];
    $arcFavoriteKeyMap[$key] = $key;
}
$arcGroupedLinks = array_intersect_key(array_replace(array_flip(array_keys($arcWorkspaceGroups)), $arcGroupedLinks), $arcGroupedLinks);
// Favoritos pertencem exclusivamente à categoria Início: saem da categoria de origem e só voltam ao desfavoritar.
$arcFavorites = [];
try {
    $arcAccess = arc_network_team_access($pdo, (int)$networkId, (int)arc_user_id());
    if ($arcAccess) $arcFavorites = (array)(arc_menu_favorites_read($pdo, (int)$arcAccess['account_id'], (int)$networkId)['favorites'] ?? []);
} catch (Throwable $e) { $arcFavorites = []; }
foreach ($arcGroupedLinks as $groupKey => $entries) {
    if ($groupKey === 'inicio') continue;
    foreach ($entries as $index => $entry) {
        if ($entry['section'] === 'panel' || !in_array($entry['section'], $arcFavorites, true)) continue;
        $entry['origin'] = $groupKey;
        $arcGroupedLinks['inicio'][] = $entry;
        unset($arcGroupedLinks[$groupKey][$index]);
    }
    $arcGroupedLinks[$groupKey] = array_values($arcGroupedLinks[$groupKey]);
}
// Seção atual -> chave do gestor.
$arcCurrentSection = (string)($arcMenuSection ?? $arcSectionFile ?? '');
$arcSectionToKey = ['dashboard'=>'dashboard','painel'=>'panel','servidor'=>'server','seguranca'=>'security','programas'=>'programs','velocidade'=>'speed','dispositivos'=>'devices','mapa'=>'map','backup'=>'backup_files','arquivos'=>'files','suporte'=>'support','chamados'=>'tickets','remoto'=>'remote','atualizacoes'=>'updates','historico'=>'history','usuarios'=>'users','permissoes'=>'permissions','preferencias'=>'preferences','configuracoes'=>'preferences','relatorios'=>'reports','cadastros'=>'registry_cad','liberacao'=>'release','agenda'=>'agenda'];
if ($arcCurrentSection === 'pentefino') {
    $arcCurrentSection = isset($arcPfModule) ? (arc_pf_modules()[$arcPfModule]['native']??'health') : 'health'; // Rota legada continua acessível; menu Configurações foi incorporado às ferramentas.
} else {
    $arcCurrentSection = $arcSectionToKey[$arcCurrentSection] ?? $arcCurrentSection;
}
$arcCurrentGroup = 'outros';
foreach ($arcGroupedLinks as $key => $entries) foreach ($entries as $entry) if ($entry['section'] === $arcCurrentSection) $arcCurrentGroup = $key; // favorito já está em 'inicio'
?>
<?php if ($arcGroupedLinks): ?>
<!-- Faixas nativas do gestor Windows: categorias na primeira linha e ferramentas na segunda. -->
<nav data-favorites-url="<?=arc_h(arc_workspace_base_url().'api/menu-favorites.php?network='.(int)$networkId)?>" data-favorites-csrf="<?=arc_h($csrf)?>" class="arc-gestor-ribbon <?= $arcCurrentSection === 'remote' ? 'arc-remote-current' : '' ?>" aria-label="Ferramentas da gestão da rede" data-active-group="<?=arc_h($arcCurrentGroup)?>">
  <div class="arc-gestor-ribbon-groups" id="arc-gestor-ribbon-groups" role="tablist" aria-label="Categorias do gestor">
    <?php foreach($arcGroupedLinks as $groupKey=>$items):
      $group=$arcWorkspaceGroups[$groupKey]??['label'=>'Outros','icon'=>'fa-ellipsis-h'];
      $selected=$groupKey===$arcCurrentGroup || ($arcCurrentGroup==='outros' && $groupKey===array_key_first($arcGroupedLinks));
    ?>
    <button type="button" id="arc-ribbon-tab-<?=arc_h($groupKey)?>" class="arc-gestor-ribbon-tab <?=$selected?'active':''?>" <?=($items||$groupKey==='inicio')?'':'hidden'?> role="tab" aria-selected="<?=$selected?'true':'false'?>" aria-controls="arc-ribbon-panel-<?=arc_h($groupKey)?>" data-group="<?=arc_h($groupKey)?>">
      <?=arc_workspace_menu_icon($group['icon'],16)?>
      <span><?=arc_h($group['label'])?></span>
    </button>
    <?php endforeach; ?>
    <?php
    // Seletor de destino: Gestor Servidor ou Gestor Colaborador (mesma lista e mesmo parâmetro "gestor" usados pelas ferramentas).
    $arcPickerItems=array_values(array_filter($networkGestores,static fn($g)=>($g['status']??'')==='approved'));
    // Nome e logo cadastrados em Admin › Configurações para cada tipo de gestor.
    $arcGB=['server'=>['title'=>'Gestor Servidor','logo_url'=>''],'collaborator'=>['title'=>'Gestor Colaborador','logo_url'=>'']];
    try{require_once dirname(__DIR__).'/includes/loader-mark.php';$arcGB=['server'=>arc_gestor_brand($pdo,'server'),'collaborator'=>arc_gestor_brand($pdo,'collaborator')];}catch(Throwable $arcGBError){}
    if($arcPickerItems):
    ?>
    <div class="arc-gestor-picker" id="arc-gestor-picker-container">
      <button type="button" id="arc-gestor-picker-button" class="arc-gestor-picker-button" aria-haspopup="listbox" aria-expanded="false" aria-controls="arc-gestor-picker-list" title="Selecionar computador">
        <i class="fa fa-server" aria-hidden="true" id="arc-gestor-picker-icon"></i>
        <span id="arc-gestor-picker-name">Selecione</span><i class="fa fa-angle-down" aria-hidden="true"></i>
      </button>
      <div class="arc-gestor-picker-list" id="arc-gestor-picker-list" role="listbox" aria-label="Selecionar computador" hidden>
        <?php foreach($arcPickerItems as $g):
          $isServer=($g['installation_profile']??'')==='server';$gb=$arcGB[$isServer?'server':'collaborator'];
          $machine=trim((string)($g['machine_name']??''));if($machine==='')$machine='Computador';
          $short=function_exists('mb_strlen')?(mb_strlen($machine,'UTF-8')>8?mb_substr($machine,0,8,'UTF-8').'...':$machine):(strlen($machine)>8?substr($machine,0,8).'...':$machine);
        ?>
        <button type="button" role="option" class="arc-gestor-picker-option" aria-selected="<?=$selectedGestorId===(int)$g['id']?'true':'false'?>" data-id="<?=(int)$g['id']?>" data-icon="<?=$isServer?'fa-server':'fa-users'?>" data-logo="<?=arc_h($gb['logo_url'])?>" data-name="<?=arc_h($short)?>" title="<?=arc_h($gb['title'].' — '.$machine)?>">
          <?php if($gb['logo_url']!==''):?><img class="arc-gb-ico" src="<?=arc_h($gb['logo_url'])?>" alt="" width="18" height="18" loading="lazy"><?php else:?><i class="fa <?=$isServer?'fa-server':'fa-users'?>" aria-hidden="true"></i><?php endif;?><span><?=arc_h($short)?></span>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
    <script>function arcPickerIcon(o){var i=document.getElementById('arc-gestor-picker-icon');if(!i)return;var box=i.parentNode,img=document.getElementById('arc-gestor-picker-logo');if(o.dataset.logo){if(!img){img=document.createElement('img');img.id='arc-gestor-picker-logo';img.className='arc-gb-ico';img.width=18;img.height=18;img.alt='';box.insertBefore(img,i)}img.src=o.dataset.logo;img.hidden=false;i.style.display='none'}else{if(img)img.hidden=true;i.style.display='';i.className='fa '+o.dataset.icon}}
    /* Caminho: redes/_menu.php — seletor compacto; apenas apresentação, sem alterar IDs ou permissões. */
    (()=>{
      const container=document.getElementById('arc-gestor-picker-container'),toggle=document.getElementById('arc-gestor-picker-button'),list=document.getElementById('arc-gestor-picker-list');
      if(!container||!toggle||!list)return;
      const entries=[...list.querySelectorAll('[data-id]')],active=entries.find(el=>el.getAttribute('aria-selected')==='true');
      if(active){document.getElementById('arc-gestor-picker-name').textContent=active.dataset.name;arcPickerIcon(active);toggle.title=active.title;}
      // A lista sai do contêiner com overflow horizontal: no iOS Safari o popup precisa estar no body.
      document.body.appendChild(list);
      function close(){list.hidden=true;toggle.setAttribute('aria-expanded','false');}
      function position(){const box=toggle.getBoundingClientRect();list.style.top=(box.bottom+4)+'px';list.style.left=Math.max(4,Math.min(box.left,innerWidth-list.offsetWidth-4))+'px';}
      toggle.addEventListener('click',()=>{const show=list.hidden;list.hidden=!show;toggle.setAttribute('aria-expanded',String(show));if(show){position();(active||entries[0])?.focus();}});
      entries.forEach(el=>el.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();const id=String(el.dataset.id||'');if(!/^\d+$/.test(id))return;entries.forEach(option=>option.setAttribute('aria-selected',option===el?'true':'false'));document.getElementById('arc-gestor-picker-name').textContent=el.dataset.name;arcPickerIcon(el);toggle.title=el.title;const native=document.getElementById('arc-gestor-target');if(native){native.value=id;}close();const url=new URL(window.location.href);url.searchParams.set('network',String(<?= (int)$networkId ?>));url.searchParams.set('gestor',id);window.location.assign(url.href);}));
      document.addEventListener('pointerdown',e=>{if(!container.contains(e.target)&&!list.contains(e.target))close();});
      window.addEventListener('resize',()=>{if(!list.hidden)position();});
      container.addEventListener('keydown',e=>{if(e.key==='Escape'){close();toggle.focus();}else if((e.key==='ArrowDown'||e.key==='ArrowUp')&&!list.hidden){e.preventDefault();let index=entries.indexOf(document.activeElement);index=(index+(e.key==='ArrowDown'?1:-1)+entries.length)%entries.length;entries[index]?.focus();}});
    })();
    </script>
    <?php endif; ?>
    <script>
    /* Caminho: redes/_menu.php — mantém a ação remota sincronizada com o gestor selecionado. */
    (()=>{
      const link=document.getElementById('arc-gestor-remote-action');
      const picker=document.getElementById('arc-gestor-picker-list');
      if(!link||!picker)return;
      const setTarget=id=>{
        if(!/^\d+$/.test(String(id))||Number(id)<=0)return;
        const url=new URL(link.dataset.base,location.href);
        url.searchParams.set('network',link.dataset.network);
        url.searchParams.set('gestor',String(id));
        url.searchParams.set('connect_code','1');
        link.href=url.href;
      };
      picker.addEventListener('click',e=>{
        const opt=e.target.closest('.arc-gestor-picker-option[data-id]');
        if(opt)setTarget(opt.dataset.id);
      });
      link.addEventListener('click',e=>{
        if(!navigator.onLine){
          e.preventDefault();
          alert('A plataforma precisa de conexão com o servidor para abrir o acesso remoto web. Para acessar um colaborador sem internet pela mesma rede local, utilize o Acesso remoto LAN no Gestor Windows instalado.');
        }
      });
    })();
    </script>


  </div>
  <div class="arc-gestor-ribbon-viewport">
    <?php foreach($arcGroupedLinks as $groupKey=>$items):
      $selected=$groupKey===$arcCurrentGroup || ($arcCurrentGroup==='outros' && $groupKey===array_key_first($arcGroupedLinks));
    ?>
    <div id="arc-ribbon-panel-<?=arc_h($groupKey)?>" class="arc-gestor-ribbon-items" role="tabpanel" aria-labelledby="arc-ribbon-tab-<?=arc_h($groupKey)?>" data-group="<?=arc_h($groupKey)?>" <?=$selected?'':'hidden'?>>
      <?php foreach($items as $item): $favoriteKey=$item['section']; $active=$item['section']===$arcCurrentSection; ?>
      <div class="arc-favorite-cell" data-band="<?=(int)$item['band']?>" data-origin="<?=arc_h((string)($item['origin']??$groupKey))?>">
      <a href="<?=arc_h($item['href'])?>" data-favorite-key="<?=arc_h($favoriteKey)?>" class="arc-gestor-ribbon-link <?=$active?'active':''?>" <?=$active?'aria-current="page"':''?> title="<?=arc_h($item['label'])?>">
        <span class="arc-db-icon" aria-hidden="true"><?=arc_workspace_menu_icon($item['icon'])?></span>
        <span><?=arc_h($item['label'])?></span>
      </a>
      <?php if ($favoriteKey!=='' && $favoriteKey!=='panel' && $favoriteKey!=='dashboard' && !($groupKey==='inicio' && !isset($item['origin'])) && in_array($favoriteKey,$arcFavAllowed,true)): ?>
      <button type="button" class="arc-favorite-star" data-favorite-key="<?=arc_h($favoriteKey)?>" aria-label="Favoritar <?=arc_h($item['label'])?>" title="Favoritar"><i class="fa <?=isset($item['origin'])?'fa-star':'fa-star-o'?>" aria-hidden="true"></i></button>
      <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </div>
</nav>

<!-- Menu inferior no estilo do Gestor Windows em janela reduzida: submenus do novo Início, Dashboard central com a logo do sistema e "Mais". -->
<nav class="arc-gestor-compact-nav" id="arc-gestor-compact-nav" aria-label="Navegação compacta" data-logo="<?=arc_h(arc_workspace_base_url().'api/brand-logo.php')?>" hidden></nav>
<script>
/* Caminho: redes/_menu.php — espelha MainWindow.BottomNav.cs: reduzida (<620px) mostra somente Início (Dashboard ao centro), excedente de 6 em "Mais". */
(()=>{'use strict';
 const ribbon=document.querySelector('.arc-gestor-ribbon'),dock=document.getElementById('arc-gestor-compact-nav');
 if(!ribbon||!dock)return;
 document.body.appendChild(dock); // dock fixo no rodapé, fora do fluxo do ribbon
 const small=window.matchMedia('(max-width:620px)');let menu=null;
 const closeMenu=()=>{if(menu){menu.remove();menu=null;}dock.querySelector('.arc-compact-nav-more')?.setAttribute('aria-expanded','false');};
 const entries=()=>{
   const home=ribbon.querySelector('.arc-gestor-ribbon-items[data-group="inicio"]');
   return [...(home?.querySelectorAll('.arc-favorite-cell')||[])].filter(cell=>!cell.dataset.origin||cell.dataset.origin==='inicio').map(cell=>{const a=cell.querySelector('.arc-gestor-ribbon-link');return a?{a,key:a.dataset.favoriteKey||'',origin:cell.dataset.origin||'inicio'}:null}).filter(Boolean);
 };
 const iconOf=a=>a.querySelector('.arc-db-icon')?.cloneNode(true);
 const labelOf=a=>(a.querySelector('span:last-child')?.textContent||a.title||'Menu').trim();
 const item=(e,center)=>{
   const l=document.createElement('a');l.className='arc-compact-nav-item'+(center?' arc-compact-nav-panel':'');l.href=e.a.href;l.title=labelOf(e.a);
   if(e.a.classList.contains('active'))l.setAttribute('aria-current','page');
   if(center&&dock.dataset.logo){
     const disc=document.createElement('span');disc.className='arc-db-icon arc-compact-logo';
     const img=new Image();img.alt='';img.src=dock.dataset.logo;img.onerror=()=>{disc.replaceChildren(iconOf(e.a)||'')};disc.appendChild(img);l.appendChild(disc);
   }else{const i=iconOf(e.a);if(i)l.appendChild(i);}
   const c=document.createElement('span');c.textContent=labelOf(e.a);l.appendChild(c);return l;
 };
 const build=()=>{
   closeMenu();dock.replaceChildren();
   const all=entries();const panel=all.find(e=>e.key==='dashboard');const others=all.filter(e=>e!==panel);
   const more=others.length>6;const shown=others.slice(0,more?5:6);const rest=others.slice(shown.length);
   const side=shown.map(e=>({e}));let moreBtn=null;
   if(more){moreBtn=document.createElement('button');moreBtn.type='button';moreBtn.className='arc-compact-nav-item arc-compact-nav-more';moreBtn.setAttribute('aria-haspopup','true');moreBtn.setAttribute('aria-expanded','false');moreBtn.innerHTML='<i class="fa fa-ellipsis-h" aria-hidden="true"></i><span>Mais</span>';side.push({more:true});}
   const half=panel?Math.ceil(side.length/2):side.length;const left=side.slice(0,half),right=side.slice(half);
   const slots=[];if(!panel)slots.push(...side);else{const n=Math.max(left.length,right.length);slots.push(...left);while(slots.length<n)slots.push(null);slots.push({e:panel,center:true});slots.push(...right);while(slots.length<n*2+1)slots.push(null);}
   dock.style.setProperty('--arc-dock-cols',String(slots.length||1));
   slots.forEach((slot,i)=>{
     const cell=document.createElement('div');cell.className='arc-compact-nav-slot';
     if(slot){cell.appendChild(slot.more?moreBtn:item(slot.e,!!slot.center));if(slots[i+1])cell.classList.add('arc-compact-nav-divided');}
     dock.appendChild(cell);
   });
   if(moreBtn)moreBtn.addEventListener('click',ev=>{
     ev.stopPropagation();if(menu){closeMenu();return;}
     menu=document.createElement('div');menu.className='arc-compact-more-menu';menu.setAttribute('role','menu');
     let last=null;rest.forEach(e=>{
       if(last!==null&&e.origin!==last){const sep=document.createElement('hr');menu.appendChild(sep);}last=e.origin;
       const l=document.createElement('a');l.setAttribute('role','menuitem');l.href=e.a.href;const i=iconOf(e.a);if(i)l.appendChild(i);const t=document.createElement('span');t.textContent=labelOf(e.a);l.appendChild(t);menu.appendChild(l);
     });
     document.body.appendChild(menu);const box=moreBtn.getBoundingClientRect();
     menu.style.bottom=(innerHeight-box.top+6)+'px';menu.style.right=Math.max(6,innerWidth-box.right-4)+'px';
     moreBtn.setAttribute('aria-expanded','true');menu.querySelector('a')?.focus();
   });
 };
 const sync=()=>{dock.hidden=!small.matches;document.documentElement.classList.toggle('arc-compact-window',small.matches);if(!small.matches)closeMenu();};
 document.addEventListener('pointerdown',e=>{if(menu&&!menu.contains(e.target)&&!e.target.closest('.arc-compact-nav-more'))closeMenu();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});
 document.addEventListener('arc-ribbon-rendered',build);
 build();sync();small.addEventListener('change',sync);
})();
</script>

<script>
/* Caminho: redes/_menu.php — troca de categoria sem navegação ou perda do estado da página. */
(function(){'use strict';
 const root=document.querySelector('.arc-gestor-ribbon');if(!root)return;
 const tabs=Array.from(root.querySelectorAll('[role="tab"]'));
 const panels=Array.from(root.querySelectorAll('[role="tabpanel"]'));
 function select(tab,focus){
   const key=tab.dataset.group;
   tabs.forEach(t=>{const active=t===tab;t.classList.toggle('active',active);t.setAttribute('aria-selected',active?'true':'false');t.tabIndex=active?0:-1;});
   panels.forEach(p=>{p.hidden=p.dataset.group!==key;});
   root.dataset.activeGroup=key;root.dataset.submenusOpen='1';
   root.classList.remove('arc-remote-current');
   if(focus)tab.focus();
 }
 tabs.forEach((tab,index)=>{
   tab.addEventListener('click',()=>select(tab,false));
   tab.addEventListener('keydown',event=>{
     if(event.key!=='ArrowRight'&&event.key!=='ArrowLeft'&&event.key!=='Home'&&event.key!=='End')return;
     event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
     select(tabs[next],true);
   });
 });
 const endpoint=root.dataset.favoritesUrl, token=root.dataset.favoritesCsrf;
 const validLinks=[...root.querySelectorAll('.arc-gestor-ribbon-link[data-favorite-key]')];
 const cells=validLinks.map(a=>a.closest('.arc-favorite-cell'));
 const panelOf=g=>panels.find(p=>p.dataset.group===g)||null;
 const originals=new Map(cells.map((cell,index)=>[cell,{group:cell.dataset.origin,index}]));
 function layoutBands(){
   panels.forEach(p=>{
     p.querySelectorAll(':scope > .arc-ribbon-sep').forEach(x=>x.remove());
     if(p.dataset.group==='inicio')return;
     const list=Array.from(p.querySelectorAll(':scope > .arc-favorite-cell')).sort((x,y)=>(originals.get(x)?.index||0)-(originals.get(y)?.index||0));
     list.forEach(c=>p.appendChild(c));
     let band=null;
     list.forEach(c=>{const b=c.dataset.band;if(band!==null&&b!==band){const sep=document.createElement('span');sep.className='arc-ribbon-sep';sep.setAttribute('role','separator');sep.setAttribute('aria-orientation','vertical');p.insertBefore(sep,c);}band=b;});
   });
 }
 const favoritesHost=panels.find(p=>p.dataset.group==='inicio');
 let current=new Set(), pending=false;
 function renderFavorites(){
   cells.forEach(cell=>{
     const a=cell.querySelector('.arc-gestor-ribbon-link'),key=a?.dataset.favoriteKey,original=originals.get(cell);
     if(!original)return;
     if(key && key!=='panel'&&key!=='dashboard'&&current.has(key)&&favoritesHost)favoritesHost.appendChild(cell);
     else{const home=panelOf(original.group);if(home)home.appendChild(cell);}
     const star=cell.querySelector('.arc-favorite-star');
     if(star){const selected=current.has(key);star.title=selected?'Desfavoritar':'Favoritar';star.setAttribute('aria-label',star.title+' '+(a?.textContent||'').trim());
       star.querySelector('i').className='fa '+(selected?'fa-star':'fa-star-o');}
   });
   // Dashboard e Painel ficam fixos no início, nessa ordem.
   const panel=validLinks.find(a=>a.dataset.favoriteKey==='panel');
   if(panel&&favoritesHost)favoritesHost.prepend(panel.closest('.arc-favorite-cell'));
   const dashboard=validLinks.find(a=>a.dataset.favoriteKey==='dashboard');
   if(dashboard&&favoritesHost)favoritesHost.prepend(dashboard.closest('.arc-favorite-cell'));
   layoutBands();
   panels.forEach(p=>{
     const visible=p.querySelectorAll('.arc-gestor-ribbon-link').length>0;
     const tab=tabs.find(t=>t.dataset.group===p.dataset.group);
     if(tab)tab.hidden=!visible && p.dataset.group!=='inicio';
   });
   document.dispatchEvent(new Event('arc-ribbon-rendered'));
 }
 async function request(operation){
    const isRead=!operation;
    const response=await fetch(endpoint,{method:isRead?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:isRead?{}:{'Content-Type':'application/json','X-CSRF-Token':token},body:isRead?undefined:JSON.stringify(operation)});
    const json=await response.json();if(!response.ok||!json.ok)throw Error(json.error||'Não foi possível sincronizar');return json;
 }
 async function sync(){if(pending||!document.visibilityState||document.visibilityState==='hidden')return;
   try{const data=await request(null);current=new Set(data.favorites||[]);renderFavorites();
   }catch(err){console.warn('Favoritos:',err.message);}
 }
 root.querySelectorAll('.arc-favorite-star').forEach(star=>star.addEventListener('click',async()=>{
   if(pending)return; pending=true; const key=star.dataset.favoriteKey, isFavorite=!current.has(key);
   star.disabled=true;
   try{const data=await request({operation:'set',key,favorite:isFavorite});current=new Set(data.favorites||[]);renderFavorites();
      const home=tabs.find(t=>t.dataset.group==='inicio');if(isFavorite&&home)select(home,false);
   }catch(err){console.warn('Favoritos:',err.message);alert('Não foi possível sincronizar o favorito. Tente novamente.');}
   finally{star.disabled=false;pending=false;}
 }));
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')sync();});
 window.setInterval(sync,30000);sync();

 // Ações fixas abrem páginas próprias, sem reutilizar o modal de instalação.
 const base=<?=json_encode(arc_workspace_base_url())?>;
 const network=<?= (int)$networkId ?>;
 function gestor(){return Number(document.getElementById('arc-gestor-target')?.value||<?= (int)$selectedGestorId ?>)}

 layoutBands();const active=tabs.find(t=>t.classList.contains('active'))||tabs[0];if(active)select(active,false);
})();
</script>
<script>
/* Caminho: redes/_menu.php — indicador de atualização no menu pai e destaque único dos submenus alterados. */
(function(){'use strict';
 const root=document.querySelector('.arc-gestor-ribbon');if(!root)return;
 const base=<?=json_encode(arc_workspace_base_url())?>,network=<?= (int)$networkId ?>,currentFile=<?=json_encode((string)($arcSectionFile??''))?>;
 const seenKey='arc_seen_platform_'+network,blinkKey='arc_blink_'+network;
 const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
 const readBlink=()=>{try{const v=JSON.parse(store.get(blinkKey)||'[]');return Array.isArray(v)?v.filter(x=>typeof x==='string'):[]}catch(e){return[]}};
 const fileOf=a=>{const m=(a.getAttribute('href')||'').match(/\/redes\/([a-z0-9_-]+)\.php/i);return m?m[1].toLowerCase():''};
 const groupOfLink=a=>a.closest('[role="tabpanel"]')?.dataset.group||'';
 function applyBlink(group){
  let pending=readBlink();if(!pending.length)return;
  const panel=root.querySelector('[role="tabpanel"][data-group="'+group+'"]');if(!panel)return;
  const shown=new Set();
  panel.querySelectorAll('.arc-gestor-ribbon-link').forEach(a=>{const f=fileOf(a);if(f&&pending.includes(f)){shown.add(f);if(f===currentFile)return;a.classList.add('arc-blink');a.addEventListener('animationend',()=>a.classList.remove('arc-blink'),{once:true});}});
  if(shown.size)store.set(blinkKey,JSON.stringify(pending.filter(f=>!shown.has(f))));
 }
 function setBadge(show,count){
  root.querySelectorAll('.arc-ribbon-badge').forEach(b=>b.remove());
  if(!show)return;
  const link=root.querySelector('.arc-gestor-ribbon-link[data-favorite-key="updates"]');if(!link)return;
  const groups=new Set([groupOfLink(link)]);const origin=link.closest('.arc-favorite-cell')?.dataset.origin;if(origin)groups.add(origin);
  groups.forEach(g=>{const tab=root.querySelector('.arc-gestor-ribbon-tab[data-group="'+g+'"]');if(!tab)return;const b=document.createElement('span');b.className='arc-ribbon-badge';b.textContent=String(count||1);b.setAttribute('role','status');b.setAttribute('aria-label','Atualização do gestor disponível');tab.appendChild(b);});
  const dot=document.createElement('span');dot.className='arc-ribbon-badge arc-ribbon-badge-dot';dot.setAttribute('aria-hidden','true');link.appendChild(dot);
 }
 async function sync(){
  if(document.hidden)return;
  try{
   const seen=store.get(seenKey)||'';
   const url=new URL(base+'api/api.php',location.href);url.search=new URLSearchParams({action:'network-gestor-versions',network_id:network,...(seen?{since:seen}:{})});
   const r=await fetch(url,{credentials:'same-origin',cache:'no-store'});const d=await r.json();if(!r.ok||!d.ok)return;
   const version=String(d.platform_version||'');
   if(version){if(seen&&seen!==version){const merged=new Set([...readBlink(),...(d.changed_tools||[])]);store.set(blinkKey,JSON.stringify([...merged]));}store.set(seenKey,version);}
   const outdated=(d.gestores||[]).filter(g=>g.approved&&g.outdated&&g.online).length;
   setBadge(d.can_update===true&&outdated>0,outdated);
   const active=root.querySelector('.arc-gestor-ribbon-tab.active');if(active)applyBlink(active.dataset.group);
  }catch(e){}
 }
 root.querySelectorAll('.arc-gestor-ribbon-tab').forEach(t=>t.addEventListener('click',()=>setTimeout(()=>applyBlink(t.dataset.group),0)));
 window.addEventListener('arc-update-state',e=>setBadge(!!e.detail?.available,1));
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync();});
 setInterval(sync,10000);sync();
})();
</script>
<?php endif; ?>
