<?php
/* Caminho: includes/gestor-workspace.php */
declare(strict_types=1);
require_once __DIR__ . '/error-logging.php';

/** Dados do gestor autenticado: nunca aceita conta/rede/computador vindos do corpo. */
function arc_gestor_workspace(PDO $pdo, array $gestor, array $body): array {
    $account=(int)$gestor['account_id'];$network=(int)$gestor['network_id'];$id=(int)$gestor['id'];
    $q=$pdo->prepare('SELECT name,logo_file,address FROM '.arc_table('managed_networks').' WHERE id=? AND account_id=?');
    $q->execute([$network,$account]);$net=$q->fetch(PDO::FETCH_ASSOC);
    if(!$net)throw new DomainException('Rede indisponível.',403);
    $op=(string)($body['op']??'info');
    if($op==='collaborators'){
        $profile=arc_gt_profile($pdo,$gestor);if($profile['role']!=='server')throw new DomainException('Somente o Servidor pode selecionar colaboradores.',403);arc_gt_require($pdo,$gestor,'coordinate');
        $q=$pdo->prepare('SELECT id,machine_name,status,last_seen_at,gestor_version FROM '.arc_table('network_gestores')." WHERE account_id=? AND network_id=? AND id<>? AND (installation_profile='collaborator' OR installation_profile IS NULL) AND status IN ('approved','pending') AND notes NOT LIKE 'DESVINCULADO|%' AND notes NOT LIKE 'TRANSFERIDO|%' ORDER BY machine_name,id");$q->execute([$account,$network,$id]);$devices=$q->fetchAll(PDO::FETCH_ASSOC);
        foreach($devices as &$device){$device['id']=(int)$device['id'];$device['online']=$device['status']==='approved'&&!empty($device['last_seen_at'])&&strtotime((string)$device['last_seen_at'])>=time()-arc_inventory_presence_seconds();}unset($device);
        return ['ok'=>true,'self_id'=>$id,'network_id'=>$network,'devices'=>$devices,'poll_seconds'=>max(3,min(120,max((int)arc_platform_setting($pdo,'platform_tool_min_interval','5'),(int)arc_platform_setting($pdo,'platform_tool_refresh_default','15'))))];
    }
    $profile=arc_gt_profile($pdo,$gestor);
    if($profile['role']!=='server'&&$op!=='info'){
        $required=match(true){$op==='dashboard'=>['panel'], $op==='connection-map'=>['speed'], str_starts_with($op,'schedule-')=>['agenda','support'], str_starts_with($op,'service-')||str_starts_with($op,'support-')=>['support'], str_starts_with($op,'ticket')=>['tickets','support'], default=>[]};
        if(!array_intersect($required,$profile['ui']['menus']))throw new DomainException('Esta área local não foi liberada para o Colaborador.',403);
    }
    if($op==='info'){
        $logo='';$file=(string)($net['logo_file']??'');
        if(preg_match('/^[a-f0-9]{40}\.(png|jpg|webp)$/D',$file)){
            $path=ARC_PRIVATE_DIR.'/storage/network-logos/'.$file;
            if(is_file($path)&&!is_link($path)&&filesize($path)<=2097152){
                $bytes=file_get_contents($path);$image=@getimagesizefromstring($bytes===false?'':$bytes);
                if($bytes!==false&&$image&&in_array($image[2],[IMAGETYPE_PNG,IMAGETYPE_JPEG,IMAGETYPE_WEBP],true))$logo=base64_encode($bytes);
            }
        }
        return ['ok'=>true,'network_id'=>$network,'gestor_id'=>$id,'network_name'=>(string)$net['name'],'logo_base64'=>$logo,'installation'=>arc_gt_profile($pdo,$gestor)];
    }
    if($op==='dashboard'){
        require_once __DIR__.'/network-inventory.php';
        arc_gt_require($pdo,$gestor,'inventory');$profile=arc_gt_profile($pdo,$gestor);
        return ['ok'=>true,'name'=>(string)$net['name']]+($profile['confirmed']&&$profile['role']==='collaborator'?arc_gt_local_dashboard($pdo,$gestor):arc_inventory_dashboard($pdo,$account,$network));
    }
    if($op==='connection-map'){
        $points=[];
        try{$q=$pdo->prepare('SELECT kind,gestor_id,latitude,longitude,accuracy_m,source,updated_at FROM '.arc_table('network_geo_points').' WHERE network_id=? AND account_id=? AND (gestor_id=0 OR gestor_id=?) ORDER BY updated_at DESC');$q->execute([$network,$account,$id]);foreach($q->fetchAll(PDO::FETCH_ASSOC) as $point)if(!isset($points[$point['kind']]))$points[$point['kind']]=$point;}catch(PDOException $e){/* Sem ponto confirmado: a interface informa a ausência. */}
        return ['ok'=>true,'network_name'=>(string)$net['name'],'address'=>(string)($net['address']??''),'points'=>$points];
    }
    // Suporte, Chamados e Agenda: mesmas regras, tabelas e funções da plataforma (includes/support.php), limitadas a este computador.
    if(str_starts_with($op,'ticket')||str_starts_with($op,'schedule-')||str_starts_with($op,'support-')||str_starts_with($op,'service-')){
        require_once __DIR__.'/support.php';
        arc_gt_require($pdo,$gestor,'support');
        $states=arc_support_ticket_states();$priorities=arc_support_ticket_priorities();
        if($op==='support-services')return ['ok'=>true,'services'=>arc_support_schedule_actions()];
        if($op==='service-run'){
            $command=(string)($body['command']??'');arc_gt_require($pdo,$gestor,arc_gt_command_capability($command));if(!isset(arc_support_schedule_actions()[$command]))throw new InvalidArgumentException('Escolha um serviço da lista.');
            arc_billing_assert_active($pdo,$account);
            if(str_starts_with($command,'power_')&&!arc_support_confirm_password($pdo,$account,$body))throw new InvalidArgumentException('Confirme a ação e informe a senha da sua conta.');
            $q=$pdo->prepare('SELECT gestor_version FROM '.arc_table('network_gestores').' WHERE id=? AND network_id=? AND account_id=?');$q->execute([$id,$network,$account]);$version=(string)$q->fetchColumn();
            if($command==='windows_update'&&version_compare($version,'3.7.1','<'))throw new DomainException('Atualize o gestor antes de verificar o Windows Update.',422);
            if(str_starts_with($command,'power_')&&version_compare($version,'3.2.0','<'))throw new DomainException('Atualize o gestor antes de usar o controle de energia.',422);
            $q=$pdo->prepare('SELECT id FROM '.arc_table('gestor_commands').' WHERE gestor_id=? AND command_name=? AND ((status=\'pending\' AND created_at>DATE_SUB(NOW(),INTERVAL 3 MINUTE)) OR (status=\'running\' AND dispatched_at>DATE_SUB(NOW(),INTERVAL 45 MINUTE))) ORDER BY id DESC LIMIT 1');$q->execute([$id,$command]);$open=$q->fetchColumn();
            if($open)return ['ok'=>true,'command_id'=>(int)$open,'already_queued'=>true];
            $q=$pdo->prepare('SELECT COUNT(*) FROM '.arc_table('gestor_commands').' WHERE gestor_id=? AND status IN (\'pending\',\'running\')');$q->execute([$id]);if((int)$q->fetchColumn()>=100)throw new DomainException('Limite de 100 comandos pendentes neste gestor.',429);
            $options=str_starts_with($command,'power_')?['delay_seconds'=>5]:($command==='gestor_update'?['mode'=>'normal']:[]);
            $pdo->beginTransaction();try{$command_id=arc_support_queue_service($pdo,$account,$network,$id,$command,$account,$options);$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
            arc_user_audit($pdo,'gestor_command_queued','Comando '.$command.' solicitado no gestor '.$id.' da rede '.$network,$account);
            return ['ok'=>true,'command_id'=>$command_id,'status'=>'pending'];
        }
        if(str_starts_with($op,'schedule-')){
            $v=array_diff_key($body,array_flip(['site_code','machine_hash','op','action']));$v['network_id']=$network;$v['gestor_id']=$id;
            try{return arc_support_schedule_run($pdo,$op,$v,$account);}catch(RuntimeException $e){throw new DomainException($e->getMessage(),422);}
        }
        if($op==='ticket-create'){
            $title=trim((string)($body['title']??''));$description=trim((string)($body['description']??''));$priority=(string)($body['priority']??'normal');
            if($title===''||mb_strlen($title)>160||$description===''||mb_strlen($description)>12000||!isset($priorities[$priority]))throw new InvalidArgumentException('Informe título, descrição e prioridade válidos.');
            arc_billing_assert_active($pdo,$account);
            $q=$pdo->prepare('SELECT COUNT(*) FROM '.arc_table('support_tickets').' WHERE account_id=? AND network_id=? AND gestor_id=? AND created_at>?');
            $q->execute([$account,$network,$id,date('Y-m-d H:i:s',time()-600)]);
            if((int)$q->fetchColumn()>=5)throw new DomainException('Aguarde antes de abrir outro chamado neste computador.',429);
            $ticket=arc_support_ticket_create($pdo,$account,$network,$id,$account,$title,"Origem: gestor Windows #".$id."\n\n".$description,$priority,'gestor_created','Chamado aberto no gestor Windows #'.$id);
            return ['ok'=>true,'ticket_id'=>$ticket];
        }
        if($op==='tickets'){
            $list=arc_support_ticket_list($pdo,$account,$network,(string)($body['status']??'active'),(string)($body['q']??''),(int)($body['page']??1),$id);
            foreach($list['tickets'] as &$row){$row['status_label']=$states[$row['status']]??$row['status'];$row['priority_label']=$priorities[$row['priority']]??$row['priority'];$row['overdue']=strtotime((string)$row['due_at'])<time()&&!in_array($row['status'],['resolved','cancelled'],true);}unset($row);
            return ['ok'=>true]+$list+['states'=>$states,'priorities'=>$priorities];
        }
        if($op==='ticket-detail'){
            $detail=arc_support_ticket_detail($pdo,$account,$network,(int)($body['ticket_id']??0),$id);if(!$detail)throw new DomainException('Chamado não encontrado neste computador.',404);
            $detail['ticket']['status_label']=$states[$detail['ticket']['status']]??$detail['ticket']['status'];$detail['ticket']['priority_label']=$priorities[$detail['ticket']['priority']]??$detail['ticket']['priority'];
            return ['ok'=>true]+$detail;
        }
        if($op==='ticket-note'){
            $ticket=(int)($body['ticket_id']??0);$message=trim((string)($body['message']??''));if($message===''||mb_strlen($message)>12000)throw new InvalidArgumentException('Escreva uma anotação válida.');
            $detail=arc_support_ticket_detail($pdo,$account,$network,$ticket,$id);if(!$detail)throw new DomainException('Chamado não encontrado neste computador.',404);
            if(in_array($detail['ticket']['status'],['resolved','cancelled'],true))throw new InvalidArgumentException('Este chamado está encerrado. Abra um novo chamado.');
            $pdo->beginTransaction();try{arc_support_event($pdo,$ticket,$account,'gestor_note',$message);$pdo->prepare('UPDATE '.arc_table('support_tickets').' SET updated_at=NOW() WHERE id=?')->execute([$ticket]);$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
            return ['ok'=>true];
        }
    }
    throw new InvalidArgumentException('Ação não permitida.');
}

/** Interface nativa: usa a sessão assinada do usuário e as permissões oficiais da rede em cada chamada. */
function arc_gestor_management(PDO $pdo,array $gestor,array $body): array {
    require_once __DIR__.'/gestor-local-ui.php';
    $user=arc_gu_token_user((string)($body['user_token']??''),(int)$gestor['id']);
    if($user<=0)throw new DomainException('Entre na sua conta no Gestor para acessar esta área.',403);
    $q=$pdo->prepare('SELECT id FROM '.arc_table('user_accounts')." WHERE id=? AND account_status='active'");$q->execute([$user]);
    if(!$q->fetchColumn())throw new DomainException('Conta indisponível.',403);
    $network=(int)($body['view_network']??$gestor['network_id']);
    $key=(string)($body['page']??'dashboard');
    if(!in_array($key,['dashboard','users','permissions','preferences','reports','registry_cad','release'],true))throw new InvalidArgumentException('Área inválida.');
    $access=null;foreach(arc_gu_networks($pdo,$user) as $candidate)if($candidate['id']===$network)$access=$candidate;
    if(!$access||(!$access['full']&&!in_array($key,$access['menus'],true)))throw new DomainException('Seu perfil não tem acesso a esta área.',403);
    if(!arc_gt_local_menu_allowed($pdo,$gestor,[$key]))throw new DomainException('Área não liberada para esta instalação.',403);
    $q=$pdo->prepare('SELECT * FROM '.arc_table('managed_networks').' WHERE id=? AND is_active=1');$q->execute([$network]);$net=$q->fetch(PDO::FETCH_ASSOC);
    if(!$net)throw new DomainException('Rede indisponível.',404);
    $account=(int)$net['account_id'];$write=$user===$account; // Mesma restrição das telas online.
    $action=(string)($body['operation']??'read');$fields=[];$rows=[];
    $registry=['name'=>['Nome da rede',100],'client_name'=>['Cliente / empresa',160],'contact_name'=>['Responsável',160],'contact_phone'=>['Telefone',40],'address'=>['Endereço',255],'notes'=>['Observações',5000],
      'doc_number'=>['CPF/CNPJ',18],'trade_name'=>['Nome fantasia',160],'company_email'=>['E-mail',160],'zip_code'=>['CEP',10],'state_code'=>['UF',2],'city_name'=>['Cidade',100],'street_name'=>['Logradouro',160],'street_number'=>['Número',20],'address_extra'=>['Complemento',100],'district_name'=>['Bairro',100],'registration_status'=>['Situação cadastral',100],'main_activity'=>['Atividade principal',160],'legal_nature'=>['Natureza jurídica',160],'opening_date'=>['Data de abertura',30]];
    $prefs=['monitor_refresh'=>['Atualização do monitor',['instant','1','5','10','15','30','60']], 'alert_latency'=>['Latência de alerta',['80','100','150','200','300']], 'alert_low_speed'=>['Alertar baixa velocidade',['0','1']], 'email_alerts'=>['Alertas por e-mail',['0','1']], 'alert_min_download_mbps'=>['Download mínimo (Mbps)',[]], 'alert_speed_interval_minutes'=>['Intervalo de medição (minutos)',['15','30','60','180','360','720','1440']]];
    if($action!=='read'){
        if(!$write)throw new DomainException('Operação restrita ao titular da rede.',403);
        $values=$body['values']??[];if(!is_array($values))throw new InvalidArgumentException('Valores inválidos.');
        if($action==='save'&&$key==='registry_cad'){
            $set=[];$args=[];foreach($registry as $field=>[$label,$max])if(array_key_exists($field,$values)){
                if(!is_string($values[$field])||mb_strlen($values[$field])>$max)throw new InvalidArgumentException('Valor inválido: '.$label);
                $v=trim($values[$field]);if($field==='name'&&$v==='')throw new InvalidArgumentException('Informe o nome da rede.');
                if($field==='company_email'&&$v!==''&&!filter_var($v,FILTER_VALIDATE_EMAIL))throw new InvalidArgumentException('E-mail inválido.');
                $set[]=$field.'=?';$args[]=$v;
            }
            if($set){$pdo->prepare('UPDATE '.arc_table('managed_networks').' SET '.implode(',',$set).' WHERE id=? AND account_id=?')->execute([...$args,$network,$account]);}
        }elseif($action==='save'&&$key==='preferences'){
            $checked=[];foreach($values as $field=>$value){
                if(!isset($prefs[$field])||!is_string($value))throw new InvalidArgumentException('Preferência inválida.');
                if($prefs[$field][1]&&!in_array($value,$prefs[$field][1],true))throw new InvalidArgumentException('Opção inválida.');
                if($field==='alert_min_download_mbps'&&(!ctype_digit($value)||(int)$value<1||(int)$value>100000))throw new InvalidArgumentException('Download deve estar entre 1 e 100000 Mbps.');
                $checked[$field]=$value;
            }
            $pdo->beginTransaction();try{
                $q=$pdo->prepare('INSERT INTO '.arc_table('network_user_preferences').' (account_id,network_id,preference_key,preference_value) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE preference_value=VALUES(preference_value)');
                foreach($checked as $field=>$value)$q->execute([$account,$network,$field,$value]);$pdo->commit();
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        }elseif($key==='users'&&$action==='member-save'){
            $email=trim((string)($values['email']??''));$role=(string)($values['role']??'viewer');
            if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new InvalidArgumentException('E-mail inválido.');
            $q=$pdo->prepare('SELECT id FROM '.arc_table('user_accounts')." WHERE email=? AND account_status='active'");$q->execute([$email]);$member=(int)$q->fetchColumn();
            if(!$member)throw new InvalidArgumentException('Usuário deve possuir conta ativa na plataforma.');
            $pdo->beginTransaction();try{
                arc_team_save($pdo,$account,$network,$member,$role);
                $pdo->prepare('UPDATE '.arc_table('network_team_members').' SET profile_id=NULL WHERE network_id=? AND account_id=? AND member_user_id=?')->execute([$network,$account,$member]);$pdo->commit();
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        }elseif($key==='users'&&$action==='member-toggle'){
            $member=(int)($values['id']??0);$enabled=(string)($values['enabled']??'');
            if(!in_array($enabled,['0','1'],true))throw new InvalidArgumentException('Estado inválido.');
            $pdo->beginTransaction();try{
                $q=$pdo->prepare('SELECT id FROM '.arc_table('user_accounts').' WHERE id=? FOR UPDATE');$q->execute([$account]);
                if($enabled==='1')arc_billing_enforce($pdo,$account,'seats');
                $pdo->prepare('UPDATE '.arc_table('network_team_members').' SET enabled=? WHERE id=? AND network_id=? AND account_id=?')->execute([(int)$enabled,$member,$network,$account]);$pdo->commit();
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        }elseif($key==='release'&&in_array($action,['approve','reject','lock'],true)){
            $device=(int)($values['id']??0);$pdo->beginTransaction();try{
                $q=$pdo->prepare('SELECT id FROM '.arc_table('user_accounts').' WHERE id=? FOR UPDATE');$q->execute([$account]);
                arc_gt_lock($pdo,$account,$network);
                $q=$pdo->prepare('SELECT * FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=? FOR UPDATE');$q->execute([$device,$account,$network]);$target=$q->fetch(PDO::FETCH_ASSOC);
                if(!$target)throw new InvalidArgumentException('Computador não encontrado.');
                if(str_starts_with((string)$target['notes'],'DESINSTALADO|')||str_starts_with((string)$target['notes'],'DESVINCULADO|')||str_starts_with((string)$target['notes'],'TRANSFERIDO|')||(string)$target['notes']==='Instalação revogada pelo gestor')throw new InvalidArgumentException('Instale e vincule novamente este computador.');
                if($action==='lock')$pdo->prepare('UPDATE '.arc_table('network_gestores')." SET ui_locked=1 WHERE id=? AND account_id=? AND network_id=? AND status='approved'")->execute([$device,$account,$network]);
                else{
                    if($action==='approve'&&$target['status']!=='approved')arc_billing_enforce($pdo,$account,'gestores');
                    $status=$action==='approve'?'approved':'rejected';
                    $pdo->prepare('UPDATE '.arc_table('network_gestores')." SET status=?,ui_locked=CASE WHEN ?='approved' THEN 0 ELSE ui_locked END,approved_at=CASE WHEN ?='approved' THEN CURRENT_TIMESTAMP ELSE approved_at END WHERE id=? AND account_id=? AND network_id=?")->execute([$status,$status,$status,$device,$account,$network]);
                    if($action==='approve'){arc_gestor_assign_profile($pdo,$network,$account,$device);arc_gt_approve_locked($pdo,$account,$network,$device);}
                }$pdo->commit();
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        }else throw new InvalidArgumentException('Operação indisponível nesta área.');
        arc_user_audit($pdo,'gestor_management_'.$action,'Rede '.$network.'; área '.$key,$user);
        return ['ok'=>true,'saved'=>true];
    }
    if($key==='registry_cad')foreach($registry as $field=>[$label,$max])$fields[]=['key'=>$field,'label'=>$label,'value'=>(string)($net[$field]??''),'max'=>$max,'options'=>[]];
    elseif($key==='preferences'){
        $q=$pdo->prepare('SELECT preference_key,preference_value FROM '.arc_table('network_user_preferences').' WHERE network_id=? AND account_id=?');$q->execute([$network,$account]);$stored=$q->fetchAll(PDO::FETCH_KEY_PAIR);
        foreach($prefs as $field=>[$label,$options])$fields[]=['key'=>$field,'label'=>$label,'value'=>(string)($stored[$field]??''),'max'=>20,'options'=>$options];
    }elseif(in_array($key,['users','permissions'],true)){
        if($key==='users'){$q=$pdo->prepare('SELECT m.id,u.display_name AS nome,u.email,m.role AS perfil,m.enabled FROM '.arc_table('network_team_members').' m JOIN '.arc_table('user_accounts').' u ON u.id=m.member_user_id WHERE m.network_id=? AND m.account_id=? ORDER BY u.display_name');}
        else{$q=$pdo->prepare('SELECT id,name AS nome,base_role AS perfil,permissions_json AS permissoes FROM '.arc_table('network_access_profiles').' WHERE network_id=? AND account_id=? ORDER BY name');}
        $q->execute([$network,$account]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
    }elseif($key==='release'){
        $q=$pdo->prepare('SELECT id,machine_name AS computador,status,installation_profile AS perfil,gestor_version AS versao,last_seen_at AS ultimo_contato,ui_locked FROM '.arc_table('network_gestores').' WHERE network_id=? AND account_id=? ORDER BY machine_name');$q->execute([$network,$account]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
    }elseif($key==='reports'){
        $q=$pdo->prepare('SELECT c.id,g.machine_name AS computador,c.command_name AS operacao,c.status,c.result_text AS resultado,c.created_at AS data FROM '.arc_table('gestor_commands').' c LEFT JOIN '.arc_table('network_gestores').' g ON g.id=c.gestor_id AND g.account_id=c.account_id AND g.network_id=c.network_id WHERE c.network_id=? AND c.account_id=? ORDER BY c.id DESC LIMIT 200');$q->execute([$network,$account]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
    }else{
        foreach(arc_gu_networks($pdo,$user) as $item){$q=$pdo->prepare('SELECT COUNT(*) AS total,COALESCE(SUM(last_seen_at>=DATE_SUB(NOW(),INTERVAL '.arc_inventory_presence_seconds().' SECOND)),0) AS online FROM '.arc_table('network_gestores')." WHERE network_id=? AND status='approved'");$q->execute([$item['id']]);$stats=$q->fetch(PDO::FETCH_ASSOC);$rows[]=['id'=>$item['id'],'rede'=>$item['name'],'perfil'=>$item['role'],'computadores'=>$stats['total'],'online'=>$stats['online']];}
    }
    return ['ok'=>true,'network_id'=>$network,'network_name'=>$net['name'],'can_write'=>$write,'fields'=>$fields,'rows'=>$rows];
}
