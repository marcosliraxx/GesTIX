<?php
/* Caminho: includes/releases.php */
declare(strict_types=1);
require_once __DIR__ . '/error-logging.php';


function arc_app_version(): string {
    $value=trim((string)@file_get_contents(dirname(__DIR__).'/VERSION'));
    if(!arc_release_valid_version($value))throw new RuntimeException('VERSION ausente ou inválido. Conclua a atualização da plataforma.');return $value;
}
/** Política de atualização remota: gestores anteriores ao WinUI 3 (< 5.0.0) não têm canal de migração e exigem reinstalação pelo download oficial.
 * Versões não identificáveis exigem diagnóstico, nunca liberação silenciosa de comandos sem autenticação.
 */
function arc_gestor_upgrade_policy(string $installed, string $published): array {
    $valid = static fn(string $v): bool => (bool)preg_match('/^\d+(?:\.\d+){1,4}$/D', $v);
    $known = $valid($installed);
    $migration = $known && $valid($published) && version_compare($published, '5.0.0', '>=')
        && version_compare($installed, '5.0.0', '<');
    return [
        'requires_reinstall' => !$known || $migration,
        'can_remote_update' => $known && !$migration,
        'migrate_native' => $migration,
        'message' => !$known
            ? 'A versao deste gestor nao foi identificada. Verifique se esta conectado e responde a comandos antes de atualizar.'
            : ($migration ? 'Esta versao do gestor e antiga e nao atualiza remotamente. Reinstale pelo download do gestor atual.' : ''),
    ];
}
/** Manifesto da release precompilada publicada (gestores/releases/<arch>/current/release.json), ou null. */
function arc_gestor_release_manifest(string $arch): ?array {
    static $cache=[];
    if(array_key_exists($arch,$cache))return $cache[$arch];
    $manifest=null;
    if(in_array($arch,['win-x64','win-arm64'],true)){
        $file=dirname(__DIR__).'/gestores/releases/'.$arch.'/current/release.json';
        if(is_file($file)&&is_readable($file)&&(int)@filesize($file)<=350000){
            $data=json_decode((string)@file_get_contents($file),true);
            if(is_array($data)&&($data['arch']??null)===$arch&&preg_match('/^\d+(?:\.\d+){1,4}$/D',(string)($data['version']??''))
                &&isset($data['files'])&&is_array($data['files'])&&isset($data['files']['Arcoll.WinUI3.exe']))$manifest=$data;
        }
    }
    return $cache[$arch]=$manifest;
}
/** 'precompiled' quando há binários publicados; 'source' quando o gestor ainda precisa compilar no computador. */
function arc_gestor_release_mode(): string {
    return (arc_gestor_release_manifest('win-x64')||arc_gestor_release_manifest('win-arm64'))?'precompiled':'source';
}
/** Versão oficial única: definida em Admin > Versão e persistida em /VERSION.
 * O manifesto Windows informa apenas se há binários instaláveis para essa versão.
 */
function arc_gestor_target_version(): string {
    return arc_app_version();
}
/** Melhor versão de binários realmente publicada (não é uma segunda versão oficial). */
function arc_gestor_published_binary_version(): ?string {
    $best=null;
    foreach (['win-x64','win-arm64'] as $arch) {
        $manifest=arc_gestor_release_manifest($arch);
        if($manifest && ($best===null || version_compare((string)$manifest['version'],$best,'>')))
            $best=(string)$manifest['version'];
    }
    return $best;
}
/** Configuração privada do monitor; o próprio monitor nunca inventaria este arquivo. */
function arc_release_policy_file(): string {return __DIR__.'/storage/releases/policy.json';}
function arc_release_default_policy(): array {
    return ['includes'=>['*'],'excludes'=>[],'widths'=>[1,1,3],'limits'=>[9,9,999]];
}
function arc_release_policy(): array {
    $default=arc_release_default_policy();
    $data=json_decode((string)@file_get_contents(arc_release_policy_file()),true);
    if(!is_array($data))return $default;
    foreach(['includes','excludes'] as $field){
        if(!isset($data[$field])||!is_array($data[$field]))$data[$field]=$default[$field];
        $data[$field]=array_values(array_unique(array_filter($data[$field],static fn($v)=>is_string($v)&&($v==='*'||(bool)preg_match('~^[a-zA-Z0-9_./-]{1,240}$~D',$v)))));
    }
    if(!$data['includes'])$data['includes']=[];
    foreach(['widths','limits'] as $field){
        if(!isset($data[$field])||!is_array($data[$field])||count($data[$field])<2||count($data[$field])>5)$data[$field]=$default[$field];
        $data[$field]=array_values(array_map('intval',$data[$field]));
    }
    if(count($data['widths'])!==count($data['limits'])){$data['widths']=$default['widths'];$data['limits']=$default['limits'];}
    return $data;
}
function arc_release_valid_version(string $version): bool {
    return (bool)preg_match('/^\d+(?:\.\d+){1,4}$/D',$version)&&strlen($version)<=32;
}
function arc_release_compare(string $left,string $right): int {
    $a=array_map('intval',explode('.',$left));$b=array_map('intval',explode('.',$right));
    for($i=0;$i<max(count($a),count($b));$i++){ $c=($a[$i]??0)<=>($b[$i]??0);if($c!==0)return $c; }
    return 0;
}
function arc_release_number_format(array $values,array $widths): string {
    return implode('.',array_map(static fn($i)=>str_pad((string)$values[$i],$widths[$i],'0',STR_PAD_LEFT),array_keys($widths)));
}
function arc_release_policy_validate(array $data,string $current): array {
    if(!isset($data['includes'],$data['excludes'],$data['widths'],$data['limits'])||!is_array($data['includes'])||!is_array($data['excludes'])||!is_array($data['widths'])||!is_array($data['limits']))throw new RuntimeException('Política de versão inválida.');
    $inventory=arc_release_inventory_paths();$allowed=array_fill_keys(array_merge($inventory['dirs'],$inventory['files']),true);
    foreach(['includes','excludes'] as $field){
        if(count($data[$field])>1500)throw new RuntimeException('Seleção excede o limite de 1.500 caminhos.');
        foreach($data[$field] as $path){if(!is_string($path)||($path!=='*'&&!isset($allowed[$path])))throw new RuntimeException('Caminho não permitido: '.substr((string)$path,0,100));}
        $data[$field]=array_values(array_unique($data[$field]));
    }
    if(count($data['widths'])<2||count($data['widths'])>5||count($data['widths'])!==count($data['limits']))throw new RuntimeException('Configure entre 2 e 5 casas de versão.');
    $values=array_map('intval',explode('.',$current));
    foreach($data['widths'] as $i=>$w){
        $limit=$data['limits'][$i];
        if(!is_int($w)||!is_int($limit))throw new RuntimeException('Largura ou limite inválido.');
        $w=(int)$w;$limit=(int)$limit;
        if($w<1||$w>5||$limit<1||$limit>99999||$limit>=10**$w)throw new RuntimeException('O limite de cada casa deve caber na largura configurada.');
        if(($values[$i]??0)>$limit)throw new RuntimeException('O limite da casa '.($i+1).' é menor que a versão atual.');
        $data['widths'][$i]=$w;$data['limits'][$i]=$limit;
    }
    if(count($values)>count($data['widths'])&&array_sum(array_slice($values,count($data['widths'])))!==0)throw new RuntimeException('Não é possível remover casas com valores diferentes de zero.');
    $formatted=arc_release_number_format(array_slice(array_pad($values,count($data['widths']),0),0,count($data['widths'])),$data['widths']);
    if(strlen($formatted)>32)throw new RuntimeException('A versão não pode ultrapassar 32 caracteres.');
    return $data;
}
function arc_release_save_policy(array $data): void {
    $path=arc_release_policy_file();
    $dir=dirname($path);
    if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Não foi possível criar a pasta privada de versões. Verifique permissões em includes/storage/releases.');
    if(!is_writable($dir))throw new RuntimeException('A pasta privada de versões não permite gravação. Verifique as permissões de includes/storage/releases.');
    $json=json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
    $temp=tempnam($dir,'.policy-');
    if($temp===false)throw new RuntimeException('Não foi possível preparar o arquivo de regras de versão.');
    try{
        $bytes=@file_put_contents($temp,$json,LOCK_EX);
        if($bytes===false||$bytes!==strlen($json))throw new RuntimeException('Falha ao gravar integralmente as regras de versão.');
        if(!@rename($temp,$path))throw new RuntimeException('Não foi possível concluir a gravação das regras de versão. Verifique as permissões do arquivo policy.json.');
        @chmod($path,0600);
        clearstatcache(true,$path);
        $check=@file_get_contents($path);
        if($check===false||!hash_equals(hash('sha256',$json),hash('sha256',$check)))throw new RuntimeException('As regras não foram confirmadas após a gravação.');
    }finally{if(is_file($temp))@unlink($temp);}
}
function arc_release_path_selected(string $path,array $policy): bool {
    $match=static function(string $needle,string $scope):bool{return $scope==='*'||$needle===$scope||str_starts_with($needle,rtrim($scope,'/').'/');};
    $included=false;foreach($policy['includes'] as $scope){if($match($path,$scope)){$included=true;break;}}
    if(!$included)return false;
    foreach($policy['excludes'] as $scope){if($match($path,$scope))return false;}
    return true;
}
/** Inventário de caminhos permitidos, sem hashes: usado na interface administrativa. */
function arc_release_inventory_paths(): array {
    $dirs=[];$files=[];
    arc_release_walk(dirname(__DIR__),static function($relative,$path)use(&$files):void{$files[]=$relative;},static function($relative)use(&$dirs):void{$dirs[]=$relative;});
    sort($dirs,SORT_STRING);sort($files,SORT_STRING);
    return ['dirs'=>$dirs,'files'=>$files];
}
function arc_release_skip(string $path): bool {
    // Binários precompilados do gestor ficam fora do inventário: são grandes e têm versão própria (release.json).
    $normalized=str_replace('\\','/',$path);
    if($normalized==='gestores/releases'||str_starts_with($normalized,'gestores/releases/'))return true;
    return (str_starts_with(basename($path),'.')&&basename($path)!=='.htaccess')||preg_match('~(?:^|/)(?:storage|uploads|backups|secrets|_sql|__pycache__|tests|scripts|docs|pacotes)(?:/|$)~',$path)||in_array(basename($path),['config.php','gestor-config.json','gestor.json','error_log','_manifest.json','VERSION'],true)||preg_match('/\.(?:log|pyc|zip|env|pem|key|pfx|tmp|updating)$/i',$path);
}
/** Percorre o inventário da plataforma uma única vez. $onFile recebe (caminho relativo, caminho absoluto); $onDir, o relativo de cada pasta. */
function arc_release_walk(string $root,callable $onFile,?callable $onDir=null): void {
    $count=0;
    foreach(new DirectoryIterator($root) as $top){
        if($top->isDot()||$top->isLink()||!$top->isDir()||arc_release_skip($top->getFilename()))continue;$folder=$top->getFilename();
        $walk=function(string $directory)use(&$walk,&$count,$root,$onFile,$onDir):void{
            foreach(new DirectoryIterator($directory) as $entry){if($entry->isDot()||$entry->isLink())continue;$relative=substr($entry->getPathname(),strlen($root)+1);if(arc_release_skip($relative))continue;
                if($entry->isDir()){if($onDir)$onDir($relative);$walk($entry->getPathname());}
                elseif($entry->isFile())$onFile($relative,$entry->getPathname());
                if(++$count>20000)throw new RuntimeException('Inventário excede o limite de segurança.');
            }
        };
        if($onDir)$onDir($folder);
        $walk($root.'/'.$folder);
    }
    foreach(glob($root.'/*')?:[] as $path)if(is_file($path)&&!is_link($path)&&preg_match('/\.(?:php|js|css|html|json)$/i',$path)&&!arc_release_skip(basename($path)))$onFile(basename($path),$path);
    if(is_file($root.'/.htaccess'))$onFile('.htaccess',$root.'/.htaccess');
}
function arc_release_code_manifest(?string $root=null): array {
    $files=[];$policy=arc_release_policy();
    arc_release_walk($root??dirname(__DIR__),static function(string $relative,string $path)use(&$files,$policy):void{
        if(!arc_release_path_selected($relative,$policy))return;
        $hash=hash_file('sha256',$path);if($hash===false)throw new RuntimeException('Não foi possível verificar um arquivo da plataforma.');$files[$relative]=$hash;
    },static function(string $relative)use(&$files,$policy):void{if(arc_release_path_selected($relative,$policy))$files[$relative.'/']='directory';});
    ksort($files,SORT_STRING);return $files;
}
/** Assinatura barata (caminho, tamanho e data) do inventário: só quando muda é preciso recalcular os SHA-256. */
function arc_release_stat_signature(?string $root=null): string {
    $lines=[];$policy=arc_release_policy();
    arc_release_walk($root??dirname(__DIR__),static function(string $relative,string $path)use(&$lines,$policy):void{
        if(!arc_release_path_selected($relative,$policy))return;
        clearstatcache(true,$path);$lines[]=$relative.'|'.(int)@filesize($path).'|'.(int)@filemtime($path);
    },static function(string $relative)use(&$lines,$policy):void{if(arc_release_path_selected($relative,$policy))$lines[]=$relative.'/';});
    sort($lines,SORT_STRING);return hash('sha256',implode("\n",$lines));
}
function arc_release_write_version(string $version): void {
    if(!arc_release_valid_version($version))throw new RuntimeException('Formato da versão inválido (2 a 5 casas).');
    $root=dirname(__DIR__);$temp=tempnam($root,'.release-');if($temp===false)throw new RuntimeException('A pasta raiz precisa permitir gravação para publicar a versão.');
    try{if(file_put_contents($temp,$version."\n",LOCK_EX)===false||!rename($temp,$root.'/VERSION'))throw new RuntimeException('Não foi possível atualizar VERSION. Confira as permissões.');chmod($root.'/VERSION',0644);}finally{if(is_file($temp))unlink($temp);}
}
function arc_release_next(string $version): string {
    $policy=arc_release_policy();$widths=$policy['widths'];$limits=$policy['limits'];
    $values=array_slice(array_pad(array_map('intval',explode('.',$version)),count($widths),0),0,count($widths));
    for($i=count($values)-1;$i>=0;$i--){
        if($values[$i]<$limits[$i]){$values[$i]++;return arc_release_number_format($values,$widths);}
        $values[$i]=0;
    }
    throw new RuntimeException('Todas as casas atingiram seus limites. Aumente o limite em Administração > Versão.');
}
function arc_release_sync(PDO $pdo,bool $force=false,?string $manualVersion=null,string $notes='',?int $admin=null): void {
    if(!$force&&(arc_config()['release_auto_detect']??true)===false)return;
    $directory=__DIR__.'/storage/releases';if(!is_dir($directory)&&!mkdir($directory,0700,true)&&!is_dir($directory))throw new RuntimeException('Armazenamento de versões indisponível.');
    $stateFile=$directory.'/scan.json';$scan=json_decode((string)@file_get_contents($stateFile),true)??[];
    if(!$force&&time()-(int)($scan['checked_at']??0)<5)return;
    /* Sem alteração nos arquivos (caminho, tamanho e data) não há o que recalcular: evita refazer todos os SHA-256 a cada intervalo. */
    $signature=arc_release_stat_signature();
    // O atalho por tamanho/mtime pode não detectar alterações do mesmo tamanho
    // gravadas no mesmo segundo. Revalida periodicamente os hashes completos.
    $signatureUnchanged=($scan['signature']??'')===$signature;
    $recentHashCheck=time()-(int)($scan['verified_at']??0)<60;
    if(!$force&&$signatureUnchanged&&$recentHashCheck&&is_file($directory.'/publish.lock')){
        $scan['checked_at']=time();
        @file_put_contents($stateFile,json_encode($scan,JSON_UNESCAPED_SLASHES),LOCK_EX);
        return;
    }
    $lock=fopen($directory.'/publish.lock','c+');if(!$lock||!flock($lock,LOCK_EX))return;
    try{
        $scan=json_decode((string)@file_get_contents($stateFile),true)??[];
        $manifest=arc_release_code_manifest();$hash=hash('sha256',json_encode($manifest,JSON_UNESCAPED_SLASHES));$version=arc_app_version();
        $q=$pdo->query('SELECT * FROM '.arc_table('platform_release_state').' WHERE id=1');$old=$q->fetch();
        $changed=$old&&(string)$old['fingerprint']!==$hash;
        // Publicação imediata: fingerprint diferente é uma alteração completa, sem espera adicional.
        // A versão publicada no banco prevalece quando o arquivo VERSION estiver atrasado.
        if($old&&arc_release_compare($version,(string)$old['version'])<0)$version=(string)$old['version'];
        if($manualVersion===null&&$changed&&$version===(string)$old['version']){
            $version=arc_release_next($version);
            $manualVersion=$version;
            $notes='Alterações de arquivos detectadas automaticamente.';
        }
        $publish=!$old||$manualVersion!==null||$version!==($old['version']??null);
        if($publish){
            $version=$manualVersion??$version;
            if($old&&$version!==$old['version']&&arc_release_compare($version,(string)$old['version'])<0)throw new RuntimeException('A nova versão precisa ser superior à publicada.');
            $previous=json_decode((string)($old['files_json']??'{}'),true)??[];$changes=['added'=>array_values(array_diff(array_keys($manifest),array_keys($previous))),'removed'=>array_values(array_diff(array_keys($previous),array_keys($manifest))),'modified'=>array_values(array_filter(array_keys(array_intersect_key($manifest,$previous)),static fn($key)=>$manifest[$key]!==$previous[$key]))];
            foreach($manifest as $path=>$digest)if(str_ends_with($path,'.php'))token_get_all((string)file_get_contents(dirname(__DIR__).'/'.$path),TOKEN_PARSE);
            $previousVersion=arc_app_version();$pdo->beginTransaction();try{
                $existing=$pdo->prepare('SELECT fingerprint FROM '.arc_table('platform_release_history').' WHERE version=?');$existing->execute([$version]);$known=$existing->fetchColumn();
                if($known!==false&&$known!==$hash)throw new RuntimeException('Esta versão já identifica outro conteúdo. Informe uma versão nova.');
                $pdo->prepare('INSERT INTO '.arc_table('platform_release_history').' (version,fingerprint,notes,source,created_by,files_count,changes_json) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE notes=VALUES(notes)')->execute([$version,$hash,$notes!==''?$notes:'Publicação centralizada da plataforma.',$admin?'manual':($old?'automatic':'initial'),$admin,count($manifest),json_encode($changes,JSON_UNESCAPED_SLASHES)]);
                $pdo->prepare('INSERT INTO '.arc_table('platform_release_state').' (id,version,fingerprint,files_json) VALUES (1,?,?,?) ON DUPLICATE KEY UPDATE version=VALUES(version),fingerprint=VALUES(fingerprint),files_json=VALUES(files_json)')->execute([$version,$hash,json_encode($manifest,JSON_UNESCAPED_SLASHES)]);
                if(arc_app_version()!==$version)arc_release_write_version($version);$pdo->commit();$scan=['checked_at'=>time(),'signature'=>$signature,'verified_at'=>time()];
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();if(arc_app_version()!==$previousVersion)arc_release_write_version($previousVersion);throw $e;}
        }
        // Recupera instalações em que VERSION ficou atrás do estado já publicado.
        if(!$publish&&$old&&arc_app_version()!==$version)arc_release_write_version($version);
        $scan=['checked_at'=>time(),'signature'=>$signature,'verified_at'=>time()];file_put_contents($stateFile,json_encode($scan),LOCK_EX);chmod($stateFile,0600);
    }catch(Throwable $e){if($force)throw $e;arc_log_error('Publicação automática: '.$e->getMessage());}finally{flock($lock,LOCK_UN);fclose($lock);}
}
function arc_release_require_published(): void {
    static $verified=false;
    if($verified)return;
    $row=arc_db()->query('SELECT version,fingerprint FROM '.arc_table('platform_release_state').' WHERE id=1')->fetch();
    // Caminho rápido: se nenhum arquivo mudou desde a última publicação (caminho, tamanho e data),
    // não recalcula o SHA-256 de toda a plataforma a cada consulta do modal/atualização.
    $scan=json_decode((string)@file_get_contents(__DIR__.'/storage/releases/scan.json'),true);
    if($row&&$row['version']===arc_app_version()&&is_array($scan)&&($scan['signature']??'')!==''&&hash_equals((string)$scan['signature'],arc_release_stat_signature())){$verified=true;return;}
    $hash=hash('sha256',json_encode(arc_release_code_manifest(),JSON_UNESCAPED_SLASHES));
    if(!$row||$row['version']!==arc_app_version()||!hash_equals($row['fingerprint'],$hash)){
        // Atualização remota: sincroniza o release antes de servir bytes autenticados.
        // Mantém a publicação transacional, inventário SHA-256 e validação de PHP.
        arc_release_sync(arc_db(),true);
        $row=arc_db()->query('SELECT version,fingerprint FROM '.arc_table('platform_release_state').' WHERE id=1')->fetch();
        $hash=hash('sha256',json_encode(arc_release_code_manifest(),JSON_UNESCAPED_SLASHES));
        if(!$row||$row['version']!==arc_app_version()||!hash_equals((string)$row['fingerprint'],$hash))
            throw new RuntimeException('Não foi possível publicar a atualização do gestor. Verifique as permissões da pasta raiz e os logs da plataforma.');
    }
    $verified=true;
}
function arc_release_metadata_source(): string {
    arc_release_require_published();$version=arc_app_version();$q=arc_db()->prepare('SELECT notes,fingerprint FROM '.arc_table('platform_release_history').' WHERE version=?');$q->execute([$version]);$row=$q->fetch()?:[];
    return "# Caminho: gestores/servidor/Arcoll.WinUI3/Worker/arcoll_release.py\n# Metadados da instalação, gerados da versão central publicada.\nVERSION = ".json_encode($version)."\nBUILD = ".json_encode($row['fingerprint']??'')."\nNOTES = ".json_encode($row['notes']??'',JSON_UNESCAPED_SLASHES)."\n";
}

/* ===== Armazenamento das releases binárias do Gestor (gestores/releases) =====
 * Política única: só a release ativa (current/release.json + current/release-files.zip) permanece.
 * Envios incompletos (.stage-*), versões arquivadas (.prev-*) e arquivos soltos (current/files) são removidos
 * somente depois de a release ativa ser conferida contra o manifesto. Parâmetros: Admin > Central de manutenção. */
function arc_gestor_release_root(): string { return dirname(__DIR__).'/gestores/releases'; }
function arc_gestor_release_arches(): array { return ['win-x64','win-arm64']; }
/** Arquivos e bytes de uma árvore, sem seguir links simbólicos. */
function arc_gestor_release_tree_stats(string $dir): array {
    $files=0;$bytes=0;
    if(!is_dir($dir)||is_link($dir))return ['files'=>0,'bytes'=>0];
    try{
        foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::LEAVES_ONLY) as $entry){
            if($entry->isLink()||!$entry->isFile())continue;
            $files++;$bytes+=(int)$entry->getSize();
        }
    }catch(Throwable $e){}
    return ['files'=>$files,'bytes'=>$bytes];
}
/** Verdadeiro se qualquer item da árvore foi alterado depois de $cutoff (envio ainda em andamento). Em dúvida, considera ativo. */
function arc_gestor_release_tree_active(string $dir,int $cutoff): bool {
    if((int)@filemtime($dir)>=$cutoff)return true;
    try{
        foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)) as $entry)
            if((int)$entry->getMTime()>=$cutoff)return true;
    }catch(Throwable $e){return true;}
    return false;
}
/** Remove uma pasta de release já identificada; recusa qualquer caminho fora de gestores/releases/<arq>/<pasta>. */
function arc_gestor_release_remove_tree(string $dir): array {
    $root=realpath(arc_gestor_release_root());$real=realpath($dir);
    if($root===false||$real===false||is_link($dir)||!str_starts_with($real.'/',$root.'/')||substr_count(substr($real,strlen($root)+1),'/')<1)
        throw new RuntimeException('Pasta de release fora da área permitida.');
    $files=0;$bytes=0;
    foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($real,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST) as $entry){
        $path=$entry->getPathname();
        if($entry->isLink()||$entry->isFile()){
            $size=$entry->isLink()?0:(int)$entry->getSize();
            if(!@unlink($path))throw new RuntimeException('Falha ao remover arquivo da release.');
            $files++;$bytes+=$size;
        }elseif($entry->isDir()&&!@rmdir($path))throw new RuntimeException('Falha ao remover pasta da release.');
    }
    if(!@rmdir($real))throw new RuntimeException('Falha ao remover pasta da release.');
    return ['files'=>$files,'bytes'=>$bytes];
}
/** Confere a release ativa. $deep calcula o SHA-256 de cada arquivo do ZIP; sem $deep confirma manifesto e presença das entradas. */
function arc_gestor_release_verify(string $arch,bool $deep=true): array {
    $dir=arc_gestor_release_root().'/'.$arch.'/current';$manifestFile=$dir.'/release.json';$archive=$dir.'/release-files.zip';
    if(!is_file($manifestFile)||!is_file($archive)||is_link($manifestFile)||is_link($archive))return ['ok'=>false,'message'=>'release ativa sem manifesto ou pacote compactado'];
    if((int)filesize($manifestFile)>350000)return ['ok'=>false,'message'=>'manifesto acima do limite'];
    $data=json_decode((string)file_get_contents($manifestFile),true);
    if(!is_array($data)||($data['arch']??'')!==$arch||!is_array($data['files']??null)||!isset($data['files']['Arcoll.WinUI3.exe']))return ['ok'=>false,'message'=>'manifesto inválido'];
    $zip=new ZipArchive();
    if($zip->open($archive,ZipArchive::RDONLY)!==true)return ['ok'=>false,'message'=>'pacote compactado ilegível'];
    try{
        foreach($data['files'] as $file=>$hash){
            if(!is_string($file)||!preg_match('~^[a-zA-Z0-9_()./+ -]+$~D',$file)||str_contains($file,'..')||str_starts_with($file,'/')||!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/Di',$hash))
                return ['ok'=>false,'message'=>'entrada insegura no manifesto'];
            if(!$deep){if($zip->statName('files/'.$file)===false)return ['ok'=>false,'message'=>'arquivo ausente no pacote: '.$file];continue;}
            $stream=$zip->getStream('files/'.$file);
            if($stream===false)return ['ok'=>false,'message'=>'arquivo ausente no pacote: '.$file];
            $context=hash_init('sha256');hash_update_stream($context,$stream);fclose($stream);
            if(!hash_equals(strtolower($hash),hash_final($context)))return ['ok'=>false,'message'=>'hash divergente: '.$file];
        }
    }finally{$zip->close();}
    return ['ok'=>true,'version'=>(string)($data['version']??''),'files'=>count($data['files'])];
}
/** Itens removíveis de uma arquitetura. $kinds: stage (envios incompletos), prev (arquivadas), loose (current/files). */
function arc_gestor_release_cleanup_arch(string $arch,bool $apply,int $cutoff,bool $deep,array $kinds,array &$report): void {
    $archDir=arc_gestor_release_root().'/'.$arch;
    if(!is_dir($archDir)||is_link($archDir))return;
    $targets=[];
    if(in_array('stage',$kinds,true))foreach(glob($archDir.'/.stage-*',GLOB_ONLYDIR)?:[] as $dir)
        if(preg_match('~/\.stage-[a-f0-9]{32}$~D',$dir)&&!is_link($dir)&&!arc_gestor_release_tree_active($dir,$cutoff))$targets[]=['path'=>$dir,'label'=>$arch.': envio incompleto'];
    $redundant=[];
    if(in_array('prev',$kinds,true))foreach(glob($archDir.'/.prev-*',GLOB_ONLYDIR)?:[] as $dir)
        if(preg_match('~/\.prev-\d{14}(?:-[a-f0-9]{6})?$~D',$dir)&&!is_link($dir))$redundant[]=['path'=>$dir,'label'=>$arch.': versão arquivada'];
    $loose=$archDir.'/current/files';
    if(in_array('loose',$kinds,true)&&is_dir($loose)&&!is_link($loose))$redundant[]=['path'=>$loose,'label'=>$arch.': arquivos soltos da release ativa'];
    if($redundant){
        $check=arc_gestor_release_verify($arch,$deep);
        if($check['ok'])$targets=array_merge($targets,$redundant);
        else $report['warnings'][]=$arch.': release ativa não verificada ('.$check['message'].'); versões arquivadas e arquivos soltos foram preservados.';
    }
    foreach($targets as $target){
        $stats=arc_gestor_release_tree_stats($target['path']);
        $report['eligible']++;$report['bytes_eligible']+=$stats['bytes'];$report['items'][]=$target['label'].' ('.$stats['files'].' arquivos)';
        if(!$apply)continue;
        try{$done=arc_gestor_release_remove_tree($target['path']);$report['deleted']++;$report['bytes_deleted']+=$done['bytes'];}
        catch(Throwable $e){$report['warnings'][]=$target['label'].': '.$e->getMessage();arc_log_error('Limpeza de releases: '.$e->getMessage());}
    }
}
/** Verifica e limpa gestores/releases. Simulação por padrão; um bloqueio impede concorrência com a publicação. */
function arc_gestor_release_cleanup(bool $apply=false,int $stageHours=6,array $kinds=['stage','prev','loose']): array {
    $report=['eligible'=>0,'deleted'=>0,'bytes_eligible'=>0,'bytes_deleted'=>0,'bytes_total'=>0,'items'=>[],'warnings'=>[]];
    $root=arc_gestor_release_root();
    if(!is_dir($root)||is_link($root))return $report;
    $lock=@fopen($root.'/.lock','c');
    if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){if($lock)fclose($lock);$report['warnings'][]='Publicação de release em andamento; tente novamente em instantes.';return $report;}
    try{
        $cutoff=time()-max(1,$stageHours)*3600;
        foreach(arc_gestor_release_arches() as $arch){
            $report['bytes_total']+=arc_gestor_release_tree_stats($root.'/'.$arch)['bytes'];
            arc_gestor_release_cleanup_arch($arch,$apply,$cutoff,true,$kinds,$report);
        }
    }finally{flock($lock,LOCK_UN);fclose($lock);}
    return $report;
}
/** Resumo textual para o painel administrativo. */
function arc_gestor_release_summary(array $report,bool $applied): string {
    $mb=static fn(int $b):string=>number_format($b/1048576,1,',','.').' MB';
    $text=$applied
        ?$report['deleted'].' de '.$report['eligible'].' item(ns) removido(s); '.$mb($report['bytes_deleted']).' liberados.'
        :'Simulação: '.$report['eligible'].' item(ns) removível(is), '.$mb($report['bytes_eligible']).' a liberar.';
    $text.=' Pasta de releases: '.$mb($report['bytes_total']).($applied?' antes da limpeza.':'.');
    if($report['items'])$text.=' Itens: '.implode('; ',array_slice($report['items'],0,6)).'.';
    if($report['warnings'])$text.=' Avisos: '.implode(' ',$report['warnings']);
    return $text;
}

/** Assinatura do pacote no mesmo canal de publicação; a chave privada nunca entra em ZIPs ou respostas. */
function arc_gestor_signing_material(): array {
 static $material=null;if($material!==null)return $material;
 if(!function_exists('openssl_pkey_new'))throw new RuntimeException('OpenSSL é necessário para assinar as atualizações.');
 $directory=__DIR__.'/storage/releases';if(!is_dir($directory)&&!mkdir($directory,0700,true)&&!is_dir($directory))throw new RuntimeException('Armazenamento de assinaturas indisponível.');
 if(is_link($directory))throw new RuntimeException('Armazenamento de assinaturas inválido.');
 $lock=fopen($directory.'/gestor-signing.lock','c');if(!$lock||!flock($lock,LOCK_EX))throw new RuntimeException('Não foi possível proteger a assinatura da publicação.');
 try{
  $path=$directory.'/gestor-signing.pem';if(is_link($path))throw new RuntimeException('Chave de assinatura inválida.');
  if(!is_file($path)){
   $key=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_RSA,'private_key_bits'=>3072]);if(!$key||!openssl_pkey_export($key,$private))throw new RuntimeException('Não foi possível gerar a identidade de assinatura.');
   $temporary=tempnam($directory,'sign-');if($temporary===false)throw new RuntimeException('Arquivo de assinatura indisponível.');chmod($temporary,0600);
   if(file_put_contents($temporary,$private,LOCK_EX)!==strlen($private)||!rename($temporary,$path)){@unlink($temporary);throw new RuntimeException('Não foi possível preservar a identidade de assinatura.');}
  }
  if(filesize($path)>16384)throw new RuntimeException('Chave de assinatura acima do limite.');
  $private=openssl_pkey_get_private((string)file_get_contents($path));$details=$private?openssl_pkey_get_details($private):false;
  if(!$private||!$details||($details['type']??null)!==OPENSSL_KEYTYPE_RSA||($details['bits']??0)<2048)throw new RuntimeException('Identidade de assinatura inválida.');
  return $material=['private'=>$private,'public'=>(string)$details['key'],'id'=>hash('sha256',(string)$details['key'])];
 }finally{flock($lock,LOCK_UN);fclose($lock);}
}
function arc_gestor_sign_package(string $version,string $hash): array {
 if(!preg_match('/^[a-f0-9]{64}$/D',$hash))throw new InvalidArgumentException('Hash de pacote inválido.');
 $key=arc_gestor_signing_material();if(!openssl_sign($version."\n".$hash,$signature,$key['private'],OPENSSL_ALGO_SHA256))throw new RuntimeException('Assinatura da publicação indisponível.');
 return ['signature'=>base64_encode($signature),'public_key'=>base64_encode($key['public']),'key_id'=>$key['id']];
}
function arc_gestor_signature_headers(string $version,string $hash): void {
 $signed=arc_gestor_sign_package($version,$hash);header('X-Package-Signature: '.$signed['signature']);header('X-Package-Public-Key: '.$signed['public_key']);header('X-Package-Key-Id: '.$signed['key_id']);
}

/** Identidade do código compilável, independente dos recursos e da versão da plataforma. */
function arc_gestor_native_source_hash(): string {
    $root=dirname(__DIR__).'/gestores/servidor/Arcoll.WinUI3';$files=[];
    $walk=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
    foreach($walk as $file){
        if(!$file->isFile()||$file->isLink())continue;
        $rel=str_replace('\\','/',substr($file->getPathname(),strlen($root)+1));
        if(preg_match('~(?:^|/)(?:bin|obj)/~',$rel)||!preg_match('/\.(?:cs|xaml|csproj|manifest)$/D',$rel))continue;
        $hash=hash_file('sha256',$file->getPathname());if($hash===false)throw new RuntimeException('Falha ao conferir código nativo.');$files[$rel]=$hash;
    }
    if(!$files)throw new RuntimeException('Código nativo ausente.');ksort($files,SORT_STRING);
    return hash('sha256',json_encode($files,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));
}
