<?php
/* Caminho: includes/gestor-local-ui.php — visibilidade local administrada; capacidades do agente permanecem separadas. */
declare(strict_types=1);
require_once __DIR__.'/workspace-menu.php';
function arc_gt_menu_catalog(): array {
 $items=[];foreach(arc_workspace_menu()['groups'] as $group)foreach($group['items'] as $item)$items[$item['key']]=$item;return $items;
}
function arc_gt_menu_capability(string $key): string {
 if(str_starts_with($key,'backup'))return 'backup';
 if(in_array($key,['files','remote','support','tickets','agenda'],true))return 'support';
 if(in_array($key,['updates','history','windows_update'],true))return 'updates';
 if(in_array($key,['dashboard','panel','server','speed','devices','map','users','permissions','preferences','reports','registry_cad','release'],true))return 'inventory';
 return 'maintenance';
}
function arc_gt_local_ui(PDO $pdo,array $g,string $role,array $profile): array {
 $known=arc_gt_menu_catalog();if($role==='server')return ['menus'=>array_keys($known),'background'=>false];
 $prefix='gestor_ui_'.(int)$g['id'].'_';$q=$pdo->prepare('SELECT preference_key,preference_value FROM '.arc_table('network_user_preferences')." WHERE account_id=? AND network_id=? AND preference_key LIKE ? ESCAPE '|'");$q->execute([$g['account_id'],$g['network_id'],str_replace(['|','_','%'],['||','|_','|%'],$prefix).'%']);$enabled=[];$initialized=false;
 foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row){$name=(string)$row['preference_key'];if(!str_starts_with($name,$prefix))continue;$key=substr($name,strlen($prefix));if($key==='initialized'){$initialized=true;continue;}if(isset($known[$key])&&(string)$row['preference_value']==='1')$enabled[]=$key;}
 return ['menus'=>$initialized?array_values(array_intersect(array_keys($known),$enabled)):['remote'],'background'=>!empty($profile['background'])];
}
function arc_gt_save_local_ui(PDO $pdo,int $account,int $network,int $id,array $menus): void {
 // Caminho: includes/gestor-local-ui.php — persistência atômica do catálogo em UMA única instrução SQL.
 // Cada menu do catálogo é gravado explicitamente (1 = liberado, 0 = bloqueado). Não há UPDATE ... LIKE:
 // o "_" é curinga no LIKE e o prefixo gestor_ui_2_ alcançava também as chaves do computador 21, 22...
 $known=arc_gt_menu_catalog();if(count($menus)>count($known))throw new InvalidArgumentException('Quantidade de menus inválida.');
 foreach($menus as $key)if(!is_string($key)||!isset($known[$key]))throw new InvalidArgumentException('Menu não reconhecido.');
 $enabled=array_fill_keys(array_map('strval',$menus),true);$prefix='gestor_ui_'.$id.'_';
 $rows=[[$account,$network,$prefix.'initialized','1']];
 foreach(array_keys($known) as $key){
   $name=$prefix.$key;if(strlen($name)>80)throw new InvalidArgumentException('Identificador de menu acima do limite.');
   $rows[]=[$account,$network,$name,isset($enabled[$key])?'1':'0'];
 }
 $placeholders=implode(',',array_fill(0,count($rows),'(?,?,?,?)'));$params=[];
 foreach($rows as $row)array_push($params,...$row);
 $pdo->prepare('INSERT INTO '.arc_table('network_user_preferences').' (account_id,network_id,preference_key,preference_value) VALUES '.$placeholders.' ON DUPLICATE KEY UPDATE preference_value=VALUES(preference_value)')->execute($params);
}
function arc_gt_local_menu_allowed(PDO $pdo,array $g,array $menus): bool {
 $p=arc_gt_profile($pdo,$g);if($p['revoked'])return false;if($p['role']==='server')return true;
 return (bool)array_intersect($menus,$p['ui']['menus']);
}
function arc_gt_assert_local_action(PDO $pdo,array $g,string $action,array $body): void {
 if($action==='gestor-pentefino-local-settings'&&!empty($body['save']))$menus=['health','options'];
 elseif($action==='gestor-terminal-local-start')$menus=['server'];
 elseif($action==='gestor-device-save')$menus=['devices','map'];
 elseif($action==='gestor-menu-favorites'&&($body['operation']??'read')!=='read')$menus=array_keys(arc_gt_menu_catalog());
 else return;
 if(!arc_gt_local_menu_allowed($pdo,$g,$menus))throw new RuntimeException('Esta ação local não foi liberada para o Colaborador.',403);
}

/* Sessão de usuário do Gestor instalado: token assinado, curto, preso à instalação; nenhuma senha fica na máquina. */
function arc_gu_ttl(PDO $pdo): int { return max(5,min(1440,(int)arc_platform_setting($pdo,'platform_gestor_session_minutes','480')))*60; }
function arc_gu_sign(string $payload): string { return hash_hmac('sha256',$payload,(string)(arc_config()['app_secret']??'arcoll').'|gestor-user'); }
function arc_gu_token_make(PDO $pdo,int $user,int $gestorId): array {
 $exp=time()+arc_gu_ttl($pdo);$payload=$user.'.'.$gestorId.'.'.$exp.'.'.bin2hex(random_bytes(8));
 return ['token'=>rtrim(strtr(base64_encode($payload),'+/','-_'),'=').'.'.arc_gu_sign($payload),'expires'=>$exp];
}
function arc_gu_token_user(string $token,int $gestorId): int {
 $parts=explode('.',$token);if(count($parts)!==2)return 0;$payload=base64_decode(strtr($parts[0],'-_','+/'),true);
 if(!is_string($payload)||!hash_equals(arc_gu_sign($payload),$parts[1]))return 0;
 $f=explode('.',$payload);if(count($f)!==4||(int)$f[1]!==$gestorId||(int)$f[2]<time())return 0;return (int)$f[0];
}
/** Direitos do perfil de acesso (chaves da plataforma) -> menus do Gestor instalado. */
function arc_gu_menus(array $rights): array {
 $map=['programas'=>['programs'],'pentefino'=>['pentefino','health','startup','performance','restore','uninstall','updater','drivers','windows_update','disk','duplicates','security'],'backup'=>['backup_files'],'painel'=>['dashboard','panel'],'servidor'=>['server'],'velocidade'=>['speed'],'dispositivos'=>['devices'],'mapa'=>['map'],'remoto'=>['remote'],'suporte'=>['support','helpdesk'],'arquivos'=>['files'],'chamados'=>['tickets'],'agenda'=>['agenda'],'relatorios'=>['reports','history'],'liberacao'=>['release'],'usuarios'=>['users'],'preferencias'=>['preferences'],'cadastros'=>['registry_cad'],'permissoes'=>['permissions']];
 $menus=['home'];foreach($rights as $r)foreach($map[$r]??[] as $m)$menus[]=$m;return array_values(array_unique($menus));
}
/** Redes a que o usuário tem acesso (titular ou membro habilitado) com papel e menus efetivos. */
function arc_gu_networks(PDO $pdo,int $user): array {
 $q=$pdo->prepare('SELECT n.id,n.name FROM '.arc_table('managed_networks').' n WHERE n.is_active=1 AND (n.account_id=? OR EXISTS (SELECT 1 FROM '.arc_table('network_team_members').' m WHERE m.network_id=n.id AND m.account_id=n.account_id AND m.member_user_id=? AND m.enabled=1)) ORDER BY n.name,n.id');
 $q->execute([$user,$user]);$out=[];
 foreach($q->fetchAll(PDO::FETCH_ASSOC) as $n){
  $access=arc_network_team_access($pdo,(int)$n['id'],$user);if(!$access)continue;
  $full=in_array($access['role'],['owner','administrator','system_admin'],true);
  $rights=$full?null:arc_network_profile_rights($pdo,(int)$n['id'],$user);
  $out[]=['id'=>(int)$n['id'],'name'=>(string)$n['name'],'role'=>$access['role'],'full'=>$full,'menus'=>$full?array_keys(arc_gt_menu_catalog()):arc_gu_menus($rights??[])];
 }
 return $out;
}
