<?php
// Caminho: api/download-gestor.php
// Instalador e desinstalador sao universais (sem rede registrada); o vinculo ocorre depois, por codigo, em redes/liberacao.php.
// O catalogo do Pente-Fino exclui Registros, removido da plataforma e do Gestor.
// Manter os geradores de pacote fonte e release binaria com o mesmo contrato.
declare(strict_types=1);
require_once __DIR__ . '/../includes/error-logging.php';


if (!is_file(__DIR__ . '/../includes/config.php')) {
    http_response_code(503);
    exit('Sistema não configurado.');
}
require __DIR__ . '/../includes/bootstrap.php';

function arc_gestor_published_version(): string {
    return arc_app_version();
}

/** Endereço HTTPS público da plataforma, usado pelo instalador e pelos scripts de instalação. */
function arc_gestor_https_origin(): string {
    $origin = arc_base_url();
    if (!preg_match('~^https://~i', $origin)) {
        $host = (string)($_SERVER['HTTP_HOST'] ?? '');
        if ($host === '' || preg_match('/[^a-zA-Z0-9.:-]/', $host)) {
            throw new RuntimeException('Não foi possível determinar o endereço HTTPS do sistema.');
        }
        $origin = 'https://' . $host . rtrim(str_replace('\\', '/', dirname(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/api/download-gestor.php')))), '/');
        if ($origin === 'https:') $origin = 'https://' . $host;
    }
    return rtrim($origin, '/');
}

try {
    $pdo = arc_db();
    arc_ensure_user_schema($pdo);
    $requestedMode = (string)($_GET['mode'] ?? '');
    // Distribuicao WinUI 3: projeto-fonte unico em gestores/servidor (motores Python em Arcoll.WinUI3/Worker).
    // O formato interno Arcoll.WinUI3/ do ZIP e mantido para nao quebrar instaladores e atualizadores existentes.
    // Um unico Gestor universal, com perfis e permissoes definidos pela plataforma.
    $nativeRoot = realpath(__DIR__ . '/../gestores/servidor/Arcoll.WinUI3');
    if ($nativeRoot === false || !is_file($nativeRoot . '/Arcoll.WinUI3.csproj') || !is_file($nativeRoot . '/INSTALAR_WINUI3.ps1')) {
        throw new RuntimeException('Projeto nativo WinUI 3 indisponivel no servidor.');
    }
    $nativeOrigin = arc_gestor_https_origin();
    if (!preg_match('~^https://[a-z0-9.:-]+(?:/|$)~i', $nativeOrigin)) throw new RuntimeException('Origem HTTPS invalida.');
    $nativeCheck = static function (PDO $db, string $token): array {
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) { http_response_code(403); exit('Token invalido.'); }
        $query = $db->prepare('SELECT k.network_id,k.account_id,k.site_code FROM ' . arc_table('gestor_download_keys') . ' k INNER JOIN ' . arc_table('managed_networks') . ' n ON n.id=k.network_id AND n.account_id=k.account_id WHERE k.token_hash=? AND k.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) AND k.fingerprint IS NULL AND n.is_active=1 AND n.monitoring_enabled=1 LIMIT 1');
        $query->execute([hash('sha256', $token)]);
        $row = $query->fetch(PDO::FETCH_ASSOC);
        if (!$row) { http_response_code(403); exit('Token expirado ou rede inativa.'); }
        return $row;
    };
    // Monta o ZIP de fontes do gestor nativo (sem binarios). Com $config, inclui o gestor-config.json da instalacao; na atualizacao nao inclui.
    $nativeZip = static function (?array $config) use ($nativeRoot, $pdo, &$zipNative, &$tmpZip): string {
        if (!class_exists(ZipArchive::class)) { http_response_code(503); exit('PHP ZIP indisponivel.'); }
        $tmpZip = tempnam(sys_get_temp_dir(), 'winui3-');
        if ($tmpZip === false) throw new RuntimeException('Pasta temporaria indisponivel.');
        $zipNative = new ZipArchive();
        if ($zipNative->open($tmpZip, ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Falha ao criar ZIP nativo.');
        $walk = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($nativeRoot, FilesystemIterator::SKIP_DOTS));
        foreach ($walk as $file) {
            if (!$file->isFile() || $file->isLink()) continue;
            $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($nativeRoot)+1));
            if (preg_match('~(?:^|/)(?:bin|obj|\.vs|\.git|packages)(?:/|$)~i', $rel)) continue;
            if (preg_match('/\.(?:exe|dll|pdb|zip|nupkg)$/i', $rel)) continue;
            if ($rel === 'gestor-config.json') continue;
            // Cloud substitui a antiga página híbrida; não distribuir arquivos zerados.
            if ($rel === 'Pages/BackupCenterPage.cs' || str_starts_with($rel,'Assets/hybrid/backup/')) continue;
            // Lista positiva: não distribui arquivos de configuração, bancos, credenciais ou logs
            // acidentalmente colocados na pasta de compilação do servidor.
            $isProjectSource = (bool)preg_match('~\.(?:cs|csproj|xaml|ps1|manifest|md)$~i', $rel);
            // O painel WebView2 local precisa acompanhar a instalacao inicial E cada atualizacao.
            // Lista positiva estrita: nao incluir outros HTML/JS/JSON que possam conter dados privados.
            $isHybridAsset = (bool)preg_match('~^Assets/hybrid/(?:dashboard|shared|internet(?:/vendor)?|pentefino|backup|arquivos|mapa|seguranca|ferramentas)/[a-zA-Z0-9_-]+\.(?:html|css|js)$~D', $rel);
            // O catalogo de navegacao e recurso de compilacao e de execucao do WinUI.
            // Mantem a lista positiva; nao libera arquivos JSON arbitrarios.
            $isWorkspaceCatalog = ($rel === 'Assets/workspace-menu.json');
            if (!$isProjectSource && !$isHybridAsset && !$isWorkspaceCatalog) continue;
            if ($isWorkspaceCatalog && ($file->getSize() < 2 || $file->getSize() > 524288)) {
                throw new RuntimeException('Catalogo de navegacao invalido ou excessivo.');
            }
            if ($isHybridAsset && $file->getSize() > 524288) {
                throw new RuntimeException('Recurso visual excede 512 KB: ' . $rel);
            }
            $zipNative->addFile($file->getPathname(), 'Arcoll.WinUI3/' . $rel);
        }
        // CSS único das telas híbridas: a fonte canônica é Assets/hybrid/shared/gestor.css; o pacote o entrega à pasta de cada tela.
        $hybridSharedCss = $nativeRoot . '/Assets/hybrid/shared/gestor.css';
        if (!is_readable($hybridSharedCss)) throw new RuntimeException('Pacote do Gestor incompleto: Assets/hybrid/shared/gestor.css ausente.');
        foreach (['dashboard', 'internet', 'pentefino', 'arquivos', 'mapa', 'seguranca', 'ferramentas'] as $hybridFolder) {
            $zipNative->addFile($hybridSharedCss, 'Arcoll.WinUI3/Assets/hybrid/' . $hybridFolder . '/gestor.css');
        }
        // O desinstalador canônico (Assets/Desinstalar_Arcoll.ps1) segue no ZIP pela lista positiva de fontes do projeto.
        // Verifica o ZIP antes de disponibilizar o instalador: evita CS1566 no Windows.
        $workspaceCatalogPath = $nativeRoot . '/Assets/workspace-menu.json';
        if (!is_readable($workspaceCatalogPath) || $zipNative->locateName('Arcoll.WinUI3/Assets/workspace-menu.json') === false) {
            throw new RuntimeException('Pacote do Gestor incompleto: Assets/workspace-menu.json nao incluido.');
        }
        $workspaceCatalog = json_decode((string)file_get_contents($workspaceCatalogPath), true);
        if (!is_array($workspaceCatalog) || !is_array($workspaceCatalog['groups'] ?? null) || !is_array($workspaceCatalog['icons'] ?? null)) {
            throw new RuntimeException('Catalogo de navegacao do Gestor invalido.');
        }
        require_once dirname(__DIR__) . '/includes/support.php';
        require_once dirname(__DIR__) . '/includes/network-pentefino.php';
        $themeFile=dirname(__DIR__).'/assets/themes/catalog.json';if(!is_readable($themeFile))throw new RuntimeException('Catálogo visual indisponível.');
        $zipNative->addFromString('Arcoll.WinUI3/Assets/theme-catalog.json',file_get_contents($themeFile));
        $zipNative->addFromString('Arcoll.WinUI3/Assets/system.ico', arc_support_icon($pdo, 'gestor'));
        $zipNative->addFromString('Arcoll.WinUI3/Assets/program-catalog.json', json_encode(arc_program_install_catalog(), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        $zipNative->addFromString('Arcoll.WinUI3/Assets/pentefino-catalog.json', json_encode([
            'catalog'=>arc_pf_catalog(), 'health'=>arc_pf_health_sets(),
            'tabs'=>arc_pf_tabs(), 'ages'=>arc_pf_age_options()
        ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        foreach (array_merge(['arcoll_pentefino.py','arcoll_programs.py','arcoll_cloud.py','arcoll_release.py','arcoll_toolkit.py','arcoll_files.py','arcoll_file_thumbnails.py'],array_map('basename',glob($nativeRoot.'/Worker/arcoll_pf_*.py')?:[])) as $engineFile) {
            $enginePath=$nativeRoot.'/Worker/'.$engineFile;
            if (!is_file($enginePath)) throw new RuntimeException('Motor do Pente-Fino incompleto: '.$engineFile);
            $zipNative->addFile($enginePath,'Arcoll.WinUI3/Assets/pentefino-engine/'.$engineFile);
        }
        $zipNative->addFile($nativeRoot.'/Worker/pentefino_worker.py','Arcoll.WinUI3/Assets/pentefino-engine/pentefino_worker.py');
        // Fonte unica: a plataforma fornece VERSION ao compilador, sem alterar projetos C#.
        $zipNative->addFromString('Arcoll.WinUI3/VERSION', arc_app_version() . "\n");
        $zipNative->addFromString('Arcoll.WinUI3/Assets/pentefino-engine/VERSION',arc_app_version());
        // Falhar ANTES de enviar um gestor sem os arquivos essenciais do painel.
        foreach (['index.html', 'styles.css', 'app.js'] as $asset) {
            $assetPath = $nativeRoot . '/Assets/hybrid/dashboard/' . $asset;
            if (!is_file($assetPath) || !is_readable($assetPath) || filesize($assetPath) === 0) {
                throw new RuntimeException('Painel hibrido incompleto: ' . $asset);
            }
            if ($zipNative->locateName('Arcoll.WinUI3/Assets/hybrid/dashboard/' . $asset) === false) {
                throw new RuntimeException('Recurso ausente no pacote de distribuicao: ' . $asset);
            }
        }

        // A aba Internet usa recursos locais; impedir distribuicao parcial da interface.
        foreach (['index.html', 'styles.css', 'app.js', 'vendor/leaflet.js', 'vendor/leaflet.css'] as $asset) {
            $assetPath = $nativeRoot . '/Assets/hybrid/internet/' . $asset;
            if (!is_file($assetPath) || !is_readable($assetPath) || filesize($assetPath) === 0
                || $zipNative->locateName('Arcoll.WinUI3/Assets/hybrid/internet/' . $asset) === false) {
                throw new RuntimeException('Interface Internet incompleta: ' . $asset);
            }
        }

        foreach (['index.html','styles.css','app.js'] as $asset) {
            $visualPath=$nativeRoot.'/Assets/hybrid/pentefino/'.$asset;
            if (!is_readable($visualPath) || filesize($visualPath)===0 || $zipNative->locateName('Arcoll.WinUI3/Assets/hybrid/pentefino/'.$asset)===false) {
                throw new RuntimeException('Interface Pente-Fino incompleta: '.$asset);
            }
        }

        foreach (['index.html','styles.css','app.js'] as $asset) {
            $visualPath=$nativeRoot.'/Assets/hybrid/arquivos/'.$asset;
            if (!is_readable($visualPath) || filesize($visualPath)===0 || $zipNative->locateName('Arcoll.WinUI3/Assets/hybrid/arquivos/'.$asset)===false) throw new RuntimeException('Interface Arquivos incompleta: '.$asset);
        }
        // Segurança e Ferramentas do Pente-Fino: sem estas pastas a página abre em branco com "Interface ... não instalada".
        foreach (['seguranca'=>'Segurança','ferramentas'=>'Ferramentas'] as $visualDir=>$visualName) {
            foreach (['index.html','styles.css','app.js'] as $asset) {
                $visualPath=$nativeRoot.'/Assets/hybrid/'.$visualDir.'/'.$asset;
                if (!is_readable($visualPath) || filesize($visualPath)===0 || $zipNative->locateName('Arcoll.WinUI3/Assets/hybrid/'.$visualDir.'/'.$asset)===false) throw new RuntimeException('Interface '.$visualName.' incompleta: '.$asset);
            }
        }
        foreach (['index.html','styles.css','app.js'] as $asset) {
            $visualPath=$nativeRoot.'/Assets/hybrid/mapa/'.$asset;
            if (!is_readable($visualPath) || filesize($visualPath)===0 || $zipNative->locateName('Arcoll.WinUI3/Assets/hybrid/mapa/'.$asset)===false) throw new RuntimeException('Interface Mapa incompleta: '.$asset);
        }
        // Cloud nativo substitui o antigo backup híbrido; o executor automático permanece.
        foreach (['Pages/CloudPage.cs','Services/BackupCenter/BackupExecutor.cs','BackupWorker/BackupWorker.csproj','BackupWorker/Program.cs','INSTALAR_BACKUP_SERVICO.ps1'] as $file) {
            if ($zipNative->locateName('Arcoll.WinUI3/'.$file)===false) throw new RuntimeException('Cloud do Gestor incompleto: '.$file);
        }

        // O workspace integrado em MainWindow.Workspace.cs e o monitor devem acompanhar o pacote.
        // Controls/GestorWorkspace.cs foi descontinuado; nao exigir arquivos removidos do projeto.
        foreach (['MainWindow.Workspace.cs','Services/PerformanceModel.cs','Services/PerformanceCollector.cs','Services/NativePerformance.cs','Services/GpuTemperature.cs','Pages/ServerPage.cs','Assets/hybrid/dashboard/server.html','Assets/hybrid/dashboard/server.css','Assets/hybrid/dashboard/server.js','Assets/hybrid/dashboard/compact-shell.js','Assets/hybrid/dashboard/standard-workspace.css','Assets/hybrid/dashboard/standard-workspace.js','Assets/hybrid/internet/standard-workspace.css','Assets/hybrid/pentefino/standard-workspace.css'] as $workspaceFile) {
            if ($zipNative->locateName('Arcoll.WinUI3/'.$workspaceFile)===false) throw new RuntimeException('Workspace do gestor incompleto: '.$workspaceFile);
        }

        foreach(['Services/LocalDatabase.cs','Services/ThemeRules.cs'] as $essential){if($zipNative->locateName('Arcoll.WinUI3/'.$essential)===false)throw new RuntimeException('Gestor incompleto: '.$essential);}

        // Logos dos programas (mesmos PNG da plataforma): o catálogo do gestor funciona sem internet.
        // Assets\** é copiado para a pasta de instalação pelo .csproj.
        foreach (glob(dirname(__DIR__) . '/assets/program-logos/*.png') ?: [] as $logo) {
            if (is_file($logo) && !is_link($logo) && filesize($logo) < 200000) $zipNative->addFile($logo, 'Arcoll.WinUI3/Assets/program-logos/' . basename($logo));
        }
        if ($config !== null) $zipNative->addFromString('Arcoll.WinUI3/gestor-config.json', json_encode($config, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        // Metadados estaveis tornam o SHA-256 reprodutivel quando o codigo nao mudou.
        // Sem isso, entradas addFromString recebem a hora atual e geram um ZIP
        // diferente a cada consulta, causando reinstalacoes normais repetidas.
        if (!method_exists($zipNative, 'setMtimeName')) {
            throw new RuntimeException('Extensao ZIP do PHP sem suporte a metadados de versao reproduziveis.');
        }
        $releaseTimestamp = 1704067200; // 01/01/2024 UTC, fixo; conteudo continua determinando o hash.
        for ($entry = 0, $count = $zipNative->numFiles; $entry < $count; $entry++) {
            $name = $zipNative->getNameIndex($entry);
            if (!is_string($name) || !$zipNative->setMtimeName($name, $releaseTimestamp)) {
                throw new RuntimeException('Falha ao normalizar metadados do pacote.');
            }
        }
        if (!$zipNative->close()) throw new RuntimeException('Falha ao fechar ZIP nativo.');
        return $tmpZip;
    };
    /* Publicacao da release binaria pelo proprio Gestor Servidor (instalacao ja atualizada, sem compilar no site).
     * Credenciais em cabecalhos; somente o gestor com perfil 'server' aprovado publica. Etapas: file (blocos) e commit (atomico). */
    if ($requestedMode === 'release-publish') {
        header('Cache-Control: private, no-store'); header('X-Content-Type-Options: nosniff');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Metodo invalido.'); }
        $fp = strtolower(trim((string)($_SERVER['HTTP_X_GESTOR_FINGERPRINT'] ?? '')));
        $code = strtoupper(trim((string)($_SERVER['HTTP_X_GESTOR_SITE_CODE'] ?? '')));
        $key = trim((string)($_SERVER['HTTP_X_GESTOR_DOWNLOAD_KEY'] ?? ''));
        if (!preg_match('/^[a-f0-9]{64}$/D', $fp) || !preg_match('/^[A-Z0-9]{5}$/D', $code) || !preg_match('/^[a-f0-9]{64}$/D', $key)) { http_response_code(403); exit('Credenciais invalidas.'); }
        $q = $pdo->prepare('SELECT a.id,a.account_id,a.network_id FROM ' . arc_table('network_gestores') . ' a INNER JOIN ' . arc_table('managed_networks') . ' n ON n.id=a.network_id AND n.account_id=a.account_id INNER JOIN ' . arc_table('gestor_download_keys') . ' k ON k.network_id=a.network_id AND k.account_id=a.account_id WHERE a.fingerprint=? AND UPPER(a.site_code)=? AND a.status=\'approved\' AND a.installation_profile=\'server\' AND n.is_active=1 AND n.monitoring_enabled=1 AND k.token_hash=? AND k.fingerprint=? LIMIT 1');
        $q->execute([$fp, $code, hash('sha256', $key), $fp]);
        $publisher = $q->fetch(PDO::FETCH_ASSOC);
        if (!$publisher) { http_response_code(403); exit('Somente o Gestor Servidor aprovado desta rede pode publicar a release.'); }
        $arch = (string)($_GET['arch'] ?? '');
        $upload = (string)($_GET['upload'] ?? '');
        if (!in_array($arch, ['win-x64','win-arm64'], true) || !preg_match('/^[a-f0-9]{32}$/D', $upload)) { http_response_code(400); exit('Parametros invalidos.'); }
        $safeName = static function(string $name): bool {
            return strlen($name) < 240 && preg_match('~^[a-zA-Z0-9._/-]+$~D', $name) === 1 && strpos($name, '//') === false
                && preg_match('~(?:^|/)\.\.?(?:/|$)~', $name) !== 1 && $name[0] !== '/' && !in_array(strtolower($name), ['gestor-config.json','gestor.json'], true);
        };
        $releasesRoot = dirname(__DIR__) . '/gestores/releases';
        $archDir = $releasesRoot . '/' . $arch;
        $stage = $archDir . '/.stage-' . $upload;
        if (!is_dir($archDir) && !@mkdir($archDir, 0755, true) && !is_dir($archDir)) throw new RuntimeException('Nao foi possivel criar gestores/releases/' . $arch . '.');
        if (!is_file($releasesRoot . '/.htaccess')) @file_put_contents($releasesRoot . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
        // Politica unica de armazenamento (Central de manutencao): prazo para envios incompletos.
        require_once dirname(__DIR__) . '/includes/storage-policy.php';
        $stageHours = (int)arc_storage_policy($pdo)['release_stage_hours'];
        @set_time_limit(0); ignore_user_abort(true);
        $step = (string)($_GET['step'] ?? '');
        if ($step === 'file') {
            $name = (string)($_GET['name'] ?? '');
            $offset = (int)($_GET['offset'] ?? -1);
            $total = (int)($_GET['total'] ?? -1);
            if (!$safeName($name) || $offset < 0 || $total < 0 || $total > 200 * 1024 * 1024 || $offset > $total) { http_response_code(400); exit('Arquivo invalido.'); }
            $chunk = file_get_contents('php://input', false, null, 0, 9 * 1024 * 1024 + 1);
            if (!is_string($chunk) || strlen($chunk) > 9 * 1024 * 1024 || $offset + strlen($chunk) > $total) { http_response_code(413); exit('Bloco invalido.'); }
            if (!is_dir($stage)) {
                // Primeiro arquivo de um novo envio: descarta somente envios anteriores abandonados.
                try { arc_gestor_release_cleanup(true, $stageHours, ['stage']); } catch (Throwable $e) { arc_log_error('Limpeza de envios de release: ' . $e->getMessage()); }
            }
            $target = $stage . '/files/' . $name;
            $dirTarget = dirname($target);
            if (!is_dir($dirTarget) && !@mkdir($dirTarget, 0755, true) && !is_dir($dirTarget)) throw new RuntimeException('Pasta de destino indisponivel.');
            if ($offset === 0 && is_file($target)) @unlink($target);
            $currentSize = is_file($target) ? (int)filesize($target) : 0;
            if ($currentSize !== $offset) { http_response_code(409); exit('Posicao divergente; reenvie o arquivo desde o inicio. Esperado: ' . $currentSize); }
            if (file_put_contents($target, $chunk, FILE_APPEND | LOCK_EX) === false) throw new RuntimeException('Falha ao gravar bloco.');
            arc_json(['ok' => true, 'size' => $currentSize + strlen($chunk)]);
        }
        if ($step === 'commit') {
            $raw = file_get_contents('php://input', false, null, 0, 600001);
            $v = is_string($raw) && strlen($raw) <= 600000 ? json_decode($raw, true) : null;
            $version = is_array($v) ? (string)($v['version'] ?? '') : '';
            $list = is_array($v) && is_array($v['files'] ?? null) ? $v['files'] : [];
            if (!preg_match('/^\d+(?:\.\d+){1,4}$/D', $version) || count($list) < 2 || count($list) > 3500 || !isset($list['Arcoll.WinUI3.exe'])) { http_response_code(400); exit('Manifesto invalido ou incompleto.'); }
            $minimumFile = $nativeRoot . '/MINIMUM_RELEASE_VERSION';
            if (is_file($minimumFile) && version_compare($version, trim((string)file_get_contents($minimumFile)), '<')) { http_response_code(422); exit('Versao do Servidor anterior ao minimo exigido pela plataforma: ' . $version); }
            $existing = arc_gestor_release_manifest($arch);
            if ($existing && version_compare($version, (string)$existing['version'], '<')) { http_response_code(422); exit('Ja existe release mais nova publicada: ' . $existing['version']); }
            // Um unico commit por vez; o bloqueio vale ate o fim da requisicao.
            $publishLock = @fopen($releasesRoot . '/.lock', 'c');
            if (!$publishLock || !flock($publishLock, LOCK_EX)) throw new RuntimeException('Nao foi possivel reservar a publicacao da release.');
            if (!is_dir($stage . '/files')) {
                // Reenvio do commit apos resposta perdida: confirma sem refazer quando a release ja esta ativa.
                $wanted = []; foreach ($list as $n => $h) { if (is_string($n) && is_string($h)) $wanted[$n] = strtolower($h); }
                $active = []; foreach (($existing['files'] ?? []) as $n => $h) { $active[(string)$n] = strtolower((string)$h); }
                ksort($wanted, SORT_STRING); ksort($active, SORT_STRING);
                if ($existing && (string)$existing['version'] === $version && $wanted === $active) arc_json(['ok' => true, 'version' => $version, 'arch' => $arch, 'files' => count($wanted)]);
                http_response_code(422); exit('Envio nao encontrado; reenvie a release.');
            }
            // Qualquer falha ate a ativacao descarta o envio: nunca deixar .stage-* orfao no servidor.
            register_shutdown_function(static function () use ($stage): void {
                if (is_dir($stage)) { try { arc_gestor_release_remove_tree($stage); } catch (Throwable $e) { arc_log_error('Descarte do envio de release: ' . $e->getMessage()); } }
            });
            $files = [];
            foreach ($list as $name => $hash) {
                if (!is_string($name) || !$safeName($name) || !is_string($hash) || !preg_match('/^[a-f0-9]{64}$/Di', $hash)) { http_response_code(400); exit('Arquivo do manifesto invalido.'); }
                $path = $stage . '/files/' . $name;
                if (!is_file($path) || is_link($path) || !hash_equals(strtolower($hash), strtolower((string)hash_file('sha256', $path)))) { http_response_code(422); exit('Arquivo ausente ou corrompido no envio: ' . $name); }
                $files[$name] = strtolower($hash);
            }
            ksort($files, SORT_STRING);
            $manifestJson = json_encode(['version' => $version, 'arch' => $arch, 'files' => $files, 'native_source_hash' => $version===arc_app_version()?arc_gestor_native_source_hash():null], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            if (strlen($manifestJson) > 349000) { http_response_code(422); exit('Manifesto excede o limite.'); }
            if (file_put_contents($stage . '/release.json', $manifestJson, LOCK_EX) === false) throw new RuntimeException('Falha ao gravar release.json.');

            // Empacotar a distribuicao nativa: o cPanel guarda um unico arquivo, nao centenas de DLLs soltas.
            if (!class_exists(ZipArchive::class)) throw new RuntimeException('Extensao ZIP obrigatoria para publicar o Gestor.');
            $releaseArchive = $stage . '/release-files.zip';
            $packed = new ZipArchive();
            if ($packed->open($releaseArchive, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Falha ao compactar release.');
            foreach ($files as $filename => $expectedHash) {
                if (!$packed->addFile($stage . '/files/' . $filename, 'files/' . $filename)) {
                    $packed->close(); throw new RuntimeException('Arquivo nao pode ser compactado: ' . $filename);
                }
            }
            if (!$packed->close()) throw new RuntimeException('Falha ao finalizar ZIP da release.');
            $checkArchive = new ZipArchive();
            if ($checkArchive->open($releaseArchive, ZipArchive::RDONLY) !== true) throw new RuntimeException('ZIP publicado nao pode ser lido.');
            foreach ($files as $filename => $expectedHash) {
                $entry = $checkArchive->getStream('files/' . $filename);
                if ($entry === false) { $checkArchive->close(); throw new RuntimeException('Arquivo ausente no ZIP: ' . $filename); }
                $ctx = hash_init('sha256'); hash_update_stream($ctx, $entry); fclose($entry);
                if (!hash_equals($expectedHash, hash_final($ctx))) {
                    $checkArchive->close(); throw new RuntimeException('Falha de integridade no ZIP: ' . $filename);
                }
            }
            $checkArchive->close();
            arc_gestor_release_remove_tree($stage . '/files');

            $current = $archDir . '/current';
            $previous = $archDir . '/.prev-' . date('YmdHis') . '-' . bin2hex(random_bytes(3));
            if (is_dir($current) && !@rename($current, $previous)) throw new RuntimeException('Nao foi possivel arquivar a release anterior.');
            if (!@rename($stage, $current)) { if (is_dir($previous)) @rename($previous, $current); throw new RuntimeException('Nao foi possivel ativar a release.'); }
            // Somente a release ativa permanece: versoes arquivadas, envios abandonados e arquivos soltos saem
            // depois de conferir o pacote recem-ativado. Falha na limpeza nunca desfaz a publicacao.
            $cleanup = ['eligible' => 0, 'deleted' => 0, 'bytes_eligible' => 0, 'bytes_deleted' => 0, 'items' => [], 'warnings' => []];
            try { arc_gestor_release_cleanup_arch($arch, true, time() - $stageHours * 3600, false, ['stage', 'prev', 'loose'], $cleanup); }
            catch (Throwable $e) { arc_log_error('Limpeza apos publicar release: ' . $e->getMessage()); }
            arc_json(['ok' => true, 'version' => $version, 'arch' => $arch, 'files' => count($files), 'freed_bytes' => $cleanup['bytes_deleted']]);
        }
        http_response_code(400); exit('Etapa invalida.');
    }
    /* Release WinUI 3 precompilada: delta calculado dos SHA256 locais. Nunca recebe caminhos arbitrarios. */
    if ($requestedMode === 'native-precompiled') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Metodo invalido.'); }
        $raw = file_get_contents('php://input', false, null, 0, 600001);
        if (!is_string($raw) || strlen($raw) > 600000) { http_response_code(413); exit('Inventario excede limite.'); }
        $v = json_decode($raw, true);
        if (!is_array($v)) { http_response_code(400); exit('JSON invalido.'); }
        $fp = strtolower(trim((string)($v['fingerprint'] ?? '')));
        $code = strtoupper(trim((string)($v['site_code'] ?? '')));
        $key = trim((string)($v['download_key'] ?? ''));
        $arch = (string)($v['arch'] ?? '');
        $force = ($v['force'] ?? false) === true;
        // Gestor gratuito (sem vinculo): os binarios publicados ja sao publicos no instalador universal; a atualizacao automatica
        // so exige impressao digital valida e o controle administrativo Admin > Versao.
        $freeUpdate = ($v['standalone'] ?? false) === true && $code === '' && $key === '';
        if ($freeUpdate) {
            if (!preg_match('/^[a-f0-9]{64}$/D', $fp) || !in_array($arch, ['win-x64','win-arm64'], true)) { http_response_code(403); exit('Impressao digital ou arquitetura invalidas.'); }
            if (arc_platform_setting($pdo, 'platform_gestor_free_auto_update', '1') !== '1') { http_response_code(403); exit('Atualizacao do gestor gratuito desativada pelo administrador.'); }
        } elseif (!preg_match('/^[a-f0-9]{64}$/D', $fp) || !preg_match('/^[A-Z0-9]{5}$/D', $code) || !preg_match('/^[a-f0-9]{64}$/D', $key)
            || !in_array($arch, ['win-x64','win-arm64'], true)) { http_response_code(403); exit('Credenciais ou arquitetura invalidas.'); }
        if (!$freeUpdate) {
        $q = $pdo->prepare('SELECT a.id,a.account_id,a.network_id FROM ' . arc_table('network_gestores') . ' a INNER JOIN ' . arc_table('managed_networks') . ' n ON n.id=a.network_id AND n.account_id=a.account_id INNER JOIN ' . arc_table('gestor_download_keys') . ' k ON k.network_id=a.network_id AND k.account_id=a.account_id WHERE a.fingerprint=? AND UPPER(a.site_code)=? AND a.status=\'approved\' AND n.is_active=1 AND n.monitoring_enabled=1 AND k.token_hash=? AND k.fingerprint=? LIMIT 1');
        $q->execute([$fp, $code, hash('sha256', $key), $fp]);
        $updateDevice=$q->fetch(PDO::FETCH_ASSOC);if(!$updateDevice){http_response_code(403);exit('Gestor nao autorizado.');}
        arc_gt_require($pdo,$updateDevice,'updates');
        }

        $dir = dirname(__DIR__) . '/gestores/releases/' . $arch . '/current';
        $manifestFile = $dir . '/release.json';
        if (!is_file($manifestFile) || !is_readable($manifestFile)) { http_response_code(404); exit('Release precompilada nao publicada para esta arquitetura.'); }
        $manifestRaw = file_get_contents($manifestFile);
        if (!is_string($manifestRaw) || strlen($manifestRaw) > 350000) throw new RuntimeException('Manifesto precompilado muito grande.');
        $manifest = json_decode($manifestRaw, true);
        // A release precompilada tem versao propria (a dos binarios publicados). Exigir igualdade com a
        // versao da plataforma fazia o servidor responder 500 a cada ajuste de PHP/CSS no site.
        if (!is_array($manifest) || ($manifest['arch'] ?? null) !== $arch || !preg_match('/^\d+(?:\.\d+){1,4}$/D', (string)($manifest['version'] ?? '')) || !isset($manifest['files']) || !is_array($manifest['files'])) {
            throw new RuntimeException('Manifesto da release precompilada invalido para ' . $arch . '.');
        }
        // Este recurso altera codigo nativo. Nao servir um binario anterior como se contivesse o workspace novo.
        // O minimo e especifico do gestor; futuras alteracoes somente PHP nao invalidam a release nativa.
        $minimumFile = $nativeRoot . '/MINIMUM_RELEASE_VERSION';
        if (is_file($minimumFile)) {
            $minimumVersion = trim((string)file_get_contents($minimumFile));
            if (!preg_match('/^\d+(?:\.\d+){1,4}$/D', $minimumVersion)) throw new RuntimeException('Versao minima nativa invalida.');
            if (version_compare((string)$manifest['version'], $minimumVersion, '<')) {
                http_response_code(404); exit('Release binaria anterior ao workspace publicado; utilizar pacote fonte autenticado.');
            }
        }
        // Reutilizar somente uma publicação cuja origem compilável foi conferida.
        // Publicações antigas sem identidade de origem continuam usando a compilação autenticada.
        if ((string)$manifest['version']!==arc_app_version() &&
            (!is_string($manifest['native_source_hash']??null)||!hash_equals(arc_gestor_native_source_hash(),$manifest['native_source_hash']))) {
            http_response_code(404);header('Cache-Control: private, no-store');
            exit('Código nativo alterado; utilizar pacote fonte autenticado.');
        }
        $manifest['binary_version']=(string)$manifest['version'];
        $manifest['version']=arc_app_version();
        $releaseVersion = arc_app_version();
        $list = $manifest['files'];
        if (count($list) < 2 || count($list) > 3500 || !isset($list['Arcoll.WinUI3.exe'])) throw new RuntimeException('Release precompilada incompleta.');
        // Recursos dinamicos gerados pelo backend sao adicionados com hash ao mesmo
        // manifesto, evitando reintroduzir a recompilacao no PC e preservando o Pente-Fino.
        require_once dirname(__DIR__) . '/includes/support.php';
        require_once dirname(__DIR__) . '/includes/network-pentefino.php';
        $generated = [
            'Assets/theme-catalog.json'=>file_get_contents(dirname(__DIR__).'/assets/themes/catalog.json'),
            'Assets/system.ico' => arc_support_icon($pdo, 'gestor'),
            'Assets/hybrid/dashboard/loader-mark.js' => (string)file_get_contents($nativeRoot . '/Assets/hybrid/dashboard/loader-mark.js'),
            'Assets/program-catalog.json' => json_encode(arc_program_install_catalog(), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
            'Assets/pentefino-catalog.json' => json_encode([
                'catalog'=>arc_pf_catalog(), 'health'=>arc_pf_health_sets(),
                'tabs'=>arc_pf_tabs(), 'ages'=>arc_pf_age_options()
            ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
            'Assets/pentefino-engine/VERSION' => $releaseVersion,
            'Assets/workspace-menu.json' => file_get_contents($nativeRoot . '/Assets/workspace-menu.json'),
        ];
        foreach (array_merge(['arcoll_pentefino.py','arcoll_programs.py','arcoll_cloud.py','arcoll_release.py','arcoll_toolkit.py','arcoll_files.py','arcoll_file_thumbnails.py'],array_map('basename',glob($nativeRoot.'/Worker/arcoll_pf_*.py')?:[])) as $engineFile) {
            $src = $nativeRoot . '/Worker/' . $engineFile;
            if (!is_file($src)) throw new RuntimeException('Motor do Pente-Fino incompleto: ' . $engineFile);
            $generated['Assets/pentefino-engine/' . $engineFile] = file_get_contents($src);
        }
        $workerFile = $nativeRoot . '/Worker/pentefino_worker.py';
        if (!is_file($workerFile)) throw new RuntimeException('Motor do Pente-Fino do WinUI ausente.');
        $generated['Assets/pentefino-engine/pentefino_worker.py'] = file_get_contents($workerFile);
        foreach (glob(dirname(__DIR__) . '/assets/program-logos/*.png') ?: [] as $logo) {
            if (is_file($logo) && !is_link($logo) && filesize($logo) < 200000) {
                $generated['Assets/program-logos/' . basename($logo)] = file_get_contents($logo);
            }
        }
        foreach ($generated as $filename => $bytesValue) {
            if (!is_string($bytesValue) || strlen($bytesValue) > 524288) throw new RuntimeException('Recurso dinamico invalido: ' . $filename);
            $list[$filename] = hash('sha256', $bytesValue);
        }
        ksort($list, SORT_STRING);
        $manifest['files'] = $list;
        $manifestRaw = json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $have = $v['files'] ?? [];
        if (!is_array($have) || count($have) > 3500) { http_response_code(400); exit('Inventario invalido.'); }
        $safe = static function(string $name): bool {
            return strlen($name) < 240 && preg_match('~^[a-zA-Z0-9._/-]+$~D', $name) === 1 && strpos($name, '//') === false && preg_match('~(?:^|/)\.\.?(?:/|$)~', $name) !== 1;
        };
        foreach ($have as $filename => $hash) {
            if (!is_string($filename) || !$safe($filename) || !is_string($hash) || !preg_match('/^[a-f0-9]{64}$/D', $hash)) { http_response_code(400); exit('Inventario inseguro.'); }
        }
        if (($v['probe'] ?? false) === true) {
            $different=0;
            foreach($list as $filename=>$hash){
                if(!is_string($filename)||!$safe($filename)||!is_string($hash)||!preg_match('/^[a-f0-9]{64}$/Di',$hash)||$filename==='gestor-config.json')throw new RuntimeException('Manifesto de release invalido.');
                if(!isset($have[$filename])||!hash_equals(strtolower($hash),$have[$filename]))$different++;
            }
            header('Cache-Control: private, no-store');
            arc_json(['ok'=>true,'version'=>$releaseVersion,'kind'=>'binary','changed_count'=>$different,'auto_update'=>arc_platform_setting($pdo, $freeUpdate ? 'platform_gestor_free_auto_update' : 'platform_gestor_auto_update', '1')==='1']);
        }
        if (!class_exists(ZipArchive::class)) { http_response_code(503); exit('PHP ZIP indisponivel.'); }
        $zipPath = tempnam(sys_get_temp_dir(), 'ti-delta-');
        if (!is_string($zipPath)) throw new RuntimeException('Pasta temporaria indisponivel.');
        $zipNative = new ZipArchive(); $tmpZip = $zipPath;
        $sourceArchive = null; $archiveTempFiles = [];
        // Temporarios sempre removidos, mesmo em falha ou interrupcao do download.
        register_shutdown_function(static function () use ($zipPath, &$archiveTempFiles): void { @unlink($zipPath); foreach ($archiveTempFiles as $leftover) @unlink($leftover); });
        $archivePath = $dir . '/release-files.zip';
        if (is_file($archivePath)) {
            $sourceArchive = new ZipArchive();
            if ($sourceArchive->open($archivePath, ZipArchive::RDONLY) !== true) throw new RuntimeException('Release compactada ilegivel.');
        }
        if ($zipNative->open($zipPath, ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Falha ao criar pacote delta.');
        if (!$zipNative->addFromString('release.json', $manifestRaw)) throw new RuntimeException('Falha ao gravar manifesto.');
        $script = $nativeRoot . '/APLICAR_PRECOMPILADO.ps1';
        if (!is_file($script)) throw new RuntimeException('Aplicador precompilado ausente.');
        $zipNative->addFile($script, 'APLICAR_PRECOMPILADO.ps1');
        $bytes = 0; $changed = 0;
        foreach ($list as $filename => $hash) {
            if (!is_string($filename) || !$safe($filename) || !is_string($hash) || !preg_match('/^[a-f0-9]{64}$/Di', $hash) || $filename === 'gestor-config.json')
                throw new RuntimeException('Manifesto de release invalido.');
            if (!$force && isset($have[$filename]) && hash_equals(strtolower($hash), $have[$filename])) continue;
            if (array_key_exists($filename, $generated)) {
                $contents = $generated[$filename];
                $filesize = strlen($contents);
                if (!$zipNative->addFromString('files/' . $filename, $contents)) throw new RuntimeException('Falha no recurso dinamico: ' . $filename);
            } elseif ($sourceArchive instanceof ZipArchive) {
                $entryName = 'files/' . $filename;
                $stat = $sourceArchive->statName($entryName);
                if (!is_array($stat) || ($stat['size'] ?? -1) < 0 || ($stat['size'] ?? 0) > 200 * 1024 * 1024) throw new RuntimeException('Arquivo ausente ou excede limite: ' . $filename);
                $filesize = (int)$stat['size'];
                $incoming = $sourceArchive->getStream($entryName);
                if ($incoming === false) throw new RuntimeException('Arquivo da release compactada indisponivel: ' . $filename);
                $tempEntry = tempnam(sys_get_temp_dir(), 'ti-entry-');
                if (!is_string($tempEntry)) { fclose($incoming); throw new RuntimeException('Espaco temporario indisponivel.'); }
                $archiveTempFiles[] = $tempEntry;
                $outEntry = fopen($tempEntry, 'wb');
                if ($outEntry === false) { fclose($incoming); throw new RuntimeException('Falha ao extrair arquivo temporario.'); }
                $copied = stream_copy_to_stream($incoming, $outEntry, $filesize + 1);
                fclose($incoming); fclose($outEntry);
                if ($copied !== $filesize || !hash_equals(strtolower($hash), strtolower((string)hash_file('sha256', $tempEntry)))) throw new RuntimeException('Integridade da release compactada falhou: ' . $filename);
                if (!$zipNative->addFile($tempEntry, $entryName)) throw new RuntimeException('Falha ao montar pacote: ' . $filename);
            } else {
                throw new RuntimeException('Release ativa sem pacote compactado; publique novamente pelo Gestor Servidor.');
            }
            $bytes += $filesize; $changed++;
            if ($bytes > 650 * 1024 * 1024) throw new RuntimeException('Delta excede 650 MB.');
        }
        if (!$zipNative->close()) throw new RuntimeException('Falha ao fechar pacote precompilado.');
        if ($sourceArchive instanceof ZipArchive) $sourceArchive->close();
        foreach ($archiveTempFiles as $tempEntry) @unlink($tempEntry);
        $hash = hash_file('sha256', $zipPath);
        if (!is_string($hash)) throw new RuntimeException('Hash de pacote indisponivel.');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="TIDigital-Precompilado-' . $arch . '.zip"');
        header('X-Gestor-Version: ' . $manifest['version']);
        header('X-Package-SHA256: ' . $hash);
        arc_gestor_signature_headers((string)($requestedMode==='native-precompiled'?$manifest['version']:arc_app_version()),$hash);
        header('X-Changed-Files: ' . $changed);
        header('Content-Length: ' . filesize($zipPath));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        readfile($zipPath); @unlink($zipPath); exit;
    }
    /* Atualizacao remota/forcada: o gestor instalado se autentica com o mesmo vinculo revogavel (impressao digital, codigo e chave). */
    if ($requestedMode === 'native-update') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Metodo invalido.'); }
        $raw = file_get_contents('php://input');
        if (!is_string($raw) || strlen($raw) > 2048) { http_response_code(413); exit('Requisicao invalida.'); }
        $v = json_decode($raw, true);
        if (!is_array($v)) { http_response_code(400); exit('JSON invalido.'); }
        $fp = strtolower(trim((string)($v['fingerprint'] ?? '')));
        $code = strtoupper(trim((string)($v['site_code'] ?? '')));
        $key = trim((string)($v['download_key'] ?? ''));
        if (!preg_match('/^[a-f0-9]{64}$/', $fp) || !preg_match('/^[A-Z0-9]{5}$/', $code) || !preg_match('/^[a-f0-9]{64}$/', $key)) { http_response_code(403); exit('Credenciais invalidas.'); }
        $q = $pdo->prepare('SELECT a.id,a.account_id,a.network_id FROM ' . arc_table('network_gestores') . ' a INNER JOIN ' . arc_table('managed_networks') . ' n ON n.id=a.network_id AND n.account_id=a.account_id INNER JOIN ' . arc_table('gestor_download_keys') . ' k ON k.network_id=a.network_id AND k.account_id=a.account_id WHERE a.fingerprint=? AND UPPER(a.site_code)=? AND a.status=\'approved\' AND n.is_active=1 AND n.monitoring_enabled=1 AND k.token_hash=? AND k.fingerprint=? LIMIT 1');
        $q->execute([$fp, $code, hash('sha256', $key), $fp]);
        $updateDevice=$q->fetch(PDO::FETCH_ASSOC);if(!$updateDevice){http_response_code(403);exit('Gestor nao autorizado.');}
        arc_gt_require($pdo,$updateDevice,'updates');
        $path = $nativeZip(null);
        $hash = hash_file('sha256', $path);
        if ($hash === false) throw new RuntimeException('Nao foi possivel assinar o pacote.');
        if(($v['probe']??false)===true){@unlink($path);header('Cache-Control: private, no-store');arc_json(['ok'=>true,'version'=>arc_app_version(),'kind'=>'source','package_hash'=>$hash,'auto_update'=>arc_platform_setting($pdo,'platform_gestor_auto_update','1')==='1']);}
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="TI-Digital-WinUI3-Atualizacao.zip"');
        header('Content-Length: ' . filesize($path));
        header('X-Gestor-Version: ' . arc_app_version());
        header('X-Package-SHA256: ' . $hash);
        arc_gestor_signature_headers((string)($requestedMode==='native-precompiled'?$manifest['version']:arc_app_version()),$hash);
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        readfile($path); @unlink($path); exit;
    }
    if ($requestedMode === 'native-package' || $requestedMode === 'native-bootstrap') {
        $token = (string)($_GET['t'] ?? '');
        $universal = (string)($_GET['universal'] ?? '') === '1';
        $nativeRecord = $universal ? null : $nativeCheck($pdo, $token);
        if ($requestedMode === 'native-bootstrap') {
            // Entrega o instalador WPF moderno; a janela gerencia download,
            // compilacao, andamento e diagnostico sem usar console interativo.
            $url = $nativeOrigin . '/api/download-gestor.php?mode=native-package&' . ($universal ? 'universal=1' : 't=' . $token);
            $visualPath = $nativeRoot . '/INSTALADOR_VISUAL_WINUI3.ps1';
            if (!is_file($visualPath)) throw new RuntimeException('Instalador visual indisponivel no servidor.');
            $visual = file_get_contents($visualPath);
            if ($visual === false || strpos($visual, '__PACKAGE_URL__') === false || strpos($visual, '__INSTALLER_THEME_BASE64__') === false) {
                throw new RuntimeException('Modelo do instalador visual invalido.');
            }
            // Identidade visual única: dados de admin/configuracoes, sem marca fixa no instalador.
            $brand = arc_public_settings($pdo);
            $theme = arc_visual_theme($pdo);
            $theme['brand_name'] = mb_substr(trim((string)($brand['site_name'] ?? 'Gestor')), 0, 90);
            $theme['brand_tagline'] = mb_substr(trim((string)($brand['tagline'] ?? '')), 0, 140);
            $theme['brand_logo_data'] = '';
            $logoFile = basename(trim((string)($brand['logo_path'] ?? '')));
            if (preg_match('/^[a-f0-9]{32,40}\.(?:png|jpg|webp)$/D', $logoFile)) {
                $logoPath = arc_upload_dir('brand') . '/' . $logoFile;
                if (is_file($logoPath) && filesize($logoPath) <= 262144 && @getimagesize($logoPath)) {
                    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($logoPath);
                    if (in_array($mime, ['image/png','image/jpeg','image/webp'], true)) {
                        $theme['brand_logo_data'] = base64_encode((string)file_get_contents($logoPath));
                    }
                }
            }
            // A marca animada configurada é preferida; na ausência, usa a silhueta da logo principal.
            require_once dirname(__DIR__) . '/includes/loader-mark.php';
            $loaderPath = arc_loader_mark_path($pdo);
            $theme['loader_logo_data'] = $loaderPath !== '' && is_file($loaderPath) && filesize($loaderPath) <= 102400
                ? base64_encode((string)file_get_contents($loaderPath)) : '';
            $palette=base64_encode(json_encode($theme,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
            $ps=str_replace(['__PACKAGE_URL__','__INSTALLER_THEME_BASE64__'],[str_replace("'","''",$url),$palette],$visual);
            // Windows PowerShell 5.1 interpreta scripts UTF-8 com BOM corretamente.
            header('Content-Type: text/plain; charset=utf-8');
            header('Cache-Control: private, no-store, max-age=0');
            header('X-Content-Type-Options: nosniff');
            exit("\xEF\xBB\xBF" . ltrim($ps, "\xEF\xBB\xBF"));
        }
        // Nome do sistema (Admin › Configurações) = nome do Gestor, do atalho e do ícone da área de trabalho.
        $nativeSystemName = trim((string)(arc_setting_values(arc_db())['site_name'] ?? ''));
        if ($nativeSystemName === '') $nativeSystemName = 'Gestor';
        $tmpZip = $nativeZip($nativeConfig = $universal ? [
            'origin'=>$nativeOrigin, 'mode'=>'standalone', 'system_name'=>$nativeSystemName, 'gestor_version'=>arc_app_version(),
        ] : [
            'origin'=>$nativeOrigin, 'system_name'=>$nativeSystemName,
            'network_id'=>(int)$nativeRecord['network_id'],
            'site_code'=>(string)$nativeRecord['site_code'],
            'download_key'=>$token,
            'gestor_version'=>arc_app_version(),
        ]);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="Gestor-Windows-Fontes.zip"');
        $packageHash=hash_file('sha256',$tmpZip);if($packageHash===false)throw new RuntimeException('Falha na integridade do pacote.');
        header('X-Package-SHA256: '.$packageHash);
        header('Content-Length: ' . filesize($tmpZip));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        readfile($tmpZip); @unlink($tmpZip); exit;
    }
    // Instalacao interativa: somente o BAT oficial. A rota antiga 'command' retorna 410 abaixo.
    /* Desinstalador visual completo. O script e generico (so recebe o tema da plataforma, nenhum segredo) e le as
     * credenciais da instalacao local; o download do atalho (.bat) exige administrador da rede. */
    if ($requestedMode === 'uninstaller-script') {
        $uninstallPath = $nativeRoot . '/Assets/Desinstalar_Arcoll.ps1';
        $uninstallText = is_file($uninstallPath) ? file_get_contents($uninstallPath) : false;
        if (!is_string($uninstallText) || strpos($uninstallText, '__INSTALLER_THEME_BASE64__') === false) throw new RuntimeException('Desinstalador indisponivel no servidor.');
        $palette = base64_encode(json_encode(arc_visual_theme($pdo), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: private, no-store, max-age=0');
        header('X-Content-Type-Options: nosniff');
        exit("\xEF\xBB\xBF" . ltrim(str_replace('__INSTALLER_THEME_BASE64__', $palette, $uninstallText), "\xEF\xBB\xBF"));
    }
    // Nome do arquivo vem da identidade publica definida em admin/configuracoes.
    $downloadBrand = arc_public_settings($pdo);
    $downloadBase = trim((string)($downloadBrand['site_name'] ?? 'Gestor'));
    $downloadBase = preg_replace('/[\\\/:*?"<>|\x00-\x1F]+/u', ' ', $downloadBase) ?? 'Gestor';
    $downloadBase = trim(preg_replace('/\s+/u', ' ', $downloadBase) ?? 'Gestor', ' .');
    $downloadBase = mb_substr($downloadBase !== '' ? $downloadBase : 'Gestor', 0, 70);
    $downloadFilename = static function (string $suffix) use ($downloadBase): string {
        $value = $downloadBase . ' ' . $suffix;
        return 'attachment; filename="' . preg_replace('/[^A-Za-z0-9 ._-]/', '_', $value) . '"; filename*=UTF-8\'\'' . rawurlencode($value);
    };
    if ($requestedMode === 'uninstaller') {
        if (!arc_is_user() && !arc_is_admin()) { header('Location: ../index.php', true, 303); exit; }
        $scriptUrl = str_replace("'", "''", $nativeOrigin . '/api/download-gestor.php?mode=uninstaller-script');
        $psCommand = <<<'PS'
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$p=Join-Path $env:TEMP ('ti-desinstalar-'+[guid]::NewGuid().ToString('N')+'.ps1')
try{Invoke-WebRequest -UseBasicParsing -MaximumRedirection 0 -Uri '__UNINSTALL_URL__' -OutFile $p; & $p}
catch{Add-Type -AssemblyName PresentationFramework;[Windows.MessageBox]::Show('Não foi possível preparar o desinstalador. Verifique a conexão e baixe-o novamente pela plataforma.','T.I. Digital · Desinstalação','OK','Error')|Out-Null;exit 1}
finally{Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue}
PS;
        $psCommand = str_replace('__UNINSTALL_URL__', $scriptUrl, $psCommand);
        $encoded = base64_encode(mb_convert_encoding($psCommand, 'UTF-16LE', 'UTF-8'));
        $bat = "@echo off\r\nsetlocal\r\n" . 'start "" powershell.exe -NoLogo -NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand ' . $encoded . "\r\nexit /b 0\r\n";
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: ' . $downloadFilename('Desinstalar.bat'));
        header('Content-Length: ' . strlen($bat));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        exit($bat);
    }
    // O download oficial e exclusivamente BAT; scripts PS1 sao componentes internos da mesma instalacao.
    if ($requestedMode === '' || $requestedMode === 'bat') {
        if (!arc_is_user() && !arc_is_admin()) { header('Location: ../index.php',true,303); exit; }
        $bootstrap = $nativeOrigin . '/api/download-gestor.php?mode=native-bootstrap&universal=1';
        $urlLiteral=str_replace("'","''",$bootstrap);
        $psCommand=<<<'PS'
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$p=Join-Path $env:TEMP ('ti-gestor-'+[guid]::NewGuid().ToString('N')+'.ps1')
try{Invoke-WebRequest -UseBasicParsing -MaximumRedirection 0 -Uri '__BOOTSTRAP__' -OutFile $p; & $p; if($LASTEXITCODE -ne 0){exit 1}}
catch{Add-Type -AssemblyName PresentationFramework;[Windows.MessageBox]::Show('Não foi possível preparar o instalador. Verifique a conexão e baixe um novo instalador pela plataforma.','T.I. Digital · Instalação','OK','Error')|Out-Null;exit 1}
finally{Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue}
PS;
        $psCommand=str_replace('__BOOTSTRAP__',$urlLiteral,$psCommand);
        $encoded=base64_encode(mb_convert_encoding($psCommand,'UTF-16LE','UTF-8'));
        $launch='powershell.exe -NoLogo -NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand '.$encoded;
        $bat="@echo off\r\nsetlocal\r\n".'start "" '.$launch."\r\nexit /b 0\r\n";
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: ' . $downloadFilename('Install.bat'));
        header('Content-Length: ' . strlen($bat));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store, max-age=0');
        exit($bat);
    }
    // Modos antigos nao podem distribuir o instalador Python descontinuado.
    http_response_code(410);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    exit('Modo antigo descontinuado. Utilize o botao Baixar Gestor para obter o instalador grafico WinUI 3.');
} catch (Throwable $e) {
    // Não exponha detalhes internos para visitantes ou usuários sem privilégio administrativo.
    $incident = strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));
    arc_log_error('Arcoll gestor download [' . $incident . '] ' . get_class($e) . ': ' . $e->getMessage());
    if (isset($zipNative) && $zipNative instanceof ZipArchive) @$zipNative->close();
    if (isset($sourceArchive) && $sourceArchive instanceof ZipArchive) @$sourceArchive->close();
    if (isset($archiveTempFiles) && is_array($archiveTempFiles)) foreach ($archiveTempFiles as $tempEntry) @unlink($tempEntry);
    if (isset($tmpZip) && is_string($tmpZip) && is_file($tmpZip)) @unlink($tmpZip);
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    $message = 'Não foi possível preparar o download do gestor. Referência: ' . $incident . '.';
    if (arc_is_admin()) {
        $message .= "\nDiagnóstico: " . $e->getMessage();
        $message .= "\nVerifique também os registros do servidor e o status da publicação em Administração > Versões.";
    }
    exit($message);
}

