<?php
/* Caminho: api/network-dashboard-actions.php — operações de cadastro e inventário migradas da página aposentada. */
declare(strict_types=1);
require_once __DIR__ . '/../includes/error-logging.php';

require dirname(__DIR__).'/includes/bootstrap.php';
require_once dirname(__DIR__).'/includes/network-inventory.php';
$pdo=arc_db();
arc_ensure_user_schema($pdo);
$admin=arc_is_admin();
$uid=arc_user_id();
if(!$admin && !$uid){header('Location: '.arc_workspace_base_url().'index.php',true,303);exit;}
$role=$admin?'admin':arc_v15_user_role($pdo);
// Convites pendentes são efetivados somente após a identidade do e-mail ser verificada no callback Google.
$arcError='';
$go=static function(string $target): never {
    header('Location: '.arc_workspace_base_url().ltrim($target,'/'),true,303);exit;
};
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=(string)($_POST['action']??'');
    $csrf=(string)($_POST['_csrf']??'');
    if ($csrf==='' || !hash_equals(arc_csrf_token(),$csrf)) {
        $arcError='Sessão expirada. Atualize a página e tente novamente.';
    } elseif ($action==='logout') {
        if(arc_is_user()) arc_user_audit($pdo,'account_logout','Logout');
        unset($_SESSION['arc_user_id'],$_SESSION['arc_user_email'],$_SESSION['arc_admin_id'],$_SESSION['arc_admin_email'],$_SESSION['arc_current_network_id'],$_SESSION['arc_network_monitor_sessions'],$_SESSION['arc_monitor_session'],$_SESSION['arc_csrf']);
        session_regenerate_id(true);
        $go('index.php');
    } elseif ($action === 'network_select' && arc_is_admin()) {
        $id=(int)($_POST['network_id']??0);
        if (!arc_select_network($pdo,$id)) $arcError='Rede não encontrada ou indisponível.';
        else {
            arc_audit($pdo,'admin_network_selected','Administrador #'.(int)arc_admin_id().' abriu rede #'.$id);
            $go('redes/painel.php?network='.$id);
        }
    } elseif (!arc_is_user()) {
        $arcError='Administradores podem consultar redes; criação, exclusão e arquivamento exigem uma conta proprietária.';
    } elseif ($action === 'network_create') {
        $name = trim((string)($_POST['network_name'] ?? ''));

        if ($name === '' || mb_strlen($name) > 100) {
            $arcError = 'Informe um nome para a rede (até 100 caracteres).';
        } else {
            try {
                $networkId=arc_network_create($pdo,(int)arc_user_id(),$_POST,true);
                $q=$pdo->prepare('SELECT site_code FROM '.arc_table('managed_networks').' WHERE id=?');$q->execute([$networkId]);$siteCode=(string)$q->fetchColumn();

                // Preservar a rede ativa e voltar ao Dashboard que iniciou o cadastro.
                $requested=(int)($_POST['return_dashboard_network'] ?? 0);
                $origin=$requested>0 && arc_network_team_access($pdo,$requested,(int)arc_user_id()) ? $requested : (int)(arc_current_network_id()??0);
                if ($origin===0 || !arc_network_team_access($pdo,$origin,(int)arc_user_id())) $origin=$networkId;
                $_SESSION['arc_flash'] = 'Rede registrada com o código ' . $siteCode . '.';
                $go('redes/dashboard.php?network='.$origin);
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                arc_log_error('Arcoll network create: ' . $e->getMessage());
                $arcError = $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível registrar a rede.';
            }
        }

    } elseif ($action === 'network_select') {
        $id = (int)($_POST['network_id'] ?? 0);

        if (!arc_select_network($pdo, $id)) {
            $arcError = 'Não foi possível selecionar essa rede.';
        } else {
            arc_user_audit($pdo, 'network_selected', 'Rede ID ' . $id);
            $_SESSION['arc_flash'] = 'Rede selecionada. Abrindo a gestão solicitada.';
            $go('redes/dashboard.php?network=' . $id);
        }

    } elseif ($action === 'network_delete') {
        $id = (int)($_POST['network_id'] ?? 0);

        if (arc_delete_network($pdo, $id, (int)arc_user_id())) {
            if (arc_current_network_id() === $id) {
                unset($_SESSION['arc_current_network_id']);
            }
            arc_user_audit($pdo, 'network_deleted', 'Rede ID ' . $id);
            $_SESSION['arc_flash'] = 'Rede excluída definitivamente.';
            $go(arc_authenticated_home($pdo) ?? 'redes/dashboard.php');
        }
        $arcError = 'Não foi possível excluir essa rede.';

    } elseif ($action === 'network_archive') {
        $id  = (int)($_POST['network_id'] ?? 0);
        $upd = $pdo->prepare(
            'UPDATE ' . arc_table('managed_networks') . ' SET is_active=0 WHERE id=? AND account_id=? AND is_active=1'
        );
        $upd->execute([$id, arc_user_id()]);

        if ($upd->rowCount()) {
            if (arc_current_network_id() === $id) {
                unset($_SESSION['arc_current_network_id']);
            }
            arc_user_audit($pdo, 'network_archived', 'Rede ID ' . $id);
            $_SESSION['arc_flash'] = 'Rede arquivada.';
            $go(arc_authenticated_home($pdo) ?? 'redes/dashboard.php');
        }
        $arcError = 'Não foi possível arquivar essa rede.';
    }
}

/* Redes e estado calculados pelos gestores aprovados vistos nos últimos 45s. */
$loadPanelNetworks = static function(PDO $pdo, bool $admin, ?int $uid): array {
    $sql='SELECT n.id,n.name,n.is_active,COUNT(a.id) AS gestor_total, '
        .'COALESCE(SUM(CASE WHEN a.last_seen_at >= DATE_SUB(NOW(),INTERVAL '.arc_inventory_presence_seconds().' SECOND) THEN 1 ELSE 0 END),0) AS gestor_online, UNIX_TIMESTAMP(MAX(a.last_seen_at)) AS last_seen_ts '
        .'FROM '.arc_table('managed_networks').' n LEFT JOIN '.arc_table('network_gestores').' a ON a.network_id=n.id AND a.account_id=n.account_id AND a.status=\'approved\'';
    $args=[];
    if (!$admin) { $sql.=' WHERE n.account_id=?';$args[]=(int)$uid; }
    $sql.=' GROUP BY n.id,n.name,n.is_active ORDER BY n.is_active DESC,n.name,n.id';
    $q=$pdo->prepare($sql);$q->execute($args);
    $rows=$q->fetchAll(PDO::FETCH_ASSOC);
    // Redes compartilhadas aparecem no mesmo inventário da conta, sem conceder titularidade.
    if (!$admin && $uid) {
        $sharedSql='SELECT n.id,n.name,n.is_active,m.role,COUNT(a.id) AS gestor_total, '
            .'COALESCE(SUM(CASE WHEN a.last_seen_at >= DATE_SUB(NOW(),INTERVAL '.arc_inventory_presence_seconds().' SECOND) THEN 1 ELSE 0 END),0) AS gestor_online, '
            .'UNIX_TIMESTAMP(MAX(a.last_seen_at)) AS last_seen_ts '
            .'FROM '.arc_table('network_team_members').' m '
            .'JOIN '.arc_table('managed_networks').' n ON n.id=m.network_id AND n.account_id=m.account_id '
            .'LEFT JOIN '.arc_table('network_gestores').' a ON a.network_id=n.id AND a.account_id=n.account_id AND a.status=\'approved\' '
            .'WHERE m.member_user_id=? AND m.enabled=1 AND n.is_active=1 AND n.account_id<>? '
            .'GROUP BY n.id,n.name,n.is_active,m.role ORDER BY n.name,n.id';
        $sharedStmt=$pdo->prepare($sharedSql);
        $sharedStmt->execute([(int)$uid,(int)$uid]);
        foreach ($sharedStmt->fetchAll(PDO::FETCH_ASSOC) as $sharedRow) {
            $sharedRow['shared']=1;
            $rows[]=$sharedRow;
        }
    }
    foreach($rows as &$r){
        $count=(int)$r['gestor_total'];$online=(int)$r['gestor_online'];
        $r['gestor_state']=$count===0?'none':($online===0?'offline':($online===$count?'online':'partial'));
        $r['has_online_gestor']=$online>0?1:0;
    }
    unset($r);
    return $rows;
};
/* Dispositivos inventariados de uma rede (modal compacto). Restrito à titularidade da rede. */
if (($_GET['ajax'] ?? '') === 'network_devices') {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    try {
        require_once dirname(__DIR__).'/includes/network-inventory.php';
        $netId=(int)($_GET['network'] ?? 0);
        $sql='SELECT n.id,n.account_id,n.name,n.is_active,n.monitoring_enabled FROM '.arc_table('managed_networks').' n WHERE n.id=?';
        $args=[$netId];
        if(!$admin){
            $sql.=' AND (n.account_id=? OR EXISTS (SELECT 1 FROM '.arc_table('network_team_members').' tm WHERE tm.account_id=n.account_id AND tm.network_id=n.id AND tm.member_user_id=? AND tm.enabled=1 AND n.is_active=1))';
            $args[]=(int)$uid;$args[]=(int)$uid;
        }
        $q=$pdo->prepare($sql);$q->execute($args);
        $net=$q->fetch(PDO::FETCH_ASSOC);
        if(!$net) arc_json(['ok'=>false,'error'=>'Rede não encontrada.'],404);
        $acc=(int)$net['account_id'];
        $dashboard=arc_inventory_dashboard($pdo,$acc,$netId);
        // A varredura segue a mesma regra da API de comandos: apenas o titular, rede ativa e com monitoramento.
        $canScan=$uid!==null && (int)$net['account_id']===(int)$uid && (int)$net['is_active']===1 && (int)$net['monitoring_enabled']===1;
        $reason='';
        if(!$canScan) $reason=(int)$net['is_active']!==1?'Rede arquivada.':((int)$net['monitoring_enabled']!==1?'Monitoramento desativado para esta rede.':'Somente o titular da rede pode solicitar a varredura.');
        arc_json(['ok'=>true,'name'=>(string)$net['name'],'can_scan'=>$canScan,'scan_reason'=>$reason]+$dashboard);
    } catch(Throwable $e) {
        arc_log_error('Painel dispositivos da rede: '.$e->getMessage());
        arc_json(['ok'=>false,'error'=>'Não foi possível carregar os dispositivos.'],503);
    }
}
if (($_GET['ajax'] ?? '') === 'cnpj_lookup') {
    $cnpj=preg_replace('/\D+/', '', (string)($_GET['cnpj']??''));
    if (strlen($cnpj)!==14) arc_json(['ok'=>false,'error'=>'Informe um CNPJ com 14 dígitos.'],422);
    if (!function_exists('curl_init')) arc_json(['ok'=>false,'error'=>'Consulta indisponível no servidor (extensão cURL ausente).'],503);
    $ch=curl_init('https://brasilapi.com.br/api/cnpj/v1/'.$cnpj);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>8,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_HTTPHEADER=>['Accept: application/json'],CURLOPT_USERAGENT=>'Arcoll-Networks/1.0']);
    $body=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if (!is_string($body)||$http!==200||strlen($body)>150000) arc_json(['ok'=>false,'error'=>'Não foi possível consultar o CNPJ no momento.'],503);
    $data=json_decode($body,true);
    if (!is_array($data)||empty($data['razao_social'])) arc_json(['ok'=>false,'error'=>'CNPJ não encontrado na consulta pública.'],404);
    $fields=['razao_social','nome_fantasia','ddd_telefone_1','ddd_telefone_2','email','cep','uf','logradouro','numero','complemento','bairro','municipio','descricao_situacao_cadastral','cnae_fiscal_descricao','cnae_fiscal','natureza_juridica','data_inicio_atividade'];
    $filtered=[];foreach($fields as $field){$v=$data[$field]??'';$filtered[$field]=is_scalar($v)?mb_substr((string)$v,0,300):'';}
    arc_json(['ok'=>true,'data'=>$filtered]);
}
if (($_GET['ajax'] ?? '') === 'offline_overview') {
    try {
        $rows=[];$onlineCount=0;
        foreach ($loadPanelNetworks($pdo,$admin,$uid) as $net) {
            $isOnline=(int)$net['is_active']===1 && (int)$net['has_online_gestor']===1;
            if ($isOnline) { $onlineCount++; continue; }
            $rows[]=['name'=>(string)$net['name'],'last_seen'=>(int)($net['last_seen_ts']??0),'inactive'=>(int)$net['is_active']!==1,'no_gestor'=>(int)$net['gestor_total']===0];
        }
        arc_json(['ok'=>true,'online'=>$onlineCount,'total'=>$onlineCount+count($rows),'offline'=>$rows,'now'=>time()]);
    } catch(Throwable $e) { arc_log_error('Resumo de redes offline: '.$e->getMessage()); arc_json(['ok'=>false,'error'=>'Não foi possível consultar as redes.'],503); }
}
if (($_GET['ajax'] ?? '') === 'network_status') {
    try {
        $states=[];
        foreach($loadPanelNetworks($pdo,$admin,$uid) as $network) {
            $states[(string)$network['id']]=['online'=>(int)$network['has_online_gestor']===1,'state'=>$network['gestor_state'],'total'=>(int)$network['gestor_total'],'online_count'=>(int)$network['gestor_online']];
        }
        arc_json(['ok'=>true,'networks'=>$states]);
    } catch(Throwable $e) {
        arc_log_error('Painel estado das redes: '.$e->getMessage());
        arc_json(['ok'=>false,'error'=>'Não foi possível atualizar as redes.'],503);
    }
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $_SESSION['arc_flash']=$arcError!==''?$arcError:'Não foi possível concluir a operação.';
    $back=(int)($_POST['return_dashboard_network']??0);
    $go('redes/dashboard.php'.($back>0?'?network='.$back:''));
}
http_response_code(404);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'error'=>'Recurso não encontrado.']);exit;
