// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Collaborators.cs
using System.Text.Json;
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3;
public sealed partial class MainWindow
{
    private sealed record CollaboratorChoice(long Id,string Name,bool Allowed=true){public override string ToString()=>Name;}
    private bool _platformOnline,_platformChecked;
    private LanClientService _lanClient=null!;
    private LanAgentService _lanAgent=null!;
    private RemoteRelayHost _relayHost=null!;
    private LanWebBridge? _lanWebBridge;
    private LanCollaboratorPage? _lanPage;
    private LanRemotePage? _lanRemotePage;
    private readonly Dictionary<long,string> _collaboratorMachines=new();
    /// <summary>Coordenação disponível pela plataforma ou, sem internet, pelo canal local já sincronizado.</summary>
    private bool CoordinationAvailable=>_runtime.IsServer&&(_runtime.Can("coordinate")||_lanClient?.Available==true);
    private bool RemoteAvailable=>true; // A interface gratuita não depende de vínculo; as sessões ainda exigem transporte seguro.
    private LanPeer? LanPeerFor(long id)=>_lanClient?.Available==true&&_collaboratorMachines.TryGetValue(id,out var machine)?_lanClient.Find(machine):null;
    private long _selectedCollaborator;
    private long _collaboratorNetwork;
    private bool _collaboratorRefreshing,_changingCollaborator,_collaboratorClosed;
    private string _localInterfaceSignature="";
    private bool _localConsentOpen;
    private readonly DispatcherTimer _collaboratorClock=new(){Interval=TimeSpan.FromSeconds(15)};
    private CollaboratorWorkspacePage? _collaboratorPage;
    private readonly TextBlock _noLocalTools=new(){Text="Nenhuma ferramenta local foi liberada. Entre em contato com o administrador da rede.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(24)};
    // Ao visualizar outra rede registrada, o perfil do usuário nessa rede decide os menus; caso contrário valem as permissões desta instalação.
    // Em qualquer rede registrada vale o perfil do usuário e o que esta máquina oferece: tudo é executado no computador onde o Gestor está instalado.
    private bool MenuVisibleHere(string key)=>(_runtime.IsServer||_runtime.VisibleLocalMenus.Contains(key))&&_runtime.User.Allows(key);
    private bool CanOpenHere(string key)=>_runtime.IsServer&&_selectedCollaborator>0?_runtime.Can("coordinate"):_runtime.CanOpenLocalMenu(key);
    private bool LocalSystemActions=>_runtime.LocalSystemControls&&_selectedCollaborator==0;
    // Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Collaborators.cs — ícone e nome de até 8 caracteres.
    private static ComboBoxItem CompactCollaboratorOption(CollaboratorChoice choice)
    {
        var machine=choice.Id==0?Environment.MachineName:choice.Name.Split(" · ",StringSplitOptions.None)[0];
        if(machine.StartsWith("Colaborador indisponível",StringComparison.OrdinalIgnoreCase))machine="Indisponível";
        var compact=machine.Length>8?machine[..8]+"...":machine;
        var content=new StackPanel{Orientation=Orientation.Horizontal,Spacing=6};
        content.Children.Add(new FontIcon{Glyph=choice.Id==0?"\uE80F":"\uE716",FontSize=13});
        content.Children.Add(new TextBlock{Text=compact,FontSize=11,VerticalAlignment=VerticalAlignment.Center});
        var option=new ComboBoxItem{Content=content,Tag=choice,IsEnabled=choice.Allowed};
        ToolTipService.SetToolTip(option,(choice.Id==0?"Servidor — ":"Colaborador — ")+choice.Name);
        return option;
    }
    private void InitializeCollaborators()
    {
        _lanClient=new LanClientService(_runtime);_lanAgent=new LanAgentService(_runtime);_lanAgent.Start();_relayHost=new RemoteRelayHost(_runtime);
        _lanWebBridge=new LanWebBridge(_runtime,_lanClient);_lanWebBridge.Start();
        _relayHost.RemoteChanged+=active=>DispatcherQueue.TryEnqueue(()=>{if(active){StatusBar.Title="Acesso remoto";StatusBar.Message="Outro Gestor está acessando este computador pela internet.";StatusBar.Severity=InfoBarSeverity.Warning;StatusBar.IsOpen=true;}else{StatusBar.IsOpen=false;HideRemoteIndicator();_remoteWasActive=false;}});
        _lanAgent.RemoteChanged+=active=>DispatcherQueue.TryEnqueue(()=>{if(active){StatusBar.Title="Acesso remoto";StatusBar.Message="O Gestor Servidor está acessando este computador pela rede local.";StatusBar.Severity=InfoBarSeverity.Warning;StatusBar.IsOpen=true;}else{StatusBar.IsOpen=false;HideRemoteIndicator();_remoteWasActive=false;}});
        Closed+=(_,_)=>{_lanWebBridge?.Dispose();_lanAgent.Dispose();_relayHost.Dispose();_lanPage?.Stop();};
        CollaboratorSelector.Items.Add(CompactCollaboratorOption(new CollaboratorChoice(0,"Este computador — Gestor Servidor")));CollaboratorSelector.SelectedIndex=0;
        CollaboratorSelector.SelectionChanged+=(_,_)=>{if(_changingCollaborator||CollaboratorSelector.SelectedItem is not ComboBoxItem {Tag:CollaboratorChoice item}||!_runtime.IsServer)return;_selectedCollaborator=item.Id;if(item.Id>0&&(_section=="remote"||!Groups.Any(g=>g.Items.Any(i=>i.Key==_section))))_section="panel";_emptyGroupShown=null;_collaboratorPage?.Disable();_lanPage?.Stop();UpdateCategoryVisibility();if(item.Id==0){_collaboratorPage?.Unavailable("Controle deste computador selecionado.");CompactHost.Content=null;}SelectSection(_section);};
        _collaboratorClock.Tick+=async(_,_)=>await RefreshCollaboratorsAsync();_collaboratorClock.Start();
        Closed+=(_,_)=>{_collaboratorClosed=true;_collaboratorClock.Stop();_collaboratorPage?.Disable();};ApplyLocalInterface();
    }
    private async Task RefreshCollaboratorsAsync()
    {
        if(_collaboratorClosed||_collaboratorRefreshing||!CoordinationAvailable)return;_collaboratorRefreshing=true;
        try{
            using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(15));
            JsonElement data=default;var platformOk=false;
            if(_runtime.Can("coordinate")){
                try{data=await _runtime.Platform.PostAsync("gestor-workspace",_runtime.Platform.WithCredentials(("op","collaborators")),timeout.Token,12);platformOk=true;}
                catch(Exception error) when(error is PlatformException or HttpRequestException or OperationCanceledException){RuntimeLog.Write("Lista de colaboradores (plataforma): "+error.Message);}
            }
            // A descoberta pela rede local funciona sem internet e complementa a lista da plataforma.
            try{await _lanClient.DiscoverAsync(timeout.Token);}catch(Exception error) when(error is OperationCanceledException or InvalidOperationException){RuntimeLog.Write("Descoberta na rede local: "+error.Message);}
            _platformOnline=platformOk;if(_runtime.Can("coordinate"))_platformChecked=true;
            if(_collaboratorClosed||!_runtime.IsServer)return;
            var choices=new List<CollaboratorChoice>{new(0,"Este computador — Gestor Servidor")};var machines=new Dictionary<long,string>();var matched=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if(platformOk){
                _collaboratorNetwork=data.GetProperty("network_id").GetInt64();
                if(data.TryGetProperty("poll_seconds",out var interval))_collaboratorClock.Interval=TimeSpan.FromSeconds(Math.Clamp(interval.GetInt32(),3,120));
                foreach(var item in data.GetProperty("devices").EnumerateArray()){
                    var id=item.GetProperty("id").GetInt64();var name=item.GetProperty("machine_name").GetString()??"Computador";var approved=item.GetProperty("status").GetString()=="approved";
                    var peer=_lanClient.Find(name);if(peer is not null){matched.Add(name);machines[id]=name;}
                    var state=approved?(item.GetProperty("online").GetBoolean()?"Online":"Offline"):"Não autorizado";
                    choices.Add(new(id,name+" · "+state+(peer is not null?" · Rede local":""),approved||peer is not null));
                }
            }
            foreach(var peer in _lanClient.Peers.Where(p=>!matched.Contains(p.Machine))){choices.Add(new(peer.SyntheticId,peer.Machine+" · Rede local",true));machines[peer.SyntheticId]=peer.Machine;}
            _collaboratorMachines.Clear();foreach(var pair in machines)_collaboratorMachines[pair.Key]=pair.Value;
            var selected=choices.FirstOrDefault(c=>c.Id==_selectedCollaborator);
            if(selected is null&&_selectedCollaborator>0){selected=new(_selectedCollaborator,"Colaborador indisponível — "+_selectedCollaborator,false);choices.Add(selected);}
            _changingCollaborator=true;try{CollaboratorSelector.Items.Clear();foreach(var item in choices)CollaboratorSelector.Items.Add(CompactCollaboratorOption(item));CollaboratorSelector.SelectedIndex=choices.FindIndex(c=>c.Id==_selectedCollaborator);}finally{_changingCollaborator=false;}
            CollaboratorSelector.IsEnabled=true;
            if(selected is {Allowed:false})_collaboratorPage?.Unavailable("O Colaborador selecionado não está autorizado. Escolha outro computador; o alvo não foi alterado automaticamente.");
        }catch(Exception error) when(error is not OperationCanceledException){RuntimeLog.Write("Lista de colaboradores: "+error.Message);ToolTipService.SetToolTip(CollaboratorSelector,"Não foi possível atualizar a lista: "+error.Message);}
        finally{_collaboratorRefreshing=false;}
    }
    private void ApplyLocalInterface()
    {
        if(_collaboratorClosed)return;
        var signature=_runtime.InstallationRole+":"+string.Join(",",_runtime.VisibleLocalMenus.OrderBy(key=>key))+":"+_runtime.AlwaysBackground+":"+_runtime.User.Signature;
        var hasTools=_runtime.IsServer||_runtime.HasLocalTools;
        // O cabeçalho substitui a Title Bar e fica sempre visível (arrastar, minimizar e fechar); sem ferramentas somem apenas as categorias.
        QuickBar.Visibility=Visibility.Visible;CategoryBar.Visibility=hasTools?Visibility.Visible:Visibility.Collapsed;CategoryTabs.Visibility=hasTools?Visibility.Visible:Visibility.Collapsed;RibbonBar.Visibility=hasTools&&!(_section=="remote"&&_remoteSubmenusHidden)?Visibility.Visible:Visibility.Collapsed;DockToggleButton.Visibility=hasTools?Visibility.Visible:Visibility.Collapsed;
        BellButton.Visibility=_runtime.IsServer&&!IsNarrowWindow?Visibility.Visible:Visibility.Collapsed;
        ServerRemoteButton.Visibility=_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;ServerRemoteButton.IsEnabled=RemoteAvailable;
        // O olho do Colaborador abre diretamente sua tela de código de acesso remoto.
        RemoteButton.Visibility=!_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;RemoteButton.IsEnabled=!_runtime.IsServer;
        CollaboratorSelector.Visibility=_runtime.IsServer&&!IsNarrowWindow?Visibility.Visible:Visibility.Collapsed;CollaboratorSelector.IsEnabled=CoordinationAvailable;
        StatusBorder.Visibility=Visibility.Visible;
        _tray.SetLocalControls(_runtime.IsServer,!_runtime.AlwaysBackground);
        _tray.SetToolCatalog(Groups.SelectMany(g=>g.Items.Where(i=>MenuVisibleHere(i.Key)).Select(i=>(g.Label,i.Label,i.Key))));
        if(!_runtime.IsServer){_selectedCollaborator=0;if(_localInterfaceSignature!=signature)_collaboratorPage?.Disable();}
        if(_runtime.AlwaysBackground&&!_localConsentOpen)AppWindow.Hide();
        if(signature==_localInterfaceSignature)return;_localInterfaceSignature=signature;ApplyRemoteOnlyWindow();
        _penteFinoPage.CancelOperations();foreach(var page in _tools.Values)page.CancelOperations();_programsPage.CancelOperations();
        UpdateCategoryVisibility();
        // O Colaborador sempre inicia na tela que exibe o código LAN/remoto.
        // O restante dos menus continua disponível após a navegação explícita.
        if(!_runtime.IsServer&&_section=="panel"&&!_runtime.User.ViewingOther){ShowCollaboratorHome();return;}
        if(!_runtime.IsServer&&!_runtime.HasLocalTools&&!_runtime.User.ViewingOther){ShowCollaboratorHome();return;}
        var allowed=Groups.SelectMany(g=>g.Items).FirstOrDefault(i=>MenuVisibleHere(i.Key)&&_runtime.CanOpenLocalMenu(i.Key));
        if(!MenuVisibleHere(_section)){if(allowed is not null)SelectSection(allowed.Key);else ShowCollaboratorHome();}
        else if(_menus.Count>0&&!(_section=="remote"&&_remoteSubmenusHidden)){BuildRibbon(_section=="remote"?Groups.First(g=>g.Key==_group):ResolveGroup(_section));ApplyTheme(_themes.Current);}
        if(_runtime.IsServer)_=RefreshCollaboratorsAsync();
    }
    private bool _remoteOnlyCompact;
    /// <summary>Colaborador com perfil somente de acesso remoto: a janela do código fica pequena e ancorada no canto da tela; ao ganhar outras ferramentas volta ao tamanho normal.</summary>
    private void ApplyRemoteOnlyWindow()
    {
        var compact=!_runtime.IsServer&&!_runtime.HasLocalTools;
        if(compact==_remoteOnlyCompact)return;
        _remoteOnlyCompact=compact;
        try{
            var work=Microsoft.UI.Windowing.DisplayArea.GetFromWindowId(AppWindow.Id,Microsoft.UI.Windowing.DisplayAreaFallback.Primary).WorkArea;
            if(compact){
                var width=Math.Max(380,Math.Min(460,work.Width-24));var height=Math.Max(420,Math.Min(640,work.Height-40));
                AppWindow.Resize(new Windows.Graphics.SizeInt32(width,height));
                AppWindow.Move(new Windows.Graphics.PointInt32(work.X+work.Width-width-16,work.Y+work.Height-height-16));
            }else ApplyDockLayout(true);
        }catch(Exception error){RuntimeLog.Write("Janela compacta do acesso remoto: "+error.Message);}
    }
    private bool _remoteSubmenusHidden;
    private void SetRemoteNavigation()
    {
        _remoteSubmenusHidden=true;_group="";
        var hasMenus=_runtime.IsServer||_runtime.HasLocalTools;
        CategoryBar.Visibility=CategoryTabs.Visibility=hasMenus?Visibility.Visible:Visibility.Collapsed;
        RibbonBar.Visibility=Visibility.Collapsed;
        UpdateCategoryVisibility();
    }
    private void OpenRemoteCategory(MenuGroup group)
    {
        _remoteSubmenusHidden=false;_group=group.Key;_emptyGroupShown=group.Key;
        RibbonBar.Visibility=Visibility.Visible;BuildRibbon(group);ApplyTheme(_themes.Current);
    }
    private void ShowCollaboratorHome()
    {
        _section="remote";PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;SetRemoteNavigation();
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
        // A tela de código é a entrada principal do Colaborador; permissões são validadas no momento de gerar/usar o código.
        var showCode=!_runtime.IsServer;var target=showCode?(object)_remoteAccessPage:_noLocalTools;
        if(!ReferenceEquals(CompactHost.Content,target))CompactHost.Content=target;
    }
    private bool TryShowCollaborator(string section)
    {
        if(!_runtime.IsServer||_selectedCollaborator<=0)return false;
        if(!CoordinationAvailable){_collaboratorPage?.Unavailable("Coordenação não autorizada para este Servidor.");return true;}
        var item=Groups.SelectMany(g=>g.Items).FirstOrDefault(i=>i.Key==section)??Groups[0].Items[0];_section=item.Key;_group=ResolveGroup(item.Key).Key;_lastSection[_group]=item.Key;
        if(CollaboratorSelector.SelectedItem is ComboBoxItem selected&&selected.Tag is CollaboratorChoice {Allowed:false})return true;
        PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
        // Mesma rede local: abre o Gestor do Colaborador direto, sem página web e sem internet.
        // Com a plataforma disponível abre o mesmo layout da plataforma; sem internet, usa o canal direto da rede local.
        // A presença na plataforma não deve desviar uma máquina que já foi descoberta na LAN.
        // O canal local é determinístico e não deve abrir o workspace web como fallback.
        var peer=LanPeerFor(_selectedCollaborator);
        // Com a plataforma disponível o Colaborador abre COMPLETO (mesmas ferramentas do Gestor, aplicadas na máquina dele).
        // A tela LAN simplificada (lista de comandos) só serve de contingência quando a plataforma está inacessível.
        if(_runtime.Can("coordinate")&&_collaboratorNetwork<=0&&!_platformChecked){
            _collaboratorPage??=new CollaboratorWorkspacePage(_runtime);_collaboratorPage.Unavailable("Conectando à plataforma para abrir o Gestor do Colaborador...");CompactHost.Content=_collaboratorPage;
            BuildRibbon(ResolveGroup(item.Key));ApplyTheme(_themes.Current);_=ReopenCollaboratorAfterRefreshAsync(section);return true;
        }
        var platformPreferred=_runtime.Can("coordinate")&&_collaboratorNetwork>0&&(_platformOnline||!_platformChecked);
        if(peer is not null && !platformPreferred){
            _lanPage??=new LanCollaboratorPage(_runtime,_lanClient,OpenLanRemote);_lanPage.Show(peer,item.Key);CompactHost.Content=_lanPage;
            BuildRibbon(ResolveGroup(item.Key));ApplyTheme(_themes.Current);return true;
        }
        _collaboratorPage??=new CollaboratorWorkspacePage(_runtime);
        if(!_runtime.Can("coordinate")||_collaboratorNetwork<=0){_collaboratorPage.Unavailable("Este Colaborador não foi encontrado na rede local e a plataforma está sem conexão.");CompactHost.Content=_collaboratorPage;return true;}
        CompactHost.Content=_collaboratorPage;
        BuildRibbon(ResolveGroup(item.Key));ApplyTheme(_themes.Current);
        _=_collaboratorPage.NavigateAsync(_collaboratorNetwork,_selectedCollaborator,item.File,item.Query);return true;
    }
    /// <summary>Primeira seleção logo após abrir o Gestor: aguarda a lista da plataforma e reabre a mesma ferramenta no Colaborador.</summary>
    private async Task ReopenCollaboratorAfterRefreshAsync(string section)
    {
        for(var i=0;_collaboratorRefreshing&&i<60;i++)await Task.Delay(250);
        await RefreshCollaboratorsAsync();
        if(_collaboratorClosed||!_runtime.IsServer||_selectedCollaborator<=0)return;
        if(_collaboratorNetwork>0||_platformChecked)DispatcherQueue.TryEnqueue(()=>SelectSection(section));
    }
    /// <summary>Ícone de olho: abre a área de acesso remoto; a conexão por código fica dentro da própria área.</summary>
    private void ServerRemote_Click(object sender,RoutedEventArgs e) => ShowRemoteArea();
    /// <summary>Acesso por código em qualquer máquina, de qualquer rede: tenta a rede local (funciona sem internet), depois o relé HTTPS (Gestor gratuito ou vinculado, sem páginas da plataforma) e, só para contas vinculadas, a sessão web da plataforma.</summary>
    private async Task ConnectRemoteByCodeAsync(string code)
    {
        var lanAvailable=_lanClient.Available;var relayAvailable=RemoteRelay.Available;var webAvailable=_runtime.IsServer?_runtime.Can("coordinate"):_runtime.Can("support");
        if(!lanAvailable&&!relayAvailable&&!webAvailable)throw new InvalidOperationException("O acesso remoto por código exige conexão com o servidor. Reinstale o Gestor pelo painel para restaurar o endereço do servidor.");
        var lanReason="";
        if(lanAvailable)
        {
            (LanPeer Peer,string Token)? found=null;
            try
            {
                using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(12));
                found=await _lanClient.BeginRemoteAsync(code,timeout.Token);
            }
            catch(Exception error) when(error is InvalidOperationException or OperationCanceledException or InvalidDataException or IOException or System.Net.Sockets.SocketException)
            {lanReason=error.Message;RuntimeLog.Write("Acesso remoto por código (rede local): "+error.Message);}
            // A máquina que reconheceu o código está na rede local: a sessão abre por ela, sem internet.
            if(found is {} hit){await OpenLanRemoteSessionAsync(hit.Peer,hit.Token);return;}
        }
        var relayReason="";
        if(relayAvailable)
        {
            try
            {
                using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(180));
                var session=await RemoteRelay.ConnectAsync(code,message=>DispatcherQueue.TryEnqueue(()=>_remoteAccessPage.ShowStatus(message)),timeout.Token);
                await OpenRelayRemoteSessionAsync(session);return;
            }
            catch(RelayException error) when(error.NotFound&&webAvailable){relayReason=error.Message;}
            catch(HttpRequestException error){RuntimeLog.Write("Acesso remoto por código (internet): "+error.Message);throw new InvalidOperationException("Sem conexão com o servidor de acesso remoto. Verifique a internet.");}
            catch(OperationCanceledException){throw new InvalidOperationException("O computador acessado não respondeu a tempo.");}
        }
        if(!webAvailable)throw new InvalidOperationException(lanReason.Length>0&&!relayAvailable?"Não foi possível abrir a sessão: "+lanReason:"Código inválido ou expirado.");
        _=relayReason;
        await ConnectRemoteOverInternetAsync(code,lanReason);
    }
    /// <summary>Código de uma máquina fora da rede local: a plataforma valida o código e cria a sessão pela internet (mesma tela de acesso remoto da plataforma).</summary>
    private async Task ConnectRemoteOverInternetAsync(string code,string lanReason)
    {
        // Servidor conhece a rede pela lista de Colaboradores; Colaborador deixa a plataforma resolver a rede pelo código (qualquer máquina da conta).
        if(_runtime.IsServer)
        {
            if(_collaboratorNetwork<=0)await RefreshCollaboratorsAsync();
            if(_collaboratorNetwork<=0||!_platformOnline)throw new InvalidOperationException("Código não encontrado na rede local e a plataforma está sem conexão com a internet."+(lanReason.Length>0?" ("+lanReason+")":""));
        }
        if(_collaboratorPage is null){_collaboratorPage=new CollaboratorWorkspacePage(_runtime);}
        _collaboratorPage.BackRequested-=BackFromRemoteWeb;_collaboratorPage.BackRequested+=BackFromRemoteWeb;
        if(!_runtime.IsServer)ExpandWindowForRemoteSession();
        _section="remote";_group="";_lastSection["remote"]="remote";
        PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;RibbonBar.Visibility=Visibility.Collapsed;SetRemoteNavigation();
        CompactHost.Content=_collaboratorPage;SetProPreview("remote");ApplyTheme(_themes.Current);
        await _collaboratorPage.NavigateAsync(_runtime.IsServer?_collaboratorNetwork:0,0,"remoto","connect_code=1&code="+Uri.EscapeDataString(code));
        // Sessão web aberta: o botão da tela de acesso remoto volta à tela do código quando a sessão termina.
    }
    private void BackFromRemoteWeb()
    {
        if(_runtime.IsServer){ShowRemoteArea();return;}
        _remoteOnlyCompact=false;ShowCollaboratorHome();ApplyRemoteOnlyWindow();
    }
    /// <summary>Colaborador: a janela compacta do código cresce para exibir a tela remota e volta ao canto ao encerrar.</summary>
    private void ExpandWindowForRemoteSession()
    {
        try{
            var work=Microsoft.UI.Windowing.DisplayArea.GetFromWindowId(AppWindow.Id,Microsoft.UI.Windowing.DisplayAreaFallback.Primary).WorkArea;
            var width=(int)(work.Width*.8);var height=(int)(work.Height*.8);
            AppWindow.Resize(new Windows.Graphics.SizeInt32(width,height));
            AppWindow.Move(new Windows.Graphics.PointInt32(work.X+(work.Width-width)/2,work.Y+(work.Height-height)/2));
        }catch(Exception error){RuntimeLog.Write("Janela da sessão remota: "+error.Message);}
    }
    private void ShowRemoteArea()
    {
        if(!_runtime.IsServer)return;
        _section="remote";_group="";_lastSection["remote"]="remote";
        PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;RibbonBar.Visibility=Visibility.Collapsed;SetRemoteNavigation();
        CompactHost.Content=_remoteAccessPage;SetProPreview("remote");ApplyTheme(_themes.Current);
    }
    /// <summary>Pedido de acesso remoto vindo da tela do Colaborador na rede local: abre o campo de código na própria tela de Acesso remoto.</summary>
    private void OpenLanRemote(LanPeer peer)
    {
        if(!_runtime.IsServer||!RemoteAvailable)return;
        ShowRemoteArea();_remoteAccessPage.OpenCodeEntry(peer.Machine);
    }
    // Remote history references a discovered machine, never the last session's token.
    private async Task ReconnectRecentAsync(string machine)
    {
        if (!_runtime.IsServer || !RemoteAvailable) throw new InvalidOperationException("Acesso remoto não autorizado para este Servidor.");
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(95));
        await _lanClient.DiscoverAsync(timeout.Token);
        var peer = _lanClient.Find(machine) ?? throw new InvalidOperationException("O Colaborador não foi encontrado na rede local.");
        var token = await _lanClient.ReconnectAsync(peer, timeout.Token);
        await OpenLanRemoteSessionAsync(peer, token);
    }

    /// <summary>Prepara a área da tela remota (LAN ou internet), reutilizando a mesma página e o mesmo layout.</summary>
    private LanRemotePage PrepareRemotePage()
    {
        if(_lanRemotePage is null){_lanRemotePage=new LanRemotePage(_lanClient);_lanRemotePage.FullscreenRequested+=on=>DispatcherQueue.TryEnqueue(()=>SetRemoteFullscreen(on));_lanRemotePage.Closed+=()=>DispatcherQueue.TryEnqueue(()=>{if(!ReferenceEquals(CompactHost.Content,_lanRemotePage))return;if(_runtime.IsServer)SelectSection(_section);else BackFromRemoteWeb();});}
        if(!_runtime.IsServer&&!_lanRemotePage.IsActive)ExpandWindowForRemoteSession();
        PageHost.Content=null;HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;CompactHost.Visibility=Visibility.Visible;CompactHost.Content=_lanRemotePage;
        UnbindPageData();PageLoader.Suspend();PageLoadingOverlay.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
        return _lanRemotePage;
    }
    private async Task OpenLanRemoteSessionAsync(LanPeer peer,string token)
    {
        if(token.Length==0)throw new InvalidOperationException("Sessão remota recusada pelo Colaborador.");
        var page=PrepareRemotePage();
        if (page.IsActive) return;
        await page.StartAsync(peer,token);
        _remoteAccessPage.RememberRecent(peer.Machine);
    }
    /// <summary>Sessão por código pela internet: a tela remota abre na própria interface do Gestor, não em página da plataforma.</summary>
    private async Task OpenRelayRemoteSessionAsync(RelaySession session)
    {
        var page=PrepareRemotePage();
        if (page.IsActive) return;
        await page.StartRelayAsync(session);
    }
}
