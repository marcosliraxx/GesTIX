// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.BottomNav.cs
// Menu inferior no estilo aplicativo mobile para a janela compacta (Servidor e Colaborador): 4–5 atalhos, Painel ao centro e "Mais".
// Reaproveita as mesmas permissões, favoritos e navegação do menu superior; some automaticamente quando a janela é expandida.
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;

namespace Arcoll.WinUI3;

public sealed partial class MainWindow
{
    private const double BottomNavMaxWidth = 620;
    private readonly Dictionary<string, (Button Button, TextBlock Label, PathIcon Icon, Border? Disc)> _bottomItems = new();
    private string _bottomSignature = "";
    private readonly List<Border> _bottomDividers = new();

    /// <summary>Mostra o menu inferior apenas em largura compacta; em janela expandida volta somente o menu superior.</summary>
    private void AdaptBottomNav(double width)
    {
        if (BottomNav is null) return;
        var collaboratorHome = !_runtime.IsServer && !_runtime.HasLocalTools;
        var show = width < BottomNavMaxWidth && !collaboratorHome;
        BottomNav.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        // Em largura compacta a barra superior ganha altura menor para sobrar área útil ao conteúdo.
        QuickBar.Height = double.NaN;
        if (show) RebuildBottomNav();
    }

    /// <summary>Rodapé reduzido = todos os submenus de Início (favoritos incluídos), Painel como bolha central; excedente de 6 vai para "Mais".</summary>
    private (MenuItem? Panel, MenuItem[] Shown, MenuItem[] Overflow) BottomLayout()
    {
        var home = Groups.First(g => g.Key == "home");
        var items = home.Items
            .Where(i => i.Key != "remote" && MenuVisibleHere(i.Key)).DistinctBy(i => i.Key).ToArray();
        var panel = items.FirstOrDefault(i => i.Key == FixedMenuKey);
        var others = items.Where(i => i.Key != FixedMenuKey).ToArray();
        var more = others.Length > 6;
        var shown = others.Take(more ? 5 : 6).ToArray();
        return (panel, shown, others.Skip(shown.Length).ToArray());
    }
    private bool BottomNavActive => IsNarrowWindow && (_runtime.IsServer || _runtime.HasLocalTools);

    private void RebuildBottomNav()
    {
        try
        {
            var (panel, shown, rest) = BottomLayout();
            var needMore = rest.Length > 0;
            var signature = string.Join("|", shown.Select(i => i.Key)) + "#" + (panel?.Key ?? "") + "#" + string.Join("|", rest.Select(i => i.Key)) + "#" + _runtime.IsServer + "#" + (_systemDashboardLogo is null ? "0" : "1");
            if (signature == _bottomSignature && BottomNavGrid.Children.Count > 0) { PaintBottomNav(Palette.From(_themes.Current)); return; }
            _bottomSignature = signature;
            BottomNavGrid.Children.Clear(); BottomNavGrid.ColumnDefinitions.Clear(); _bottomItems.Clear();

            // Os dois lados do Painel têm sempre o mesmo número de colunas: a bolha central fica exatamente no meio,
            // como na barra de um aplicativo de celular (colunas vazias completam o lado menor).
            var side = new List<object>(shown);
            if (needMore) side.Add("more");
            var half = panel is null ? side.Count : (side.Count + 1) / 2;
            var left = side.Take(half).ToList();
            var right = side.Skip(half).ToList();
            var slots = new List<object?>();
            if (panel is null) slots.AddRange(side);
            else
            {
                var sideColumns = Math.Max(left.Count, right.Count);
                slots.AddRange(left); for (var i = left.Count; i < sideColumns; i++) slots.Add(null);
                slots.Add(panel);
                slots.AddRange(right); for (var i = right.Count; i < sideColumns; i++) slots.Add(null);
            }

            _bottomDividers.Clear();
            for (var index = 0; index < slots.Count; index++)
            {
                BottomNavGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                if (slots[index] is null) continue;
                var element = slots[index] is MenuItem item ? BottomButton(item, item.Key == FixedMenuKey) : BottomMoreButton(rest);
                Grid.SetColumn(element, index); BottomNavGrid.Children.Add(element);
                // Linha vertical entre menus vizinhos do rodapé (nunca depois do último item).
                if (index + 1 < slots.Count && slots[index + 1] is not null)
                {
                    var divider = new Border { Width = 1, Margin = new Thickness(0, 12, -1, 12), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Stretch, IsHitTestVisible = false };
                    Canvas.SetZIndex(divider, 1); Grid.SetColumn(divider, index); BottomNavGrid.Children.Add(divider); _bottomDividers.Add(divider);
                }
            }
            PaintBottomNav(Palette.From(_themes.Current));
        }
        catch (Exception ex) { RuntimeLog.Write("Menu inferior: " + ex.Message); }
    }

    private Button BottomButton(MenuItem item, bool center)
    {
        var icon = WorkspaceIcon(item.Icon, center ? 22 : 20);
        var label = new TextBlock { Text = item.Label, FontSize = 9.5, MaxLines = 1, TextTrimming = TextTrimming.CharacterEllipsis, HorizontalAlignment = HorizontalAlignment.Center, TextAlignment = TextAlignment.Center };
        UIElement glyph = icon; Border? disc = null;
        if (center)
        {
            // Botão central: bolha flutuante com a logo da rede registrada (ou o ícone do Painel quando não há logo).
            if (_systemDashboardLogo is not null)
            {
                disc = new Border { Width = 46, Height = 46, CornerRadius = new CornerRadius(23), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 2, 0, 0), BorderThickness = new Thickness(0), Padding = new Thickness(0), Tag = "logo",
                    Background = new ImageBrush { ImageSource = _systemDashboardLogo, Stretch = Stretch.UniformToFill } };
            }
            else
            {
                disc = new Border { Width = 40, Height = 40, CornerRadius = new CornerRadius(20), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 2, 0, 0), Child = icon };
                icon.HorizontalAlignment = HorizontalAlignment.Center; icon.VerticalAlignment = VerticalAlignment.Center;
            }
            glyph = disc;
        }
        var content = new StackPanel { Orientation = Orientation.Vertical, Spacing = center ? 1 : 3, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        content.Children.Add(glyph); content.Children.Add(label);
        var button = new Button
        {
            Tag = item.Key, Content = content, Style = (Style)RootGrid.Resources["FlatButton"], HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch,
            MinWidth = 0, MinHeight = 64, Padding = new Thickness(2, 3, 2, 2), CornerRadius = new CornerRadius(10), IsEnabled = CanOpenHere(item.Key)
        };
        AutomationProperties.SetName(button, item.Label); AutomationProperties.SetAutomationId(button, "bottom-" + (item.Key == "speed" ? "internet" : item.Key));
        ToolTipService.SetToolTip(button, item.Label);
        button.Click += Menu_Click;
        _bottomItems[item.Key] = (button, label, icon, disc);
        return button;
    }

    private Button BottomMoreButton(MenuItem[] rest)
    {
        var icon = new FontIcon { Glyph = "\uE712", FontSize = 18 };
        var label = new TextBlock { Text = "Mais", FontSize = 9.5, HorizontalAlignment = HorizontalAlignment.Center };
        var content = new StackPanel { Orientation = Orientation.Vertical, Spacing = 3, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        content.Children.Add(icon); content.Children.Add(label);
        var button = new Button { Content = content, Style = (Style)RootGrid.Resources["FlatButton"], HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch, MinWidth = 0, MinHeight = 64, Padding = new Thickness(2, 3, 2, 2), CornerRadius = new CornerRadius(10) };
        AutomationProperties.SetName(button, "Mais opções"); AutomationProperties.SetAutomationId(button, "bottom-more");
        var flyout = new MenuFlyout { Placement = Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.Top };
        string? lastGroup = null;
        foreach (var item in rest)
        {
            var group = GroupKeyOf(item.Key);
            if (lastGroup is not null && group != lastGroup) flyout.Items.Add(new MenuFlyoutSeparator());
            lastGroup = group;
            var entry = new MenuFlyoutItem { Text = item.Label, Icon = WorkspaceIcon(item.Icon, 16), IsEnabled = CanOpenHere(item.Key) };
            var key = item.Key; entry.Click += (_, _) => QueueSectionNavigation(key);
            flyout.Items.Add(entry);
        }
        button.Flyout = flyout; button.IsEnabled = rest.Length > 0;
        _bottomItems["__more"] = (button, label, new PathIcon(), null);
        _bottomMoreIcon = icon;
        return button;
    }
    private FontIcon? _bottomMoreIcon;
    private Microsoft.UI.Xaml.Media.ImageSource? _networkLogo;
    private Microsoft.UI.Xaml.Media.ImageSource? _systemDashboardLogo=new Microsoft.UI.Xaml.Media.Imaging.BitmapImage(new Uri("ms-appx:///Assets/system.ico"));

    /// <summary>Cores do menu inferior: item da página aberta em destaque; os demais em tom neutro.</summary>
    private void PaintBottomNav(Palette p)
    {
        if (BottomNav is null) return;
        var areas = AreaColors();
        BottomNav.Background = ThemeService.Brush(areas.Area3);
        BottomNav.BorderBrush = ThemeService.Brush(areas.Line);
        var transparent = new SolidColorBrush(Microsoft.UI.Colors.Transparent);
        var dividerBrush = p.Line;
        foreach (var divider in _bottomDividers) divider.Background = dividerBrush;
        foreach (var (key, entry) in _bottomItems)
        {
            if (key == "__more") { entry.Label.Foreground = p.Muted; if (_bottomMoreIcon is not null) _bottomMoreIcon.Foreground = p.Muted; continue; }
            var selected = key == _section;
            var ink = selected ? p.Accent : p.Muted;
            entry.Button.Background = selected && entry.Disc is null ? ThemeService.Brush(GestorAreaPalette.Mix(areas.Area3, areas.Accent, .14)) : transparent;
            entry.Label.Foreground = selected ? p.Text : p.Muted; entry.Label.FontWeight = selected ? Microsoft.UI.Text.FontWeights.SemiBold : Microsoft.UI.Text.FontWeights.Normal;
            if (entry.Disc is not null)
            {
                if (entry.Disc.Tag as string == "logo") { entry.Disc.Background = new ImageBrush { ImageSource = _systemDashboardLogo, Stretch = Stretch.UniformToFill }; entry.Disc.BorderThickness = new Thickness(0);entry.Disc.Padding=new Thickness(0); }
                else { entry.Disc.Background = p.Accent; entry.Icon.Foreground = InkOn(p.Accent); }
            }
            else entry.Icon.Foreground = ink;
        }
    }
}
