// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.xaml.cs
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;
using Arcoll.WinUI3.Models;
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Arcoll.WinUI3.Services.BackupCenter;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI.Windowing;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage.Streams;
namespace Arcoll.WinUI3;

public sealed partial class MainWindow : Window
{
    private readonly GestorClient _gestor = new();
    private readonly ThemeService _themes = new();
    private readonly PresenceService _presence = new();
    private readonly GestorRuntime _runtime = new();
    private readonly TelemetryHub _hub = new();
    private readonly TrayService _tray = new();
    private AuthState _trayLast = AuthState.Checking;
    private readonly ServerPage _serverPage;

    private readonly DashboardPage _dashboardPage;
    private readonly PenteFinoPage _penteFinoPage;
    private readonly CloudPage _backupPage;
    private readonly CloudBackupPage _backupSyncPage;
    private readonly CloudConfigPage _cloudConfigPage;
    private Task<bool> ConfirmBackupSyncAsync(string title, string message, string action) => ConfirmAsync(title, message, action);
    private readonly BackupBackgroundLoop _backupLoop;
    private readonly CloudSyncService _cloudSync;
    private readonly SpeedPage _speedPage;
    private readonly DevicesPage _devicesPage;
    private readonly MapPage _mapPage;
    private readonly ProgramsPage _programsPage;
    private readonly NetworkDashboardPage _networkDashboardPage;
    private readonly Dictionary<string, MaintenancePage> _tools = new();
    private readonly WindowsUpdatePage _windowsUpdatePage;
    private readonly FilesPage _filesPage;
    private readonly SupportPage _supportPage;
    private readonly TicketsPage _ticketsPage;
    private readonly AgendaPage _agendaPage;
    private readonly RemoteAccessPage _remoteAccessPage;
    private readonly DispatcherTimer _refreshTimer = new() { Interval = TimeSpan.FromSeconds(45) };
    // Indicador discreto de acesso ativo no canto inferior direito; encerramento exige confirmação local.
    private Window? _remoteIndicator;
    private Button? _remoteEyeButton;
    private bool _remoteWasActive;
    private bool _remoteEyeBlink;
    // O indicador pertence somente ao computador que RECEBE a conexão.
    // Uma sessão de visualização iniciada neste Gestor nunca aciona o olho local.
    private bool AnyRemoteSessionActive => _runtime.IsRemoteSessionActive || _lanAgent?.RemoteActive == true || _relayHost?.RemoteActive == true;
    private const uint WdaExcludeFromCapture = 0x00000011;
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetWindowDisplayAffinity(IntPtr window, uint affinity);
    private readonly DispatcherTimer _remoteIndicatorTimer = new() { Interval = TimeSpan.FromMilliseconds(650) };
    private readonly DispatcherTimer _themeTimer = new() { Interval = TimeSpan.FromSeconds(30) };
    private DateTime _lastBrand = DateTime.MinValue;
    private bool _branding, _remoteDialog, _refreshing, _exiting;
    private string _section = "dashboard", _brandSite = "";
    // Catálogo único: categoria, navegação, seleção visual e acessibilidade usam as mesmas definições.
    private sealed record MenuItem(string Key, string Label, string Icon, int Band = 0, string File = "", bool Platform = false, string Query = "");
    private sealed record MenuGroup(string Key, string Label, string Icon, MenuItem[] Items);
    // O catalogo faz parte do executavel: uma copia externa ausente nao pode impedir a abertura.
    private static JsonDocument OpenWorkspaceMenu()
    {
        var menuPath = Path.Combine(AppContext.BaseDirectory, "Assets", "workspace-menu.json");
        try
        {
            if (File.Exists(menuPath))
                return JsonDocument.Parse(File.ReadAllText(menuPath));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException)
        {
            RuntimeLog.Write("Catalogo externo de navegacao indisponivel; usando recurso interno: " + ex.Message);
        }
        using var embedded = typeof(MainWindow).Assembly.GetManifestResourceStream("Arcoll.WinUI3.workspace-menu.json")
            ?? throw new InvalidOperationException("Catalogo de navegacao nao incorporado ao executavel.");
        return JsonDocument.Parse(embedded);
    }
    private static readonly MenuGroup[] Groups = LoadWorkspaceMenu();
    private static MenuGroup[] LoadWorkspaceMenu()
    {
        using var doc = OpenWorkspaceMenu();
        var loaded = doc.RootElement.GetProperty("groups").EnumerateArray().Select(g => new MenuGroup(
            g.GetProperty("key").GetString()!, g.GetProperty("label").GetString()!, g.GetProperty("icon").GetString()!,
            g.GetProperty("items").EnumerateArray().Where(i=>i.GetProperty("key").GetString()!="permissions").Select(i => new MenuItem(i.GetProperty("key").GetString()!,
                i.GetProperty("label").GetString()!,i.GetProperty("icon").GetString()!,i.GetProperty("band").GetInt32(),
                i.GetProperty("file").GetString()!, i.TryGetProperty("platform",out var online)&&online.GetBoolean(), i.TryGetProperty("query",out var query)?query.GetString()??"":"")).ToArray())).ToArray();
        // Gestor: Internet, Dispositivos e Mapa passam para o menu Início e a categoria Rede deixa de existir.
        var moved = loaded.Where(g => g.Key == "network").SelectMany(g => g.Items).Select(item => item with { Band = 1 }).ToArray();
        return loaded.Where(g => g.Key != "network")
            .Select(g => g.Key == "home" ? g with { Items = g.Items.Concat(moved).ToArray() } : g).ToArray();
    }
    private static readonly Dictionary<string,string> WorkspaceIconPaths = LoadWorkspaceIcons();
    private static Dictionary<string,string> LoadWorkspaceIcons()
    {
        using var doc = OpenWorkspaceMenu();
        return doc.RootElement.GetProperty("icons").EnumerateObject().ToDictionary(p=>p.Name,p=>p.Value.GetString()!);
    }
    private static PathIcon WorkspaceIcon(string name,double size)
    {
        var data=System.Security.SecurityElement.Escape(WorkspaceIconPaths[name]);
        return (PathIcon)Microsoft.UI.Xaml.Markup.XamlReader.Load($"<PathIcon xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" Data=\"F1 {data}\" Width=\"{size}\" Height=\"{size}\"/>");
    }
    private readonly Dictionary<string, Button> _tabs = new(), _menus = new();
    private readonly Dictionary<string, string> _lastSection = new();
    private readonly List<Border> _separators = new();
    private readonly Dictionary<string, Button> _stars = new();
    // Itens já presentes na categoria Início não recebem estrela de favoritos.
    private const string FixedMenuKey = "dashboard";
    private readonly HashSet<string> _favorites = LoadFavorites();
    // Submenus movidos pelo usuário para outra categoria (chave do submenu → chave da categoria).
    private readonly Dictionary<string, string> _layout = LoadLayout();
    private string? _dragKey;
    private static string LayoutFile => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TI-Digital", "menu-layout.json");
    private static Dictionary<string, string> LoadLayout()
    {
        try
        {
            if (File.Exists(LayoutFile))
            {
                var saved = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(LayoutFile)) ?? new();
                return saved.Where(x => x.Key != FixedMenuKey && Groups.Any(g => g.Key != "home" && g.Key == x.Value) && Groups.Any(g => g.Items.Any(i => i.Key == x.Key)))
                    .ToDictionary(x => x.Key, x => x.Value, StringComparer.Ordinal);
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { }
        return new(StringComparer.Ordinal);
    }
    private void SaveLayout()
    {
        try { Directory.CreateDirectory(Path.GetDirectoryName(LayoutFile)!); File.WriteAllText(LayoutFile, JsonSerializer.Serialize(_layout)); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { RuntimeLog.Write("Layout do menu: " + ex.Message); }
    }
    // Categoria atual de um submenu: a escolhida pelo usuário ao arrastar ou, se não houver, a de origem.
    private string GroupKeyOf(string key) => _layout.TryGetValue(key, out var moved)
        ? moved
        : Groups.FirstOrDefault(g => g.Items.Any(i => i.Key == key))?.Key ?? "home";
    // Itens da categoria já considerando os que foram movidos para dentro/fora dela (movidos entram na última faixa).
    private IEnumerable<MenuItem> ItemsOf(MenuGroup group)
    {
        var lastBand = group.Items.Max(i => i.Band);
        var own = group.Items.Where(i => GroupKeyOf(i.Key) == group.Key);
        var incoming = Groups.Where(g => g.Key != group.Key).SelectMany(g => g.Items).Where(i => GroupKeyOf(i.Key) == group.Key).Select(i => i with { Band = lastBand });
        return own.Concat(incoming).Where(i=>i.Key!="remote"&&(MenuVisibleHere(i.Key)||_runtime.IsProLocked(i.Key)));
    }
    // Categoria some quando todos os seus submenus estão favoritados (volta ao desfavoritar algum). Início nunca some.
    private void UpdateCategoryVisibility()
    {
        foreach (var group in Groups)
        {
            if (!_tabs.TryGetValue(group.Key, out var tab)) continue;
            var items = ItemsOf(group).ToArray();
            tab.Visibility = (group.Key == "home" ? group.Items.Any(i=>MenuVisibleHere(i.Key)) || Groups.SelectMany(g=>g.Items).Any(i=>MenuVisibleHere(i.Key)&&_favorites.Contains(i.Key)) : items.Any(i=>!_favorites.Contains(i.Key)) || (_runtime.IsServer&&items.Length==0)) ? Visibility.Visible : Visibility.Collapsed;
            // Janela reduzida: com todos os submenus de Início no rodapé, a aba Início some do topo (mais espaço).

        }
    }
    private string FirstSectionOf(MenuGroup group) => group.Key == "home" ? Groups.SelectMany(g=>g.Items).FirstOrDefault(i=>MenuVisibleHere(i.Key)&&(i.Key==FixedMenuKey||_favorites.Contains(i.Key)))?.Key??"" : ItemsOf(group).FirstOrDefault(i => !_favorites.Contains(i.Key))?.Key ?? "";
    private void MoveMenuItem(string key, string targetGroup)
    {
        if (key == FixedMenuKey || GroupKeyOf(key) == targetGroup || targetGroup == "home") return;
        var origin = Groups.FirstOrDefault(g => g.Items.Any(i => i.Key == key))?.Key;
        if (origin == targetGroup) _layout.Remove(key); else _layout[key] = targetGroup;
        SaveLayout();
        RefreshRibbonAfterFavorite();
    }
    private static string FavoritesFile => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TI-Digital", "menu-favorites.json");
    private static HashSet<string> LoadFavorites()
    {
        try { if (File.Exists(FavoritesFile)) return new((JsonSerializer.Deserialize<string[]>(File.ReadAllText(FavoritesFile)) ?? Array.Empty<string>()).Where(key => key != FixedMenuKey && Groups.Any(g => g.Items.Any(i => i.Key == key))), StringComparer.Ordinal); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { }
        return new();
    }
    // Estado compartilhado pela rede: conta/rede no servidor; arquivo local serve só como cache offline.
    private bool _favoriteSyncing, _favoriteWritePending;
    private async Task SyncFavoritesAsync()
    {
        if (_favoriteSyncing || _favoriteWritePending || !_runtime.Allowed) return;
        _favoriteSyncing = true;
        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(9));
            var remote = await _runtime.Platform.PostAsync("gestor-menu-favorites",
                _runtime.Platform.WithCredentials(("operation", "read")), cts.Token, 9);
            if (remote.TryGetProperty("initialized", out var init) && init.ValueKind == JsonValueKind.False)
            {
                remote = await _runtime.Platform.PostAsync("gestor-menu-favorites",
                    _runtime.Platform.WithCredentials(("operation", "initialize"), ("favorites", _favorites.ToArray())), cts.Token, 9);
            }
            ApplyRemoteFavorites(remote);
        }
        catch (Exception ex) { RuntimeLog.Write("Sincronização de favoritos: " + ex.Message); }
        finally { _favoriteSyncing = false; }
    }
    private void ApplyRemoteFavorites(JsonElement response)
    {
        if (_favoriteWritePending || !response.TryGetProperty("favorites", out var list) || list.ValueKind != JsonValueKind.Array) return;
        var valid = Groups.SelectMany(g => g.Items).Where(i => i.Key != FixedMenuKey).Select(i => i.Key).ToHashSet(StringComparer.Ordinal);
        var incoming = list.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
            .Select(x => x.GetString() ?? "").Where(valid.Contains).ToHashSet(StringComparer.Ordinal);
        if (_favorites.SetEquals(incoming)) return;
        _favorites.Clear(); _favorites.UnionWith(incoming);
        SaveFavorites();
        RefreshRibbonAfterFavorite();
    }
    private async Task PushFavoriteAsync(string key, bool favorite)
    {
        _favoriteWritePending = true;
        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            var response = await _runtime.Platform.PostAsync("gestor-menu-favorites",
                _runtime.Platform.WithCredentials(("operation", "set"), ("key", key), ("favorite", favorite)), cts.Token, 10);
            _favoriteWritePending = false;
            ApplyRemoteFavorites(response);
        }
        catch (Exception ex) { RuntimeLog.Write("Não foi possível publicar o favorito: " + ex.Message); }
        finally { _favoriteWritePending = false; }
    }
    private void SaveFavorites()
    {
        try { Directory.CreateDirectory(Path.GetDirectoryName(FavoritesFile)!); File.WriteAllText(FavoritesFile, JsonSerializer.Serialize(_favorites.OrderBy(x => x).ToArray())); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { RuntimeLog.Write("Favoritos do menu: " + ex.Message); }
    }
    // Favoritos vivem somente na categoria Início; fora dela o item deixa de aparecer no menu de origem.
    private MenuGroup ResolveGroup(string section) => _favorites.Contains(section)
        ? Groups[0]
        : Groups.FirstOrDefault(g => g.Key == GroupKeyOf(section)) ?? Groups[0];
    private string LastSectionFor(MenuGroup group) => _lastSection.TryGetValue(group.Key, out var last) && MenuVisibleHere(last) && ResolveGroup(last).Key == group.Key ? last : FirstSectionOf(group);
    // Categoria sem submenus visíveis (todos movidos): apenas mostra a faixa vazia, que continua aceitando itens arrastados.
    private string? _emptyGroupShown;
    private void ShowEmptyCategory(MenuGroup group) { _emptyGroupShown = group.Key; _group = group.Key; BuildRibbon(group); ApplyTheme(_themes.Current); }
    private string _group = "home";
    private GestorTheme? _appliedTheme;
    private AuthState? _paletteState;

    private CancellationTokenSource? _pending;

    public MainWindow()
    {
        InitializeComponent();
        InitializeCustomHeader();
        BuildCategories();
        RootGrid.SizeChanged += (_, e) => AdaptHybridLayout(e.NewSize.Width);
        RootGrid.Loaded += async (_, _) => await InitializeHybridDashboardAsync();
        _dashboardPage = new(_runtime); _serverPage = new(_hub, () => FooterText.Text, () => _runtime.CanOpenLocalMenu("server"));
        _speedPage = new(_runtime); _devicesPage = new(_runtime, m => SetWorkspaceFooter(m)); _mapPage = new(_runtime, m => SetWorkspaceFooter(m));
        _programsPage = new(_runtime, ConfirmAsync); _filesPage = new(_runtime); _windowsUpdatePage = new(_runtime, ConfirmAsync);
        _backupPage = new CloudPage(_runtime, this);
        _backupSyncPage = new CloudBackupPage(_runtime, ConfirmBackupSyncAsync);
        _cloudConfigPage = new CloudConfigPage(_runtime, this);
        _backupLoop = new BackupBackgroundLoop(() => { var c = _runtime.Platform.Config; return new(c.Origin,c.Fingerprint,c.SiteCode,c.DownloadKey); }, () => _runtime.Can("backup"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TI-Digital", "BackupCache"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TI-Digital", "Restaurados"), log: RuntimeLog.Write);
        _backupLoop.Start();
        _cloudSync = new CloudSyncService(() => _runtime.Platform.Config, () => _runtime.IsServer && _runtime.Can("backup"), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TI-Digital", "CloudSync"), RuntimeLog.Write);
        _cloudSync.Start();
        _penteFinoPage = new PenteFinoPage(_runtime, SelectSection);
        foreach(var item in Groups.SelectMany(g=>g.Items).Where(i=>i.Platform))
            _tools.Add(item.Key,new PlatformManagementPage(_runtime,ConfirmAsync,item.Key,item.Label,item.File));
        _networkDashboardPage = new(_runtime, RequestUserLoginAsync);
        _tools.Add("startup", new StartupPage(_runtime, ConfirmAsync));
        _tools.Add("performance", new PerformancePage(_runtime, ConfirmAsync)); _tools.Add("restore", new RestorePage(_runtime, ConfirmAsync));
        _tools.Add("security", new SecurityPage(_runtime, ConfirmAsync));
        _tools.Add("uninstall", new UninstallPage(_runtime, ConfirmAsync));
        _tools.Add("updater", new SoftwareUpdatesPage(_runtime, ConfirmAsync)); _tools.Add("drivers", new DriversPage(_runtime, ConfirmAsync));
        _tools.Add("disk", new DiskPage(_runtime, ConfirmAsync)); _tools.Add("duplicates", new DuplicatesPage(_runtime, ConfirmAsync));
        _supportPage = new(_runtime, ShowRemoteCodeAsync, () => SelectSection("tickets")); _ticketsPage = new(_runtime);
        _agendaPage = new(_runtime); _remoteAccessPage = new(_runtime, FetchRemoteCodeAsync, ConnectRemoteByCodeAsync); _remoteAccessPage.ConfigureRecent(ReconnectRecentAsync);
        var icon = Path.Combine(AppContext.BaseDirectory, "Assets", "system.ico");
        if (File.Exists(icon)) try { AppWindow.SetIcon(icon); } catch (Exception ex) { RuntimeLog.Write("Ícone da janela: " + ex.Message); }
        var work = DisplayArea.GetFromWindowId(AppWindow.Id, DisplayAreaFallback.Primary).WorkArea;
        ApplyDockLayout(false);
        InitializeCollaborators(); _hub.Start(); SelectSection("dashboard"); ApplyTheme(_themes.Current);
        RootGrid.Loaded += (_, _) => { ReadaptLayout(); ScheduleStartupRelayout(); };
        Activated += (_, _) => ReadaptLayout(false);
        _refreshTimer.Tick += async (_, _) => await RefreshAsync();
        _themeTimer.Tick += async (_, _) => { await RefreshThemeAsync(); await SyncFavoritesAsync(); if (DateTime.UtcNow - _lastBrand > TimeSpan.FromMinutes(2)) await RefreshBrandAsync(); };
        _refreshTimer.Start(); _themeTimer.Start();
        _remoteIndicatorTimer.Tick += (_, _) => SyncRemoteIndicator();
        _remoteIndicatorTimer.Start();
        _runtime.ProgramActivity += message => DispatcherQueue.TryEnqueue(() => {
            _programsPage.ShowActivity(message);
            FooterOperation.Text = string.IsNullOrWhiteSpace(message) ? "" : "Programas · " + message;
        });
        _runtime.Changed += () => DispatcherQueue.TryEnqueue(UpdateRuntimeUi);
        _runtime.RemoteToolRequested += section => DispatcherQueue.TryEnqueue(() =>
        {
            if (!_runtime.CanOpenLocalMenu(section)||_selectedCollaborator>0||_runtime.AlwaysBackground) return;
            ShowFromBackground();
            SelectSection(section);
        });
        // O andamento segue no serviço; não criar janela flutuante no gestor.
        _runtime.Consent = message =>
        {
            var result = new TaskCompletionSource<bool>();
            if (!DispatcherQueue.TryEnqueue(async () => { try { _localConsentOpen=true;if(!_runtime.IsServer)ShowCollaboratorHome(); AppWindow.Show(); Activate(); result.TrySetResult(await ConfirmRemoteAccessAsync(message)); } catch { result.TrySetResult(false); } finally { _localConsentOpen=false;if(_runtime.AlwaysBackground)AppWindow.Hide(); } })) result.TrySetResult(false);
            return result.Task;
        };
        _runtime.UpdateCheckRequested += () => DispatcherQueue.TryEnqueue(async () => {
            if(!_runtime.CanOpenLocalMenu("updates")||_runtime.AlwaysBackground||_selectedCollaborator>0)return;
            ShowFromBackground();ShowGestorUpdateArea();
            if(_gestorUpdatePage is not null)await _gestorUpdatePage.CheckNowAsync();
        });
        _runtime.SupportCodeRequested += () => DispatcherQueue.TryEnqueue(async () => {
            if(_runtime.Allowed)await ShowRemoteCodeAsync();
        });
        _runtime.RequestExit = () => DispatcherQueue.TryEnqueue(ExitGestor);
        AppWindow.Closing += (_, e) => { if (!_exiting) { e.Cancel = true; AppWindow.Hide(); } };
        // Ações do ícone da bandeja: chamadas diretas não dependem da janela aberta.
        _tray.OnTool = section => DispatcherQueue.TryEnqueue(() => { if (!CanOpenHere(section)||_runtime.AlwaysBackground) { _tray.Notify("Gestor", "Acesso à ferramenta indisponível até a autorização da rede."); return; } ShowFromBackground(); SelectSection(section); });
        _tray.OnCancel = () => DispatcherQueue.TryEnqueue(() => {
            if(!LocalSystemActions)return;
            if (!_runtime.HasActiveRemoteCommand && !_penteFinoPage.HasActiveOperations && !UpdatePresentation.Current.CanCancel && _pageDataSource?.CanCancelCollection != true) { _tray.Notify("Gestor", "Não há operação cancelável em execução."); return; }
            if (!_tray.Confirm("Interromper operações", "Interromper as operações canceláveis deste computador? Alterações concluídas não serão revertidas.")) return;
            _pageDataSource?.CancelCollection(); _penteFinoPage.CancelOperations(); UpdateService.CancelPreparation(); _runtime.CancelActiveRemoteCommand();
            _tray.Notify("Gestor", "Interrupção solicitada às rotinas compatíveis.");
        });
        _tray.OnSync = () => DispatcherQueue.TryEnqueue(async () => {
            if(!LocalSystemActions)return;
            if (!_runtime.Allowed) { _tray.Notify("Gestor", "A rede ainda não autorizou este dispositivo."); return; }
            try { await _runtime.ScanNowAsync(CancellationToken.None); _tray.Notify("Gestor", "Sincronização solicitada."); }
            catch (Exception error) { RuntimeLog.Write("Sincronização pela bandeja: " + error); _tray.Notify("Gestor", "Falha ao sincronizar. Consulte o registro de atividades."); }
        });
        _tray.OnUninstall = () => DispatcherQueue.TryEnqueue(() => {
            if(!LocalSystemActions)return;
            if (!_tray.Confirm("Desinstalar gestor", "Remover este Gestor, suas configurações locais e os dados exclusivos desta instalação na plataforma?\n\nA operação exige autorização do Windows, conexão à plataforma e não pode ser desfeita.")) return;
            StartUninstall();
        });
        ApplyLocalInterface();
        _tray.OnOpen = () => DispatcherQueue.TryEnqueue(ShowFromBackground);
        _tray.OnRestart = () => DispatcherQueue.TryEnqueue(()=>{if(LocalSystemActions)RestartGestor();});
        _tray.OnExit = () => DispatcherQueue.TryEnqueue(async () => { if(!LocalSystemActions)return; ShowFromBackground(); if (await ConfirmAsync("Encerrar gestor", "Encerrar interrompe o monitoramento até a próxima inicialização. Continuar?", "Encerrar")) ExitGestor(); });
        _tray.Start(); _runtime.Start(); _presence.Start();
        Closed += (_, _) =>
        {
            _exiting = true;
            _refreshTimer.Stop(); _themeTimer.Stop(); _remoteIndicatorTimer.Stop(); HideRemoteIndicator(); _pending?.Cancel(); _hub.Dispose(); _gestor.Dispose(); _themes.Dispose(); _presence.Dispose(); foreach (var page in _tools.Values) page.CancelOperations(); _programsPage.CancelOperations(); _penteFinoPage.CancelOperations(); _backupLoop.Dispose(); _cloudSync.Dispose(); _runtime.Dispose(); _tray.Dispose();
        };
        _ = RefreshAsync(); _ = RefreshThemeAsync(); _ = SyncFavoritesAsync();
    }
    public void ShowFromBackground() { if(_runtime.AlwaysBackground||(!_runtime.LocalAllowed&&LocalUiPolicy.StartsHidden(_runtime.Platform.Config)))return; var hidden = !AppWindow.IsVisible; if (hidden) PrepareSlideIn(); AppWindow.Show(); Activate(); if (hidden) SlideIn(); }
    private void ExitGestor() { _exiting = true; Close(); Application.Current.Exit(); }
    private void RestartGestor()
    {
        var exe = Environment.ProcessPath; if (string.IsNullOrEmpty(exe)) return;
        try { Process.Start(new ProcessStartInfo(exe) { UseShellExecute = false, CreateNoWindow = true, Arguments = "--background --wait-exit " + Environment.ProcessId }); ExitGestor(); }
        catch (Exception ex) { RuntimeLog.Write("Falha ao reiniciar: " + ex.Message); }
    }
    private async Task RefreshThemeAsync()
    {
        try { using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(12)); await _themes.RefreshAsync(timeout.Token); } catch { }
        ApplyTheme(_themes.Current);
    }
    private void BuildCategories()
    {
        foreach (var group in Groups)
        {
            var label = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 6, VerticalAlignment = VerticalAlignment.Center };
            label.Children.Add(WorkspaceIcon(group.Icon,16));
            label.Children.Add(new TextBlock { Text = group.Label, FontSize = 12, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center });
            label.Children.Add(CategoryUpdateBadge(group.Key));
            var tab = new Button { Tag = group.Key, Content = label, Style = (Style)RootGrid.Resources["RibbonTab"], Margin = new Thickness(0) };
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetAutomationId(tab, "category-" + group.Key);
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(tab, group.Label);
            tab.Click += (_, _) => { if(_section=="remote"){OpenRemoteCategory(group);return;} var target = LastSectionFor(group); if (target.Length == 0) ShowEmptyCategory(group); else QueueSectionNavigation(target); };
            // Soltar um submenu sobre a categoria move o submenu para ela.
            tab.AllowDrop = group.Key != "home";
            tab.DragOver += (_, e) =>
            {
                var accept = _dragKey is not null && group.Key != "home" && GroupKeyOf(_dragKey) != group.Key;
                e.AcceptedOperation = accept ? DataPackageOperation.Move : DataPackageOperation.None;
                if (accept) e.DragUIOverride.Caption = "Mover para " + group.Label;
                e.Handled = true;
            };
            tab.DragEnter += (_, _) => { if (_dragKey is not null && group.Key != "home" && GroupKeyOf(_dragKey) != group.Key) SetNavigationHover(tab, true); };
            tab.DragLeave += (_, _) => SetNavigationHover(tab, false);
            tab.Drop += (_, e) =>
            {
                var key = _dragKey; _dragKey = null; SetNavigationHover(tab, false); e.Handled = true;
                if (key is not null && !DispatcherQueue.TryEnqueue(() => MoveMenuItem(key, group.Key))) RuntimeLog.Write("Layout do menu: DispatcherQueue indisponível.");
            };
            tab.PointerEntered += (_, _) => SetNavigationHover(tab, true); tab.PointerExited += (_, _) => SetNavigationHover(tab, false);
            _tabs.Add(group.Key, tab);
            // Menu Gestão fica no lado direito da barra de abas; as demais categorias, à esquerda.
            CategoryTabs.Children.Add(tab);
        }
    }
    private void BuildRibbon(MenuGroup group)
    {
        RibbonMenus.Children.Clear(); _menus.Clear(); _separators.Clear(); _stars.Clear();
        // Botões em faixas (bandas) separadas por linha vertical; favoritos vêm primeiro dentro da própria faixa.
        // Favoritos pertencem exclusivamente à faixa Início: saem do menu de origem e não se duplicam.
        var items = group.Key == "home"
            ? group.Items.Where(i=>MenuVisibleHere(i.Key)).Concat(Groups.Where(g => g.Key != "home").SelectMany(g => ItemsOf(g)).Where(i => _favorites.Contains(i.Key)))
            : ItemsOf(group).Where(i => !_favorites.Contains(i.Key));
        // O Painel permanece sempre em primeiro lugar em Início, mesmo com favoritos.
        var primary = group.Key == "home" ? FixedMenuKey : "";
        var ordered = items.DistinctBy(i => i.Key).Select((item, index) => (item, index))
            .OrderBy(x => x.item.Key == primary ? -1 : (group.Key == "home" ? 0 : x.item.Band))
            .ThenBy(x => x.index).Select(x => x.item).ToArray();
        // Janela reduzida: o rodapé já mostra os submenus de Início; eles não se repetem no topo.
        if (group.Key == "home" && BottomNavActive && _section!="remote") { var inBottom = BottomLayout(); var hidden = inBottom.Shown.Select(i => i.Key).Append(FixedMenuKey).ToHashSet(); ordered = ordered.Where(i => !hidden.Contains(i.Key)).ToArray(); }
        var band = ordered.Length > 0 ? ordered[0].Band : 0;
        foreach (var item in ordered)
        {
            if (item.Band != band)
            {
                band = item.Band;
                var line = new Border { Width = 1, Margin = new Thickness(6, 8, 6, 8), VerticalAlignment = VerticalAlignment.Stretch };
                _separators.Add(line); RibbonMenus.Children.Add(line);
            }
            var content = new StackPanel { Orientation = Orientation.Vertical, Spacing = 3, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            // O mesmo contorno vetorial é usado pelo menu da plataforma.
            content.Children.Add(WorkspaceIcon(item.Icon,26));
            content.Children.Add(new TextBlock { Text = item.Label, FontSize = 12, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap, MaxLines = 2 });
            var proLocked = _runtime.IsProLocked(item.Key);
            // Recurso da versão PRO: visível, porém esmaecido; o selo é um diamante sobreposto no canto da célula.
            if (proLocked) content.Opacity = .45;
            var button = new Button { Tag = item.Key, Content = content, Style = (Style)RootGrid.Resources["FlatButton"], MinWidth = 78, Height = 66, Padding = new Thickness(12, 6, 12, 4), CornerRadius = new CornerRadius(8) };
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetAutomationId(button, "nav-" + (item.Key == "speed" ? "internet" : item.Key));
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(button, item.Label); ToolTipService.SetToolTip(button, item.Label);
            button.Click += Menu_Click;
            button.PointerEntered += (_, _) => SetNavigationHover(button, true); button.PointerExited += (_, _) => SetNavigationHover(button, false);
            _menus.Add(item.Key, button);
            var cell = new Grid(); cell.Children.Add(button);
            // Todo submenu (exceto o Painel) pode ser arrastado para outra categoria e favoritado em Início.
            if (item.Key != FixedMenuKey)
            {
                button.CanDrag = true;
                button.DragStarting += (_, e) => { _dragKey = item.Key; e.Data.SetText(item.Key); e.Data.RequestedOperation = DataPackageOperation.Move; };
                button.DropCompleted += (_, _) => _dragKey = null;
                // Fora de In\u00EDcio toda estrela favorita; em In\u00EDcio ela aparece nos itens favoritados para permitir desfavoritar.
                var isFavorite = _favorites.Contains(item.Key);
                if (group.Key != "home" || isFavorite)
                {
                var star = new Button { Tag = item.Key, Style = (Style)RootGrid.Resources["FlatButton"], Width = 22, Height = 22, Padding = new Thickness(0), CornerRadius = new CornerRadius(11), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 1, 1, 0), Content = new FontIcon { FontSize = 11, Glyph = isFavorite ? "\uE735" : "\uE734" } };
                Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(star, (isFavorite ? "Desfavoritar " : "Favoritar ") + item.Label); ToolTipService.SetToolTip(star, isFavorite ? "Desfavoritar" : "Favoritar");
                star.Click += (_, _) =>
                {
                    if (!_favorites.Remove(item.Key)) _favorites.Add(item.Key);
                    SaveFavorites();
                    _ = PushFavoriteAsync(item.Key, _favorites.Contains(item.Key));
                    // Reconstrói a faixa fora do evento Click: o botão clicado pertence à árvore que será substituída.
                    if (!DispatcherQueue.TryEnqueue(RefreshRibbonAfterFavorite)) RuntimeLog.Write("Favoritos do menu: DispatcherQueue indisponível.");
                };
                _stars.Add(item.Key, star); cell.Children.Add(star);
                }
            }
            if (proLocked) cell.Children.Add(ProDiamond());
            if (item.Key == UpdateMenuKey) cell.Children.Add(UpdateMenuBadge());
            RibbonMenus.Children.Add(cell);
        }
        UpdateCategoryVisibility(); ApplyUpdateBadges(); BlinkPendingMenus();
        RibbonScroll.ChangeView(0, null, null, true);
        // Sem nada para mostrar no topo (tudo está no rodapé), a faixa de submenus some e libera espaço.
        if (ordered.Length == 0 && group.Key == "home" && BottomNavActive) { RibbonBar.Visibility = Visibility.Collapsed; _ribbonHiddenByBottom = true; }
        else if (_ribbonHiddenByBottom) { _ribbonHiddenByBottom = false; RibbonBar.Visibility = _runtime.IsServer || _runtime.HasLocalTools ? Visibility.Visible : Visibility.Collapsed; }
    }
    private bool _ribbonHiddenByBottom;
    /// <summary>Selo da versão PRO: diamante vetorial (substitui o texto "PRO") no canto superior esquerdo do submenu.</summary>
    private static Microsoft.UI.Xaml.Shapes.Polygon ProDiamond()
    {
        var gem = new Microsoft.UI.Xaml.Shapes.Polygon
        {
            Points = new PointCollection
            {
                new Windows.Foundation.Point(3, 0), new Windows.Foundation.Point(11, 0), new Windows.Foundation.Point(14, 4),
                new Windows.Foundation.Point(7, 13), new Windows.Foundation.Point(0, 4)
            },
            Width = 14, Height = 13, Stretch = Stretch.Fill,
            Fill = ThemeService.Brush("#F59E0B"), Stroke = ThemeService.Brush("#B45309"), StrokeThickness = 1,
            HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(4, 3, 0, 0), IsHitTestVisible = false
        };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(gem, "Versão PRO");
        return gem;
    }
    private void RebuildRibbonForWidth()
    {
        try
        {
            if (_compactClosed || _group.Length == 0) return;
            var current = _emptyGroupShown is not null ? Groups.First(g => g.Key == _emptyGroupShown) : ResolveGroup(_section);
            BuildRibbon(current); ApplyTheme(_themes.Current);
        }
        catch (Exception ex) { RuntimeLog.Write("Submenus (largura): " + ex.Message); }
    }
    private void RefreshRibbonAfterFavorite()
    {
        try
        {
            foreach (var entry in _lastSection.ToArray()) if (ResolveGroup(entry.Value).Key != entry.Key) _lastSection.Remove(entry.Key);
            // A área aberta continua visível; apenas a categoria que a contém muda (Início para favoritos, origem ao desfavoritar).
            var current = _emptyGroupShown is not null ? Groups.First(g => g.Key == _emptyGroupShown) : ResolveGroup(_section);
            _group = current.Key; if (_emptyGroupShown is null) _lastSection[current.Key] = _section;
            BuildRibbon(current); ApplyTheme(_themes.Current);
            PublishHybridState();
        }
        catch (Exception ex) { RuntimeLog.Write("Favoritos do menu: " + ex); }
    }
    private void ApplyTheme(GestorTheme t)
    {
        PaintPageLoading();var p = Palette.From(t); RootGrid.Background = p.Alt; RootGrid.RequestedTheme = p.Light ? ElementTheme.Light : ElementTheme.Dark;
        QuickBar.Background = new SolidColorBrush(Microsoft.UI.ColorHelper.FromArgb(214, ((SolidColorBrush)p.Surface).Color.R, ((SolidColorBrush)p.Surface).Color.G, ((SolidColorBrush)p.Surface).Color.B)); RibbonBar.Background = StatusBorder.Background = p.Surface; CategoryBar.Background = p.Surface;
        QuickBar.BorderBrush = RibbonBar.BorderBrush = StatusBorder.BorderBrush = p.Line;
        var accent = ((SolidColorBrush)p.Accent).Color;
        var ink = ThemeService.Brush(GestorAreaPalette.Ink(t.Accent));
        foreach (var (key, tab) in _tabs)
        {
            var selected = key == _group;
            tab.Background = selected ? p.Accent : p.Surface;
            tab.Foreground = selected ? ink : p.Text;
            tab.BorderBrush = selected ? p.Accent : p.Line;
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetHelpText(tab, selected ? "Categoria selecionada" : "Abrir categoria");
        }
        foreach (var (key, menu) in _menus)
        {
            var selected = key == _section;
            menu.Background = selected ? p.Alt : p.Surface;
            menu.Foreground = selected ? p.Accent : p.Text;
            menu.BorderBrush = selected ? p.Accent : p.Line;
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetHelpText(menu, selected ? "Página selecionada" : "Abrir página");
        }
        foreach (var separator in _separators) separator.Background = p.Line;
        foreach (var divider in _ribbonDividers) divider.Background = p.Line;
        ApplyHybridChrome(p);
        PaintPairBar(p, ink);
        ConnectionLabel.Foreground = FooterText.Foreground = p.Muted;
        if (_appliedTheme == t && _paletteState == _runtime.State) return; _appliedTheme = t; _paletteState = _runtime.State;
        _networkDashboardPage.ApplyPalette(p); _remoteAccessPage.ApplyPalette(p); _dashboardPage.ApplyPalette(p); _serverPage.ApplyPalette(p); _speedPage.ApplyPalette(p); _devicesPage.ApplyPalette(p); _mapPage.ApplyPalette(p);
        _backupPage.ApplyPalette(p); _backupSyncPage.ApplyPalette(p); _cloudConfigPage.ApplyPalette(p); _penteFinoPage.ApplyPalette(p); _programsPage.ApplyPalette(p); foreach (var page in _tools.Values) page.ApplyPalette(p); _windowsUpdatePage.ApplyPalette(p); _filesPage.ApplyPalette(p); _supportPage.ApplyPalette(p); _ticketsPage.ApplyPalette(p); _agendaPage.ApplyPalette(p);
    }
    // Prévia de TODOS os recursos PRO no modo independente: navegação permitida, ações não.
    private bool IsFreePreview(string key) => _runtime.Platform.Config.IsStandalone && _runtime.IsProLocked(key);

    // A camada transparente retém cliques, arrastes e toques; somente a rolagem é repassada.
    // Mantém os ScrollViewers internos das páginas na sua altura original (inclusive Programas).
    private void SetProPreview(string key)
    {
        var preview = IsFreePreview(key);
        CompactHost.Opacity = preview ? 0.46 : 1.0;
        CompactHost.IsHitTestVisible = !preview;
        ProPreviewBlocker.Visibility = preview ? Visibility.Visible : Visibility.Collapsed;
    }
    private void ProPreviewWheel(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (ProPreviewBlocker.Visibility != Visibility.Visible) return;
        var scroll = FindPreviewScroll(CompactHost.Content as DependencyObject);
        if (scroll is null) return;
        var delta = e.GetCurrentPoint(ProPreviewBlocker).Properties.MouseWheelDelta;
        scroll.ChangeView(null, Math.Clamp(scroll.VerticalOffset - delta, 0, scroll.ScrollableHeight), null, true);
        e.Handled = true;
    }
    private static ScrollViewer? FindPreviewScroll(DependencyObject? root)
    {
        if (root is null) return null;
        if (root is ScrollViewer scroll && scroll.ScrollableHeight > 0) return scroll;
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            var found = FindPreviewScroll(VisualTreeHelper.GetChild(root, i));
            if (found is not null) return found;
        }
        return null;
    }

    private void Menu_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button menu) return;
        var target = menu.Tag?.ToString() ?? "panel";
        if (_runtime.IsProLocked(target) && !IsFreePreview(target))
        {
            if (_runtime.Platform.Config.IsStandalone) ShowLinkDialog("Recurso PRO", "Este recurso faz parte da versão PRO e exige o vínculo com a plataforma online.");
            return;
        }
        RuntimeLog.Write($"Navegação: clique em {target}; atual={_section}");
        QueueSectionNavigation(target);
    }
    // Adiar a troca para depois do evento Click evita alterar a árvore visual
    // enquanto WinUI ainda processa RoutedEventArgs do botão que originou a ação.
    private void QueueSectionNavigation(string section)
    {
        if (!DispatcherQueue.TryEnqueue(() =>
        {
            RuntimeLog.Write("Navegação: evento concluído, iniciando troca para " + section);
            SelectSection(section);
        })) RuntimeLog.Write("Navegação: DispatcherQueue indisponível para " + section);
    }
    private void SelectSection(string section)
    {
        // Erros de uma área não devem encerrar a interface inteira; preservar telemetria diagnóstica.
        try { SelectSectionCore(section); }
        catch (Exception ex)
        {
            RuntimeLog.Write("Falha ao abrir área " + section + ": " + ex);
            if(!_runtime.IsServer){ShowCollaboratorHome();return;}
            try
            {
                PageHost.Content = null;
                CompactHost.Content = null;
                HybridDashboard.Visibility = Visibility.Collapsed;
                CompactHost.Visibility = Visibility.Visible;
                CompactHost.Content = _dashboardPage;
                _section = "panel";
                StatusBar.Title = "Área temporariamente indisponível";
                StatusBar.Message = "A área não pôde ser aberta. Consulte o registro do gestor para identificar a causa.";
                StatusBar.Severity = InfoBarSeverity.Warning;
                StatusBar.IsOpen = true;
            }
            catch (Exception fallback) { RuntimeLog.Write("Falha na recuperação da navegação: " + fallback); }
        }
    }
    private void SelectSectionCore(string section)
    {
        if(section=="monitor")section="server";
        if (_runtime.IsProLocked(section) && !IsFreePreview(section))
        {
            if (_runtime.Platform.Config.IsStandalone) ShowLinkDialog("Recurso PRO", "Vincule o Gestor para utilizar este recurso.");
            return;
        }
        // Com um Colaborador selecionado, "remote" abre a ferramenta dele (TryShowCollaborator) e não a área de acesso remoto do Servidor.
        if(section=="remote"&&!(_runtime.IsServer&&_selectedCollaborator>0)){if(_runtime.IsServer)ShowRemoteArea();else ShowCollaboratorHome();return;}
        if(!_runtime.User.ViewingOther&&!_runtime.IsServer&&(!_runtime.CanOpenLocalMenu(section)||!MenuVisibleHere(section))){ShowCollaboratorHome();return;}
        if(_runtime.User.ViewingOther&&!MenuVisibleHere(section)){RuntimeLog.Write("Navegação: área não liberada ao perfil nesta rede: "+section);return;}
        if(TryShowCollaborator(section))return;
        if(section is "updates" or "history"){ShowGestorUpdateArea(section=="history"?"history":"update");return;}
        if (!Groups.Any(g => g.Items.Any(i => i.Key == section))) section = "panel";
        var group = ResolveGroup(section);
        if (section == _section && _group == group.Key && (_menus.Count > 0) && (section=="panel"&&_hybridReady?HybridDashboard.Visibility==Visibility.Visible:CompactHost.Content is not null))
        {
            RuntimeLog.Write("Navegação: área já ativa: " + section);
            return;
        }
        _emptyGroupShown = null;_remoteSubmenusHidden=false;
        CategoryBar.Visibility=CategoryTabs.Visibility=Visibility.Visible;RibbonBar.Visibility=Visibility.Visible;
        ShowPageLoading("Preparando " + section, 5);
        RuntimeLog.Write("Navegação: iniciando " + section);
        // Um favorito sempre abre dentro da faixa Início; os demais, na categoria de origem.
        _section = section; _lastSection[group.Key] = section;
        if (_group != group.Key || _menus.Count == 0) { _group = group.Key; BuildRibbon(group); }
        // Cada ferramenta tem sua página e seu estado; trocar menus não cancela nem reinicia operações.
        RuntimeLog.Write("Navegação: liberando conteúdo anterior");
        PageHost.Content = null; CompactHost.Content = null; HybridDashboard.Visibility = Visibility.Collapsed;
        var bounded = true;
        PageScroll.Visibility = bounded ? Visibility.Collapsed : Visibility.Visible;
        CompactHost.Visibility = bounded ? Visibility.Visible : Visibility.Collapsed;
        if (section == "panel") { if (_hybridReady) { HybridDashboard.Visibility = Visibility.Visible; CompactHost.Visibility = Visibility.Collapsed; } else CompactHost.Content = _dashboardPage; }
        else if (section == "backup_sync") CompactHost.Content = _backupSyncPage;
        else if (section == "cloud_config") CompactHost.Content = _cloudConfigPage;
        else if (section.StartsWith("backup", StringComparison.Ordinal)) { _backupPage.Navigate(section); CompactHost.Content = _backupPage; }
        else if (section == "programs") CompactHost.Content = _programsPage;
        else if (section == "health") CompactHost.Content = _penteFinoPage;
        else if (section == "dashboard") CompactHost.Content = _networkDashboardPage;
        else if (_tools.TryGetValue(section, out var tool)) CompactHost.Content = tool;
        else CompactHost.Content = section switch { "windows_update" => _windowsUpdatePage, "devices" => _devicesPage, "map" => _mapPage, "files" => _filesPage, "server" => _serverPage, "speed" => _speedPage, "support" => _supportPage, "tickets" => _ticketsPage, "agenda" => _agendaPage, "remote" => _remoteAccessPage, _ => _serverPage };
        // Prévia segura e rolável: o bloqueio é restrito à área do submenu PRO.
        SetProPreview(section);
        RuntimeLog.Write("Navegação: conteúdo criado; aplicando tema: " + section);
        ApplyTheme(_themes.Current);
        // Evita animar a árvore visual durante a troca de páginas nativas;
        // mantém a animação no painel web sem competir com o carregamento WinUI.
        if (section == "panel" && _hybridReady) AnimateHybridPage();
        PublishHybridState();
        FinishPageLoading();
        if (_networkStale.Remove(section)) _ = ReloadSectionForNetworkAsync(section);
        RuntimeLog.Write("Navegação: concluída " + section);
    }
    private async Task RefreshAsync()
    {
        if (_refreshing) return; _refreshing = true;
        _pending?.Cancel(); _pending?.Dispose(); _pending = new(TimeSpan.FromSeconds(12));
        try { var info = await _gestor.HealthAsync(_pending.Token); FooterText.Text = info.Host + " · " + info.Ip + " · v" + info.Version; }
        catch (Exception ex) { SetWorkspaceFooter(ex.Message); }
        finally { _refreshing = false; }
    }
    private async Task RefreshBrandAsync()
    {
        if (_runtime.Platform.Config.IsStandalone) { ApplyFreeFooterIdentity(); return; }
        if (_branding || !_runtime.Allowed) return; _branding = true;
        try
        {
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
            if (_brandSite != _runtime.Platform.Config.SiteCode) { _brandSite = _runtime.Platform.Config.SiteCode; NetworkBadge.Child = new TextBlock { Text = "REDE", FontSize = 10, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }; }
            var info = await WorkspaceService.GetAsync(_runtime, "info", timeout.Token);
            NetworkTitle.Text = info.GetProperty("network_name").ToString(); ToolTipService.SetToolTip(NetworkTitle,NetworkTitle.Text);
            var logo = info.GetProperty("logo_base64").GetString() ?? "";
            if (logo.Length > 0)
            {
                var bytes = Convert.FromBase64String(logo); using var stream = new InMemoryRandomAccessStream();
                using (var writer = new DataWriter(stream)) { writer.WriteBytes(bytes); await writer.StoreAsync(); writer.DetachStream(); }
                stream.Seek(0); var bitmap = new BitmapImage(); await bitmap.SetSourceAsync(stream);
                NetworkBadge.Child = new Image { Source = bitmap, Stretch = Stretch.Uniform };
                _networkLogo = bitmap; if (BottomNav.Visibility == Visibility.Visible) RebuildBottomNav();
            }
            else NetworkBadge.Child = new TextBlock { Text = string.IsNullOrWhiteSpace(info.GetProperty("network_name").ToString()) ? "REDE" : info.GetProperty("network_name").ToString()[..Math.Min(2, info.GetProperty("network_name").ToString().Length)].ToUpperInvariant(), FontSize = 14, FontWeight = Microsoft.UI.Text.FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            ToolTipService.SetToolTip(BrandButton, "Painel · " + info.GetProperty("network_name"));
            _lastBrand = DateTime.UtcNow;
        }
        catch (Exception ex) { RuntimeLog.Write("Logo da rede: " + ex.Message); _lastBrand = DateTime.UtcNow; }
        finally { _branding = false; }
    }
    private void UpdateRuntimeUi()
    {
        RefreshPairBar();
        DispatcherQueue.TryEnqueue(() => ReadaptLayout());
        ApplyLocalInterface();
        if (!_runtime.LocalAllowed) { _penteFinoPage.CancelOperations(); foreach (var page in _tools.Values) page.CancelOperations(); _programsPage.CancelOperations(); }
        if (_paletteState != _runtime.State) ApplyTheme(_themes.Current);
        _serverPage.RefreshAuthorization();
        GateOverlay.Visibility = _runtime.Gated ? Visibility.Visible : Visibility.Collapsed; GateText.Text = _runtime.StateNotice;
        UpdateLoginDialog(); RefreshSessionChrome();
        InstallationProfileText.Text=_runtime.InstallationLabel;
        InstallationProfileChoice.Visibility=_runtime.State==AuthState.Pending?Visibility.Visible:Visibility.Collapsed;
        ServerProfile.IsEnabled=_runtime.ServerEligible;
        if(!ServerProfile.IsEnabled&&InstallationProfileSelector.SelectedItem==ServerProfile)InstallationProfileSelector.SelectedItem=CollaboratorProfile;
        ToolTipService.SetToolTip(NetworkTitle,_runtime.NetworkName+" · "+_runtime.InstallationLabel);
        ConnectionLabel.Text = _runtime.State switch { AuthState.Approved or AuthState.UiLocked => "Conectado · " + _runtime.NetworkName, AuthState.Pending => "Aguardando liberação", AuthState.Checking => "Verificando…", _ => "Sem confirmação" };
        var shownNetwork = _runtime.User.Active ? _runtime.User.Current?.Name ?? _runtime.NetworkName : _runtime.NetworkName;
        NetworkTitle.Text = string.IsNullOrWhiteSpace(shownNetwork) ? NetworkTitle.Text : shownNetwork;
        ApplyGestorIdentity();
        ApplyFreeFooterIdentity();
        var state = _runtime.Allowed ? TrayState.Connected : _runtime.State is AuthState.Pending or AuthState.Checking ? TrayState.Pending : TrayState.Offline;
        _tray.SetState(state, ConnectionLabel.Text);
        if (_trayLast != _runtime.State) { _trayLast = _runtime.State; if (_runtime.Allowed) _ = RefreshBrandAsync(); }
        if (_runtime.LastActivity.Length > 0 && _runtime.Allowed) WorkspaceRuntimeActivity(_runtime.LastActivity);
        PublishHybridState();
    }
    private async void InstallationProfile_Save_Click(object sender,RoutedEventArgs e)
    {
        InstallationProfileSave.IsEnabled=false;
        try{using var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(15));var selected=(InstallationProfileSelector.SelectedItem as ComboBoxItem)?.Tag as string??"collaborator";await _runtime.ChooseInstallationAsync(selected,cancel.Token);InstallationProfileText.Text="Perfil solicitado. Aguarde a aprovação administrativa.";}
        catch(Exception error){InstallationProfileText.Text=error.Message;}
        finally{InstallationProfileSave.IsEnabled=true;}
    }
    private async void GateRetry_Click(object sender, RoutedEventArgs e) { await _runtime.RecheckAsync(); GateText.Text = _runtime.StateNotice; }
    private void SyncRemoteIndicator()
    {
        var active = AnyRemoteSessionActive;
        if (active)
        {
            if (_remoteIndicator is null)
            {
                try
                {
                    // Janela independente no Windows da máquina ACESSADA, sem elemento no navegador do operador.
                    var (indicator, eye) = CreateRemoteEyeWindow();
                    _remoteIndicator = indicator; _remoteEyeButton = eye;
                }
                catch (Exception e) { RuntimeLog.Write("Indicador remoto indisponível: " + e.Message); }
            }
        }
        else if (_remoteWasActive)
        {
            HideRemoteIndicator();
            ShowRemoteEndedNotice();
        }
        _remoteWasActive = active;
    }
    private async Task EndRemoteAccessFromIndicatorAsync()
    {
        // Confirmação compacta no centro da tela da máquina acessada, sem abrir o Gestor.
        if (!AnyRemoteSessionActive) return;
        if (!await ConfirmEndRemoteCompactAsync()) return;
        if (_lanRemotePage?.IsActive == true)
        {
            try { await _lanRemotePage.EndAsync(); }
            catch (Exception error) { RuntimeLog.Write("Encerramento da sessão remota LAN: " + error.Message); }
        }
        _runtime.EndRemoteSessionLocally();
        _lanAgent?.EndRemoteLocally();
        _relayHost?.EndLocally();
        SyncRemoteIndicator();
    }

    private void HideRemoteIndicator()
    {
        _remoteEyeButton = null;
        if (_remoteIndicator is { } indicator)
        {
            _remoteIndicator = null;
            try { indicator.Close(); } catch (Exception e) { RuntimeLog.Write("Fechamento do indicador remoto: " + e.Message); }
        }
    }
    private async void ShowRemoteEndedNotice()
    {
        try
        {
            // A confirmação aparece mesmo se o gestor estiver minimizado na bandeja.
            AppWindow.Show(); Activate();
            var dialog = Ui.MessageDialog(Content.XamlRoot, Palette.From(_themes.Current), "Acesso encerrado",
                "Sessão remota finalizada.",
                close: "Ok", defaultButton: ContentDialogButton.Close);
            await dialog.ShowAsync();
            if (_runtime.AlwaysBackground) AppWindow.Hide();
        }
        catch (Exception error) { RuntimeLog.Write("Aviso de encerramento remoto: " + error.Message); }
    }
    private async void RemoteAccess_Click(object sender, RoutedEventArgs e) => await ShowRemoteCodeAsync();
    private string _standaloneCode = ""; private DateTime _standaloneUntil = DateTime.MinValue;
    private (string Code, int Seconds) StandaloneRemoteCode()
    {
        if (_standaloneCode.Length == 0 || DateTime.UtcNow >= _standaloneUntil)
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            _standaloneCode = new string(Enumerable.Range(0, 5).Select(_ => alphabet[System.Security.Cryptography.RandomNumberGenerator.GetInt32(alphabet.Length)]).ToArray());
            _standaloneUntil = DateTime.UtcNow.AddSeconds(LanSettings.Load().CodeSeconds);
        }
        _lanAgent?.AcceptCode(_standaloneCode, (int)Math.Ceiling((_standaloneUntil - DateTime.UtcNow).TotalSeconds));
        return (_standaloneCode, Math.Max(1, (int)Math.Ceiling((_standaloneUntil - DateTime.UtcNow).TotalSeconds)));
    }
    /// <summary>Código único: vale na rede local e no relé de internet. É publicado no relé para que qualquer Gestor, em qualquer rede, possa acessar este computador.</summary>
    private async Task<(string Code, int Seconds)> FetchRemoteCodeAsync(CancellationToken ct)
    {
        var result = await FetchRemoteCodeCoreAsync(ct);
        try
        {
            for (var attempt = 0; attempt < 4 && !await _relayHost.PublishAsync(result.Code, result.Seconds, ct); attempt++)
            {
                if (!_runtime.Platform.Config.IsStandalone) break;
                _standaloneCode = ""; result = StandaloneRemoteCode();
            }
        }
        catch (Exception error) when (error is InvalidOperationException or HttpRequestException or OperationCanceledException) { RuntimeLog.Write("Código de acesso remoto no relé: " + error.Message); }
        return result;
    }
    private async Task<(string Code, int Seconds)> FetchRemoteCodeCoreAsync(CancellationToken ct)
    {
        // Um único código: o mesmo vale na plataforma e na rede local (o Servidor identifica sozinho o caminho).
        // Programa independente: o código é gerado localmente, sem exigir vínculo com a plataforma.
        if (_runtime.Platform.Config.IsStandalone) return StandaloneRemoteCode();
        try
        {
            if (!_runtime.Can("support") && _lanAgent?.OfflineCode() is { } localOnly) return localOnly;
            var result = await _runtime.Platform.PostAsync("gestor-support-code", _runtime.Platform.WithCredentials(), ct, 12);
            var code = result.GetProperty("code").GetString() ?? ""; var seconds = result.GetProperty("expires_in").GetInt32();
            _lanAgent?.AcceptCode(code, seconds);
            return (code, seconds);
        }
        catch (Exception error) when (error is PlatformException or HttpRequestException or OperationCanceledException)
        {
            if (_lanAgent?.OfflineCode() is { } offline) return offline;
            throw;
        }
    }
    private Task ShowRemoteCodeAsync()
    {
        // Acesso à interface e ao código é gratuito em qualquer perfil; a sessão valida o código no transporte escolhido.
        if(_runtime.IsServer){_changingCollaborator=true;try{_selectedCollaborator=0;CollaboratorSelector.SelectedIndex=0;}finally{_changingCollaborator=false;}SelectSection("remote");}
        else ShowCollaboratorHome();
        ShowFromBackground();return Task.CompletedTask;
    }
    private async Task<bool> ConfirmRemoteAccessAsync(string message)
    {
        _ = message;
        var dialog = Ui.MessageDialog(Content.XamlRoot, Palette.From(_themes.Current), "Permitir acesso remoto?",
            "Um administrador pediu acesso temporário à tela, mouse e teclado. Você pode encerrar pelo ícone na tela.",
            "Permitir", close: "Negar", defaultButton: ContentDialogButton.Primary);
        return await dialog.ShowAsync() == ContentDialogResult.Primary;
    }

    private async Task<bool> ConfirmAsync(string title, string message, string primary)
    {
        var dialog = Ui.MessageDialog(Content.XamlRoot, Palette.From(_themes.Current), title, message, primary, close: "Cancelar", defaultButton: ContentDialogButton.Close);
        return await dialog.ShowAsync() == ContentDialogResult.Primary;
    }
}
