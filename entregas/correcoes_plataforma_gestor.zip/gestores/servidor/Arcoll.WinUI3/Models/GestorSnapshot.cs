// Caminho: gestores/servidor/Arcoll.WinUI3/Models/GestorSnapshot.cs
namespace Arcoll.WinUI3.Models;

public sealed record GestorSnapshot(string Host, string Ip, string Gateway, string Os, string Version, bool Online);
public sealed record DeviceInfo(string Name, string Ip, string Mac, string Kind, long? LatencyMs, string Detail,int[]? OpenPorts=null,string TypeConfidence="indeterminada",string[]? TypeEvidence=null,string Ssid="",string Gateway="",string Link="",int Ttl=0);
public sealed record OpenPort(int Port, string Service);

public static class AppInfo
{
    public static string Version { get; } = ReadVersion();
    private static string ReadVersion()
    {
        // Recibo da instalação validada, emitido pelo aplicador após conferir o pacote assinado.
        // A versão compilada continua sendo o fallback; a versão oficial vem de /VERSION.
        try {
            var receipt=System.IO.Path.Combine(AppContext.BaseDirectory,"deployed-release.json");
            if(System.IO.File.Exists(receipt)&&new System.IO.FileInfo(receipt).Length<4096){
                using var doc=System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(receipt));
                var version=doc.RootElement.GetProperty("version").GetString()??"";
                var expected=doc.RootElement.GetProperty("executable_sha256").GetString()??"";
                using var input=System.IO.File.OpenRead(System.IO.Path.Combine(AppContext.BaseDirectory,"Arcoll.WinUI3.exe"));
                var hash=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(input));
                if(TryCompareRelease(version,version,out _)&&hash.Equals(expected,StringComparison.OrdinalIgnoreCase))return version;
            }
        }catch(Exception error)when(error is System.IO.IOException or UnauthorizedAccessException or System.Text.Json.JsonException or KeyNotFoundException or InvalidOperationException){}
        // A versão publicada pode ter de 2 a 5 casas; o InformationalVersion preserva o valor integral recebido no build.
        var asm = typeof(AppInfo).Assembly;
        var info = asm.GetCustomAttributes(typeof(System.Reflection.AssemblyInformationalVersionAttribute), false)
            .OfType<System.Reflection.AssemblyInformationalVersionAttribute>().FirstOrDefault()?.InformationalVersion ?? "";
        var plus = info.IndexOf('+'); if (plus >= 0) info = info[..plus];
        if (TryCompareRelease(info, info, out _)) return info;
        var v = asm.GetName().Version ?? throw new InvalidOperationException("Versão do executável não definida.");
        return v.Revision > 0 ? v.ToString(4) : v.ToString(3);
    }
    public static bool SameRelease(string left, string right) => TryCompareRelease(left, right, out var c) && c == 0;
    // Comparação do formato publicável (2 a 5 casas), sem a limitação de 4 componentes de System.Version.
    public static bool TryCompareRelease(string left, string right, out int comparison)
    {
        comparison = 0;
        static bool Parse(string value, out int[] parts)
        {
            parts = Array.Empty<int>();
            if (string.IsNullOrWhiteSpace(value) || value.Length > 32) return false;
            var items = value.Split('.');
            if (items.Length < 2 || items.Length > 5) return false;
            var result = new int[items.Length];
            for (var i = 0; i < items.Length; i++)
            {
                if (items[i].Length is < 1 or > 5 || !items[i].All(char.IsAsciiDigit)
                    || !int.TryParse(items[i], out result[i])) return false;
            }
            parts = result;
            return true;
        }
        if (!Parse(left, out var a) || !Parse(right, out var b)) return false;
        for (var i = 0; i < Math.Max(a.Length, b.Length); i++)
        {
            comparison = (i < a.Length ? a[i] : 0).CompareTo(i < b.Length ? b[i] : 0);
            if (comparison != 0) return true;
        }
        return true;
    }
}
