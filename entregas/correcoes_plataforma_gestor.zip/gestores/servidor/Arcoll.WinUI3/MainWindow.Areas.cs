// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Areas.cs
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Win32;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3;
public sealed partial class MainWindow
{
 private Services.GestorTheme? _areaTheme;private bool _areaApplying;private int _osCaption=-1;
 [DllImport("dwmapi.dll")]private static extern int DwmSetWindowAttribute(IntPtr hwnd,int attribute,ref int value,int size);
 private Services.GestorAreaColors AreaColors()=>Services.GestorAreaPalette.Create(_themes.Current.Background,_themes.Current.Surface,_themes.Current.Text,_themes.Current.Accent,_themes.Current.Muted,Services.ThemeService.IsLight(_themes.Current));
 private void InitializeGestorAreas()
 {
  FooterText.RegisterPropertyChangedCallback(TextBlock.ForegroundProperty,(_,_)=>PaintAreaFooter());
  RootGrid.RegisterPropertyChangedCallback(Microsoft.UI.Xaml.FrameworkElement.RequestedThemeProperty,(_,_)=>DispatcherQueue.TryEnqueue(()=>{_osCaption=-1;RefreshOsCaption();}));
  PaintAreaFooter();RefreshOsCaption();
 }
 private void PaintAreaFooter()
 {
  if(_areaApplying)return;_areaApplying=true;
  try{var c=AreaColors();StatusBorder.Background=Services.ThemeService.Brush(c.Area10);var brush=Services.ThemeService.Brush(c.FooterText);if(FooterText.Foreground is not Microsoft.UI.Xaml.Media.SolidColorBrush old||old.Color!=((Microsoft.UI.Xaml.Media.SolidColorBrush)brush).Color)FooterText.Foreground=brush;}
  finally{_areaApplying=false;}
 }
 private void RefreshGestorAreas()
 {
  RefreshOsCaption();PaintAreaFooter();
  if(_areaTheme==_themes.Current)return;_areaTheme=_themes.Current;
  var c=AreaColors();_gestorUpdatePage?.ApplyAreas(c);
  var json=JsonSerializer.Serialize(c,new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
  foreach(var core in _compactCores.ToArray())_ = ApplyAreaScriptAsync(core,"window.__tiSetAreas?.("+json+");");
 }
 private static async Task ApplyAreaScriptAsync(Microsoft.Web.WebView2.Core.CoreWebView2 core,string script){try{await core.ExecuteScriptAsync(script);}catch(Exception error)when(error is InvalidOperationException or COMException){}}
 // Páginas web embutidas: esconde qualquer barra de rolagem (a rolagem por roda/toque continua).
 private const string HiddenScrollbarsScript="(function(){var css='*{scrollbar-width:none!important;-ms-overflow-style:none!important}*::-webkit-scrollbar{display:none!important;width:0!important;height:0!important}';function add(){if(document.getElementById('ti-no-scrollbars'))return;var s=document.createElement('style');s.id='ti-no-scrollbars';s.textContent=css;(document.head||document.documentElement).appendChild(s)}add();document.addEventListener('DOMContentLoaded',add)})();";
 private string CurrentCompactScript()=>"window.__tiAreaPalette="+JsonSerializer.Serialize(AreaColors(),new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase})+";\n"+"window.__tiLoaderMark="+JsonSerializer.Serialize(_themes.LoaderMark)+";\n"+_loaderMarkScript+"\n"+HiddenScrollbarsScript+"\n"+_compactScript+"\n"+_workspaceScript;
 /// <summary>O cabeçalho do Gestor ocupa o lugar da Title Bar: conteúdo estendido, altura de 48 px e botões de janela do sistema com a cor do cabeçalho.</summary>
 private void InitializeCustomHeader()
 {
  try
  {
   ExtendsContentIntoTitleBar=true;SetTitleBar(HeaderDragRegion);ApplyCaptionPolicy();
   AppWindow.TitleBar.PreferredHeightOption=Microsoft.UI.Windowing.TitleBarHeightOption.Tall;
   QuickBar.SizeChanged+=(_,_)=>UpdateCaptionInset();

  }
  catch(Exception error)when(error is InvalidOperationException or COMException or NotSupportedException){Services.RuntimeLog.Write("Cabeçalho do gestor: "+error.Message);}
 }
/// <summary>Sem minimizar nem maximizar: o botão de modo de tela (mobile → desktop → tela cheia) faz esse papel; só o fechar (X) permanece. Reaplicado sempre que o presenter é recriado.</summary>
 private void ApplyCaptionPolicy()
 {
  try{if(AppWindow.Presenter is Microsoft.UI.Windowing.OverlappedPresenter presenter){presenter.IsMinimizable=false;presenter.IsMaximizable=false;}}
  catch(Exception error)when(error is InvalidOperationException or COMException or NotSupportedException){Services.RuntimeLog.Write("Botões da janela: "+error.Message);}
 }
 /// <summary>Reserva à direita o espaço do botão fechar do sistema (já em pixels lógicos).</summary>
 private void UpdateCaptionInset()
 {
  try{var scale=QuickBar.XamlRoot?.RasterizationScale??1.0;CaptionInset.Width=Math.Max(0,AppWindow.TitleBar.RightInset/scale);}
  catch(Exception error)when(error is InvalidOperationException or COMException){}
 }
 /// <summary>Botão fechar transparente sobre o cabeçalho, com o contraste do tema ativo.</summary>
 private void PaintCaptionButtons(Windows.UI.Color ink)
 {
  try
  {
   var bar=AppWindow.TitleBar;var clear=Microsoft.UI.Colors.Transparent;var hover=Windows.UI.Color.FromArgb(46,ink.R,ink.G,ink.B);var press=Windows.UI.Color.FromArgb(80,ink.R,ink.G,ink.B);
   bar.BackgroundColor=clear;bar.InactiveBackgroundColor=clear;bar.ButtonBackgroundColor=clear;bar.ButtonInactiveBackgroundColor=clear;
   bar.ForegroundColor=ink;bar.ButtonForegroundColor=ink;bar.ButtonInactiveForegroundColor=Windows.UI.Color.FromArgb(150,ink.R,ink.G,ink.B);
   bar.ButtonHoverBackgroundColor=hover;bar.ButtonHoverForegroundColor=ink;bar.ButtonPressedBackgroundColor=press;bar.ButtonPressedForegroundColor=ink;
  }
  catch(Exception error)when(error is InvalidOperationException or COMException){}
 }
 private void RefreshOsCaption()
 {
  try{using var key=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");var dark=Convert.ToInt32(key?.GetValue("AppsUseLightTheme",1))==0?1:0;if(dark==_osCaption)return;_osCaption=dark;
   var hwnd=WinRT.Interop.WindowNative.GetWindowHandle(this);if(DwmSetWindowAttribute(hwnd,20,ref dark,sizeof(int))!=0)DwmSetWindowAttribute(hwnd,19,ref dark,sizeof(int));
  }catch(Exception error)when(error is InvalidOperationException or COMException or UnauthorizedAccessException){ }
 }
}
