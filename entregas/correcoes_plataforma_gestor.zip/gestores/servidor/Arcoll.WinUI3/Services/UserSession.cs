// Caminho: gestores/servidor/Arcoll.WinUI3/Services/UserSession.cs
using System.Text.Json;
namespace Arcoll.WinUI3.Services;

public sealed record NetworkAccess(long Id, string Name, string Role, bool Full, IReadOnlySet<string> Menus);

/// <summary>
/// Sessão do usuário que entrou na tela protegida do Gestor. O token é assinado pela plataforma, expira por configuração administrativa
/// e fica somente em memória: nenhuma senha ou token é gravado na máquina.
/// </summary>
public sealed class UserSession
{
    private string _token = "";
    private DateTime _expiresUtc = DateTime.MinValue;
    public string UserName { get; private set; } = "";
    public string Role { get; private set; } = "";
    /// <summary>Foto do perfil (data URI) devolvida pela plataforma no login; vazia quando o usuário não tem foto.</summary>
    public string Avatar { get; private set; } = "";
    public long HomeNetworkId { get; private set; }
    public long ActiveNetworkId { get; private set; }
    public IReadOnlyList<NetworkAccess> Networks { get; private set; } = Array.Empty<NetworkAccess>();
    public bool Active => _token.Length > 0 && DateTime.UtcNow < _expiresUtc;
    public bool ViewingOther => Active && ActiveNetworkId != HomeNetworkId;
    public string Token => Active ? _token : "";
    public NetworkAccess? Current => Active ? Networks.FirstOrDefault(n => n.Id == ActiveNetworkId) : null;
    public string Signature => Active ? $"{UserName}|{ActiveNetworkId}|{string.Join(",", Current?.Menus.OrderBy(m => m) ?? Enumerable.Empty<string>())}" : "";

    /// <summary>Filtro de menus pelo perfil do usuário: sem sessão ativa não restringe (o filtro da instalação continua valendo).</summary>
    public bool Allows(string key)
    {
        if (!Active || key == "remote") return true;
        var net = Current;
        if (net is null) return true;
        return net.Full || net.Menus.Contains(key);
    }

    public event Action? Changed;

    public static async Task<UserSession> LoginAsync(PlatformClient platform, UserSession target, string email, string password, CancellationToken ct)
    {
        var r = await platform.PostAsync("gestor-user-login", platform.WithCredentials(("email", email.Trim()), ("password", password), ("standalone",platform.Config.IsStandalone)), ct, 15);
        var networks = new List<NetworkAccess>();
        foreach (var n in r.GetProperty("networks").EnumerateArray())
        {
            var menus = new HashSet<string>(StringComparer.Ordinal);
            if (n.TryGetProperty("menus", out var list) && list.ValueKind == JsonValueKind.Array)
                foreach (var m in list.EnumerateArray()) if (m.ValueKind == JsonValueKind.String) menus.Add(m.GetString()!);
            networks.Add(new NetworkAccess(n.GetProperty("id").GetInt64(), n.GetProperty("name").GetString() ?? "Rede",
                n.GetProperty("role").GetString() ?? "viewer", n.TryGetProperty("full", out var f) && f.ValueKind == JsonValueKind.True, menus));
        }
        var user = r.GetProperty("user");
        var token=r.GetProperty("token").GetString()??"";
        var expires=DateTimeOffset.FromUnixTimeSeconds(r.GetProperty("expires").GetInt64()).UtcDateTime;
        var name=user.GetProperty("name").GetString()??"";
        var role=user.GetProperty("role").GetString()??"viewer";
        var avatar=user.TryGetProperty("avatar",out var photo)&&photo.ValueKind==JsonValueKind.String?photo.GetString()??"":"";
        var home=r.GetProperty("home_network_id").GetInt64();
        if(token.Length==0||expires<=DateTime.UtcNow)throw new PlatformException("A plataforma não confirmou uma sessão válida. Tente entrar novamente.");
        target._token=token;target._expiresUtc=expires;target.UserName=name;target.Role=role;target.Avatar=avatar;
        target.HomeNetworkId=home;target.ActiveNetworkId=home;target.Networks=networks;
        target.Changed?.Invoke();
        return target;
    }

    public void RefreshNetworks(IEnumerable<JsonElement> rows)
    {
        if(!Active)return;
        var updated=rows.Select(n=>new NetworkAccess(n.GetProperty("id").GetInt64(),n.GetProperty("name").GetString()??"Rede",n.GetProperty("role").GetString()??"viewer",n.GetProperty("full").GetBoolean(),n.GetProperty("menus").EnumerateArray().Select(m=>m.GetString()??"").ToHashSet(StringComparer.Ordinal))).ToArray();
        var before=Signature+"|"+string.Join(";",Networks.Select(n=>n.Id+":"+n.Name+":"+n.Role));
        Networks=updated;
        if(!updated.Any(n=>n.Id==ActiveNetworkId))ActiveNetworkId=updated.FirstOrDefault()?.Id??0;
        if(before!=Signature+"|"+string.Join(";",Networks.Select(n=>n.Id+":"+n.Name+":"+n.Role)))Changed?.Invoke();
    }

    public bool Select(long networkId)
    {
        if (!Active || Networks.All(n => n.Id != networkId)) return false;
        ActiveNetworkId = networkId; Changed?.Invoke(); return true;
    }

    public void Clear()
    {
        _token = ""; _expiresUtc = DateTime.MinValue; UserName = ""; Role = ""; Avatar = ""; Networks = Array.Empty<NetworkAccess>(); ActiveNetworkId = HomeNetworkId = 0;
        Changed?.Invoke();
    }
}
