// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/SessionDialogs.cs
// Modais do Gestor: login do usuário, vínculo da conta à rede (QR Code + código → login → escolha da rede) e menu do Gestor Windows.
using Arcoll.WinUI3.Controls;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Windows.ApplicationModel.DataTransfer;
using Windows.System;
namespace Arcoll.WinUI3.Pages;

/// <summary>Componentes comuns dos modais: moldura com tema ativo, cabeçalho com selo e botões arredondados.</summary>
internal static class ModalKit
{
    public static ContentDialog Create(XamlRoot root, Palette p, UIElement content, double width = 420)
    {
        var dialog = new ContentDialog
        {
            XamlRoot = root, Content = content, Background = p.Surface, BorderBrush = p.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(18),
            Foreground = p.Text, Padding = new Thickness(24), RequestedTheme = p.Light ? ElementTheme.Light : ElementTheme.Dark,
        };
        dialog.Resources["ContentDialogMinWidth"] = width; dialog.Resources["ContentDialogMaxWidth"] = width + 48;
        return dialog;
    }

    public static UIElement Header(Palette p, string glyph, string title, string subtitle)
    {
        var badge = new Grid { Width = 44, Height = 44, VerticalAlignment = VerticalAlignment.Center };
        badge.Children.Add(new Border { CornerRadius = new CornerRadius(22), Background = p.Accent, Opacity = .18 });
        badge.Children.Add(new FontIcon { Glyph = glyph, FontSize = 20, Foreground = p.Accent, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center });
        var titles = new StackPanel { Spacing = 2, VerticalAlignment = VerticalAlignment.Center };
        titles.Children.Add(Ui.Label(title, p.Text, 18, true, true));
        if (subtitle.Length > 0) titles.Children.Add(Ui.Label(subtitle, p.Muted, 12, false, true));
        var head = new Grid { ColumnSpacing = 12 };
        head.ColumnDefinitions.Add(new() { Width = GridLength.Auto }); head.ColumnDefinitions.Add(new() { Width = new GridLength(1, GridUnitType.Star) });
        head.Children.Add(badge); Grid.SetColumn(titles, 1); head.Children.Add(titles);
        return head;
    }

    private static Brush InkFor(Brush fill)
    {
        if (fill is not SolidColorBrush solid) return new SolidColorBrush(Microsoft.UI.Colors.White);
        var c = solid.Color; var luminance = (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) / 255;
        return new SolidColorBrush(luminance > .6 ? Windows.UI.Color.FromArgb(255, 15, 23, 42) : Microsoft.UI.Colors.White);
    }

    public static Button Action(Palette p, string glyph, string text, bool primary, bool danger = false)
    {
        var fill = danger ? p.Danger : primary ? p.Accent : p.Alt; var ink = primary || danger ? InkFor(fill) : p.Text;
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, HorizontalAlignment = HorizontalAlignment.Center };
        row.Children.Add(new FontIcon { Glyph = glyph, FontSize = 15, Foreground = ink });
        row.Children.Add(new TextBlock { Text = text, FontSize = 13, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, Foreground = ink, VerticalAlignment = VerticalAlignment.Center });
        var button = new Button { Content = row, HorizontalAlignment = HorizontalAlignment.Stretch, MinHeight = 40, CornerRadius = new CornerRadius(10), Padding = new Thickness(12, 6, 12, 6), Background = fill, BorderBrush = primary || danger ? fill : p.Line };
        foreach (var key in new[] { "ButtonBackgroundPointerOver", "ButtonBackgroundPressed" }) button.Resources[key] = fill;
        foreach (var key in new[] { "ButtonForegroundPointerOver", "ButtonForegroundPressed" }) button.Resources[key] = ink;
        foreach (var key in new[] { "ButtonBorderBrushPointerOver", "ButtonBorderBrushPressed" }) button.Resources[key] = primary || danger ? fill : p.Accent;
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(button, text);
        return button;
    }

    public static TextBlock Message(Palette p) => new() { FontSize = 12, TextWrapping = TextWrapping.Wrap, Foreground = p.Muted, Visibility = Visibility.Collapsed };

    public static void Show(TextBlock block, Brush brush, string text) { block.Text = text; block.Foreground = brush; block.Visibility = text.Length == 0 ? Visibility.Collapsed : Visibility.Visible; }
}

/// <summary>Login do usuário em modal (substitui a antiga tela de acesso protegido). Obrigatório quando o gestor exige login.</summary>
public static class LoginDialog
{
    public static async Task<bool> ShowAsync(XamlRoot root, Palette p, string networkName, bool required, Func<string, string, CancellationToken, Task> login)
    {
        var email = new TextBox { Header = "E-mail", PlaceholderText = "usuario@empresa.com", InputScope = new Microsoft.UI.Xaml.Input.InputScope { Names = { new Microsoft.UI.Xaml.Input.InputScopeName(Microsoft.UI.Xaml.Input.InputScopeNameValue.EmailSmtpAddress) } } };
        var password = new PasswordBox { Header = "Senha", PlaceholderText = "Senha" };
        var message = ModalKit.Message(p); var busy = new ProgressBar { IsIndeterminate = true, Visibility = Visibility.Collapsed };
        var enter = ModalKit.Action(p, "\uE72E", "Entrar", true); var cancel = ModalKit.Action(p, "\uE711", "Cancelar", false);
        var subtitle = string.IsNullOrWhiteSpace(networkName) ? "Informe suas credenciais" : "Rede " + networkName + " · informe suas credenciais";
        var body = new StackPanel { Spacing = 12 };
        body.Children.Add(ModalKit.Header(p, "\uE77B", "Entrar no Gestor", subtitle)); body.Children.Add(email); body.Children.Add(password); body.Children.Add(message); body.Children.Add(busy); body.Children.Add(enter);
        if (!required) body.Children.Add(cancel);
        body.Children.Add(Ui.Label("O gestor abre com as áreas liberadas para o seu perfil.", p.Muted, 11, false, true));
        var dialog = ModalKit.Create(root, p, body, 400);
        var ok = false; var working = false;
        async Task Submit()
        {
            if (working) return;
            if (email.Text.Trim().Length == 0 || password.Password.Length == 0) { ModalKit.Show(message, p.Danger, "Informe o e-mail e a senha."); return; }
            working = true; enter.IsEnabled = false; busy.Visibility = Visibility.Visible; ModalKit.Show(message, p.Muted, "");
            try
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
                await login(email.Text.Trim(), password.Password, timeout.Token);
                ok = true; password.Password = ""; dialog.Hide();
            }
            catch (PlatformException ex) { ModalKit.Show(message, p.Danger, ex.Message); }
            catch (System.Text.Json.JsonException ex) { RuntimeLog.Write("Resposta de login: "+ex.Message);ModalKit.Show(message,p.Danger,"A plataforma retornou uma resposta de login inválida. Atualize a plataforma e o Gestor juntos."); }
            catch (KeyNotFoundException ex) { RuntimeLog.Write("Resposta de login incompleta: "+ex.Message);ModalKit.Show(message,p.Danger,"A resposta de login está incompleta. Atualize a plataforma e o Gestor juntos."); }
            catch (OperationCanceledException) { ModalKit.Show(message,p.Danger,"A conexão demorou para responder. Verifique a internet e tente novamente."); }
            catch (Exception ex) { RuntimeLog.Write("Login de usuário: " + ex.GetType().Name + ": " + ex.Message); ModalKit.Show(message, p.Danger, "Não foi possível entrar. Verifique a conexão e tente novamente."); }
            finally { working = false; enter.IsEnabled = true; busy.Visibility = Visibility.Collapsed; }
        }
        enter.Click += async (_, _) => await Submit(); cancel.Click += (_, _) => dialog.Hide();
        password.KeyDown += async (_, e) => { if (e.Key == VirtualKey.Enter) { e.Handled = true; await Submit(); } };
        email.KeyDown += async (_, e) => { if (e.Key == VirtualKey.Enter) { e.Handled = true; await Submit(); } };
        dialog.Closing += (_, args) => { if (required && !ok && args.Result == ContentDialogResult.None) args.Cancel = true; };
        dialog.Opened += (_, _) => email.Focus(FocusState.Programmatic);
        await dialog.ShowAsync();
        return ok;
    }
}

/// <summary>Resultado da vinculação por QR Code; o login do usuário é independente.</summary>
public sealed record LinkOutcome(bool Linked, string Email, string Password);

/// <summary>Modal exclusivamente de QR Code e código. A aprovação ocorre na plataforma, sem solicitar senha neste modal.</summary>
public static class LinkAccountDialog
{
    public static async Task<LinkOutcome> ShowAsync(XamlRoot root, Palette p, GestorConfig cfg, string title, string subtitle)
    {
        using var stop = new CancellationTokenSource();
        string token = "", code = "", link = "";
        bool linked = false;
        var qr = new QrView(); qr.SetSize(190);
        var codeText = new TextBlock { Text = "…", FontSize = 28, FontWeight = Microsoft.UI.Text.FontWeights.Bold, FontFamily = new FontFamily("Cascadia Mono, Consolas"), IsTextSelectionEnabled = true, Foreground = p.Text, HorizontalAlignment = HorizontalAlignment.Center, CharacterSpacing = 100 };
        var caption = Ui.Label("CÓDIGO DE VINCULAÇÃO", p.Muted, 10.5, true); caption.HorizontalAlignment = HorizontalAlignment.Center;
        var hint = Ui.Label("Leia o QR Code na plataforma ou informe o código de vinculação.", p.Muted, 12, false, true); hint.TextAlignment = TextAlignment.Center;
        var bar = new ProgressBar { IsIndeterminate = true };
        var status = Ui.Label("Gerando código…", p.Muted, 12, false, true); status.TextAlignment = TextAlignment.Center;
        var copy = ModalKit.Action(p, "\uE8C8", "Copiar código", false);
        var send = ModalKit.Action(p, "\uE724", "Enviar", false);
        copy.IsEnabled = send.IsEnabled = false;
        var tools = new Grid { ColumnSpacing = 8 };
        tools.ColumnDefinitions.Add(new()); tools.ColumnDefinitions.Add(new());
        tools.Children.Add(copy); Grid.SetColumn(send, 1); tools.Children.Add(send);
        var plate = new StackPanel { Spacing = 9, HorizontalAlignment = HorizontalAlignment.Center };
        plate.Children.Add(qr); plate.Children.Add(hint); plate.Children.Add(caption); plate.Children.Add(codeText);
        var body = new StackPanel { Spacing = 14 };
        body.Children.Add(ModalKit.Header(p, "\uE71B", title, subtitle));
        body.Children.Add(new Border { Background = p.Alt, BorderBrush = p.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(16), Padding = new Thickness(16), Child = plate });
        body.Children.Add(tools); body.Children.Add(bar); body.Children.Add(status);
        var dialog = ModalKit.Create(root, p, new ScrollViewer { MaxHeight = 610, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = body }, 420);
        dialog.CloseButtonText = "Fechar";
        copy.Click += (_, _) => { if (code.Length == 0) return; var data = new DataPackage(); data.SetText(code); Clipboard.SetContent(data); status.Text = "Código copiado."; };
        send.Click += async (_, _) =>
        {
            if (code.Length == 0) return;
            var message = "*" + title + "*\nCódigo de vinculação: *" + code + "*" + (link.Length == 0 ? "" : "\n" + link);
            await Launcher.LaunchUriAsync(new Uri("https://wa.me/?text=" + Uri.EscapeDataString(message)));
        };
        async Task Poll()
        {
            try
            {
                var pair = await PairingService.BeginAsync(cfg, stop.Token);
                token = pair.Token; code = pair.Code;
                link = cfg.Origin.TrimEnd('/') + "/redes/liberacao.php?pair=" + code.Replace("-", "");
                codeText.Text = code; qr.SetContent(link); copy.IsEnabled = send.IsEnabled = true;
                bar.IsIndeterminate = false; bar.Maximum = Math.Max(1, pair.Seconds);
                var until = DateTime.UtcNow.AddSeconds(pair.Seconds);
                while (!stop.IsCancellationRequested)
                {
                    var left = (int)Math.Max(0, (until - DateTime.UtcNow).TotalSeconds);
                    bar.Value = Math.Clamp(left, 0, bar.Maximum);
                    status.Text = "Válido por " + left + " s · aguardando aprovação na plataforma";
                    if (left <= 0) { status.Text = "Código expirado. Reabra a vinculação para gerar outro."; copy.IsEnabled = send.IsEnabled = false; qr.SetContent(""); break; }
                    await Task.Delay(3000, stop.Token);
                    var state = await PairingService.StatusAsync(cfg, token, stop.Token);
                    if (state == "linked") { linked = true; dialog.Hide(); break; }
                    if (state is "expired" or "unlinked") { status.Text = "Código expirado ou cancelado. Gere outro código."; copy.IsEnabled = send.IsEnabled = false; break; }
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { bar.IsIndeterminate = false; bar.Value = 0; codeText.Text = "—"; status.Text = ex.Message; status.Foreground = p.Danger; }
        }
        _ = Poll();
        try { await dialog.ShowAsync(); } finally { stop.Cancel(); }
        return new LinkOutcome(linked, "", "");
    }
}

public enum GestorMenuChoice { None, Update, Reinstall, Uninstall, Center }

/// <summary>Menu do Gestor Windows (ícone do cabeçalho): atualizar, reinstalar e desinstalar este gestor.</summary>
public static class GestorMenuDialog
{
    public static async Task<GestorMenuChoice> ShowAsync(XamlRoot root, Palette p, string version, bool updateAvailable, bool canUpdate, bool canUninstall)
    {
        var choice = GestorMenuChoice.None; ContentDialog? dialog = null;
        Button Row(string glyph, string text, string detail, GestorMenuChoice value, bool enabled, bool primary, bool danger = false)
        {
            var button = ModalKit.Action(p, glyph, text, primary, danger); button.IsEnabled = enabled;
            ToolTipService.SetToolTip(button, detail);
            button.Click += (_, _) => { choice = value; dialog?.Hide(); };
            return button;
        }
        var body = new StackPanel { Spacing = 10 };
        body.Children.Add(ModalKit.Header(p, "\uE895", "Gestor Windows", "Versão instalada " + version + (updateAvailable ? " · nova versão disponível" : "")));
        body.Children.Add(Row("\uE895", updateAvailable ? "Atualizar gestor (nova versão)" : "Atualizar gestor", "Verifica e instala a versão publicada pela plataforma.", GestorMenuChoice.Update, canUpdate, true));
        body.Children.Add(Row("\uE777", "Reinstalar gestor", "Baixa e valida novamente todos os arquivos publicados, preservando a configuração.", GestorMenuChoice.Reinstall, canUpdate, false));
        body.Children.Add(Row("\uE74D", "Desinstalar gestor", "Remove este Gestor e os dados exclusivos desta instalação.", GestorMenuChoice.Uninstall, canUninstall, false, true));
        var center = new HyperlinkButton { Content = "Abrir central de atualização", HorizontalAlignment = HorizontalAlignment.Center, Foreground = p.Accent };
        center.Click += (_, _) => { choice = GestorMenuChoice.Center; dialog?.Hide(); };
        body.Children.Add(center);
        if (!canUpdate) body.Children.Add(Ui.Label("Conecte e autorize o gestor para atualizar ou reinstalar.", p.Muted, 11, false, true));
        dialog = ModalKit.Create(root, p, body, 380); dialog.CloseButtonText = "Fechar";
        await dialog.ShowAsync();
        return choice;
    }
}
