// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/NetworkDashboardPage.cs
using System.Text.Json;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3.Pages;

/// <summary>Dashboard nativo disponível sem sessão; os dados de redes e o cadastro exigem login.</summary>
public sealed class NetworkDashboardPage : UserControl,IPageDataSource
{
    public PageDataLoad DataLoad{get;}=new("Redes da sua conta");
    public bool CanCancelCollection=>false;
    public void CancelCollection(){}
    private readonly GestorRuntime _runtime;
    private readonly Func<Task<bool>> _login;
    private readonly StackPanel _body=new(){Spacing=12,Padding=new Thickness(14)};
    private readonly TextBlock _status=new(){TextWrapping=TextWrapping.Wrap};
    private Palette _palette=new();
    private JsonElement[] _rows=[];
    private bool _busy;
    private string _session="";
    public NetworkDashboardPage(GestorRuntime runtime,Func<Task<bool>> login)
    {
        _runtime=runtime;_login=login;
        Content=new ScrollViewer{Content=_body,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        DataLoad.Complete();
        _poll.Tick+=async(_,_)=>{if(!_dialogOpen)await CollectDataAsync();};
        Loaded+=async(_,_)=>{_runtime.User.Changed+=SessionChanged;_poll.Start();await CollectDataAsync();};
        Unloaded+=(_,_)=>{_runtime.User.Changed-=SessionChanged;_poll.Stop();};
        Render();
    }
    private void SessionChanged()=>DispatcherQueue.TryEnqueue(async()=>await CollectDataAsync());
    public void ApplyPalette(Palette palette){_palette=palette;Render();}
    private async Task<JsonElement> RequestAsync(string operation,object? values=null)
    {
        if(!_runtime.User.Active)throw new UnauthorizedAccessException("Entre na sua conta para continuar.");
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(25));
        return await _runtime.Platform.PostAsync("gestor-account-dashboard",_runtime.Platform.WithCredentials(("standalone",_runtime.Platform.Config.IsStandalone),("user_token",_runtime.User.Token),("operation",operation),("values",values)),timeout.Token);
    }
    public async Task CollectDataAsync()
    {
        var signature=_runtime.User.Signature;
        if(_session!=signature){_session=signature;_rows=[];_logos.Clear();_status.Text="";}
        if(!_runtime.User.Active){_rows=[];DataLoad.Complete();Render();return;}
        if(_busy)return;_busy=true;Render();
        try{
            var result=await RequestAsync("read");
            if(signature!=_runtime.User.Signature)return;
            if(result.TryGetProperty("poll_seconds",out var poll))_poll.Interval=TimeSpan.FromSeconds(Math.Clamp(poll.GetInt32(),3,120));
            _rows=result.GetProperty("rows").EnumerateArray().Select(x=>x.Clone()).ToArray();_runtime.User.RefreshNetworks(result.GetProperty("networks").EnumerateArray());_session=_runtime.User.Signature;_status.Text="";
        }catch(Exception error){if(signature==_runtime.User.Signature)_status.Text=error.Message;}
        finally{_busy=false;DataLoad.Complete();Render();if(signature!=_runtime.User.Signature&&_runtime.User.Active)await CollectDataAsync();}
    }
    private Button Button(string text,Func<Task> action)
    {
        var button=new Button{Content=text,Foreground=_palette.Text,Background=_palette.Surface,IsEnabled=!_busy};
        button.Click+=async(_,_)=>{button.IsEnabled=false;try{await action();}catch(Exception error){_status.Text=error.Message;}finally{Render();}};
        return button;
    }
    private readonly Grid _cards=new(){ColumnSpacing=8,RowSpacing=8};
    private readonly TextBox _search=new(){PlaceholderText="Buscar rede...",MinWidth=0};
    private readonly ComboBox _filter=new(){ItemsSource=new[]{"Todas","Online","Offline"},SelectedIndex=0,MinWidth=80};
    private readonly DispatcherTimer _poll=new(){Interval=TimeSpan.FromSeconds(15)};
    private readonly Dictionary<long,Microsoft.UI.Xaml.Media.ImageSource> _logos=new();
    private readonly HashSet<long> _logoPending=new();
    private bool _layoutBuilt,_dialogOpen;
    private Button? _all,_online,_offline,_newNetwork;
    private void Render()
    {
        if(_session!=_runtime.User.Signature){_rows=[];_logos.Clear();_status.Text="";}
        Background=_palette.Alt;_status.Foreground=_palette.Muted;
        if(!_layoutBuilt){
            _layoutBuilt=true;
            var searchRow=new Grid{ColumnSpacing=6};searchRow.ColumnDefinitions.Add(new(){Width=new GridLength(1,GridUnitType.Star)});searchRow.ColumnDefinitions.Add(new(){Width=GridLength.Auto});
            searchRow.Children.Add(_search);Grid.SetColumn(_filter,1);searchRow.Children.Add(_filter);_body.Children.Add(searchRow);
            var actions=new Grid{ColumnSpacing=6};actions.ColumnDefinitions.Add(new(){Width=new GridLength(1,GridUnitType.Star)});actions.ColumnDefinitions.Add(new(){Width=GridLength.Auto});
            var indicators=new StackPanel{Orientation=Orientation.Horizontal,Spacing=5};
            _all=Button("Redes",()=>SetFilterAsync(0));_online=Button("Online",()=>SetFilterAsync(1));_offline=Button("Offline",()=>SetFilterAsync(2));
            indicators.Children.Add(_all);indicators.Children.Add(_online);indicators.Children.Add(_offline);actions.Children.Add(indicators);
            _newNetwork=Button("+ Nova rede",CreateAsync);Grid.SetColumn(_newNetwork,1);actions.Children.Add(_newNetwork);_body.Children.Add(actions);_body.Children.Add(_cards);_body.Children.Add(_status);
            _search.TextChanged+=(_,_)=>RenderCards();_filter.SelectionChanged+=(_,_)=>RenderCards();
            SizeChanged+=(_,e)=>{if(Math.Abs(e.NewSize.Width-e.PreviousSize.Width)>1)RenderCards();};
        }
        _search.Foreground=_filter.Foreground=_palette.Text;_search.Background=_filter.Background=_palette.Surface;
        var online=_rows.Count(IsOnline);
        if(_all is not null)_all.Content="Redes "+_rows.Length;
        if(_online is not null)_online.Content="Online "+online;
        if(_offline is not null)_offline.Content="Offline "+(_rows.Length-online);
        foreach(var button in new[]{_all,_online,_offline,_newNetwork})if(button is not null){button.Foreground=_palette.Text;button.Background=_palette.Surface;button.IsEnabled=!_busy;}
        RenderCards();
    }
    private Task SetFilterAsync(int index){_filter.SelectedIndex=index;RenderCards();return Task.CompletedTask;}
    private static string V(JsonElement item,string name)=>item.TryGetProperty(name,out var value)?value.ToString():"";
    private static bool IsOnline(JsonElement item)=>V(item,"is_active")=="1"&&long.TryParse(V(item,"gestores_online"),out var online)&&online>0;
    private static string Normal(string text)=>ProgramService.Normalize(text);
    private void RenderCards()
    {
        _cards.Children.Clear();_cards.ColumnDefinitions.Clear();_cards.RowDefinitions.Clear();
        var columns=Math.Max(1,(int)(Math.Max(128,ActualWidth-28)/136));
        for(var c=0;c<columns;c++)_cards.ColumnDefinitions.Add(new());
        var index=0;
        void Add(UIElement element){if(index%columns==0)_cards.RowDefinitions.Add(new(){Height=new GridLength(142)});Grid.SetColumn(element,index%columns);Grid.SetRow(element,index/columns);_cards.Children.Add(element);index++;}
        var query=Normal(_search.Text);
        foreach(var row in _rows){
            var item=row.Clone();var online=IsOnline(item);
            if(_filter.SelectedIndex==1&&!online||_filter.SelectedIndex==2&&online)continue;
            if(!Normal(V(item,"name")+" "+V(item,"client_name")+" "+V(item,"site_code")).Contains(query))continue;
            var id=item.GetProperty("id").GetInt64();var content=new Grid{RowSpacing=3};
            foreach(var h in new[]{47d,17,14,14,14})content.RowDefinitions.Add(new(){Height=new GridLength(h)});
            var logo=new Image{Width=43,Height=43,Stretch=Microsoft.UI.Xaml.Media.Stretch.Uniform,HorizontalAlignment=HorizontalAlignment.Center};
            if(_logos.TryGetValue(id,out var cached))logo.Source=cached;else if(V(item,"logo_file").Length>0)_=LoadLogoAsync(id,logo,_runtime.User.Signature);
            var placeholder=new SymbolIcon(Symbol.World){Width=43,Height=43,Foreground=_palette.Accent,Visibility=logo.Source is null?Visibility.Visible:Visibility.Collapsed};
            var logoHost=new Grid();logoHost.Children.Add(placeholder);logoHost.Children.Add(logo);content.Children.Add(logoHost);
            logo.ImageOpened+=(_,_)=>placeholder.Visibility=Visibility.Collapsed;
            var badge=Ui.Label(online?"● Online":"● Offline",online?_palette.Success:_palette.Danger,8);badge.HorizontalAlignment=HorizontalAlignment.Right;content.Children.Add(badge);
            var texts=new[]{V(item,"name"),V(item,"trade_name").Length>0?V(item,"trade_name"):V(item,"client_name"),string.Join(" / ",new[]{V(item,"city_name"),V(item,"state_code")}.Where(x=>x.Length>0))+" · "+V(item,"site_code"),V(item,"gestores_online")+" de "+V(item,"gestores_total")+" gestores online"};
            for(var i=0;i<texts.Length;i++){var label=Ui.Label(texts[i],i==0?_palette.Text:_palette.Muted,i==0?11:9,i==0);label.MaxLines=1;label.TextTrimming=TextTrimming.CharacterEllipsis;label.HorizontalAlignment=HorizontalAlignment.Center;Grid.SetRow(label,i+1);content.Children.Add(label);}
            var tile=Button(V(item,"name"),()=>ShowComputersAsync(item));tile.Content=content;tile.Height=142;tile.Padding=new Thickness(8,7,8,5);tile.HorizontalContentAlignment=HorizontalAlignment.Stretch;tile.HorizontalAlignment=HorizontalAlignment.Stretch;tile.CornerRadius=new CornerRadius(11);ToolTipService.SetToolTip(tile,V(item,"name"));Add(tile);
        }
        var add=Button("Adicionar nova rede",CreateAsync);var addContent=new StackPanel{Spacing=6,HorizontalAlignment=HorizontalAlignment.Center};addContent.Children.Add(new SymbolIcon(Symbol.Add){Foreground=_palette.Accent});addContent.Children.Add(Ui.Label("Adicionar nova rede",_palette.Text,11,true));addContent.Children.Add(Ui.Label("Cadastre uma empresa",_palette.Muted,9));add.Content=addContent;add.HorizontalAlignment=HorizontalAlignment.Stretch;add.Height=142;add.CornerRadius=new CornerRadius(11);Add(add);
    }
    private async Task LoadLogoAsync(long id,Image target,string session)
    {
        if(!_runtime.User.Active||!_logoPending.Add(id))return;
        try{
            var result=await RequestAsync("logo",new{network_id=id});var uri=V(result,"logo");var comma=uri.IndexOf(',');if(comma<0||!uri.StartsWith("data:image/",StringComparison.Ordinal)||session!=_runtime.User.Signature)return;
            using var stream=new Windows.Storage.Streams.InMemoryRandomAccessStream();
            using(var writer=new Windows.Storage.Streams.DataWriter(stream)){writer.WriteBytes(Convert.FromBase64String(uri[(comma+1)..]));await writer.StoreAsync();writer.DetachStream();}stream.Seek(0);
            var bitmap=new Microsoft.UI.Xaml.Media.Imaging.BitmapImage();await bitmap.SetSourceAsync(stream);
            if(session!=_runtime.User.Signature)return;_logos[id]=bitmap;target.Source=bitmap;DispatcherQueue.TryEnqueue(RenderCards);
        }catch(Exception error){RuntimeLog.Write("Logo da rede: "+error.Message);}
        finally{_logoPending.Remove(id);}
    }
    private async Task ShowComputersAsync(JsonElement network)
    {
        if(_dialogOpen||XamlRoot is null)return;_dialogOpen=true;
        try{
            var data=await RequestAsync("computers",new{network_id=network.GetProperty("id").GetInt64()});
            var rows=data.GetProperty("devices").EnumerateArray().Select(x=>x.Clone()).ToList();
            foreach(var gestor in data.GetProperty("gestores").EnumerateArray())if(!rows.Any(x=>Normal(V(x,"name"))==Normal(V(gestor,"name"))))rows.Add(gestor.Clone());
            var body=new StackPanel{Spacing=8};var select=new ComboBox{ItemsSource=new[]{"Todos","Online","Offline"},SelectedIndex=0,HorizontalAlignment=HorizontalAlignment.Stretch};var sort=new ComboBox{ItemsSource=new[]{"Nome","Online primeiro"},SelectedIndex=0,HorizontalAlignment=HorizontalAlignment.Stretch};body.Children.Add(select);body.Children.Add(sort);
            var list=new StackPanel{Spacing=7};body.Children.Add(list);
            void ShowList(){
                list.Children.Clear();
                var filtered=rows.Where(d=>select.SelectedIndex==0||(select.SelectedIndex==1)==(V(d,"online").Equals("true",StringComparison.OrdinalIgnoreCase)||V(d,"online")=="1"));
                filtered=sort.SelectedIndex==1?filtered.OrderByDescending(d=>V(d,"online").Equals("true",StringComparison.OrdinalIgnoreCase)||V(d,"online")=="1").ThenBy(d=>V(d,"name")):filtered.OrderBy(d=>V(d,"name"));
                foreach(var device in filtered){var d=device.Clone();var button=Button(V(d,"name")+" · "+(V(d,"online").Equals("true",StringComparison.OrdinalIgnoreCase)?"Online":"Offline"),()=>{list.Children.Clear();list.Children.Add(Button("Voltar aos computadores",()=>{ShowList();return Task.CompletedTask;}));foreach(var field in new[]{("name","Computador"),("ip","IP"),("mac","MAC"),("type","Tipo")})list.Children.Add(Ui.Label(field.Item2+": "+V(d,field.Item1),_palette.Text,13,wrap:true));return Task.CompletedTask;});button.HorizontalAlignment=HorizontalAlignment.Stretch;list.Children.Add(button);}
                if(!filtered.Any())list.Children.Add(Ui.Label("Nenhum computador neste filtro.",_palette.Muted,12));
            }
            select.SelectionChanged+=(_,_)=>ShowList();sort.SelectionChanged+=(_,_)=>ShowList();ShowList();
            body.Children.Add(Ui.Label("Total no inventário: "+V(data,"total_devices")+" · Consulta sem alterar a rede atual",_palette.Muted,11,wrap:true));
            await Ui.Dialog(XamlRoot,_palette,V(network,"name"),new ScrollViewer{Content=body,MaxHeight=480},close:"Fechar").ShowAsync();
        }finally{_dialogOpen=false;}
    }
    private async Task CreateAsync()
    {
        if(!_runtime.User.Active&&!await _login())return;
        if(XamlRoot is null)return;
        var name=new TextBox{Header="Nome da rede",MaxLength=100};
        var company=new TextBox{Header="Cliente / empresa",MaxLength=160};
        var error=new TextBlock{TextWrapping=TextWrapping.Wrap,Foreground=_palette.Danger};
        var fields=new StackPanel{Spacing=12};fields.Children.Add(name);fields.Children.Add(company);fields.Children.Add(error);
        var dialog=Ui.Dialog(XamlRoot,_palette,"Nova rede",fields,primary:"Cadastrar",close:"Cancelar");
        dialog.PrimaryButtonClick+=async(_,args)=>{
            var deferred=args.GetDeferral();args.Cancel=true;dialog.IsPrimaryButtonEnabled=false;
            try{
                if(string.IsNullOrWhiteSpace(name.Text)){error.Text="Informe o nome da rede.";return;}
                await RequestAsync("create",new{network_name=name.Text.Trim(),client_name=company.Text.Trim()});
                args.Cancel=false;
            }catch(Exception ex){error.Text=ex.Message;}
            finally{dialog.IsPrimaryButtonEnabled=true;deferred.Complete();}
        };
        if(await dialog.ShowAsync()==ContentDialogResult.Primary)await CollectDataAsync();
    }
}
