// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/NetworkDashboardPage.cs
using System.Text.Json;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3.Pages;

/// <summary>Dashboard nativo disponível sem sessão; os dados de redes e o cadastro exigem login.</summary>
public sealed class NetworkDashboardPage : UserControl,IPageDataSource
{
    public PageDataLoad DataLoad{get;}=new("Redes da sua conta");
    public bool CanCancelCollection=>false;
    public void CancelCollection(){}
    private readonly GestorRuntime _runtime;
    private readonly Func<Task<bool>> _login;
    private readonly StackPanel _body=new(){Spacing=12,Padding=new Thickness(14)};
    private readonly TextBlock _status=new(){TextWrapping=TextWrapping.Wrap};
    private Palette _palette=new();
    private JsonElement[] _rows=[];
    private bool _busy;
    private string _session="";
    public NetworkDashboardPage(GestorRuntime runtime,Func<Task<bool>> login)
    {
        _runtime=runtime;_login=login;
        Content=new ScrollViewer{Content=_body,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        DataLoad.Complete();
        Loaded+=async(_,_)=>{_runtime.User.Changed+=SessionChanged;await CollectDataAsync();};
        Unloaded+=(_,_)=>_runtime.User.Changed-=SessionChanged;
        Render();
    }
    private void SessionChanged()=>DispatcherQueue.TryEnqueue(async()=>await CollectDataAsync());
    public void ApplyPalette(Palette palette){_palette=palette;Render();}
    private async Task<JsonElement> RequestAsync(string operation,object? values=null)
    {
        if(!_runtime.User.Active)throw new UnauthorizedAccessException("Entre na sua conta para continuar.");
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(25));
        return await _runtime.Platform.PostAsync("gestor-account-dashboard",_runtime.Platform.WithCredentials(("standalone",_runtime.Platform.Config.IsStandalone),("user_token",_runtime.User.Token),("operation",operation),("values",values)),timeout.Token);
    }
    public async Task CollectDataAsync()
    {
        var signature=_runtime.User.Signature;
        if(_session!=signature){_session=signature;_rows=[];_status.Text="";}
        if(!_runtime.User.Active){_rows=[];DataLoad.Complete();Render();return;}
        if(_busy)return;_busy=true;Render();
        try{
            var result=await RequestAsync("read");
            if(signature!=_runtime.User.Signature)return;
            _rows=result.GetProperty("rows").EnumerateArray().Select(x=>x.Clone()).ToArray();_runtime.User.RefreshNetworks(_rows);_session=_runtime.User.Signature;_status.Text="";
        }catch(Exception error){if(signature==_runtime.User.Signature)_status.Text=error.Message;}
        finally{_busy=false;DataLoad.Complete();Render();if(signature!=_runtime.User.Signature&&_runtime.User.Active)await CollectDataAsync();}
    }
    private Button Button(string text,Func<Task> action)
    {
        var button=new Button{Content=text,Foreground=_palette.Text,Background=_palette.Surface,IsEnabled=!_busy};
        button.Click+=async(_,_)=>{button.IsEnabled=false;try{await action();}catch(Exception error){_status.Text=error.Message;}finally{Render();}};
        return button;
    }
    private void Render()
    {
        if(_session!=_runtime.User.Signature){_rows=[];_status.Text="";}
        _body.Children.Clear();Background=_palette.Alt;
        _body.Children.Add(Ui.Label("Dashboard",_palette.Text,20,true));
        _body.Children.Add(Button("+ Nova rede",CreateAsync));
        _body.Children.Add(Ui.Label("Redes: "+_rows.Length,_palette.Muted,12));
        if(_runtime.User.Active)_body.Children.Add(Button(_busy?"Atualizando…":"Atualizar",CollectDataAsync));
        foreach(var row in _rows){
            var item=row.Clone();var name=item.GetProperty("name").GetString()??"Rede";
            var content=new StackPanel{Spacing=5};content.Children.Add(Ui.Label(name,_palette.Text,15,true));
            content.Children.Add(Ui.Label(item.GetProperty("online")+" de "+item.GetProperty("total")+" gestores online",_palette.Muted,12));
            var tile=Button(name,async()=>{var id=item.GetProperty("id").GetInt64();if(!_runtime.User.Select(id))throw new UnauthorizedAccessException("Entre novamente para atualizar suas redes.");await CollectDataAsync();});tile.Content=content;_body.Children.Add(tile);
        }
        if(_rows.Length==0)_body.Children.Add(Ui.Label("Nenhuma rede para exibir. Cadastre uma nova rede para começar.",_palette.Muted,13,wrap:true));
        _status.Foreground=_palette.Muted;_body.Children.Add(_status);
    }
    private async Task CreateAsync()
    {
        if(!_runtime.User.Active&&!await _login())return;
        if(XamlRoot is null)return;
        var name=new TextBox{Header="Nome da rede",MaxLength=100};
        var company=new TextBox{Header="Cliente / empresa",MaxLength=160};
        var error=new TextBlock{TextWrapping=TextWrapping.Wrap,Foreground=_palette.Danger};
        var fields=new StackPanel{Spacing=12};fields.Children.Add(name);fields.Children.Add(company);fields.Children.Add(error);
        var dialog=Ui.Dialog(XamlRoot,_palette,"Nova rede",fields,primary:"Cadastrar",close:"Cancelar");
        dialog.PrimaryButtonClick+=async(_,args)=>{
            var deferred=args.GetDeferral();args.Cancel=true;dialog.IsPrimaryButtonEnabled=false;
            try{
                if(string.IsNullOrWhiteSpace(name.Text)){error.Text="Informe o nome da rede.";return;}
                await RequestAsync("create",new{network_name=name.Text.Trim(),client_name=company.Text.Trim()});
                args.Cancel=false;
            }catch(Exception ex){error.Text=ex.Message;}
            finally{dialog.IsPrimaryButtonEnabled=true;deferred.Complete();}
        };
        if(await dialog.ShowAsync()==ContentDialogResult.Primary)await CollectDataAsync();
    }
}
