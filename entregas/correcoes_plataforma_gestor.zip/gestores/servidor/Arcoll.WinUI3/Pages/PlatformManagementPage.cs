// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/PlatformManagementPage.cs
using System.Text.Json;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3.Pages;

/// <summary>Gestão nativa, sem navegador ou frames; cada operação revalida a sessão e o perfil na API oficial.</summary>
public sealed class PlatformManagementPage : MaintenancePage
{
    private string _scope="";
    private readonly Dictionary<string,string> _draft=new();
    public PlatformManagementPage(GestorRuntime runtime,Func<string,string,string,Task<bool>> confirm,string key,string label,string file)
        : base(runtime,confirm,key,label,"Administre os dados da rede com as permissões da sua conta.") { }
    private async Task LoadAsync()
    {
        using var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(25));
        var data=await WorkspaceService.GetAsync(Runtime,"management",cancel.Token,("page",Kind));
        StoreReport(data);_scope=Runtime.User.Signature;_draft.Clear();
    }
    private async Task SaveAsync(string action,object values)
    {
        if(_scope!=Runtime.User.Signature||!Runtime.User.Active)throw new UnauthorizedAccessException("A sessão ou a rede mudou. Consulte novamente.");
        if(!await Confirm("Confirmar alteração","Aplicar esta alteração na rede "+Get(Report,"network_name")+"?","Aplicar"))return;
        using var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(25));
        await WorkspaceService.GetAsync(Runtime,"management",cancel.Token,("page",Kind),("operation",action),("values",values));
        await LoadAsync();Status("Alteração salva.");
    }
    protected override void Build()
    {
        if(_scope!=Runtime.User.Signature){Report=default;_draft.Clear();}
        Actions(CollectAction("Atualizar",LoadAsync,Runtime.User.Active));
        if(!Runtime.User.Active){Text("Entre na sua conta pelo menu do usuário para acessar a gestão.");return;}
        if(Report.ValueKind!=JsonValueKind.Object){Text("Atualize para consultar os dados autorizados da rede.");return;}
        Text(Get(Report,"network_name"),true);
        var write=Yes(Report,"can_write");
        foreach(var field in Rows(Report,"fields"))
        {
            var key=Get(field,"key");var value=_draft.TryGetValue(key,out var draft)?draft:Get(field,"value");
            var options=Rows(field,"options").Select(x=>x.ToString()).ToArray();
            if(options.Length>0){
                var input=new ComboBox{Header=Get(field,"label"),ItemsSource=options,SelectedItem=options.Contains(value)?value:null,IsEnabled=write,HorizontalAlignment=HorizontalAlignment.Stretch,Foreground=P.Text,Background=P.Surface};
                input.SelectionChanged+=(_,_)=>{if(input.SelectedItem is string selected)_draft[key]=selected;};View.Children.Add(input);
            }else{
                var input=new TextBox{Header=Get(field,"label"),Text=value,MaxLength=(int)Number(field,"max"),IsReadOnly=!write,Foreground=P.Text,Background=P.Surface};
                input.TextChanged+=(_,_)=>_draft[key]=input.Text;View.Children.Add(input);
            }
        }
        if(write&&Rows(Report,"fields").Length>0)Actions(Action("Salvar",async()=>{
            var values=Rows(Report,"fields").Where(f=>_draft.ContainsKey(Get(f,"key"))).ToDictionary(f=>Get(f,"key"),f=>_draft[Get(f,"key")]);
            if(values.Count==0){Status("Nenhuma alteração para salvar.");return;}await SaveAsync("save",values);
        }));
        if(write&&Kind=="users"){
            var email=new TextBox{Header="E-mail de conta existente",Foreground=P.Text,Background=P.Surface};
            var role=new ComboBox{Header="Perfil básico",ItemsSource=new[]{"viewer","operator","administrator"},SelectedIndex=0,Foreground=P.Text,Background=P.Surface};
            View.Children.Add(email);View.Children.Add(role);
            Actions(Action("Adicionar / atualizar membro",()=>SaveAsync("member-save",new{email=email.Text,role=role.SelectedItem?.ToString()})));
        }
        var count=0;
        foreach(var row in Rows(Report,"rows"))
        {
            var summary=string.Join(" · ",row.EnumerateObject().Where(x=>x.Name!="id").Select(x=>x.Name+": "+x.Value.ToString()));
            if(!Matches(summary))continue;count++;Text(summary,true);
            var id=Get(row,"id");
            if(Kind=="dashboard")Actions(Action("Abrir rede",async()=>{if(!long.TryParse(id,out var network)||!Runtime.User.Select(network))throw new UnauthorizedAccessException("Rede indisponível.");await LoadAsync();}));
            if(write&&Kind=="users")Actions(Action(Get(row,"enabled")=="1"?"Desativar":"Ativar",()=>SaveAsync("member-toggle",new{id,enabled=Get(row,"enabled")=="1"?"0":"1"})));
            if(write&&Kind=="release"){
                var status=Get(row,"status");
                Actions(Action("Aprovar",()=>SaveAsync("approve",new{id}),status!="approved"),Action("Rejeitar",()=>SaveAsync("reject",new{id}),status=="pending"),Action("Exigir login",()=>SaveAsync("lock",new{id}),status=="approved"));
            }
        }
        if(count==0&&Rows(Report,"fields").Length==0)Text("Nenhum registro disponível neste filtro.");
    }
}
