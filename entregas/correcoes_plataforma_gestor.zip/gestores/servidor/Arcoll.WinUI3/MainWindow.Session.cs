// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Session.cs
// Sessão do usuário: botão de login/foto no cabeçalho, login em modal e seletor de redes registradas no rodapé (sem iframes).
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Windows.Storage.Streams;

namespace Arcoll.WinUI3;

public sealed partial class MainWindow
{
    private bool _loginRequested;
    private string _networkListSignature = "", _userAvatarApplied = "\0";
    private MenuFlyout? _networkMenu;
    // Áreas que precisam recarregar os dados da rede selecionada (cada uma recarrega ao ser exibida).
    private readonly HashSet<string> _networkStale = new(StringComparer.Ordinal);
    private static readonly string[] NetworkBoundSections = { "panel", "tickets", "agenda", "support" };

    private static string RoleLabel(string role) => role switch
    {
        "owner" => "Proprietário", "administrator" => "Administrador", "operator" => "Operador", "viewer" => "Visualização", _ => role,
    };

    // Versão grátis: o botão abre o vínculo da conta (login → escolha da rede); vinculado: login do usuário ou menu com foto.
    private bool UserEntryWanted() => _runtime.Platform.Config.IsStandalone || _runtime.IsServer || _runtime.HasLocalTools || _runtime.User.Active;

    /// <summary>Véu translúcido sobre a cor do cabeçalho (campos e avatar sem foto).</summary>
    private static SolidColorBrush HeaderSoft() => new(Windows.UI.Color.FromArgb(38, 255, 255, 255));

    /// <summary>Cores dos controles do cabeçalho e da barra de abas sobre a cor do tema.</summary>
    private void PaintHeaderControls(Brush ink)
    {
        var soft = HeaderSoft();
        CollaboratorSelector.Foreground = ink; CollaboratorSelector.Background = soft; CollaboratorSelector.BorderBrush = new SolidColorBrush(Microsoft.UI.Colors.Transparent);
        UserAvatar.BorderBrush = ink; UserGlyph.Foreground = ink;
        if (!_runtime.User.Active || _runtime.User.Avatar.Length == 0) UserAvatar.Background = soft;
        foreach (var pane in _windowsMark.Children.OfType<Microsoft.UI.Xaml.Shapes.Shape>()) pane.Fill = ink;
        foreach (var button in new[] { UpdateCenterButton, BellButton, RemoteButton, ServerRemoteButton, DockToggleButton })
        {
            button.Foreground = ink;
            if (button.Content is Grid host) foreach (var icon in host.Children.OfType<FontIcon>()) icon.Foreground = ink;
            else if (button.Content is FontIcon single) single.Foreground = ink;
        }
    }

    private void RefreshSessionChrome()
    {
        UserButton.Visibility = UserEntryWanted() ? Visibility.Visible : Visibility.Collapsed;
        RefreshUserButton();
        RefreshNetworkSelector();
    }

    /// <summary>Rodapé: com login, o nome da rede vira o alterador das redes registradas do perfil (antes ficava no cabeçalho).</summary>
    private void RefreshNetworkSelector()
    {
        var user = _runtime.User;
        var multiple = user.Active && user.Networks.Count > 1;
        NetworkChevron.Visibility = multiple ? Visibility.Visible : Visibility.Collapsed;
        var signature = multiple + "|" + user.ActiveNetworkId + "|" + user.HomeNetworkId + "|" + string.Join(",", user.Networks.Select(n => n.Id + n.Name));
        if (signature == _networkListSignature) return;
        _networkListSignature = signature;
        if (!multiple) { _networkMenu = null; return; }
        var menu = new MenuFlyout { Placement = Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.TopEdgeAlignedLeft };
        menu.Items.Add(new MenuFlyoutItem { Text = "Redes registradas", IsEnabled = false });
        foreach (var n in user.Networks)
        {
            var id = n.Id;
            var item = new ToggleMenuFlyoutItem { Text = n.Name + (id == user.HomeNetworkId ? " · esta máquina" : ""), IsChecked = id == user.ActiveNetworkId };
            item.Click += (_, _) =>
            {
                item.IsChecked = id == _runtime.User.ActiveNetworkId;
                if (id == _runtime.User.ActiveNetworkId) return;
                // Troca adiada para fora do evento do menu: evita alterar a árvore visual enquanto o WinUI ainda processa o clique.
                if (!DispatcherQueue.TryEnqueue(() => SwitchNetwork(id))) RuntimeLog.Write("Troca de rede: DispatcherQueue indisponível.");
            };
            menu.Items.Add(item);
        }
        _networkMenu = menu;
        ToolTipService.SetToolTip(BrandButton, "Alternar entre as redes registradas");
    }

    /// <summary>Com mais de uma rede registrada o clique abre a lista de redes; caso contrário segue para o Painel.</summary>
    private void BrandButton_Click(object sender, RoutedEventArgs e)
    {
        if (_networkMenu is not null && _runtime.User.Active && _runtime.User.Networks.Count > 1) { _networkMenu.ShowAt(BrandButton); return; }
        Menu_Click(sender, e);
    }

    private readonly Grid _windowsMark = WindowsMark();
    private InfoBadge? _updateButtonBadge;

    /// <summary>Botão Gestor Windows do cabeçalho (mesmo botão da plataforma): logotipo vetorial e selo de atualização disponível.</summary>
    private void InitializeUpdateButton()
    {
        _updateButtonBadge = new InfoBadge { Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, -4, -6, 0), IsHitTestVisible = false };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(_updateButtonBadge, "Atualização do gestor disponível");
        var host = new Grid(); host.Children.Add(_windowsMark); host.Children.Add(_updateButtonBadge);
        UpdateCenterButton.Content = host;
    }

    /// <summary>Logotipo do Windows desenhado em vetor.</summary>
    private static Grid WindowsMark()
    {
        var mark = new Grid { Width = 16, Height = 16 };
        mark.RowDefinitions.Add(new RowDefinition()); mark.RowDefinitions.Add(new RowDefinition());
        mark.ColumnDefinitions.Add(new ColumnDefinition()); mark.ColumnDefinitions.Add(new ColumnDefinition());
        for (var i = 0; i < 4; i++)
        {
            var pane = new Microsoft.UI.Xaml.Shapes.Rectangle { Margin = new Thickness(i % 2 == 0 ? 0 : 1, i < 2 ? 0 : 1, i % 2 == 0 ? 1 : 0, i < 2 ? 1 : 0) };
            Grid.SetRow(pane, i / 2); Grid.SetColumn(pane, i % 2); mark.Children.Add(pane);
        }
        return mark;
    }

    /// <summary>Troca a rede gerenciada: zera o colaborador selecionado, invalida os dados das áreas ligadas à rede e abre a primeira área liberada ao perfil.</summary>
    private void SwitchNetwork(long id)
    {
        try
        {
            if (!_runtime.User.Select(id)) { RefreshSessionChrome(); return; }
            RuntimeLog.Write("Rede alterada para " + id);
            _changingCollaborator = true; try { _selectedCollaborator = 0; CollaboratorSelector.SelectedIndex = 0; } finally { _changingCollaborator = false; }
            _collaboratorPage?.Disable(); _lanPage?.Stop();
            foreach (var key in NetworkBoundSections) _networkStale.Add(key);
            _lastBrand = DateTime.MinValue; _ = RefreshBrandAsync();
            UpdateCategoryVisibility();
            var user = _runtime.User;
            var target = MenuVisibleHere(_section) && NetworkBoundSections.Contains(_section) ? _section : new[] { "panel", "speed", "tickets", "agenda", "support", "home" }.FirstOrDefault(k => MenuVisibleHere(k) && Groups.Any(g => g.Items.Any(i => i.Key == k)));
            if (target is null) { StatusBar.Title = "Rede " + (user.Current?.Name ?? ""); StatusBar.Message = "Seu perfil não tem áreas liberadas para gerenciar esta rede pelo Gestor."; StatusBar.Severity = InfoBarSeverity.Warning; StatusBar.IsOpen = true; return; }
            if (target == _section) { if (_networkStale.Remove(target)) _ = ReloadSectionForNetworkAsync(target); BuildRibbon(ResolveGroup(target)); ApplyTheme(_themes.Current); }
            else SelectSection(target);
        }
        catch (Exception ex) { RuntimeLog.Write("Troca de rede: " + ex); StatusBar.Title = "Não foi possível trocar de rede"; StatusBar.Message = ex.Message; StatusBar.Severity = InfoBarSeverity.Warning; StatusBar.IsOpen = true; }
    }

    /// <summary>Recarrega, na rede selecionada, a área que acabou de ser exibida.</summary>
    private async Task ReloadSectionForNetworkAsync(string section)
    {
        try
        {
            if (section == "panel" && _hybridReady) { await CollectNetworkPageAsync(); return; }
            if ((CompactHost.Content ?? PageHost.Content) is IPageDataSource source) await source.CollectDataAsync();
        }
        catch (Exception ex) { RuntimeLog.Write("Dados da rede selecionada (" + section + "): " + ex.Message); }
    }

    private void UserLogout_Click(object sender, RoutedEventArgs e)
    {
        _loginRequested = false; _runtime.User.Clear();
        _networkStale.Clear(); _lastBrand = DateTime.MinValue; _ = RefreshBrandAsync();
    }

    /// <summary>Ícone de pessoa sem login; foto do perfil (ou inicial do nome) com login.</summary>
    private void RefreshUserButton()
    {
        var user = _runtime.User;
        var state = user.Active ? user.UserName + "|" + user.Avatar.Length + "|" + user.Role + "|" + user.ActiveNetworkId : "";
        if (state == _userAvatarApplied) return;
        _userAvatarApplied = state;
        var label = user.Active ? user.UserName : "Entrar";
        ToolTipService.SetToolTip(UserButton, label); Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(UserButton, label);
        if (!user.Active)
        {
            UserButton.Flyout = null; UserAvatar.Background = HeaderSoft(); UserGlyph.Visibility = Visibility.Visible; UserGlyph.Glyph = "\uE77B";
            return;
        }
        var menu = new MenuFlyout();
        menu.Items.Add(new MenuFlyoutItem { Text = user.UserName, IsEnabled = false });
        menu.Items.Add(new MenuFlyoutItem { Text = RoleLabel(user.Current?.Role ?? user.Role) + (user.ViewingOther ? " · visualizando outra rede" : ""), IsEnabled = false });
        menu.Items.Add(new MenuFlyoutSeparator());
        var logout = new MenuFlyoutItem { Text = "Sair", Icon = new FontIcon { Glyph = "\uE72E" } }; logout.Click += UserLogout_Click; menu.Items.Add(logout);
        UserButton.Flyout = menu;
        UserAvatar.Background = HeaderSoft();
        UserGlyph.Visibility = Visibility.Visible; UserGlyph.Glyph = "\uE77B";
        if (user.Avatar.Length > 0) _ = LoadUserAvatarAsync(user.Avatar, state);
    }

    private async Task LoadUserAvatarAsync(string dataUri, string state)
    {
        try
        {
            var comma = dataUri.IndexOf(',');
            if (comma < 0 || !dataUri.StartsWith("data:image/", StringComparison.Ordinal)) return;
            using var stream = new InMemoryRandomAccessStream();
            using (var writer = new DataWriter(stream)) { writer.WriteBytes(Convert.FromBase64String(dataUri[(comma + 1)..])); await writer.StoreAsync(); writer.DetachStream(); }
            stream.Seek(0);
            var bitmap = new BitmapImage(); await bitmap.SetSourceAsync(stream);
            if (state != _userAvatarApplied) return; // outro login ocorreu durante a leitura
            UserAvatar.Background = new ImageBrush { ImageSource = bitmap, Stretch = Stretch.UniformToFill };
            UserGlyph.Visibility = Visibility.Collapsed;
        }
        catch (Exception ex) { RuntimeLog.Write("Foto do usuário: " + ex.Message); }
    }

    /// <summary>Botão do cabeçalho: versão grátis abre o vínculo da conta (login → rede); vinculado abre o login em modal.</summary>
    private void UserButton_Click(object sender, RoutedEventArgs e)
    {
        if (_runtime.User.Active) return; // com login, o menu do usuário abre pelo Flyout
        _loginRequested = true; DispatcherQueue.TryEnqueue(UpdateLoginDialog);
    }

    private async Task<bool> RequestUserLoginAsync()
    {
        if(_runtime.User.Active)return true;
        _loginRequested=true;
        await ShowLoginDialogAsync();
        return _runtime.User.Active;
    }

    /// <summary>Abre o modal de login quando o gestor exige acesso (obrigatório) ou quando a pessoa pede pelo botão do cabeçalho.</summary>
    private void UpdateLoginDialog()
    {
        var need = _runtime.NeedsUserLogin || (_loginRequested && !_runtime.User.Active);
        if (!need && _runtime.User.Active) _loginRequested = false;
        if (need) _ = ShowLoginDialogAsync();
    }

    private async Task ShowLoginDialogAsync()
    {
        if (_modalOpen || Content?.XamlRoot is null) return;
        _modalOpen = true;
        try
        {
            var ok = await LoginDialog.ShowAsync(Content.XamlRoot, Pages.Palette.From(_themes.Current), _runtime.NetworkName, _runtime.NeedsUserLogin, async (email, password, ct) => { await _runtime.LoginUserAsync(email, password, ct); RefreshSessionChrome(); });
            _loginRequested = false;
            if (ok)
            {
                RefreshSessionChrome();
                UpdateRuntimeUi();
                _networkStale.UnionWith(NetworkBoundSections);
                // Dashboard local: a seção panel contém o painel de dados nativo do Gestor.
                var next = new[] { "dashboard", "panel" }.FirstOrDefault(_runtime.User.Allows);
                if (next is not null)
                {
                    QueueSectionNavigation(next);
                    _ = ReloadSectionForNetworkAsync(next);
                }
            }
        }
        catch (Exception ex) { RuntimeLog.Write("Modal de login: " + ex.GetType().Name + ": " + ex.Message); }
        finally { _modalOpen = false; }
    }
}
