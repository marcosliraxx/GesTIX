// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Brand.cs
// Identidade por gestor (nome + logo de Admin › Configurações) e logo de animação nas bolinhas de carregamento (nativas e web).
using System.Text.Json;
using Arcoll.WinUI3.Controls;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Media.Imaging;
using Windows.Storage.Streams;

namespace Arcoll.WinUI3;

public sealed partial class MainWindow
{
    private string _loaderMarkScript = "";
    private string _gestorLogoData = "";
    private bool? _brandRoleServer;

    /// <summary>O perfil do gestor só é conhecido após a autorização: reaplica nome, logo e ícone quando ele muda.</summary>
    private void EnsureBrandRole()
    {
        if (_compactClosed || _brandRoleServer == _runtime.IsServer) return;
        _brandRoleServer = _runtime.IsServer; ApplyGestorIdentity();
    }

    private void InitializeGestorIdentity()
    {
        _themes.BrandChanged += () => DispatcherQueue.TryEnqueue(() => { if (!_compactClosed) ApplyGestorIdentity(); });
        ApplyGestorIdentity();
    }

    /// <summary>Marca do tipo de gestor desta instalação (Servidor ou Colaborador).</summary>
    private GestorBrand CurrentGestorBrand() => _runtime.IsServer ? _themes.Server : _themes.Collaborator;

    private string _brandApplied = "";
    private void ApplyGestorIdentity()
    {
        try
        {
            var brand = CurrentGestorBrand();
            var applied = (_runtime.IsServer ? "s" : "c") + "|" + brand.Title + "|" + brand.LogoData.Length + "|" + _themes.LoaderMark.Length + "|" + _runtime.SystemName;
            if (applied == _brandApplied) return;
            _brandApplied = applied;
            // Barra de título, atalho e ícone = "Nome do sistema" definido em Admin › Configurações (mesmo nome da plataforma).
            var platformName = brand.Title.Length > 0 && !brand.Title.Equals("Gestor Servidor", StringComparison.OrdinalIgnoreCase) && !brand.Title.Equals("Gestor Colaborador", StringComparison.OrdinalIgnoreCase)
                ? brand.Title : _runtime.SystemName;
            if (string.IsNullOrWhiteSpace(platformName) || platformName.Equals("T.I Digital", StringComparison.OrdinalIgnoreCase)) platformName = "Gestor";
            var caption = platformName;
            TrayService.BrandName = platformName;
            Title = caption;
            try { AppWindow.Title = caption; } catch (Exception) { }
            BrandShell.Apply(this, platformName, brand.LogoData, _runtime.IsServer ? "server" : "collaborator");
            if (GestorName is not null)
            {
                GestorName.Text = platformName; ToolTipService.SetToolTip(GestorIdentity, platformName);
                GestorName.Visibility = RootGrid.ActualWidth >= 520 ? Visibility.Visible : Visibility.Collapsed;
            }
            var dashboardLogo=brand.LogoData.Length>0?brand.LogoData:_themes.LoaderMark;
            if (_gestorLogoData != dashboardLogo) { _gestorLogoData = dashboardLogo; _ = LoadGestorLogoAsync(dashboardLogo); }
            // A logo de animação vale para a bolinha nativa e para todas as páginas web do gestor.
            PageLoadingView.SetMark(_themes.LoaderMark);
            PushLoaderMarkToViews();
            ApplyFreeFooterIdentity();
        }
        catch (Exception ex) { RuntimeLog.Write("Identidade do gestor: " + ex.Message); }
    }

    private string _footerMarkApplied = "";
    /// <summary>Uso independente: o rodapé mostra a logo de animação da plataforma e a descrição "Versão grátis".</summary>
    private void ApplyFreeFooterIdentity()
    {
        if (!_runtime.Platform.Config.IsStandalone) { _footerMarkApplied = ""; return; }
        NetworkTitle.Text = "Versão grátis";
        ToolTipService.SetToolTip(NetworkTitle, "Versão grátis");
        ToolTipService.SetToolTip(BrandButton, "Painel · Versão grátis");
        NetworkBadge.Background = ThemeService.Brush(GestorAreaPalette.Shade(_themes.Current.Accent, .55));
        var mark = _themes.LoaderMark;
        if (_footerMarkApplied == mark && NetworkBadge.Child is Image) return;
        _footerMarkApplied = mark;
        _ = LoadFooterMarkAsync(mark);
    }

    private async Task LoadFooterMarkAsync(string dataUri)
    {
        try
        {
            if (!dataUri.StartsWith("data:image/png;base64,", StringComparison.Ordinal))
            {
                if (NetworkBadge.Child is not TextBlock) NetworkBadge.Child = new TextBlock { Text = "GR", FontSize = 10, FontWeight = Microsoft.UI.Text.FontWeights.Bold, Foreground = ThemeService.Brush("#FFFFFF"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                return;
            }
            using var stream = new InMemoryRandomAccessStream();
            using (var writer = new DataWriter(stream)) { writer.WriteBytes(Convert.FromBase64String(dataUri[22..])); await writer.StoreAsync(); writer.DetachStream(); }
            stream.Seek(0);
            var bitmap = new BitmapImage(); await bitmap.SetSourceAsync(stream);
            var image = new Image { Source = bitmap, Stretch = Microsoft.UI.Xaml.Media.Stretch.Uniform, Opacity = .55 };
            var pulse = new DoubleAnimation { From = .35, To = 1, Duration = new Duration(TimeSpan.FromMilliseconds(1200)), AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever };
            Storyboard.SetTarget(pulse, image); Storyboard.SetTargetProperty(pulse, "Opacity");
            var board = new Storyboard(); board.Children.Add(pulse);
            NetworkBadge.Child = image; board.Begin();
        }
        catch (Exception ex) { RuntimeLog.Write("Logo de animação do rodapé: " + ex.Message); }
    }

    private async Task LoadGestorLogoAsync(string dataUri)
    {
        try
        {
            var comma = dataUri.IndexOf(',');
            if (comma < 0 || !dataUri.StartsWith("data:image/", StringComparison.Ordinal)) { GestorLogo.Visibility = Visibility.Collapsed;_systemDashboardLogo=new BitmapImage(new Uri("ms-appx:///Assets/system.ico"));_bottomSignature="";RebuildBottomNav();return; }
            var bytes = Convert.FromBase64String(dataUri[(comma + 1)..]);
            using var stream = new InMemoryRandomAccessStream();
            using (var writer = new DataWriter(stream)) { writer.WriteBytes(bytes); await writer.StoreAsync(); writer.DetachStream(); }
            stream.Seek(0);
            var bitmap = new BitmapImage(); await bitmap.SetSourceAsync(stream);
            GestorLogo.Source = bitmap; GestorLogo.Visibility = Visibility.Visible;
            _systemDashboardLogo=bitmap;_bottomSignature="";RebuildBottomNav();
        }
        catch (Exception ex) { GestorLogo.Visibility = Visibility.Collapsed; RuntimeLog.Write("Logo do gestor: " + ex.Message); }
    }

    /// <summary>Reenvia a logo de animação às páginas web já abertas (as novas recebem pelo script de documento).</summary>
    private void PushLoaderMarkToViews()
    {
        if (_loaderMarkScript.Length == 0) return;
        var script = "window.__tiLoaderMark=" + JsonSerializer.Serialize(_themes.LoaderMark) + ";window.__arcLoaderMarkSet&&window.__arcLoaderMarkSet(window.__tiLoaderMark);";
        foreach (var core in _compactCores.ToArray())
            try { _ = core.ExecuteScriptAsync(script); } catch (Exception) { }
    }
}
