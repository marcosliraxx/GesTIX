// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Pairing.cs
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
namespace Arcoll.WinUI3;
/// <summary>Vinculação à plataforma: barra de convite (Sem vínculo / Vincular) e modal exclusivo de QR Code, copiar e enviar.</summary>
public sealed partial class MainWindow
{
    // Um único modal por vez (ContentDialog não admite dois abertos): vínculo, login e menu do Gestor compartilham esta trava.
    private bool _modalOpen;
    private void PlatformPair_Click(object sender,RoutedEventArgs e)=>ShowLinkDialog("Vincular à plataforma online","Ative a gestão remota e os recursos PRO.");
    private void PairBarSkip_Click(object sender,RoutedEventArgs e){PairingService.DismissBar();RefreshPairBar();}
    private void RefreshPairBar()=>PlatformPairBar.Visibility=_runtime.Platform.Config.IsStandalone&&!PairingService.BarDismissed?Visibility.Visible:Visibility.Collapsed;
    /// <summary>Cores da barra de convite vêm do tema ativo (Admin › Configurações).</summary>
    private void PaintPairBar(Pages.Palette p,Microsoft.UI.Xaml.Media.Brush ink)
    {
        PlatformPairBar.Background=p.Accent;PairBarText.Foreground=ink;
        PairBarSkip.Foreground=ink;PairBarSkip.BorderBrush=ink;PairBarSkip.Background=new Microsoft.UI.Xaml.Media.SolidColorBrush(Microsoft.UI.Colors.Transparent);
        PairBarLink.Foreground=p.Accent;PairBarLink.Background=ink;PairBarLink.BorderBrush=ink;
        foreach(var key in new[]{"ButtonForegroundPointerOver","ButtonForegroundPressed"}){PairBarSkip.Resources[key]=ink;PairBarLink.Resources[key]=p.Accent;}
        foreach(var key in new[]{"ButtonBackgroundPointerOver","ButtonBackgroundPressed"}){PairBarLink.Resources[key]=ink;PairBarSkip.Resources[key]=new Microsoft.UI.Xaml.Media.SolidColorBrush(Windows.UI.Color.FromArgb(46,255,255,255));}
    }
    private async void ShowLinkDialog(string title,string subtitle)
    {
        if(!_runtime.Platform.Config.IsStandalone||_modalOpen||Content?.XamlRoot is null)return;
        _modalOpen=true;
        try
        {
            var outcome=await LinkAccountDialog.ShowAsync(Content.XamlRoot,Pages.Palette.From(_themes.Current),_runtime.Platform.Config,title,subtitle);
            if(outcome.Linked)
            {
                PairingService.ResetBar();await _runtime.RecheckAsync();_runtime.Platform.Reload();
                RefreshSessionChrome();UpdateRuntimeUi();
            }
        }
        catch(Exception ex){RuntimeLog.Write("Vínculo da conta: "+ex.Message);}
        finally{_modalOpen=false;RefreshPairBar();}
    }
}
