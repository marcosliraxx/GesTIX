param([string]$Source=(Join-Path $PSScriptRoot '..\Arcoll.WinUI3'))
$ErrorActionPreference='Stop'
$checks=0;$root=Join-Path $env:TEMP ('ti-update-handoff-test-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
function Check([bool]$value,[string]$label){if(-not $value){throw ('FAIL '+$label)};$script:checks++;Write-Host ('PASS '+$label)}
function Get-Process([int]$Id,[string]$ErrorAction){return $script:agent}
function Stop-Process([int]$Id,[switch]$Force,[string]$ErrorAction){$script:stops++}
function Get-Date{$script:clock=$script:clock.AddSeconds($(if($script:expire){60}else{1}));return $script:clock}
function Start-Sleep([int]$Milliseconds){}
function Reject([scriptblock]$action,[string]$label){$failed=$false;try{&$action}catch{$failed=$true};Check $failed $label}
try{
 $definitions=@()
 foreach($file in @('INSTALAR_WINUI3.ps1','APLICAR_PRECOMPILADO.ps1')){
  $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Source $file),[ref]$tokens,[ref]$errors)
  Check ($errors.Count -eq 0) ('PowerShell parser '+$file)
  $function=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Invoke-IntegratedHandoff'},$true)
  Check ($null -ne $function) ('two-way handoff exists in '+$file)
  $definitions+=$function.Extent.Text
 }
 Check ($definitions[0] -eq $definitions[1]) 'source and binary use same handoff protocol'
 . ([scriptblock]::Create($definitions[0]))
 $id='a'*32;$script:stops=0;$script:waits=0;$script:expire=$false;$script:clock=[DateTime]::UtcNow
 $script:agent=[pscustomobject]@{ProcessName='Arcoll.WinUI3';Path=(Join-Path $root 'WinUI3\Arcoll.WinUI3.exe');HasExited=$false}
 $script:agent|Add-Member ScriptMethod WaitForExit {param($ms)$script:waits++;return $true}
 [IO.File]::WriteAllText((Join-Path $root 'update-handoff-ack.json'),(@{update_id=$id}|ConvertTo-Json))
 Invoke-IntegratedHandoff $id 987654 $root
 Check ($script:waits -eq 1 -and $script:stops -eq 0) 'valid acknowledgement permits graceful exit only'
 $ready=Get-Content (Join-Path $root 'update-handoff.json') -Raw|ConvertFrom-Json
 Check ($ready.update_id -eq $id -and $ready.ready) 'ready state correlated with operation'
 $script:waits=0;$script:expire=$true
 [IO.File]::WriteAllText((Join-Path $root 'update-handoff-ack.json'),(@{update_id=('b'*32)}|ConvertTo-Json))
 Reject {Invoke-IntegratedHandoff $id 987654 $root} 'wrong acknowledgement cannot authorize swap'
 Check ($script:waits -eq 0 -and $script:stops -eq 0) 'no process termination before acknowledged handoff'
 Reject {Invoke-IntegratedHandoff '../unsafe' 987654 $root} 'malformed operation rejected'
 $script:agent.Path='C:\Other\Arcoll.WinUI3.exe'
 Reject {Invoke-IntegratedHandoff $id 987654 $root} 'foreign parent executable rejected'
 Write-Host ($checks.ToString()+' handoff assertions passed; no real agent stopped or replaced.')
}finally{Remove-Item -LiteralPath $root -Recurse -Force}
