<?php
declare(strict_types=1);
$root=__DIR__.'/site';foreach(['api','includes','agentes/servidor/Arcoll.WinUI3','agentes/windows','agentes/releases/win-x64/current/files']as $dir)@mkdir($root.'/'.$dir,0777,true);copy(__DIR__.'/download-agent.php',$root.'/api/download-agent.php');
file_put_contents($root.'/includes/config.php',"<?php // synthetic test fixture\n");
file_put_contents($root.'/includes/bootstrap.php',<<<'PHP'
<?php
function arc_db():PDO{static $p;return $p??=new PDO('sqlite:'.dirname(__DIR__).'/fixture.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);}
function arc_ensure_user_schema(PDO $p):void{}
function arc_table(string $name):string{return '`'.$name.'`';}
function arc_app_version():string{return '5.0.116';}
function arc_base_url():string{return 'https://fixture.test';}
function arc_json(array $v,int $code=200):never{http_response_code($code);header('Content-Type: application/json');echo json_encode($v);exit;}
function arc_support_icon(PDO $p,string $type):string{return 'synthetic-icon';}
function arc_program_install_catalog():array{return [];}
function arc_clean_catalog():array{return [];}
function arc_clean_registry_checks():array{return [];}
function arc_clean_health_sets():array{return [];}
function arc_clean_tabs():array{return [];}
function arc_clean_age_options():array{return [];}
PHP);
file_put_contents($root.'/includes/support.php','<?php');file_put_contents($root.'/includes/network-clean.php','<?php');require $root.'/includes/bootstrap.php';$p=arc_db();$p->exec('CREATE TABLE network_agents(id INTEGER,account_id INTEGER,network_id INTEGER,fingerprint TEXT,site_code TEXT,status TEXT);CREATE TABLE managed_networks(id INTEGER,account_id INTEGER,is_active INTEGER,monitoring_enabled INTEGER);CREATE TABLE agent_download_keys(network_id INTEGER,account_id INTEGER,token_hash TEXT,fingerprint TEXT)');$fp=str_repeat('a',64);$p->prepare("INSERT INTO network_agents VALUES(1,1,10,?,'TEST1','approved')")->execute([$fp]);$p->exec('INSERT INTO managed_networks VALUES(10,1,1,1)');$p->prepare('INSERT INTO agent_download_keys VALUES(10,1,?,?)')->execute([hash('sha256',str_repeat('b',64)),$fp]);
$native=$root.'/agentes/servidor/Arcoll.WinUI3';$paths=['MainWindow.Workspace.cs','Controls/AgentWorkspace.cs','Services/PerformanceModel.cs','Services/PerformanceCollector.cs','Services/NativePerformance.cs','Services/GpuTemperature.cs','Pages/ServerPage.cs','Assets/hybrid/dashboard/server.html','Assets/hybrid/dashboard/server.css','Assets/hybrid/dashboard/server.js','Assets/hybrid/dashboard/compact-shell.js','Assets/hybrid/dashboard/standard-workspace.css','Assets/hybrid/dashboard/standard-workspace.js','Assets/hybrid/internet/standard-workspace.css','Assets/hybrid/pentefino/standard-workspace.css','Assets/hybrid/backup/standard-workspace.css','Arcoll.WinUI3.csproj','INSTALAR_WINUI3.ps1','APLICAR_PRECOMPILADO.ps1','Worker/clean_worker.py','Services/BackupCenter/BackupExecutor.cs','Pages/BackupCenterPage.cs','BackupWorker/BackupWorker.csproj','BackupWorker/Program.cs','INSTALAR_BACKUP_SERVICO.ps1'];foreach(['dashboard','internet','pentefino','backup']as $dir)foreach(['index.html','styles.css','app.js']as $name)$paths[]='Assets/hybrid/'.$dir.'/'.$name;$paths[]='Assets/hybrid/backup/native.css';foreach(['leaflet.js','leaflet.css']as $name)$paths[]='Assets/hybrid/internet/vendor/'.$name;foreach($paths as $file){@mkdir(dirname($native.'/'.$file),0777,true);file_put_contents($native.'/'.$file,'synthetic fixture '.$file);}foreach(['arcoll_clean.py','arcoll_programs.py','arcoll_cloud.py','arcoll_release.py']as $name)file_put_contents($root.'/agentes/windows/'.$name,'# fixture');
$release=$root.'/agentes/releases/win-x64/current';file_put_contents($release.'/files/Arcoll.WinUI3.exe','not an executable; test bytes only');file_put_contents($release.'/files/sample.dll','fixture DLL bytes');file_put_contents($release.'/release.json',json_encode(['version'=>'5.0.116','arch'=>'win-x64','files'=>['Arcoll.WinUI3.exe'=>hash_file('sha256',$release.'/files/Arcoll.WinUI3.exe'),'sample.dll'=>hash_file('sha256',$release.'/files/sample.dll')]]));
echo "Synthetic probe site ready\n";
