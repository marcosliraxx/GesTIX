using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Automation;
namespace Arcoll.WinUI3.Controls;
/// <summary>Shared native toolbar/content/activity frame. Owns no operations or permissions.</summary>
public sealed class AgentWorkspace:Grid
{
 private readonly StackPanel _tools=new(){Orientation=Orientation.Horizontal,Spacing=7};private readonly Grid _body=new();
 private readonly Border _toolbar=new(),_aside=new();private readonly StackPanel _events=new(){Spacing=0};private readonly ToggleButton _toggle=new(){Content=new FontIcon{Glyph="\uE783",FontSize=17},Width=32,Height=32,MinWidth=32,Padding=new Thickness(5)};
 private readonly TextBlock _heading=new(){Text="Atividades",FontSize=13,FontWeight=Microsoft.UI.Text.FontWeights.SemiBold};private readonly List<TextBlock> _tracked=[];private string _last="";private readonly Action<string> _context;
 public AgentWorkspace(UIElement content,bool bounded,Action<string> context){_context=context;RowDefinitions.Add(new(){Height=GridLength.Auto});RowDefinitions.Add(new(){Height=new GridLength(1,GridUnitType.Star)});_toolbar.Child=new ScrollViewer{Content=_tools,HorizontalScrollBarVisibility=ScrollBarVisibility.Auto,VerticalScrollBarVisibility=ScrollBarVisibility.Disabled,HorizontalScrollMode=ScrollMode.Auto};_toolbar.Padding=new Thickness(10,7,10,7);_toolbar.BorderThickness=new Thickness(0,0,0,1);Children.Add(_toolbar);
 _tools.Children.Add(_toggle);AutomationProperties.SetName(_toggle,"Atividades");ToolTipService.SetToolTip(_toggle,"Mostrar ou recolher Atividades");_toggle.Checked+=(_,_)=>Open(true);_toggle.Unchecked+=(_,_)=>Open(false);
 _body.ColumnDefinitions.Add(new(){Width=new GridLength(1,GridUnitType.Star)});_body.ColumnDefinitions.Add(new(){Width=new GridLength(0)});var view=bounded?content:new ScrollViewer{Content=content,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled};_body.Children.Add(view);
 var side=new Grid();side.RowDefinitions.Add(new(){Height=GridLength.Auto});side.RowDefinitions.Add(new(){Height=new GridLength(1,GridUnitType.Star)});_heading.Margin=new Thickness(14);side.Children.Add(_heading);var scroll=new ScrollViewer{Content=_events,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};SetRow(scroll,1);side.Children.Add(scroll);_aside.Child=side;_aside.BorderThickness=new Thickness(1,0,0,0);SetColumn(_aside,1);_body.Children.Add(_aside);SetRow(_body,1);Children.Add(_body);Open(false);AddActivity("Página aberta");}
 public void AddTool(UIElement element){Detach(element);if(element is FrameworkElement f){f.Margin=new Thickness(0);if(f is TextBox){f.Width=250;f.MinWidth=140;f.MaxWidth=450;}if(f is ComboBox){f.MinWidth=150;f.Width=180;}}if(element is Control c){c.FontSize=12;c.MinHeight=30;} _tools.Children.Insert(_tools.Children.Count-1,element);}
 public void AddTools(UIElement node){if(node is TextBox or ComboBox or Button){AddTool(node);return;}foreach(var child in ChildrenOf(node).ToArray())AddTools(child);}
 public void Track(TextBlock text,bool summary=false){if(_tracked.Contains(text))return;_tracked.Add(text);void Update(){if(!string.IsNullOrWhiteSpace(text.Text)){if(summary)_context(text.Text);else AddActivity(text.Text);}}text.RegisterPropertyChangedCallback(TextBlock.TextProperty,(_,_)=>Update());Update();text.Visibility=Visibility.Collapsed;}
 public void AddActivity(string text){text=text.Trim();if(text.Length==0||text==_last)return;_last=text;var label=new TextBlock{Text=DateTime.Now.ToString("dd/MM HH:mm:ss")+"\n"+text,TextWrapping=TextWrapping.Wrap,FontSize=11,Margin=new Thickness(14,10,14,10)};_events.Children.Insert(0,label);while(_events.Children.Count>100)_events.Children.RemoveAt(100);_context(text);}
 public void Paint(AgentAreaColors c){Background=ThemeService.Brush(c.Area5);_toolbar.Background=ThemeService.Brush(c.Area4);_toolbar.BorderBrush=_aside.BorderBrush=ThemeService.Brush(c.Line);_aside.Background=ThemeService.Brush(c.Area7);_heading.Foreground=ThemeService.Brush(c.Text);foreach(var t in _events.Children.OfType<TextBlock>())t.Foreground=ThemeService.Brush(c.Text);_toggle.Foreground=ThemeService.Brush(c.Text);}
 private void Open(bool open){_body.ColumnDefinitions[1].Width=new GridLength(open?240:0);_aside.Visibility=open?Visibility.Visible:Visibility.Collapsed;}
 public static IEnumerable<UIElement> ChildrenOf(UIElement node)=>node switch{Panel p=>p.Children.ToArray(),Border{Child:UIElement c}=>[c],ContentControl{Content:UIElement c}=>[c],ScrollViewer{Content:UIElement c}=>[c],_=>[]};
 public static void Detach(UIElement node){if(node is not FrameworkElement f)return;switch(f.Parent){case Panel p:p.Children.Remove(node);break;case Border b:b.Child=null;break;case ContentControl c:c.Content=null;break;case ScrollViewer s:s.Content=null;break;}}
}
