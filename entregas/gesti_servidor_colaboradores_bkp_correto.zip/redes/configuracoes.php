<?php
/* Caminho: redes/configuracoes.php — Configurações centralizadas por rede; backup usa a Central existente. */
declare(strict_types=1);
require_once __DIR__.'/../includes/error-logging.php';
$arcSectionFile='configuracoes';
require __DIR__.'/_base.php';
require __DIR__.'/_topo.php';
$arcCanBackup=in_array($teamRole,['owner','administrator','system_admin'],true);
$selectedTab=(string)($_GET['tab']??'geral');
if(!in_array($selectedTab,['geral','backup','gestores'],true))$selectedTab='geral';
if(in_array($selectedTab,['backup','gestores'],true)&&!$arcCanBackup)$selectedTab='geral';
$gestores=[];$chosen=0;
if($arcCanBackup){
 require_once dirname(__DIR__).'/includes/backup-center.php';
 $gestores=arc_bc_q($pdo,'SELECT id,machine_name FROM '.arc_table('network_gestores')." WHERE account_id=? AND network_id=? AND status='approved' ORDER BY machine_name,id",[(int)$account,(int)$networkId])->fetchAll(PDO::FETCH_ASSOC);
 $chosen=(int)($_GET['gestor']??($gestores[0]['id']??0));
 if(!array_filter($gestores,static fn($a)=>(int)$a['id']===$chosen))$chosen=(int)($gestores[0]['id']??0);
 if($selectedTab==='backup'&&$chosen)arc_bc_manager($pdo,(int)$networkId,$chosen);
}
?>
<style>
.arc-ncfg{display:flex;flex-direction:column;gap:12px;min-width:0;color:var(--text)}
.arc-ncfg-header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 15px;border:1px solid var(--border);border-radius:12px;background:var(--surface-alt)}
.arc-ncfg-header h1{font-size:17px;margin:0}.arc-ncfg-header small{color:var(--muted);margin-left:auto}
.arc-ncfg-nav{display:flex;gap:7px;flex-wrap:wrap}.arc-ncfg-nav a{padding:9px 16px;color:var(--text);text-decoration:none;border:1px solid var(--border);border-radius:9px;background:var(--surface-alt);font-weight:600;font-size:13px}
.arc-ncfg-nav a[aria-current=page]{background:var(--primary);border-color:var(--primary);color:#fff}
.arc-ncfg-area{min-width:0;border:1px solid var(--border);background:var(--surface-alt);border-radius:12px;padding:15px}
.arc-ncfg-area h2{margin:0 0 13px;font-size:16px}.arc-ncfg-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.arc-ncfg-grid label{display:grid;gap:6px;font-size:13px}.arc-ncfg-grid select{width:100%;min-width:0;padding:10px;border:1px solid var(--border);border-radius:8px;background:var(--surface);color:var(--text)}
.arc-ncfg-check{display:flex!important;align-items:center;gap:8px}.arc-ncfg-check input{width:17px;height:17px;flex:0 0 17px;accent-color:var(--primary)}
.arc-ncfg-actions{margin-top:15px;display:flex;justify-content:flex-end}.arc-ncfg-picker{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-bottom:12px}.arc-ncfg-picker select{min-width:220px;max-width:100%;padding:8px;border:1px solid var(--border);border-radius:9px;background:var(--surface);color:var(--text)}
@media(max-width:690px){.arc-ncfg-grid{grid-template-columns:1fr}.arc-ncfg-header small{margin-left:0}.arc-ncfg-area{padding:9px}}
</style>
<section class="arc-ncfg" aria-label="Configurações da rede">
<header class="arc-ncfg-header"><h1><i class="fa fa-cogs" aria-hidden="true"></i> Configurações da rede</h1><small><?=arc_h((string)$network['name'])?></small></header>
<nav class="arc-ncfg-nav" aria-label="Categorias de configurações">
<?php if($arcCanBackup):?><a href="<?=arc_h(arc_workspace_base_url())?>redes/configuracoes.php?network=<?=(int)$networkId?>&tab=gestores" <?=$selectedTab==='gestores'?'aria-current="page"':''?>>Gestores e Colaboradores</a><?php endif;?>
<a href="<?=arc_h(arc_workspace_base_url())?>redes/configuracoes.php?network=<?=(int)$networkId?>&tab=geral" <?=$selectedTab==='geral'?'aria-current="page"':''?>>Gerais e notificações</a>
<?php if($arcCanBackup): ?><a href="<?=arc_h(arc_workspace_base_url())?>redes/configuracoes.php?network=<?=(int)$networkId?>&tab=backup" <?=$selectedTab==='backup'?'aria-current="page"':''?>>Backup e sincronização</a><?php endif; ?>
</nav>
<?php if($selectedTab==='geral'): ?>
<div class="arc-ncfg-area"><h2>Monitoramento e avisos</h2>
<?php if($arcError!==''):?><p role="alert"><?=arc_h($arcError)?></p><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=arc_h($csrf)?>"><input type="hidden" name="action" value="network_preferences_update"><div class="arc-ncfg-grid">
<label>Atualização do monitoramento<select name="monitor_refresh"><?php foreach(['instant'=>'Instantâneo','1'=>'1 segundo','5'=>'5 segundos','10'=>'10 segundos','15'=>'15 segundos','30'=>'30 segundos','60'=>'60 segundos'] as $v=>$t): ?><option value="<?=arc_h((string)$v)?>" <?=$networkPrefs['monitor_refresh']===(string)$v?'selected':''?>><?=arc_h($t)?></option><?php endforeach;?></select></label>
<label>Alerta de latência<select name="alert_latency"><?php foreach(['80','100','150','200','300'] as $v):?><option value="<?=$v?>" <?=$networkPrefs['alert_latency']===$v?'selected':''?>><?=$v?> ms</option><?php endforeach;?></select></label>
<label class="arc-ncfg-check"><input type="checkbox" name="alert_low_speed" <?=$networkPrefs['alert_low_speed']==='1'?'checked':''?>> Alertar quando houver velocidade baixa</label>
<label class="arc-ncfg-check"><input type="checkbox" name="email_alerts" <?=$networkPrefs['email_alerts']==='1'?'checked':''?>> Receber alertas por e-mail</label>
</div><div class="arc-ncfg-actions"><button type="submit" class="button" <?=!$isNetworkOwner?'disabled':''?>>Salvar configurações</button></div></form></div>
<?php elseif($selectedTab==='backup'): ?>
<div class="arc-ncfg-area"><h2>Backup por computador</h2>
<?php if(!$chosen):?><p>Aprove um computador nesta rede para configurar as pastas e a sincronização.</p><?php else: ?>
<div class="arc-ncfg-picker"><label for="bc-gestor">Computador</label><select id="bc-gestor"><?php foreach($gestores as $g):?><option value="<?=(int)$g['id']?>" <?=(int)$g['id']===$chosen?'selected':''?>><?=arc_h((string)$g['machine_name'])?></option><?php endforeach;?></select></div>
<link rel="stylesheet" href="<?=arc_h(arc_workspace_base_url())?>assets/backup-center/styles.css">
<section id="backup-center" class="bc-app" data-transport="web" data-api="<?=arc_h(arc_workspace_base_url().'api/backup.php')?>" data-cloud-api="<?=arc_h(arc_workspace_base_url().'api/cloud.php')?>" data-network="<?=(int)$networkId?>" data-gestor="<?=$chosen?>" data-csrf="<?=arc_h($csrf)?>" data-tab="sync"><p role="status">Carregando sincronização…</p></section>
<script src="<?=arc_h(arc_workspace_base_url())?>assets/backup-center/app.js" defer></script>
<script>document.getElementById('bc-gestor').addEventListener('change',function(){const u=new URL(location.href);u.searchParams.set('gestor',this.value);location.assign(u.href);});</script>
<?php endif;?></div>
<?php else:require __DIR__.'/_gestor_topology.php';endif; ?>
</section>
<?php require __DIR__.'/_rodape.php'; ?>
