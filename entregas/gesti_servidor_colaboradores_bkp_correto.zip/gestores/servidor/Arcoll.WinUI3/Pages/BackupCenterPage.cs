// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/BackupCenterPage.cs
using System.Diagnostics;
using System.Text.Json;
using Arcoll.WinUI3.Services;
using Arcoll.WinUI3.Services.BackupCenter;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
namespace Arcoll.WinUI3.Pages;
/// <summary>Interface de sincronização do gestor: configura, sincroniza e restaura direto no computador, com as mesmas regras da plataforma.</summary>
public sealed class BackupCenterPage:UserControl,IPageDataSource
{
 private bool _dataBridgeConfigured;
 public PageDataLoad DataLoad{get;}=new("Consultando os planos e destinos de backup",true);
 public async Task CollectDataAsync(){if(!_ready){await InitializeAsync();return;}await _web.CoreWebView2.ExecuteScriptAsync("window.dispatchEvent(new Event('ti-page-collect'));");}

 private const string Origin="https://backup.tidigital.local/";private readonly GestorRuntime _runtime;private readonly WebView2 _web=new(){HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Stretch};private bool _ready,_loading;private string _tab="sync";private Palette _palette=new();
 public BackupCenterPage(GestorRuntime runtime){_runtime=runtime;Content=_web;Loaded+=async(_,_)=>await InitializeAsync();}
 public void Navigate(string section){_tab=section switch{"backup_restore"=>"restore","backup_history"=>"history",_=>"sync"};Post(new{type="navigate",tab=_tab});}
 public void ApplyPalette(Palette palette){_palette=palette;Post(new{type="theme",dark=!palette.Light});}
 private void Post(object value){if(!_ready)return;try{_web.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(value));}catch(InvalidOperationException){}}
 private async Task InitializeAsync(){if(_ready||_loading)return;_loading=true;DataLoad.Begin("Preparando a consulta da Central de Backup");Content=_web;try{if(_dataBridgeConfigured&&_web.CoreWebView2 is not null){_web.CoreWebView2.Reload();return;}var assets=Path.Combine(AppContext.BaseDirectory,"Assets","hybrid","backup");var profile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","BackupWebView");Directory.CreateDirectory(profile);var environment=await CoreWebView2Environment.CreateWithOptionsAsync(null,profile,null);await _web.EnsureCoreWebView2Async(environment);var web=_web.CoreWebView2??throw new InvalidOperationException("WebView2 não inicializado.");web.Settings.AreDevToolsEnabled=false;web.Settings.AreDefaultContextMenusEnabled=false;web.Settings.AreHostObjectsAllowed=false;web.SetVirtualHostNameToFolderMapping("backup.tidigital.local",assets,CoreWebView2HostResourceAccessKind.DenyCors);web.NavigationStarting+=(_,e)=>{if(!e.Uri.StartsWith(Origin,StringComparison.OrdinalIgnoreCase))e.Cancel=true;};web.NewWindowRequested+=(_,e)=>e.Handled=true;web.WebMessageReceived+=async(_,e)=>{if(!e.Source.StartsWith(Origin,StringComparison.OrdinalIgnoreCase))return;string id="";try{using var document=JsonDocument.Parse(e.WebMessageAsJson);var body=document.RootElement;var type=Text(body,"type");if(type=="ready"){_ready=true;Navigate(_tab=="sync"?"backup":"backup_"+_tab);ApplyPalette(_palette);return;}if(type!="request")return;id=Text(body,"id");if(id.Length>20)return;var action=Text(body,"action");var data=body.GetProperty("data");if(!_runtime.Can("backup"))throw new UnauthorizedAccessException("Autorize o gestor na plataforma.");var config=_runtime.Platform.Config;using var remote=new BackupHttpClient(new(config.Origin,config.Fingerprint,config.SiteCode,config.DownloadKey));using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(75));object result;
 if(action=="platform"){await OpenPlatformAsync(Text(data,"tab"));result=new{ok=true};}
 else if(action=="service"){var dialog=new ContentDialog{Title="Backup antes do login",Content="Na pasta do gestor, execute INSTALAR_BACKUP_SERVICO.ps1 como administrador. O instalador pede confirmação e cria uma tarefa protegida no início do Windows. A conta SYSTEM precisa ter permissão nas pastas e no compartilhamento NAS. Consulte o guia antes de ativar os planos.",CloseButtonText="Entendi",XamlRoot=XamlRoot};await dialog.ShowAsync();result=new{ok=true};}
 else if(action=="state"){DataLoad.Begin("Consultando planos, destinos e históricos",preserveData:true);result=await remote.StateAsync(timeout.Token);DataLoad.Complete();}
 else if(action=="run")result=await remote.CallAsync("gestor-request-run",new{plan_id=Text(data,"plan_id")},timeout.Token);
 else if(action=="points")result=await remote.CallAsync("gestor-points",new{plan_id=Text(data,"plan_id"),offset=Number(data,"offset")},timeout.Token);
 else if(action=="files")result=await remote.CallAsync("gestor-files-list",new{run_id=Text(data,"run_id"),offset=Number(data,"offset")},timeout.Token);
 else if(action=="queue"&&Text(data,"kind")=="verify")result=await remote.CallAsync("gestor-verify",new{source_run=Text(data,"source_run")},timeout.Token);
 else if(action is "save" or "pause" or "cancel" or "queue" or "pin" or "unarchive" or "legacy-drive" or "legacy-pause")result=await remote.CallAsync("gestor-"+action,data,timeout.Token);
 else if(action=="browse")result=await FileBrowserService.BrowseAsync(Text(data,"path"),true,timeout.Token);
 else if(action=="known")result=KnownFolders();
 else {await OpenPlatformAsync(_tab);result=new{ok=true};}Post(new{type="reply",id,data=result});
 }catch(Exception error){if(DataLoad.Current.Phase==DataLoadPhase.Loading)DataLoad.Fail("Não foi possível consultar o backup: "+error.Message);Post(new{type="reply",id,error=error.Message});}};_dataBridgeConfigured=true;_web.Source=new Uri(Origin+"index.html");}catch(Exception error){DataLoad.Fail("Não foi possível abrir o backup: "+error.Message);Content=Ui.Label("Central de Backup indisponível: "+error.Message,_palette.Text,14,wrap:true);}finally{_loading=false;}}
 private async Task OpenPlatformAsync(string tab){if(tab is not("sync" or "restore" or "history"))tab="sync";using var remote=new BackupHttpClient(new(_runtime.Platform.Config.Origin,_runtime.Platform.Config.Fingerprint,_runtime.Platform.Config.SiteCode,_runtime.Platform.Config.DownloadKey));using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(20));var state=await remote.StateAsync(timeout.Token);var scope=state.GetProperty("scope");var origin=_runtime.Platform.Config.Origin.TrimEnd('/');var uri=new Uri(origin+"/redes/backup.php?network="+scope.GetProperty("network").GetInt64()+"&gestor="+scope.GetProperty("gestor").GetInt64()+"&tab="+tab);Process.Start(new ProcessStartInfo(uri.AbsoluteUri){UseShellExecute=true});}
 /// <summary>Atalhos de pastas do usuário para escolher o que sincronizar com um clique.</summary>
 private static object KnownFolders(){var list=new List<object>();void Add(string name,string path){if(!string.IsNullOrWhiteSpace(path)&&Directory.Exists(path))list.Add(new{name,path});}Add("Documentos",Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));Add("Área de Trabalho",Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));Add("Imagens",Environment.GetFolderPath(Environment.SpecialFolder.MyPictures));return new{ok=true,folders=list};}
 private static string Text(JsonElement value,string name)=>value.ValueKind==JsonValueKind.Object&&value.TryGetProperty(name,out var item)&&item.ValueKind==JsonValueKind.String?item.GetString()??"":"";private static int Number(JsonElement value,string name)=>value.TryGetProperty(name,out var item)&&item.TryGetInt32(out var number)?Math.Max(0,number):0;
}
