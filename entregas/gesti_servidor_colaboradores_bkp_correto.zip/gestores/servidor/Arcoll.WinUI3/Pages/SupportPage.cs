// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/SupportPage.cs
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
namespace Arcoll.WinUI3.Pages;
/// <summary>Suporte do gestor local: mesmos cartões da plataforma; cada serviço pergunta se executa agora ou cria rotina.</summary>
public sealed class SupportPage : UserControl
{
    private static readonly Dictionary<string, string> LocalServices = new() { ["power_restart"] = "Reiniciar PC", ["screen_lock"] = "Bloquear PC", ["power_shutdown"] = "Desligar PC" };
    private readonly GestorRuntime _runtime; private readonly Func<Task> _remote; private readonly Action _tickets;
    private Palette _p = new();
    private Dictionary<string, string> _services = new(LocalServices);
    private bool _busy;
    public SupportPage(GestorRuntime runtime, Func<Task> remote, Action tickets) { _runtime = runtime; _remote = remote; _tickets = tickets; Loaded += async (_, _) => await LoadAsync(); Render(); }
    public void ApplyPalette(Palette p) { _p = p; Render(); }
    private async Task LoadAsync()
    {
        try
        {
            if (_runtime.Can("support"))
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
                var online = await SupportFmt.ServicesAsync(_runtime, timeout.Token);
                if (online.Count > 0) _services = online;
            }
        }
        catch (Exception ex) { RuntimeLog.Write("Suporte/serviços: " + ex.Message); }
        Render();
    }
    /// <summary>Cartão igual ao da plataforma: ícone, título e legenda; ao tocar, pergunta se executa agora ou cria rotina.</summary>
    private Button Tile(string glyph, string title, string caption, Func<Task> choose)
    {
        var body = new StackPanel { Spacing = 8, HorizontalAlignment = HorizontalAlignment.Left };
        body.Children.Add(new FontIcon { Glyph = glyph, FontSize = 19, Foreground = _p.Accent });
        body.Children.Add(Ui.Label(title, _p.Text, 13, true, true));
        body.Children.Add(Ui.Label(caption, _p.Muted, 11, false, true));
        var button = new Button
        {
            Content = body, MinHeight = 85, Padding = new Thickness(15), Margin = new Thickness(0, 0, 10, 10),
            HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Left, VerticalContentAlignment = VerticalAlignment.Top,
            Background = _p.Alt, BorderBrush = _p.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(9),
        };
        ToolTipService.SetToolTip(button, title); AutomationProperties.SetName(button, title);
        button.Click += async (_, _) => await GuardAsync(title, choose);
        return button;
    }
    private void Render()
    {
        var panel = new VariableSizedWrapGrid { Orientation = Orientation.Horizontal, ItemWidth = 210, ItemHeight = 105 };
        foreach (var (command, label) in _services) { var key = command; var name = label; panel.Children.Add(Tile(SupportFmt.Glyph(command), label, "Executar agora ou criar rotina", () => ChooseAsync(key, name))); }
        panel.Children.Add(Tile("\uE8D7", "Gerar código temporário", "Acesso remoto deste computador", _remote));
        panel.Children.Add(Tile("\uE8F2", "Consultar chamados", "Abrir chamados de suporte", () => { _tickets(); return Task.CompletedTask; }));
        var stack = new StackPanel { Padding = new Thickness(18), Spacing = 8 };
        stack.Children.Add(Ui.Label("Serviços de suporte", _p.Text, 15, true));
        stack.Children.Add(panel);
        Content = new ScrollViewer { Content = stack, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    }
    private async Task GuardAsync(string title, Func<Task> run)
    {
        if (_busy) return; _busy = true;
        try { await run(); }
        catch (Exception ex) { RuntimeLog.Write("Suporte/" + title + ": " + ex.Message); await Message("Não foi possível concluir", ex.Message); }
        finally { _busy = false; }
    }
    private async Task Message(string title, string text) { if (XamlRoot is null) return; await Ui.MessageDialog(XamlRoot, _p, title, text).ShowAsync(); }
    /// <summary>Mesma escolha da plataforma: Executar agora (com confirmação) ou Criar rotina (formulário único de Agenda).</summary>
    private async Task ChooseAsync(string command, string title)
    {
        if (XamlRoot is null) return;
        var result = await Ui.MessageDialog(XamlRoot, _p, title, "Escolha como deseja executar este serviço.", "Executar agora", "Criar rotina", "Cancelar", ContentDialogButton.Primary).ShowAsync();
        if (result == ContentDialogResult.Secondary)
        {
            if (await ScheduleEditor.ShowAsync(XamlRoot, _p, _runtime, _services, command, null)) await Message(title, "Rotina criada. Consulte a Agenda para gerenciar.");
            return;
        }
        if (result != ContentDialogResult.Primary) return;
        var confirm = await Ui.MessageDialog(XamlRoot, _p, title, "Confirmar execução deste comando neste computador?", "Confirmar", "", "Cancelar", ContentDialogButton.Primary).ShowAsync();
        if (confirm == ContentDialogResult.Primary) await RunAsync(command);
    }
    // Energia e bloqueio são executados direto neste computador; os demais serviços usam o mesmo fluxo da plataforma.
    private async Task RunAsync(string command)
    {
        switch (command)
        {
            case "power_restart": case "power_shutdown": MaintenanceService.SchedulePower(command, 5); return;
            case "screen_lock": MaintenanceService.LockSession(); return;
        }
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        await WorkspaceService.GetAsync(_runtime, "service-run", timeout.Token, ("command", command), ("password", ""), ("confirmed", true));
    }
}
