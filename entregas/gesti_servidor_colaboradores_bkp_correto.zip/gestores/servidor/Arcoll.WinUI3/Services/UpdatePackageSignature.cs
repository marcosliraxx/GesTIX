// Caminho: gestores/servidor/Arcoll.WinUI3/Services/UpdatePackageSignature.cs
using System.Security.Cryptography;
using System.Text;
namespace Arcoll.WinUI3.Services;

/// <summary>Valida o pacote assinado pelo publicador HTTPS e fixa sua chave pública por origem.</summary>
public static class UpdatePackageSignature
{
    public static void Verify(HttpResponseMessage response,GestorConfig config,string version,string digest)
    {
        static string Header(HttpResponseMessage response,string name)=>response.Headers.TryGetValues(name,out var values)?values.SingleOrDefault()??"":"";
        var encodedKey=Header(response,"X-Package-Public-Key");var signature=Header(response,"X-Package-Signature");
        if(encodedKey.Length is < 100 or > 8192||signature.Length is < 100 or > 2048)throw new InvalidDataException("Publicação sem assinatura válida. Atualize a API de publicação antes de continuar.");
        var pem=Encoding.UTF8.GetString(Convert.FromBase64String(encodedKey));
        using var key=RSA.Create();key.ImportFromPem(pem);if(key.KeySize<2048)throw new InvalidDataException("Chave de assinatura abaixo do mínimo.");
        if(!key.VerifyData(Encoding.UTF8.GetBytes(version+"\n"+digest.ToLowerInvariant()),Convert.FromBase64String(signature),HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1))throw new InvalidDataException("Assinatura do pacote não confere. Nenhum arquivo será aplicado.");
        var directory=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","UpdateKeys");Directory.CreateDirectory(directory);
        var pin=Path.Combine(directory,Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(config.Origin)))+".pem");
        // A primeira chave chega pelo canal HTTPS autenticado; mudanças posteriores exigem revisão administrativa.
        if(File.Exists(pin)){
            using var trusted=RSA.Create();trusted.ImportFromPem(File.ReadAllText(pin));
            if(!CryptographicOperations.FixedTimeEquals(trusted.ExportSubjectPublicKeyInfo(),key.ExportSubjectPublicKeyInfo()))throw new InvalidDataException("A identidade de assinatura da plataforma mudou. Confirme a publicação com o administrador.");
        }else{
            try{using var stream=new FileStream(pin,FileMode.CreateNew,FileAccess.Write,FileShare.None);using var writer=new StreamWriter(stream,Encoding.UTF8);writer.Write(pem);}
            catch(IOException) when(File.Exists(pin)){using var trusted=RSA.Create();trusted.ImportFromPem(File.ReadAllText(pin));if(!trusted.ExportSubjectPublicKeyInfo().SequenceEqual(key.ExportSubjectPublicKeyInfo()))throw new InvalidDataException("Chave de publicação divergente.");}
        }
    }
}
