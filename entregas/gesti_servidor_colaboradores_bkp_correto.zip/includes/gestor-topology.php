<?php
/* Caminho: includes/gestor-topology.php — perfis distribuídos, identidade e coordenação nas tabelas existentes. */
declare(strict_types=1);

function arc_gt_capabilities(): array {return ['maintenance'=>1,'backup'=>2,'inventory'=>4,'updates'=>8,'support'=>16,'network_scan'=>32,'coordinate'=>64];}
function arc_gt_labels(): array {return ['maintenance'=>'Pente-Fino e programas locais','backup'=>'Backup autorizado','inventory'=>'Inventário do computador','updates'=>'Atualizações','support'=>'Suporte autorizado','network_scan'=>'Descoberta da rede','coordinate'=>'Coordenação de tarefas'];}
function arc_gt_read(PDO $pdo,int $account,int $network,string $key,array $default=[]): array {
 $q=$pdo->prepare('SELECT preference_value FROM '.arc_table('network_user_preferences').' WHERE account_id=? AND network_id=? AND preference_key=?');$q->execute([$account,$network,$key]);$v=$q->fetchColumn();$data=$v===false?null:json_decode((string)$v,true);return is_array($data)?$data:$default;
}
function arc_gt_write(PDO $pdo,int $account,int $network,string $key,array $value): void {
 if($key==='gestor_topology')unset($value['primary']);
 $json=json_encode($value,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES);if(strlen($key)>80||strlen($json)>255)throw new InvalidArgumentException('Configuração distribuída acima do limite.');
 $pdo->prepare('INSERT INTO '.arc_table('network_user_preferences').' (account_id,network_id,preference_key,preference_value) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE preference_value=VALUES(preference_value)')->execute([$account,$network,$key,$json]);
}
function arc_gt_lock(PDO $pdo,int $account,int $network): void {
 if(!$pdo->inTransaction())throw new LogicException('Coordenação exige transação.');
 $q=$pdo->prepare('SELECT id FROM '.arc_table('managed_networks').' WHERE id=? AND account_id=? AND is_active=1 FOR UPDATE');$q->execute([$network,$account]);if(!$q->fetchColumn())throw new DomainException('Rede indisponível.',403);
}
function arc_gt_state(PDO $pdo,int $account,int $network): array {
 $state=arc_gt_read($pdo,$account,$network,'gestor_topology',['revision'=>0]);
 $q=$pdo->prepare('SELECT id FROM '.arc_table('network_gestores')." WHERE account_id=? AND network_id=? AND installation_profile='server' AND status='approved' ORDER BY id LIMIT 1");$q->execute([$account,$network]);$state['primary']=(int)$q->fetchColumn();return $state;
}
function arc_gt_profile(PDO $pdo,array $g): array {
 $account=(int)$g['account_id'];$network=(int)$g['network_id'];$id=(int)$g['id'];$state=arc_gt_state($pdo,$account,$network);
 // Instalações legadas conservam capacidades até a confirmação administrativa; não são promovidas silenciosamente.
 $p=arc_gt_read($pdo,$account,$network,'gestor_profile_'.$id,['mask'=>127,'confirmed'=>false,'requested'=>'collaborator','revoked'=>false]);
 $role=(int)($state['primary']??0)===$id?'server':'collaborator';$mask=(int)($p['mask']??31);$caps=[];foreach(arc_gt_capabilities() as $name=>$bit)$caps[$name]=($mask&$bit)!==0;
 if(!empty($p['confirmed'])&&$role!=='server'){$caps['network_scan']=false;$caps['coordinate']=false;}
 return ['role'=>$role,'requested_role'=>$p['requested']??'collaborator','confirmed'=>!empty($p['confirmed']),'revoked'=>!empty($p['revoked']),'permissions'=>$caps,'primary_id'=>(int)($state['primary']??0),'revision'=>(int)($state['revision']??0),'report_ttl_seconds'=>max(60,min(604800,(int)arc_platform_setting($pdo,'platform_gestor_report_ttl','604800'))),'offline_seconds'=>max(0,min(86400,(int)arc_platform_setting($pdo,'platform_gestor_offline_seconds','3600')))];
}
function arc_gt_require(PDO $pdo,array $g,string $capability): void {
 $p=arc_gt_profile($pdo,$g);if($p['revoked']||empty($p['permissions'][$capability]))throw new RuntimeException('Operação não autorizada para esta instalação.',403);
}
function arc_gt_command_capability(string $command): string {
 if(in_array($command,['scan_map','scan_devices'],true))return 'network_scan';
 if(in_array($command,['gestor_update','gestor_update_check','windows_update'],true))return 'updates';
 if(str_starts_with($command,'pentefino_')||str_starts_with($command,'program_')||$command==='cloud_folders')return 'maintenance';
 if(in_array($command,['remote_assistance','support_code_prompt','terminal_diagnostic','file_transfer','file_browser','file_bundle','file_execute','file_operation','power_shutdown','power_restart','power_cancel','screen_lock'],true))return 'support';
 return 'inventory';
}
function arc_gt_register(PDO $pdo,array $g,string $requested): array {
 if(!in_array($requested,['auto','server','collaborator'],true))throw new InvalidArgumentException('Perfil de instalação inválido.');
 $own=!$pdo->inTransaction();if($own)$pdo->beginTransaction();try{arc_gt_lock($pdo,(int)$g['account_id'],(int)$g['network_id']);$state=arc_gt_state($pdo,(int)$g['account_id'],(int)$g['network_id']);$key='gestor_profile_'.(int)$g['id'];$existing=arc_gt_read($pdo,(int)$g['account_id'],(int)$g['network_id'],$key);
  if(!$existing){$server=empty($state['primary'])&&$requested!=='collaborator';arc_gt_write($pdo,(int)$g['account_id'],(int)$g['network_id'],$key,['mask'=>31,'confirmed'=>false,'requested'=>$server?'server':'collaborator','revoked'=>false]);}
  if($own)$pdo->commit();return arc_gt_profile($pdo,$g);
 }catch(Throwable $e){if($own&&$pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function arc_gt_choose(PDO $pdo,array $g,string $role): array {
 if(!in_array($role,['server','collaborator'],true))throw new InvalidArgumentException('Perfil inválido.');
 $pdo->beginTransaction();try{arc_gt_lock($pdo,(int)$g['account_id'],(int)$g['network_id']);$q=$pdo->prepare('SELECT status FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=? FOR UPDATE');$q->execute([$g['id'],$g['account_id'],$g['network_id']]);if($q->fetchColumn()!=='pending')throw new DomainException('A escolha de perfil exige uma instalação pendente.',409);
 $state=arc_gt_state($pdo,(int)$g['account_id'],(int)$g['network_id']);if($role==='server'&&!empty($state['primary']))throw new DomainException('Já existe servidor principal reservado. Escolha Colaborador.',409);
 $p=arc_gt_read($pdo,(int)$g['account_id'],(int)$g['network_id'],'gestor_profile_'.$g['id'],['mask'=>31,'confirmed'=>false,'revoked'=>false]);$p['requested']=$role;arc_gt_write($pdo,(int)$g['account_id'],(int)$g['network_id'],'gestor_profile_'.$g['id'],$p);$pdo->commit();return arc_gt_profile($pdo,$g);
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function arc_gt_change(PDO $pdo,int $account,int $network,int $id,string $operation,int $mask,string $role): void {
 if(!in_array($operation,['confirm','permissions','transfer','revoke'],true)||!in_array($role,['server','collaborator'],true)||$mask<0||$mask>127)throw new InvalidArgumentException('Alteração de instalação inválida.');
 $pdo->beginTransaction();try{
  arc_gt_lock($pdo,$account,$network);$state=arc_gt_state($pdo,$account,$network);$old=(int)($state['primary']??0);
  $q=$pdo->prepare('SELECT id,status,machine_name,fingerprint FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=? FOR UPDATE');$q->execute([$id,$account,$network]);$g=$q->fetch(PDO::FETCH_ASSOC);if(!$g||($operation!=='revoke'&&$g['status']!=='approved'))throw new DomainException('Selecione um computador aprovado nesta rede.',409);
  if($operation==='confirm'&&$role==='server'&&$old&&$old!==$id)throw new DomainException('Já existe servidor principal. Use a transferência autorizada.',409);
  if($operation==='permissions'&&(($old===$id)!==($role==='server')))throw new DomainException('Mudança de perfil exige confirmação ou transferência.',409);
  if($operation==='transfer'&&$role!=='server')throw new InvalidArgumentException('O destino da transferência deve ser Servidor.');
  if($operation==='transfer'&&$old&&$old!==$id){
   // A identidade anterior é revogada na mesma transação da promoção; nunca coexistem dois principais.
   arc_gt_revoke_locked($pdo,$account,$network,$old);
  }
  if($operation==='revoke'){arc_gt_revoke_locked($pdo,$account,$network,$id);if($old===$id)$state['primary']=0;}
  else{$pdo->prepare('UPDATE '.arc_table('network_gestores').' SET installation_profile=? WHERE id=? AND account_id=? AND network_id=?')->execute([$role,$id,$account,$network]);if($role==='server')$state['primary']=$id;elseif($old===$id)$state['primary']=0;arc_gt_write($pdo,$account,$network,'gestor_profile_'.$id,['mask'=>$role==='server'?$mask:($mask&31),'confirmed'=>true,'requested'=>$role,'revoked'=>false]);}
  $state['revision']=(int)($state['revision']??0)+1;arc_gt_write($pdo,$account,$network,'gestor_topology',$state);
  arc_user_audit($pdo,'gestor_topology_'.$operation,'Rede '.$network.'; instalação '.$id.'; anterior '.$old.'; perfil '.$role.'; revisão '.$state['revision'].'; ator '.(arc_is_admin()?'admin:'.arc_admin_id():'user:'.arc_user_id()),$account);
  $pdo->commit();
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function arc_gt_revoke_locked(PDO $pdo,int $account,int $network,int $id): void {
 $pdo->prepare('DELETE FROM '.arc_table('gestor_download_keys').' WHERE account_id=? AND network_id=? AND fingerprint IN (SELECT fingerprint FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=?)')->execute([$account,$network,$id,$account,$network]);
 $pdo->prepare('UPDATE '.arc_table('network_gestores')." SET installation_profile='collaborator',status='blocked',ui_locked=1,notes='Vínculo revogado pela coordenação da rede' WHERE id=? AND account_id=? AND network_id=?")->execute([$id,$account,$network]);
 $pdo->prepare('UPDATE '.arc_table('gestor_commands')." SET status='failed',result_text='Identidade da instalação revogada',completed_at=NOW() WHERE gestor_id=? AND account_id=? AND network_id=? AND status IN ('pending','running')")->execute([$id,$account,$network]);
 $p=arc_gt_read($pdo,$account,$network,'gestor_profile_'.$id,['mask'=>0,'confirmed'=>true,'requested'=>'collaborator']);$p['revoked']=true;arc_gt_write($pdo,$account,$network,'gestor_profile_'.$id,$p);
}

/** Uma chamada repetida usa o mesmo comando por máquina; nada é executado duas vezes pelo lote. */
function arc_gt_batch(PDO $pdo,int $account,int $network,int $actor,array $ids,string $command,string $request): array {
 $max=max(1,min(100,(int)arc_platform_setting($pdo,'platform_gestor_batch_size','20')));
 if(!preg_match('/^[a-f0-9]{32}$/D',$request)||!in_array($command,['diagnostic','gestor_update','pentefino_scan'],true)||!$ids||count($ids)>$max)throw new InvalidArgumentException('Lote inválido ou acima do limite administrativo.');
 $ids=array_values(array_unique(array_map('intval',$ids)));sort($ids,SORT_NUMERIC);if(min($ids)<1)throw new InvalidArgumentException('Computador inválido.');
 $signature=hash('sha256',json_encode([$actor,$ids,$command]));$expires=time()+max(60,min(604800,(int)arc_platform_setting($pdo,'platform_gestor_batch_ttl','86400')));
 $pdo->beginTransaction();try{arc_gt_lock($pdo,$account,$network);$key='gestor_batch_'.$request;$saved=arc_gt_read($pdo,$account,$network,$key);
 if($saved&&!hash_equals((string)$saved['signature'],$signature))throw new DomainException('O identificador do lote já foi usado para outra solicitação.',409);
 if(!$saved)arc_gt_write($pdo,$account,$network,$key,['signature'=>$signature,'expires'=>$expires,'actor'=>$actor]);else $expires=(int)$saved['expires'];
 $result=[];foreach($ids as $id){$itemKey='gestor_batch_item_'.$request.'_'.$id;$item=arc_gt_read($pdo,$account,$network,$itemKey);
  if(!$item){if($expires<=time())throw new DomainException('O prazo deste lote foi encerrado.',409);$q=$pdo->prepare('SELECT id,account_id,network_id,status FROM '.arc_table('network_gestores').' WHERE id=? AND network_id=? AND account_id=? FOR UPDATE');$q->execute([$id,$network,$account]);$g=$q->fetch(PDO::FETCH_ASSOC);if(!$g||$g['status']!=='approved')throw new DomainException('Um dos computadores não está aprovado nesta rede.',403);
   arc_gt_require($pdo,$g,arc_gt_command_capability($command));
   $active=$pdo->prepare('SELECT id FROM '.arc_table('gestor_commands')." WHERE gestor_id=? AND network_id=? AND account_id=? AND command_name=? AND status IN ('pending','running') ORDER BY id DESC LIMIT 1 FOR UPDATE");$active->execute([$id,$network,$account,$command]);$cid=(int)$active->fetchColumn();
   if(!$cid)$cid=arc_support_queue_service($pdo,$account,$network,$id,$command,$actor,$command==='gestor_update'?['mode'=>'normal']:[]);
   if($command==='pentefino_scan'){
    $q=$pdo->prepare('SELECT command_id FROM '.arc_table('gestor_terminal_jobs').' WHERE command_id=?');$q->execute([$cid]);
    if(!$q->fetchColumn()){$settings=arc_pf_settings_get($pdo,$id,$network,$account);$categories=[];foreach(arc_pf_catalog() as $key=>$definition)if(!empty($definition['default'])&&$key!=='custom_folders')$categories[]=$key;
     if(!$categories)throw new DomainException('Nenhuma categoria de análise está configurada.',409);
     $payload=['categories'=>$categories,'age_days'=>7,'period_days'=>0,'exclusions'=>$settings['exclusions'],'custom_folders'=>$settings['custom_folders']];
     $pdo->prepare('INSERT INTO '.arc_table('gestor_terminal_jobs').' (command_id,gestor_id,network_id,request_text) VALUES (?,?,?,?)')->execute([$cid,$id,$network,json_encode($payload,JSON_THROW_ON_ERROR)]);
    }
   }
   arc_gt_write($pdo,$account,$network,'gestor_command_'.$cid,['expires'=>$expires,'batch'=>$request]);
   $item=['command'=>$cid,'expires'=>$expires,'batch'=>$request];arc_gt_write($pdo,$account,$network,$itemKey,$item);
  }$result[]=['gestor_id'=>$id,'command_id'=>(int)$item['command']];
 }
 if(!$saved)arc_user_audit($pdo,'gestor_batch_queued','Rede '.$network.'; lote '.$request.'; comando '.$command.'; máquinas '.implode(',',$ids),$account);
 $pdo->commit();return ['request_id'=>$request,'expires_at'=>$expires,'commands'=>$result];
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function arc_gt_dispatch_allowed(PDO $pdo,array $g,array $command): bool {
 $id=(int)$command['id'];$account=(int)$g['account_id'];$network=(int)$g['network_id'];$reason='';
 $meta=arc_gt_read($pdo,$account,$network,'gestor_command_'.$id);
 if($meta&&(int)($meta['expires']??0)<=time())$reason='Prazo do lote encerrado antes do despacho';
 try{arc_gt_require($pdo,$g,arc_gt_command_capability((string)$command['command_name']));}catch(RuntimeException $e){$reason=$e->getMessage();}
 if($reason==='')return true;
 $pdo->prepare('UPDATE '.arc_table('gestor_commands')." SET status=?,result_text=?,completed_at=NOW() WHERE id=? AND gestor_id=? AND account_id=? AND network_id=? AND status='pending'")->execute([$meta&&(int)($meta['expires']??0)<=time()?'expired':'failed',$reason,$id,$g['id'],$account,$network]);return false;
}
function arc_gt_choose_credentials(PDO $pdo,array $v): array {
 $fp=(string)($v['fingerprint']??'');$site=(string)($v['site_code']??'');$key=(string)($v['download_key']??'');
 if(!preg_match('/^[a-f0-9]{64}$/D',$fp)||!preg_match('/^[A-Z0-9]{5}$/D',$site)||!preg_match('/^[a-f0-9]{64}$/D',$key))throw new DomainException('Identidade inválida.',403);
 $q=$pdo->prepare('SELECT a.id,a.account_id,a.network_id FROM '.arc_table('network_gestores').' a JOIN '.arc_table('gestor_download_keys').' k ON k.account_id=a.account_id AND k.network_id=a.network_id AND k.fingerprint=a.fingerprint JOIN '.arc_table('managed_networks')." n ON n.id=a.network_id AND n.account_id=a.account_id WHERE a.fingerprint=? AND a.site_code=? AND k.token_hash=? AND a.status='pending' AND n.is_active=1");$q->execute([$fp,$site,hash('sha256',$key)]);$g=$q->fetch(PDO::FETCH_ASSOC);if(!$g)throw new DomainException('Instalação pendente não autenticada.',403);
 return arc_gt_choose($pdo,$g,(string)($v['role']??''));
}

/** A aprovação existente ativa o perfil solicitado sob a mesma trava por rede. */
function arc_gt_approve_locked(PDO $pdo,int $account,int $network,int $id): void {
 arc_gt_lock($pdo,$account,$network);$key='gestor_profile_'.$id;$p=arc_gt_read($pdo,$account,$network,$key);
 if(!$p)return; // Migração legada continua exigindo confirmação, sem eleger servidor automaticamente.
 $state=arc_gt_state($pdo,$account,$network);$server=($p['requested']??'collaborator')==='server'&&(empty($state['primary'])||(int)$state['primary']===$id);
 $pdo->prepare('UPDATE '.arc_table('network_gestores').' SET installation_profile=? WHERE id=? AND account_id=? AND network_id=?')->execute([$server?'server':'collaborator',$id,$account,$network]);
 $mask=!empty($p['confirmed'])&&empty($p['revoked'])?(int)($p['mask']??31):($server?127:31);
 $p=['mask'=>$server?$mask:($mask&31),'confirmed'=>true,'requested'=>$server?'server':'collaborator','revoked'=>false];
 if($server){$state['primary']=$id;$state['revision']=(int)($state['revision']??0)+1;arc_gt_write($pdo,$account,$network,'gestor_topology',$state);}
 arc_gt_write($pdo,$account,$network,$key,$p);
 arc_user_audit($pdo,'gestor_profile_activated','Rede '.$network.'; instalação '.$id.'; perfil '.($server?'Servidor':'Colaborador').'; rede '.$network,$account);
}
function arc_gt_local_dashboard(PDO $pdo,array $g): array {
 require_once __DIR__.'/network-inventory.php';
 $account=(int)$g['account_id'];$network=(int)$g['network_id'];$id=(int)$g['id'];
 $q=$pdo->prepare('SELECT id,UNIX_TIMESTAMP(last_seen_at) AS seen FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=?');$q->execute([$id,$account,$network]);$sensor=$q->fetch(PDO::FETCH_ASSOC);
 $observations=arc_gt_inventory_rows($pdo,$g,arc_inventory_list($pdo,$account,$network,$id));$now=time();$sensor['inventory_seen']=array_reduce($observations,static fn($n,$row)=>max($n,(int)($row['last_seen']??0)),0);
 return ['now'=>$now,'updated'=>$sensor['inventory_seen'],'limited'=>false,'events'=>[],'presence_seconds'=>arc_inventory_presence_seconds()]+arc_inventory_dashboard_rows([$sensor],$observations,$now);
}

/** Limita a apresentação nativa do Colaborador ao próprio host, inclusive inventários antigos preservados. */
function arc_gt_inventory_rows(PDO $pdo,array $g,array $rows): array {
 $profile=arc_gt_profile($pdo,$g);if(!$profile['confirmed']||$profile['role']==='server')return $rows;
 $q=$pdo->prepare('SELECT machine_name,local_ip FROM '.arc_table('network_gestores').' WHERE id=? AND account_id=? AND network_id=?');$q->execute([$g['id'],$g['account_id'],$g['network_id']]);$host=$q->fetch(PDO::FETCH_ASSOC);if(!$host)return [];
 $marked=array_values(array_filter($rows,static function($row){$payload=$row['payload']??json_decode((string)($row['payload_json']??''),true);return is_array($payload)&&!empty($payload['gestor_installed']);}));
 if(count($marked)===1)return $marked;
 return array_values(array_filter($rows,static fn($row)=>(!empty($host['local_ip'])&&(string)($row['ip']??'')===(string)$host['local_ip'])||(!empty($host['machine_name'])&&strcasecmp((string)($row['detected_name']??''),(string)$host['machine_name'])===0)));
}
