<?php
/* Caminho: includes/network-storage.php | v1.0.0 | Uso de armazenamento, limites e ciclos de autoexclusão por rede */
declare(strict_types=1);
require_once __DIR__ . '/error-logging.php';
require_once __DIR__ . '/storage-policy.php';

/** Áreas exibidas em Redes › Configurações. */
function arc_netstore_areas(): array {
 return ['db'=>'Banco de dados','logs'=>'Logs e diagnósticos','files'=>'Arquivos','cloud'=>'Nuvem'];
}

/**
 * Origens auditadas por rede. Nunca inclui contas, credenciais, gestores, inventário corrente nem tarefas abertas.
 * kind: rows (tabela com network_id), transfers (tabela + arquivos em disco), remote (arquivos temporários de sessões remotas).
 */
function arc_netstore_catalog(): array {
 return [
  'telemetry'=>['area'=>'logs','kind'=>'rows','label'=>'Telemetria e métricas dos gestores','table'=>'gestor_telemetry','date'=>'captured_at','pk'=>'id','days'=>14,'mb'=>50,
    'size'=>'COUNT(*)*160+COALESCE(SUM(LENGTH(t.payload_json)),0)','note'=>'Mantém sempre o registro mais recente de cada tipo por gestor.'],
  'terminal'=>['area'=>'logs','kind'=>'rows','label'=>'Saídas de terminal e tarefas remotas','table'=>'gestor_terminal_jobs','date'=>'updated_at','pk'=>'command_id','days'=>14,'mb'=>20,
    'size'=>'COUNT(*)*120+COALESCE(SUM(LENGTH(t.request_text)),0)+COALESCE(SUM(LENGTH(t.output_text)),0)','note'=>'Somente comandos já finalizados.'],
  'commands'=>['area'=>'logs','kind'=>'rows','label'=>'Comandos finalizados','table'=>'gestor_commands','date'=>'created_at','pk'=>'id','days'=>45,'mb'=>30,
    'size'=>'COUNT(*)*200+COALESCE(SUM(LENGTH(t.result_text)),0)','note'=>'Comandos concluídos, com falha ou expirados e sem registros dependentes.'],
  'command_errors'=>['area'=>'logs','kind'=>'rows','label'=>'Diagnósticos de comandos com erro','table'=>'gestor_command_errors','date'=>'recorded_at','pk'=>'command_id','days'=>30,'mb'=>10,
    'size'=>'COUNT(*)*120+COALESCE(SUM(LENGTH(t.diagnostic_text)),0)','note'=>''],
  'browser'=>['area'=>'db','kind'=>'rows','label'=>'Histórico do explorador de arquivos','table'=>'file_browser_requests','date'=>'created_at','pk'=>'id','days'=>7,'mb'=>25,
    'size'=>'COUNT(*)*300+COALESCE(SUM(LENGTH(t.path_text)),0)+COALESCE(SUM(LENGTH(t.result_json)),0)','note'=>'Somente consultas encerradas.'],
  'device_events'=>['area'=>'db','kind'=>'rows','label'=>'Histórico de eventos de dispositivos','table'=>'network_device_events','date'=>'occurred_at','epoch'=>true,'pk'=>'id','days'=>90,'mb'=>20,
    'size'=>'COUNT(*)*260','note'=>'O inventário atual dos dispositivos é preservado.'],
  'clean_history'=>['area'=>'db','kind'=>'rows','label'=>'Histórico de limpezas dos gestores','table'=>'clean_history','date'=>'created_at','pk'=>'id','days'=>90,'mb'=>5,
    'size'=>'COUNT(*)*220','note'=>''],
  'transfers'=>['area'=>'files','kind'=>'transfers','label'=>'Transferências de arquivos','table'=>'support_file_transfers','date'=>'created_at','pk'=>'id','days'=>30,'mb'=>500,
    'size'=>'COUNT(*)*250+COALESCE(SUM(CASE WHEN t.storage_key IS NOT NULL THEN t.file_size ELSE 0 END),0)','note'=>'Arquivos e histórico de transferências encerradas ou vencidas.'],
  'remote_files'=>['area'=>'files','kind'=>'remote','label'=>'Arquivos temporários do acesso remoto','days'=>2,'mb'=>200,'note'=>'Imagens e controles de sessões remotas já encerradas.'],
  'backup_runs'=>['area'=>'cloud','kind'=>'rows','label'=>'Histórico e manifestos de backup na nuvem','table'=>'backup_center_runs','date'=>'started','epoch'=>true,'pk'=>'id','days'=>180,'mb'=>0,'on'=>false,
    'size'=>"COUNT(*)*400+COALESCE(SUM(LENGTH(t.manifest_json)),0)+COALESCE(SUM(LENGTH(t.summary_json)),0)+COALESCE(SUM(LENGTH(t.selection_json)),0)+COALESCE(SUM(LENGTH(t.plan_json)),0)",
    'note'=>'Remove somente o registro das execuções antigas; mantém fixadas, em andamento, as 3 mais recentes de cada plano e as usadas como origem de restauração. Os objetos já enviados ao provedor não são apagados pela plataforma.'],
 ];
}

/** Ordem de execução: dependentes antes dos comandos que os referenciam. */
function arc_netstore_order(): array {
 return ['terminal','browser','transfers','remote_files','commands','command_errors','telemetry','device_events','clean_history','backup_runs'];
}

function arc_netstore_fmt(int|float $bytes): string {
 $bytes=max(0,(float)$bytes);$units=['B','KB','MB','GB','TB'];$i=0;
 while($bytes>=1024&&$i<count($units)-1){$bytes/=1024;$i++;}
 return number_format($bytes,$i===0?0:($bytes<10?2:1),',','.').' '.$units[$i];
}

/** Condição extra de segurança por origem (somente dados encerrados e dispensáveis). */
function arc_netstore_extra(string $key,array $inventory): string {
 switch($key){
  case 'telemetry':
   return ' AND EXISTS (SELECT 1 FROM '.arc_table('gestor_telemetry').' n WHERE n.gestor_id=t.gestor_id AND n.event_type=t.event_type AND n.id>t.id)';
  case 'terminal':
   return ' AND EXISTS (SELECT 1 FROM '.arc_table('gestor_commands')." c WHERE c.id=t.command_id AND c.status IN ('completed','failed','expired'))";
  case 'commands':
   return " AND t.status IN ('completed','failed','expired')".arc_storage_command_guard($inventory);
  case 'browser':
   return " AND t.status NOT IN ('pending','running','processing','queued')";
  case 'backup_runs':
   $r=arc_table('backup_center_runs');
   return " AND t.pinned=0 AND t.ended>0 AND t.state NOT IN ('queued','running') AND (SELECT COUNT(*) FROM $r k WHERE k.plan_id=t.plan_id AND k.ended>0 AND k.started>t.started)>=3 AND NOT EXISTS (SELECT 1 FROM $r s WHERE s.source_run=t.id)";
 }
 return '';
}

/** Arquivos temporários de sessões remotas que pertencem a comandos desta rede. */
function arc_netstore_remote_files(PDO $pdo,int $network): array {
 $dir=arc_storage_remote_dir();$regex=arc_storage_remote_regex();$byCommand=[];
 if(!is_dir($dir)||is_link($dir))return [];
 try{$it=new FilesystemIterator($dir,FilesystemIterator::SKIP_DOTS);}catch(Throwable $e){return [];}
 foreach($it as $file){
  if(!$file->isFile()||$file->isLink()||!preg_match($regex,$file->getFilename()))continue;
  if(!preg_match('/-([0-9]+)(?:\.|$)/',$file->getFilename(),$m))continue;
  $byCommand[(int)$m[1]][]=['path'=>$file->getPathname(),'bytes'=>(int)$file->getSize(),'mtime'=>(int)$file->getMTime()];
 }
 if(!$byCommand)return [];
 $owned=[];
 foreach(array_chunk(array_keys($byCommand),400) as $chunk){
  $q=$pdo->prepare('SELECT id,status,created_at FROM '.arc_table('gestor_commands').' WHERE network_id=? AND id IN ('.implode(',',array_fill(0,count($chunk),'?')).')');
  $q->execute(array_merge([$network],$chunk));
  foreach($q->fetchAll(PDO::FETCH_ASSOC) as $command)$owned[(int)$command['id']]=$command;
 }
 $files=[];
 foreach($owned as $id=>$command){
  $live=in_array((string)$command['status'],['pending','running'],true)&&(int)strtotime((string)$command['created_at'])>=time()-7200;
  foreach($byCommand[$id] as $f){$f['live']=$live;$files[]=$f;}
 }
 usort($files,static fn(array $a,array $b):int=>$a['mtime']<=>$b['mtime']);
 return $files;
}

/** Uso atual de cada origem, para esta rede. */
function arc_netstore_usage(PDO $pdo,int $network): array {
 $inventory=arc_storage_inventory($pdo);$out=[];
 foreach(arc_netstore_catalog() as $key=>$meta){
  $row=['bytes'=>0,'rows'=>0,'oldest'=>null,'available'=>true];
  try{
   if($meta['kind']==='remote'){
    $files=arc_netstore_remote_files($pdo,$network);
    $row['rows']=count($files);$row['bytes']=array_sum(array_column($files,'bytes'));
    $row['oldest']=$files?(int)$files[0]['mtime']:null;
   }elseif(!isset($inventory[arc_prefix().$meta['table']])){
    $row['available']=false;
   }else{
    $q=$pdo->prepare('SELECT COUNT(*) c,'.$meta['size'].' b,MIN(t.`'.$meta['date'].'`) m FROM '.arc_table($meta['table']).' t WHERE t.network_id=?');
    $q->execute([$network]);$r=$q->fetch(PDO::FETCH_ASSOC)?:[];
    $row['rows']=(int)($r['c']??0);$row['bytes']=(int)($r['b']??0);
    $m=$r['m']??null;
    $row['oldest']=$m===null?null:(!empty($meta['epoch'])?(int)$m:(int)strtotime((string)$m));
   }
  }catch(Throwable $e){arc_log_error('Uso de armazenamento da rede ('.$key.'): '.$e->getMessage());$row['available']=false;}
  $out[$key]=$row;
 }
 return $out;
}

/** Dados preservados (inventário e cadastros): exibidos para dar o total real da rede, nunca apagados por ciclos. */
function arc_netstore_preserved(PDO $pdo,int $network): array {
 $defs=[
  ['Inventário de dispositivos','network_device_inventory','COUNT(*)*600'],
  ['Inventário de programas','gestor_software_inventory','COALESCE(SUM(LENGTH(t.programs_json)),0)'],
  ['Relatórios de limpeza atuais','gestor_clean_inventory','COALESCE(SUM(LENGTH(t.report_json)),0)'],
  ['Gestores e cadastros','network_gestores','COALESCE(SUM(LENGTH(t.machine_details)),0)+COUNT(*)*500'],
 ];
 $inventory=arc_storage_inventory($pdo);$out=[];
 foreach($defs as [$label,$table,$expr]){
  if(!isset($inventory[arc_prefix().$table]))continue;
  try{
   $q=$pdo->prepare('SELECT COUNT(*) c,'.$expr.' b FROM '.arc_table($table).' t WHERE t.network_id=?');$q->execute([$network]);$r=$q->fetch(PDO::FETCH_ASSOC)?:[];
   $out[]=['label'=>$label,'rows'=>(int)($r['c']??0),'bytes'=>(int)($r['b']??0)];
  }catch(Throwable $e){arc_log_error('Dados preservados da rede ('.$table.'): '.$e->getMessage());}
 }
 return $out;
}

/** Contas de nuvem conectadas à rede e a cota informada pelo provedor. */
function arc_netstore_cloud(PDO $pdo,int $network): array {
 try{
  $q=$pdo->prepare('SELECT provider,label,quota_used,quota_total,status FROM '.arc_table('cloud_connections').' WHERE network_id=? ORDER BY id');
  $q->execute([$network]);return $q->fetchAll(PDO::FETCH_ASSOC);
 }catch(Throwable $e){return [];}
}

/** Política da rede (preferências da rede), limitada pelos tetos definidos pela administração da plataforma. */
function arc_netstore_policy(PDO $pdo,int $account,int $network): array {
 $platform=arc_storage_policy($pdo);$min=(int)$platform['network_min_days'];
 $p=['auto'=>false,'global_mb'=>0,'last_run'=>'','categories'=>[]];$saved=[];
 try{
  $q=$pdo->prepare('SELECT preference_key,preference_value FROM '.arc_table('network_user_preferences').' WHERE account_id=? AND network_id=? AND preference_key LIKE ?');
  $q->execute([$account,$network,'storage\\_%']);
  foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row)$saved[(string)$row['preference_key']]=(string)$row['preference_value'];
 }catch(Throwable $e){arc_log_error('Política de armazenamento da rede: '.$e->getMessage());}
 $p['auto']=($saved['storage_auto']??'0')==='1';
 $p['last_run']=$saved['storage_last_run']??'';
 $global=max(0,min(1048576,(int)($saved['storage_global_mb']??0)));$cap=(int)$platform['network_cap_mb'];
 if($cap>0)$global=$global>0?min($global,$cap):$cap;
 $p['global_mb']=$global;
 foreach(arc_netstore_catalog() as $key=>$meta){
  $p['categories'][$key]=[
   'on'=>array_key_exists("storage_{$key}_on",$saved)?$saved["storage_{$key}_on"]==='1':(bool)($meta['on']??true),
   'days'=>max($min,min(3650,(int)($saved["storage_{$key}_days"]??$meta['days']))),
   'mb'=>max(0,min(1048576,(int)($saved["storage_{$key}_mb"]??$meta['mb']))),
  ];
 }
 return $p;
}

function arc_netstore_policy_save(PDO $pdo,int $account,int $network,array $post): void {
 $platform=arc_storage_policy($pdo);$min=(int)$platform['network_min_days'];
 $rows=['storage_auto'=>!empty($post['storage_auto'])?'1':'0','storage_global_mb'=>(string)max(0,min(1048576,(int)($post['storage_global_mb']??0)))];
 foreach(arc_netstore_catalog() as $key=>$meta){
  if($meta['area']==='cloud')continue; // Regras de backup são salvas exclusivamente no Cloud Config.
  $rows["storage_{$key}_on"]=isset($post['storage_on'][$key])?'1':'0';
  $rows["storage_{$key}_days"]=(string)max($min,min(3650,(int)($post['storage_days'][$key]??$meta['days'])));
  $rows["storage_{$key}_mb"]=(string)max(0,min(1048576,(int)($post['storage_mb'][$key]??$meta['mb'])));
 }
 arc_netstore_write_prefs($pdo,$account,$network,$rows);
}
function arc_netstore_write_prefs(PDO $pdo,int $account,int $network,array $rows): void {
 $stmt=$pdo->prepare('INSERT INTO '.arc_table('network_user_preferences').' (account_id,network_id,preference_key,preference_value) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE preference_value=VALUES(preference_value)');
 foreach($rows as $key=>$value)$stmt->execute([$account,$network,(string)$key,(string)$value]);
}

/** Datas no formato do banco (fuso do PHP, como o restante da plataforma). */
function arc_netstore_date(int $ts): string { return date('Y-m-d H:i:s',$ts); }

/** Ciclo de linhas: período (dias) e quantidade (MB), sempre do mais antigo para o mais novo e preservando as últimas 24 h. */
function arc_netstore_rows(PDO $pdo,string $key,array $meta,int $network,array $inventory,array $usage,int $days,int $freeNeed,bool $manual,bool $execute): array {
 $table=arc_table($meta['table']);$col='t.`'.$meta['date'].'`';$epoch=!empty($meta['epoch']);
 $now=time();$floor=$now-86400;$period=$manual?$floor:min($floor,$now-$days*86400);
 $extra=arc_netstore_extra($key,$inventory);
 $value=static fn(int $ts)=>$epoch?$ts:arc_netstore_date($ts);
 $count=static function(int $ts) use($pdo,$table,$col,$network,$extra,$value):int{
  $q=$pdo->prepare('SELECT COUNT(*) FROM '.$table.' t WHERE t.network_id=? AND '.$col.' < ?'.$extra);$q->execute([$network,$value($ts)]);return (int)$q->fetchColumn();
 };
 $eligible=$count($floor);$periodCount=$manual?$eligible:$count($period);
 $qtyRows=0;
 if($freeNeed>0&&$usage['rows']>0){$avg=max(1,intdiv((int)$usage['bytes'],(int)$usage['rows']));$qtyRows=(int)ceil($freeNeed/$avg);}
 $planned=min($eligible,max($periodCount,$qtyRows),5000);
 $deleted=0;
 if($execute&&$planned>0){
  $pk=$meta['pk'];
  while($deleted<$planned){
   $batch=min(250,$planned-$deleted);
   $q=$pdo->prepare('SELECT t.`'.$pk.'` FROM '.$table.' t WHERE t.network_id=? AND '.$col.' < ?'.$extra.' ORDER BY '.$col.' ASC LIMIT '.$batch);
   $q->execute([$network,$value($floor)]);$ids=$q->fetchAll(PDO::FETCH_COLUMN);if(!$ids)break;
   $del=$pdo->prepare('DELETE FROM '.$table.' WHERE `'.$pk.'` IN ('.implode(',',array_fill(0,count($ids),'?')).') AND network_id=?');
   $del->execute(array_merge($ids,[$network]));$n=$del->rowCount();if($n<1)break;$deleted+=$n;
  }
 }
 $avgBytes=$usage['rows']>0?$usage['bytes']/$usage['rows']:0;
 return ['eligible'=>$eligible,'planned'=>$planned,'deleted'=>$deleted,'freed'=>(int)round(($execute?$deleted:$planned)*$avgBytes)];
}

/** Ciclo de transferências: remove primeiro o arquivo guardado e depois o registro encerrado. */
function arc_netstore_transfers(PDO $pdo,int $network,int $days,int $freeNeed,bool $manual,bool $execute): array {
 $t=arc_table('support_file_transfers');$now=time();$floor=$now-86400;$period=$manual?$floor:min($floor,$now-$days*86400);
 $q=$pdo->prepare('SELECT t.id,t.storage_key,t.file_size,t.created_at FROM '.$t." t WHERE t.network_id=? AND (t.status IN ('completed','cancelled','declined','failed','expired') OR t.expires_at<NOW()) AND t.created_at < ? ORDER BY t.created_at ASC LIMIT 2000");
 $q->execute([$network,arc_netstore_date($floor)]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
 $planned=0;$deleted=0;$freed=0;
 foreach($rows as $row){
  $due=(int)strtotime((string)$row['created_at'])<$period;
  if(!$due&&$freeNeed-$freed<=0)continue;
  $key=(string)($row['storage_key']??'');$size=$key!==''?(int)$row['file_size']:0;$planned++;
  if($execute){
   if($key!==''){
    if(!preg_match('/^[a-f0-9]{64}$/D',$key))continue;
    $path=ARC_PRIVATE_DIR.'/storage/transfers/'.$key;
    if(is_file($path)&&!@unlink($path))continue;
   }
   $pdo->prepare('DELETE FROM '.$t.' WHERE id=? AND network_id=?')->execute([(int)$row['id'],$network]);$deleted++;
  }
  $freed+=$size+250;
 }
 return ['eligible'=>count($rows),'planned'=>$planned,'deleted'=>$deleted,'freed'=>$freed];
}

/** Ciclo dos arquivos temporários de sessões remotas desta rede. */
function arc_netstore_remote(PDO $pdo,int $network,int $days,int $freeNeed,bool $manual,bool $execute): array {
 $files=arc_netstore_remote_files($pdo,$network);$now=time();$floor=$now-7200;$period=$manual?$floor:min($floor,$now-$days*86400);
 $eligible=0;$planned=0;$deleted=0;$freed=0;
 foreach($files as $file){
  if($file['live']||$file['mtime']>=$floor)continue;
  $eligible++;
  if($file['mtime']>=$period&&$freeNeed-$freed<=0)continue;
  $planned++;
  if($execute){if(!@unlink($file['path']))continue;$deleted++;}
  $freed+=$file['bytes'];
 }
 return ['eligible'=>$eligible,'planned'=>$planned,'deleted'=>$deleted,'freed'=>$freed];
}

/**
 * Executa os ciclos da rede.
 * mode auto: respeita a política (categorias ligadas, prazo e limites) e só roda com os ciclos automáticos ativos.
 * mode manual: limpa tudo que é seguro (exceto últimas 24 h), em uma ou em todas as categorias.
 */
function arc_netstore_run(PDO $pdo,int $account,int $network,string $mode='auto',bool $execute=true,?string $only=null): array {
 $platform=arc_storage_policy($pdo);$policy=arc_netstore_policy($pdo,$account,$network);$manual=$mode==='manual';
 $result=['mode'=>$mode,'executed'=>$execute,'skipped'=>false,'message'=>'','categories'=>[],'deleted'=>0,'freed'=>0];
 if(!$manual&&(!$platform['network_cycles']||!$policy['auto'])){$result['skipped']=true;$result['message']='Ciclos automáticos desativados.';return $result;}
 $catalog=arc_netstore_catalog();$inventory=arc_storage_inventory($pdo);$usage=arc_netstore_usage($pdo,$network);
 $total=array_sum(array_column($usage,'bytes'));$limit=(int)$policy['global_mb']*1048576;
 $globalNeed=$limit>0&&$total>$limit?$total-intdiv($limit*9,10):0;
 foreach(arc_netstore_order() as $key){
  if($only!==null&&$only!==$key)continue;
  $meta=$catalog[$key];$cfg=$policy['categories'][$key];$u=$usage[$key];
  if(!$u['available']||(!$manual&&!$cfg['on']))continue;
  $own=$cfg['mb']>0&&$u['bytes']>$cfg['mb']*1048576?$u['bytes']-intdiv($cfg['mb']*1048576*9,10):0;
  $need=$manual?0:max($own,$globalNeed);
  try{
   $r=match($meta['kind']){
    'remote'=>arc_netstore_remote($pdo,$network,$cfg['days'],$need,$manual,$execute),
    'transfers'=>arc_netstore_transfers($pdo,$network,$cfg['days'],$need,$manual,$execute),
    default=>arc_netstore_rows($pdo,$key,$meta,$network,$inventory,$u,$cfg['days'],$need,$manual,$execute),
   };
  }catch(Throwable $e){arc_log_error('Ciclo de armazenamento da rede '.$network.' ('.$key.'): '.$e->getMessage());continue;}
  $r['label']=$meta['label'];$result['categories'][$key]=$r;
  $result['deleted']+=$r['deleted'];$result['freed']+=$r['freed'];
  $globalNeed=max(0,$globalNeed-$r['freed']);
 }
 if($mode==='auto'&&$execute)arc_netstore_write_prefs($pdo,$account,$network,['storage_last_run'=>gmdate('Y-m-d H:i:s').' UTC']);
 return $result;
}

/** Usado pela rotina de manutenção (cron): percorre todas as redes que ligaram os ciclos automáticos. */
function arc_netstore_run_all(PDO $pdo,bool $execute=true): array {
 $platform=arc_storage_policy($pdo);$out=[];
 if(!$platform['network_cycles'])return $out;
 $q=$pdo->query('SELECT DISTINCT p.account_id,p.network_id FROM '.arc_table('network_user_preferences').' p JOIN '.arc_table('managed_networks')." n ON n.id=p.network_id AND n.account_id=p.account_id WHERE p.preference_key='storage_auto' AND p.preference_value='1'");
 foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row){
  try{$out[(int)$row['network_id']]=arc_netstore_run($pdo,(int)$row['account_id'],(int)$row['network_id'],'auto',$execute);}
  catch(Throwable $e){arc_log_error('Ciclos da rede '.$row['network_id'].': '.$e->getMessage());}
 }
 return $out;
}
