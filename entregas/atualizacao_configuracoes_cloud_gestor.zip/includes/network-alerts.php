<?php
declare(strict_types=1);
/** Configuração da rede é a autoridade; o agente não escolhe destinatários nem limites SMTP. */
function arc_network_alerts(PDO $pdo,array $gestor,string $type,array $event):void {
 if(!in_array($type,['server_metrics','speed_test'],true))return;
 $account=(int)$gestor['account_id'];$network=(int)$gestor['network_id'];
 $q=$pdo->prepare('SELECT preference_key,preference_value FROM '.arc_table('network_user_preferences')." WHERE account_id=? AND network_id=? AND preference_key IN ('email_alerts','alert_latency','alert_low_speed','alert_min_download_mbps')");
 $q->execute([$account,$network]);$prefs=$q->fetchAll(PDO::FETCH_KEY_PAIR);
 if(($prefs['email_alerts']??'1')!=='1'||arc_platform_setting($pdo,'platform_smtp_enabled','0')!=='1')return;
 $system=arc_system_prefs($pdo);if(($system['notifications_email']??'1')!=='1')return;
 $latency=$type==='server_metrics'?($event['metrics']['Internet']??null):($event['latency_ms']??null);
 $download=$type==='speed_test'?($event['download_mbps']??null):null;
 $alerts=[];$limit=max(10,min(2000,(int)($prefs['alert_latency']??150)));
 if(is_numeric($latency)&&(float)$latency>=$limit)$alerts['latency']='Latência de '.round((float)$latency,2).' ms (limite '.$limit.' ms).';
 $min=max(1,min(100000,(int)($prefs['alert_min_download_mbps']??10)));
 if(($prefs['alert_low_speed']??'0')==='1'&&is_numeric($download)&&(float)$download<$min)$alerts['speed']='Download de '.round((float)$download,2).' Mbps (mínimo '.$min.' Mbps).';
 if(!$alerts)return;
 $q=$pdo->prepare('SELECT n.name,u.email FROM '.arc_table('managed_networks').' n JOIN '.arc_table('user_accounts').' u ON u.id=n.account_id WHERE n.id=? AND n.account_id=?');$q->execute([$network,$account]);$owner=$q->fetch(PDO::FETCH_ASSOC);
 if(!$owner||!filter_var($owner['email'],FILTER_VALIDATE_EMAIL))return;
 foreach($alerts as $key=>$message){
  // Reserva transacional impede múltiplos agentes de enviar o mesmo aviso simultaneamente.
  $pdo->beginTransaction();
  try{
   arc_gt_lock($pdo,$account,$network);$pref='network_alert_'.$key;$saved=arc_gt_read($pdo,$account,$network,$pref);
   if((int)($saved['next']??0)>time()){$pdo->commit();continue;}
   arc_gt_write($pdo,$account,$network,$pref,['next'=>time()+300,'state'=>'sending']);$pdo->commit();
  }catch(Throwable $error){if($pdo->inTransaction())$pdo->rollBack();throw $error;}
  try{
   arc_platform_smtp_send($pdo,(string)$owner['email'],'Alerta de rede: '.(string)$owner['name'],"Rede: ".$owner['name']."\nComputador ID: ".(int)$gestor['id']."\n".$message);
   arc_gt_write($pdo,$account,$network,$pref,['next'=>time()+1800,'state'=>'sent','at'=>time()]);
  }catch(Throwable $error){arc_gt_write($pdo,$account,$network,$pref,['next'=>time()+300,'state'=>'failed','at'=>time()]);arc_log_error('Alerta de rede '.$network.': '.$error->getMessage());}
 }
}
