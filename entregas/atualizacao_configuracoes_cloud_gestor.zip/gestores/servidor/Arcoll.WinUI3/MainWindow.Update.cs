// Caminho: gestores/servidor/Arcoll.WinUI3/MainWindow.Update.cs
using Arcoll.WinUI3.Pages;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Animation;
namespace Arcoll.WinUI3;
public sealed partial class MainWindow
{
 // Indicador de nova versão: um ponto na categoria que contém o submenu Atualizações e outro no próprio submenu.
 private const string UpdateMenuKey="updates";private readonly Dictionary<string,InfoBadge> _tabBadges=new();private readonly List<InfoBadge> _menuBadges=new();private readonly DispatcherTimer _updateBadgeTimer=new(){Interval=TimeSpan.FromMinutes(2)};private bool _updateBadge,_badgePolling;
 private InfoBadge CategoryUpdateBadge(string group){var badge=new InfoBadge{VerticalAlignment=VerticalAlignment.Top,Visibility=Visibility.Collapsed};Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(badge,"Atualização do gestor disponível");_tabBadges[group]=badge;return badge;}
 private InfoBadge UpdateMenuBadge(){var badge=new InfoBadge{HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Top,Margin=new Thickness(8,6,0,0),IsHitTestVisible=false,Visibility=_updateBadge?Visibility.Visible:Visibility.Collapsed};Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(badge,"Atualização do gestor disponível");_menuBadges.Add(badge);return badge;}
 private void ApplyUpdateBadges(){var parent=GroupKeyOf(UpdateMenuKey);foreach(var entry in _tabBadges)entry.Value.Visibility=_updateBadge&&(entry.Key==parent||(entry.Key=="home"&&_favorites.Contains(UpdateMenuKey)))?Visibility.Visible:Visibility.Collapsed;_menuBadges.RemoveAll(b=>b.XamlRoot is null);foreach(var badge in _menuBadges)badge.Visibility=_updateBadge?Visibility.Visible:Visibility.Collapsed;}
 private void SetUpdateBadge(bool available){DispatcherQueue.TryEnqueue(()=>{if(_updateUiClosed||_updateBadge==available)return;_updateBadge=available;ApplyUpdateBadges();});}
 private async Task PollUpdateBadgeAsync(){if(_badgePolling||_updateUiClosed||!_runtime.Can("updates")||UpdatePresentation.Current.Status is "working" or "restarting")return;_badgePolling=true;try{var polled=await UpdateCheckService.CheckAsync(_runtime.Platform,CancellationToken.None);SetUpdateBadge(polled.Available);NotifyUpdate(polled);DispatcherQueue.TryEnqueue(()=>_gestorUpdatePage?.SetAvailability(polled));}catch(Exception error){RuntimeLog.Write("Indicador de atualização: "+error.Message);}finally{_badgePolling=false;}}
 private GestorUpdatePage? _gestorUpdatePage;private readonly DispatcherTimer _updateReceiptTimer=new(){Interval=TimeSpan.FromSeconds(1)};private bool _updateUiClosed;private string _updateShownId="";
 private void InitializeUpdateArea()
 {
  // Entry exists only on the existing refresh icon; no extra top-level category.
  _gestorUpdatePage=new GestorUpdatePage(_runtime,StartGestorUpdateAsync,CheckGestorUpdateAsync);
  UpdatePresentation.Changed+=UpdateViewChanged;_runtime.Changed+=UpdateAuthorizationChanged;
  InitializeBell();
  var restored=UpdatePresentation.Restore();UpdateHistoryStore.ImportLastSession();
  _updateReceiptTimer.Tick+=(_,_)=>{UpdatePresentation.PollReceipts();RefreshGestorAreas();};_updateReceiptTimer.Start();
  _updateBadgeTimer.Tick+=async(_,_)=>await PollUpdateBadgeAsync();_updateBadgeTimer.Start();var firstBadge=new DispatcherTimer{Interval=TimeSpan.FromSeconds(5)};firstBadge.Tick+=async(_,_)=>{firstBadge.Stop();await PollUpdateBadgeAsync();};firstBadge.Start();
  Closed+=(_,_)=>{_updateUiClosed=true;_updateReceiptTimer.Stop();_updateBadgeTimer.Stop();UpdatePresentation.Changed-=UpdateViewChanged;_runtime.Changed-=UpdateAuthorizationChanged;};
  if(restored&&UpdatePresentation.Current.Status is "working" or "restarting"){PublishCollaboratorUpdate(UpdatePresentation.Current);ShowGestorUpdateArea();}
 }
 private Window? _collaboratorUpdateWindow;
 private TextBlock? _collaboratorUpdateText;
 private ProgressBar? _collaboratorUpdateProgress;
 private void PublishCollaboratorUpdate(UpdateViewState state)
 {
  if(_runtime.IsServer)return;
  if(state.Status is "working" or "restarting")
  {
   if(_collaboratorUpdateWindow is null)
   {
    _collaboratorUpdateText=new TextBlock{TextWrapping=TextWrapping.Wrap};
    _collaboratorUpdateProgress=new ProgressBar{Minimum=0,Maximum=100,Height=8};
    var content=new StackPanel{Spacing=18,Padding=new Thickness(24)};
    content.Children.Add(new TextBlock{Text="Atualizando Gestor Colaborador",FontSize=20});
    content.Children.Add(_collaboratorUpdateText);content.Children.Add(_collaboratorUpdateProgress);
    content.Children.Add(new TextBlock{Text="Aguarde. O gestor reiniciará automaticamente ao concluir.",TextWrapping=TextWrapping.Wrap});
    _collaboratorUpdateWindow=new Window{Title="Atualização do Gestor",Content=content};
    _collaboratorUpdateWindow.AppWindow.Resize(new Windows.Graphics.SizeInt32(540,260));
    _collaboratorUpdateWindow.Closed+=(_,_)=>{_collaboratorUpdateWindow=null;};
    _collaboratorUpdateWindow.Activate();
   }
   _collaboratorUpdateText!.Text=$"{state.Percent}% · {state.Message}";
   _collaboratorUpdateProgress!.Value=state.Percent;
  }
  else if(_collaboratorUpdateWindow is not null)
  {
   _collaboratorUpdateText!.Text=state.Message;
   _collaboratorUpdateProgress!.Value=state.Percent;
  }
 }
 private void UpdateViewChanged(UpdateViewState state){if(!_updateUiClosed)DispatcherQueue.TryEnqueue(()=>{if(_updateUiClosed)return;PublishCollaboratorUpdate(state);if(state.Status=="working"&&state.Id!=_updateShownId){_updateShownId=state.Id;ShowGestorUpdateArea();}_gestorUpdatePage?.Publish();});}
 private void UpdateAuthorizationChanged(){if(!_updateUiClosed)DispatcherQueue.TryEnqueue(()=>_gestorUpdatePage?.Publish());}
 private void GestorUpdate_Open_Click(object sender,RoutedEventArgs args)=>ShowGestorUpdateArea();
 private void ShowGestorUpdateArea(string view="update")
 {
  var key=view=="history"?"history":"updates";
  if(TryShowCollaborator(key))return;
  if(!_runtime.CanOpenLocalMenu(key))return;
  if(_gestorUpdatePage is null)return;
  var group=Groups.First(g=>g.Key=="helpdesk");
  _section=view=="history"?"history":"updates";
  _lastSection[group.Key]=_section;
  _group=group.Key;
  BuildRibbon(group);
  HybridDashboard.Visibility=Visibility.Collapsed;PageScroll.Visibility=Visibility.Collapsed;PageHost.Content=null;CompactHost.Visibility=Visibility.Visible;CompactHost.Content=_gestorUpdatePage;HeroFrame.Visibility=Visibility.Collapsed;StatusBar.IsOpen=false;
  _gestorUpdatePage.ApplyAreas(AreaColors());_gestorUpdatePage.Navigate(view);ApplyTheme(_themes.Current);_gestorUpdatePage.Publish();FinishPageLoading();
 }
 private async Task<UpdateAvailability> CheckGestorUpdateAsync(){if(!_runtime.CanOpenLocalMenu("updates")||_selectedCollaborator>0)throw new UnauthorizedAccessException("Conecte e autorize o gestor para verificar.");var result=await UpdateCheckService.CheckAsync(_runtime.Platform,CancellationToken.None);SetUpdateBadge(result.Available);NotifyUpdate(result);return result;}
 private async Task StartGestorUpdateAsync(bool force)
 {
  if(!_runtime.CanOpenLocalMenu("updates")||_selectedCollaborator>0)throw new UnauthorizedAccessException("Conecte e autorize o gestor para atualizar.");
  if(force&&!await ConfirmAsync("Reinstalar gestor","Baixar e validar novamente os arquivos publicados? A configuração do computador será preservada.","Reinstalar"))return;
  using var timeout=new CancellationTokenSource(TimeSpan.FromMinutes(50));
  try{var result=await UpdateService.StageAndLaunchAsync(_runtime.Platform,0,force,(_,_)=>{},timeout.Token,_runtime.IsServer);if(result.Launched){await Task.Delay(1000);ExitGestor();}}
  catch(OperationCanceledException){}
  catch(Exception error){RuntimeLog.Write("Central de atualização: "+error.Message);throw;}
 }

 private void NotifyUpdate(UpdateAvailability result){if(result.Available)NotificationCenter.Add("update-available-"+result.Version,"Atualização disponível","Nova versão "+result.Version+" publicada. Abra Helpdesk › Atualizações para instalar.");}
 // Sino de notificações do cabeçalho: lista, contagem de não lidas e limpeza.
 private InfoBadge? _bellBadge;private StackPanel? _bellList;
 private void InitializeBell()
 {
  _bellBadge=new InfoBadge{Visibility=Visibility.Collapsed,HorizontalAlignment=HorizontalAlignment.Right,VerticalAlignment=VerticalAlignment.Top,IsHitTestVisible=false};
  _bellList=new StackPanel{Spacing=6,MinWidth=300,MaxWidth=380};
  var clear=new Button{Content="Limpar tudo",HorizontalAlignment=HorizontalAlignment.Right};clear.Click+=(_,_)=>NotificationCenter.Clear();
  var scroll=new ScrollViewer{MaxHeight=360,Content=_bellList,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
  var panel=new StackPanel{Spacing=8};panel.Children.Add(new TextBlock{Text="Notificações",FontSize=15,FontWeight=Microsoft.UI.Text.FontWeights.SemiBold});panel.Children.Add(scroll);panel.Children.Add(clear);
  var flyout=new Flyout{Content=panel};flyout.Opened+=(_,_)=>{RenderBell();NotificationCenter.MarkAllRead();};
  var icon=new Grid();icon.Children.Add(new FontIcon{Glyph="\uEA8F",FontSize=16});icon.Children.Add(_bellBadge);
  BellButton.Content=icon;BellButton.Flyout=flyout;BellButton.Visibility=_runtime.IsServer?Visibility.Visible:Visibility.Collapsed;
  NotificationCenter.Changed+=()=>DispatcherQueue.TryEnqueue(()=>{RenderBell();RefreshBellBadge();});
  RenderBell();RefreshBellBadge();
 }
 private void RefreshBellBadge(){if(_bellBadge is null)return;var n=NotificationCenter.Unread;_bellBadge.Value=n;_bellBadge.Visibility=n>0?Visibility.Visible:Visibility.Collapsed;}
 private void RenderBell()
 {
  if(_bellList is null)return;_bellList.Children.Clear();var items=NotificationCenter.Items;
  if(items.Count==0){_bellList.Children.Add(new TextBlock{Text="Nenhuma notificação.",Opacity=.7});return;}
  foreach(var item in items)
  {
   var box=new StackPanel{Spacing=2,Padding=new Thickness(8,6,8,6)};
   box.Children.Add(new TextBlock{Text=item.Title,FontWeight=item.Read?Microsoft.UI.Text.FontWeights.Normal:Microsoft.UI.Text.FontWeights.SemiBold});
   box.Children.Add(new TextBlock{Text=item.Message,TextWrapping=TextWrapping.Wrap,FontSize=12,Opacity=.85});
   box.Children.Add(new TextBlock{Text=DateTimeOffset.FromUnixTimeSeconds(item.Time).ToLocalTime().ToString("dd/MM/yyyy HH:mm"),FontSize=10,Opacity=.6});
   _bellList.Children.Add(new Border{Child=box,CornerRadius=new CornerRadius(6),BorderThickness=new Thickness(1),BorderBrush=ThemeService.Brush("#3A4F6A")});
  }
 }
 // Submenus alterados por uma atualização piscam na primeira abertura do menu pai e depois não piscam mais.
 private void BlinkPendingMenus()
 {
  var pending=UpdateChangeLog.Pending();if(pending.Length==0)return;var shown=new List<string>();
  foreach(var key in pending)
  {
   if(!_menus.TryGetValue(key,out var button))continue;shown.Add(key);
   var animation=new DoubleAnimation{From=1,To=.25,Duration=new Duration(TimeSpan.FromMilliseconds(450)),AutoReverse=true,RepeatBehavior=new RepeatBehavior(8)};
   Storyboard.SetTarget(animation,button);Storyboard.SetTargetProperty(animation,"Opacity");
   var board=new Storyboard();board.Children.Add(animation);board.Completed+=(_,_)=>button.Opacity=1;board.Begin();
  }
  if(shown.Count>0)UpdateChangeLog.Clear(shown);
 }
}
