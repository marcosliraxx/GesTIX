// Caminho: gestores/servidor/Arcoll.WinUI3/Services/CloudSyncService.cs
// Sincronização incremental contínua do Gestor Servidor: somente upload, não apaga arquivos remotos.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Arcoll.WinUI3.Services;
public sealed class CloudSyncService : IDisposable
{
    private readonly Func<GestorConfig> _config;
    private readonly Func<bool> _allowed;
    private readonly Action<string>? _log;
    private readonly CancellationTokenSource _stop = new();
    private readonly string _cacheRoot;
    private Task? _worker;
    private readonly Dictionary<string, string> _known = new(StringComparer.OrdinalIgnoreCase);
    private string _scope = "";
    private long _lastRunRequest;
    private DateTime _lastCompleted = DateTime.MinValue;
    private string _lastDaily = "";
    private const int MaxFiles = 100000;
    private const int MaxRecent = 25;
    private readonly List<Dictionary<string, object?>> _recent = new();
    public CloudSyncService(Func<GestorConfig> config, Func<bool> allowed, string cacheRoot, Action<string>? log = null)
    {
        _config = config; _allowed = allowed; _cacheRoot = cacheRoot; _log = log;
    }
    public void Start() => _worker ??= Task.Run(LoopAsync);
    private async Task LoopAsync()
    {
        while (!_stop.IsCancellationRequested)
        {
            try { if (_allowed()) await SyncAsync(_stop.Token); }
            catch (OperationCanceledException) when (_stop.IsCancellationRequested) { break; }
            catch (Exception ex) { _log?.Invoke("Cloud Sync: " + ex.GetType().Name + " · " + ex.Message); }
            try { await Task.Delay(TimeSpan.FromSeconds(30), _stop.Token); }
            catch (OperationCanceledException) { break; }
        }
    }
    private static string Sha(string data) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(data))).ToLowerInvariant();
    private static string Hash(byte[] data) => Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
    private static string Text(JsonElement obj,string key) => obj.ValueKind == JsonValueKind.Object && obj.TryGetProperty(key,out var value)&&value.ValueKind==JsonValueKind.String?value.GetString()??"":"";
    private static int Int(JsonElement obj,string key,int fallback=0) => obj.ValueKind==JsonValueKind.Object&&obj.TryGetProperty(key,out var v)&&v.TryGetInt32(out var result)?result:fallback;
    private static bool Bool(JsonElement obj,string key) => obj.ValueKind==JsonValueKind.Object&&obj.TryGetProperty(key,out var v)&&v.ValueKind==JsonValueKind.True;
    private static string Iso() => DateTimeOffset.Now.ToString("yyyy-MM-dd'T'HH:mm:sszzz");
    private static HttpClient Client(GestorConfig cfg)
    {
        var client = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false }) { Timeout = TimeSpan.FromMinutes(3) };
        PlatformClient.ApplyDefaults(client);
        client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Fingerprint",cfg.Fingerprint);
        client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Site-Code",cfg.SiteCode);
        client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Key",cfg.DownloadKey);
        return client;
    }
    private static async Task<JsonElement> Request(HttpClient client,string origin,string action,object body,CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post,origin.TrimEnd('/')+"/api/cloud.php?action="+Uri.EscapeDataString(action))
            { Content = PlatformClient.JsonBody(body) };
        return await Send(client,request,ct);
    }
    private static async Task<JsonElement> Send(HttpClient client,HttpRequestMessage request,CancellationToken ct)
    {
        using var response = await client.SendAsync(request,ct);
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
        var result = doc.RootElement;
        if (!response.IsSuccessStatusCode || !Bool(result,"ok"))
            throw new IOException("Cloud: " + (Text(result,"error") is var error && error.Length > 0 ? error : "requisição recusada"));
        return result.Clone();
    }
    private void ReadCache(string key)
    {
        if (_scope == key) return;
        _scope = key; _known.Clear(); _recent.Clear();_lastRunRequest=0;_lastCompleted=DateTime.MinValue;_lastDaily="";
        var path = Path.Combine(_cacheRoot,key+".json");
        try
        {
            if (!File.Exists(path)) return;
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            if(doc.RootElement.TryGetProperty("last_run_request",out var req)&&req.TryGetInt64(out var run))_lastRunRequest=run;
            if(doc.RootElement.TryGetProperty("completed_utc",out var completed)&&DateTime.TryParse(completed.GetString(),null,System.Globalization.DateTimeStyles.RoundtripKind,out var timestamp))_lastCompleted=timestamp;
            _lastDaily=Text(doc.RootElement,"daily");
            if (doc.RootElement.TryGetProperty("files",out var data)&&data.ValueKind==JsonValueKind.Object)
                foreach(var item in data.EnumerateObject()) if (item.Value.ValueKind==JsonValueKind.String && _known.Count<MaxFiles)
                    _known[item.Name]=item.Value.GetString()??"";
            if (doc.RootElement.TryGetProperty("recent",out var recent)&&recent.ValueKind==JsonValueKind.Array)
                foreach (var item in recent.EnumerateArray().Take(MaxRecent))
                {
                    var label = Text(item,"name");if(label.Length==0)continue;
                    _recent.Add(new Dictionary<string,object?> { ["name"]=label,["folder"]=Text(item,"folder"),["size"]=Int(item,"size"),["at"]=Text(item,"at") });
                }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { _log?.Invoke("Manifesto Cloud: " + ex.Message); }
    }
    private void SaveCache()
    {
        Directory.CreateDirectory(_cacheRoot);
        var path = Path.Combine(_cacheRoot,_scope+".json");
        var temp = path+".tmp";
        File.WriteAllText(temp,JsonSerializer.Serialize(new { files=_known,recent=_recent,last_run_request=_lastRunRequest,completed_utc=_lastCompleted.ToString("O"),daily=_lastDaily }));
        File.Move(temp,path,true);
    }
    private static bool Unsafe(string path,bool isDir)
    {
        var attrs=File.GetAttributes(path);
        return (attrs&FileAttributes.ReparsePoint)!=0 || (attrs&FileAttributes.System)!=0 || ((attrs&FileAttributes.Offline)!=0&&!isDir);
    }
    private static bool SourceAllowed(string path)
    {
        if (!Regex.IsMatch(path,@"^[a-zA-Z]:\\") || path.Length<4 || path.Contains("..",StringComparison.Ordinal)) return false;
        var root=Path.GetPathRoot(path);
        if (string.IsNullOrEmpty(root) || !new DriveInfo(root).IsReady) return false;
        if (new DriveInfo(root).DriveType is not (DriveType.Fixed or DriveType.Removable)) return false;
        var normalized=Path.GetFullPath(path).TrimEnd('\\');
        if(normalized.Length<=3) return false;
        foreach(var blocked in new[]{Environment.GetFolderPath(Environment.SpecialFolder.Windows),Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital")})
            if(!string.IsNullOrWhiteSpace(blocked)&&(normalized.Equals(blocked,StringComparison.OrdinalIgnoreCase)||normalized.StartsWith(blocked.TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase)))return false;
        for(var cursor=new DirectoryInfo(normalized);cursor is not null;cursor=cursor.Parent)
            if (!cursor.Exists || (cursor.Attributes&FileAttributes.ReparsePoint)!=0) return false;
        return true;
    }
    private static bool Skip(string name,JsonElement settings)
    {
        if (!settings.TryGetProperty("exclusions",out var patterns)||patterns.ValueKind!=JsonValueKind.Array)return false;
        foreach (var entry in patterns.EnumerateArray())
        {
            if(entry.ValueKind!=JsonValueKind.String)continue;
            var pat=entry.GetString()??"";if (pat.Length==0 || pat.Length>200)continue;
            try { if(Regex.IsMatch(name,"^"+Regex.Escape(pat).Replace(@"\*",".*").Replace(@"\?",".")+"$",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant,TimeSpan.FromMilliseconds(100)))return true; }
            catch(RegexMatchTimeoutException) { }
        }
        return false;
    }
    private async Task SyncAsync(CancellationToken ct)
    {
        var cfg=_config();
        if(!Uri.TryCreate(cfg.Origin,UriKind.Absolute,out var uri)||uri.Scheme!=Uri.UriSchemeHttps)return;
        using var client=Client(cfg);
        var state=await Request(client,cfg.Origin,"gestor-state",new{},ct);
        var job=state.GetProperty("job");if(!Bool(job,"available"))return;
        var settings=job.GetProperty("settings");
        if(!settings.TryGetProperty("folders",out var folders)||folders.ValueKind!=JsonValueKind.Array||folders.GetArrayLength()==0)return;
        var revision=Text(job,"revision");if(revision.Length!=64)return;
        var scope=Sha(cfg.Origin+"|"+cfg.Fingerprint+"|"+revision);
        ReadCache(scope);
        var request=job.TryGetProperty("run_request",out var runValue)&&runValue.TryGetInt64(out var runNumber)?runNumber:0;
        var manual=request>_lastRunRequest;
        var schedule=Text(settings,"schedule");
        var daily=Text(settings,"daily_time");
        var today=DateTime.Now.ToString("yyyy-MM-dd");
        if(!manual)
        {
            if(schedule=="manual")return;
            if(schedule=="interval"&&DateTime.UtcNow-_lastCompleted<TimeSpan.FromMinutes(Int(settings,"interval_minutes",60)))return;
            if(schedule=="daily"&&(_lastDaily==today||!TimeSpan.TryParse(daily,out var due)||DateTime.Now.TimeOfDay<due))return;
        }
        await Request(client,cfg.Origin,"gestor-state",new{status=new{state="scanning",message="Verificando pastas locais...",last_run_at=Iso()}},ct);
        var maxSize=state.GetProperty("max_file_bytes").GetInt64();
        var maxFileMb=Int(settings,"max_file_mb",2048);
        maxSize=Math.Min(maxSize,(long)maxFileMb*1048576L);
        var folderStats=new List<Dictionary<string,object?>>();
        var failures=new List<Dictionary<string,string>>();
        var filesScanned=0;var changed=0;var totalBytes=0L;var unchanged=0;
        var now=Iso();var lastProgress=DateTime.UtcNow;
        for(var i=0;i<folders.GetArrayLength();i++)
        {
            ct.ThrowIfCancellationRequested();
            var folder=folders[i];var root=Environment.ExpandEnvironmentVariables(Text(folder,"path"));var label=Text(folder,"label");
            var folderFiles=0;var folderBytes=0L;var unavailable=false;
            try
            {
                if(!SourceAllowed(root))throw new UnauthorizedAccessException("Caminho local inválido, protegido ou indisponível.");
                var stack=new Stack<string>();stack.Push(Path.GetFullPath(root));
                while(stack.Count>0&&filesScanned<MaxFiles)
                {
                    ct.ThrowIfCancellationRequested();
                    var directory=stack.Pop();if(Unsafe(directory,true))continue;
                    foreach(var item in Directory.EnumerateFileSystemEntries(directory))
                    {
                        ct.ThrowIfCancellationRequested();
                        var relative=Path.GetRelativePath(root,item).Replace('\\','/');
                        if(Skip(Path.GetFileName(item),settings)||Skip(relative,settings))continue;
                        try
                        {
                            var isDir=Directory.Exists(item);
                            if(Unsafe(item,isDir))continue;
                            if(isDir){stack.Push(item);continue;}
                            if(!File.Exists(item))continue;
                            if(filesScanned>=MaxFiles)throw new IOException("Limite de 100.000 arquivos por execução atingido. Divida as pastas configuradas.");
                            var file=new FileInfo(item);if(file.Length>maxSize||file.Length<0)continue;
                            // File opened with share ReadWrite: scan only settled timestamps and recheck before upload.
                            if(DateTime.UtcNow-file.LastWriteTimeUtc<TimeSpan.FromSeconds(2))continue;
                            var version=file.Length+":"+file.LastWriteTimeUtc.Ticks;
                            var key=i+"|"+relative;
                            folderFiles++;folderBytes+=file.Length;filesScanned++;
                            if(_known.TryGetValue(key,out var saved)&&saved==version){unchanged++;continue;}
                            if(DateTime.UtcNow-lastProgress>TimeSpan.FromSeconds(15))
                            {
                                lastProgress=DateTime.UtcNow;
                                await Request(client,cfg.Origin,"gestor-state",new{status=new{state="uploading",message="Sincronizando arquivos...",files_done=changed,bytes_done=totalBytes,last_run_at=now}},ct);
                            }
                            await Upload(client,cfg.Origin,item,i,relative,file,revision,maxSize,Int(settings,"bandwidth_kbps"),ct);
                            _known[key]=version;changed++;totalBytes+=file.Length;
                            _recent.Insert(0,new Dictionary<string,object?>{["name"]=file.Name,["folder"]=label,["size"]=file.Length,["at"]=Iso()});
                            if(_recent.Count>MaxRecent)_recent.RemoveAt(_recent.Count-1);
                            SaveCache();
                        }
                        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException)
                        {
                            if(failures.Count<12)failures.Add(new(){["path"]=relative,["message"]=ex.Message[..Math.Min(150,ex.Message.Length)]});
                        }
                    }
                }
            }
            catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or ArgumentException)
            {
                unavailable=true;
                if(failures.Count<12)failures.Add(new(){["path"]=label,["message"]=ex.Message[..Math.Min(150,ex.Message.Length)]});
            }
            folderStats.Add(new(){["label"]=label,["files"]=folderFiles,["bytes"]=folderBytes,["missing"]=unavailable,["pending"]=0});
        }
        var report=new Dictionary<string,object?>
        {
            ["state"]=failures.Count>0?"error":"idle",["message"]=failures.Count>0?"Sincronização com pendências.":"Pastas sincronizadas; arquivos preservados na nuvem.",
            ["last_run_at"]=Iso(),["last_success_at"]=failures.Count==0?Iso():null,["synced_files"]=filesScanned,
            ["files_done"]=changed,["bytes_done"]=totalBytes,["files_total"]=filesScanned,["errors"]=failures.Count,
            ["folders"]=folderStats,["recent_files"]=_recent,["failures"]=failures,
            ["runs"]=new[]{new{at=now,files=changed,bytes=totalBytes,result=failures.Count>0?"partial":"success"}}
        };
        await Request(client,cfg.Origin,"gestor-state",new{status=report},ct);
        if(failures.Count==0){_lastRunRequest=request;_lastCompleted=DateTime.UtcNow;_lastDaily=today;SaveCache();}
    }
    private static async Task Upload(HttpClient client,string origin,string path,int index,string relative,FileInfo info,string revision,long maxBytes,int bandwidthKbps,CancellationToken ct)
    {
        if(info.Length>maxBytes)throw new IOException("Arquivo acima do limite da nuvem.");
        var originalLength=info.Length;var modified=info.LastWriteTimeUtc;
        var token=Sha(originalLength+":"+((modified.Ticks-DateTime.UnixEpoch.Ticks)/10));
        var version=Sha(token+":0");
        var start=await Request(client,origin,"gestor-begin",new{folder=index,relative,size=originalLength,
            mtime=new DateTimeOffset(modified,TimeSpan.Zero).ToUnixTimeSeconds(),file_version=version,revision},ct);
        if(Bool(start,"done"))return;
        if(originalLength==0)throw new IOException("O provedor não concluiu o arquivo vazio.");
        var upload=Text(start,"upload_id");var chunk=Int(start,"chunk");
        if(!Regex.IsMatch(upload,"^[a-f0-9]{32}$")||chunk<1||chunk>5242880)throw new IOException("Sessão de envio inválida.");
        long offset=start.GetProperty("next_offset").GetInt64();
        using var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read,81920,FileOptions.Asynchronous|FileOptions.SequentialScan);
        if(stream.Length!=originalLength||File.GetLastWriteTimeUtc(path)!=modified)throw new IOException("Arquivo modificado antes do envio.");
        var buffer=new byte[chunk];var loops=0;
        var throttle=System.Diagnostics.Stopwatch.StartNew();var initialOffset=offset;
        while(offset<originalLength)
        {
            ct.ThrowIfCancellationRequested();
            if(File.GetLastWriteTimeUtc(path)!=modified||stream.Length!=originalLength)throw new IOException("Arquivo modificado durante o envio.");
            stream.Position=offset;var length=(int)Math.Min(chunk,originalLength-offset);
            var read=0;
            while(read<length)
            {
                var count=await stream.ReadAsync(buffer.AsMemory(read,length-read),ct);
                if(count==0)throw new IOException("Leitura parcial do arquivo.");
                read+=count;
            }
            var segment=buffer.AsSpan(0,length).ToArray();
            using var request=new HttpRequestMessage(HttpMethod.Post,origin.TrimEnd('/')+"/api/cloud.php?action=gestor-chunk")
            { Content=new ByteArrayContent(segment) };
            request.Content.Headers.ContentType=new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
            request.Headers.TryAddWithoutValidation("X-Arcoll-Upload",upload);
            request.Headers.TryAddWithoutValidation("X-Arcoll-Revision",revision);
            request.Headers.TryAddWithoutValidation("X-Arcoll-Offset",offset.ToString(System.Globalization.CultureInfo.InvariantCulture));
            request.Headers.TryAddWithoutValidation("X-Arcoll-Sha256",Hash(segment));
            var answer=await Send(client,request,ct);
            var next=answer.GetProperty("next_offset").GetInt64();
            if(next<=offset||next>originalLength||++loops>100000)throw new IOException("O provedor não confirmou o progresso.");
            offset=next;
            if(bandwidthKbps>0)
            {
                var expected=TimeSpan.FromSeconds((offset-initialOffset)/(bandwidthKbps*1024d));
                var delay=expected-throttle.Elapsed;
                while(delay>TimeSpan.Zero){await Task.Delay(delay>TimeSpan.FromSeconds(1)?TimeSpan.FromSeconds(1):delay,ct);delay=expected-throttle.Elapsed;}
            }
            if(Bool(answer,"done"))break;
        }
        if(offset!=originalLength||File.GetLastWriteTimeUtc(path)!=modified)throw new IOException("Upload incompleto ou arquivo alterado.");
    }
    public void Dispose() => _stop.Cancel();
}
