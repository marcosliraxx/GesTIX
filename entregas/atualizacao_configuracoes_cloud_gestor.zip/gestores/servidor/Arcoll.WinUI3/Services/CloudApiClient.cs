using System.Net.Http;
using System.Text.Json;
namespace Arcoll.WinUI3.Services;
/// <summary>Cloud usa a identidade autenticada da própria instalação; credenciais do provedor nunca chegam ao gestor.</summary>
public static class CloudApiClient
{
 public static async Task<JsonElement> PostAsync(GestorConfig config,string action,object payload,CancellationToken ct=default)
 {
  if(!Uri.TryCreate(config.Origin,UriKind.Absolute,out var origin)||origin.Scheme!=Uri.UriSchemeHttps)throw new InvalidOperationException("Servidor HTTPS não configurado.");
  using var client=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false,UseProxy=false}){Timeout=TimeSpan.FromSeconds(45)};
  PlatformClient.ApplyDefaults(client);
  client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Fingerprint",config.Fingerprint);
  client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Site-Code",config.SiteCode);
  client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Key",config.DownloadKey);
  using var request=new HttpRequestMessage(HttpMethod.Post,config.Origin.TrimEnd('/')+"/api/cloud.php?action="+Uri.EscapeDataString(action)){Content=PlatformClient.JsonBody(payload)};
  using var response=await client.SendAsync(request,ct);
  using var doc=JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
  var result=doc.RootElement;
  if(!response.IsSuccessStatusCode||!result.TryGetProperty("ok",out var ok)||ok.ValueKind!=JsonValueKind.True)
   throw new InvalidOperationException(result.TryGetProperty("error",out var error)?error.GetString():"Falha ao consultar o Cloud.");
  return result.Clone();
 }
}
