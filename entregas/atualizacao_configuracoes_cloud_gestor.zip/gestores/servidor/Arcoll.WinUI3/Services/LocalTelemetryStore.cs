// Histórico detalhado local; não armazena credenciais nem respostas de terminal.
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace Arcoll.WinUI3.Services;
public static class LocalTelemetryStore
{
 private static readonly object Gate=new();
 public static int RetentionDays {get;set;}=30;
 public static bool Hybrid {get;set;}=true;
 private static readonly HashSet<string> Types=new(){"server_metrics","telemetry","dashboard","speed_test","network_scan","device_event"};
 private static DateTime _lastCleanup=DateTime.MinValue;
 public static void Append(GestorConfig config,Dictionary<string,object?> data)
 {
  if(!Hybrid||!data.TryGetValue("event",out var kind)||!Types.Contains(kind?.ToString()??""))return;
  try
  {
   lock(Gate)
   {
    var scope=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(config.Origin+"|"+config.SiteCode+"|"+config.Fingerprint)))[..24];
    var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"TI-Digital","History",scope);
    Directory.CreateDirectory(dir);
    var prefix=DateTime.UtcNow.ToString("yyyyMMdd");var path=Path.Combine(dir,prefix+"-00.jsonl");
    for(var i=0;File.Exists(path)&&new FileInfo(path).Length>=8*1024*1024;i++)path=Path.Combine(dir,prefix+"-"+(i+1).ToString("D4")+".jsonl");
    var json=JsonSerializer.Serialize(data);if(Encoding.UTF8.GetByteCount(json)>210000)return;
    File.AppendAllText(path,json+"\n",new UTF8Encoding(false));
    if(DateTime.UtcNow-_lastCleanup>TimeSpan.FromMinutes(5))
    {
     _lastCleanup=DateTime.UtcNow;
     var files=new DirectoryInfo(dir).GetFiles("*.jsonl").OrderBy(f=>f.LastWriteTimeUtc).ToArray();
     long total=files.Sum(f=>f.Length);
     foreach(var file in files)
      if(file.FullName!=path&&(file.LastWriteTimeUtc<DateTime.UtcNow.AddDays(-RetentionDays)||total>256L*1024*1024))
      {var length=file.Length;file.Delete();total-=length;}
    }
   }
  }
  catch(Exception error)when(error is IOException or UnauthorizedAccessException or JsonException){RuntimeLog.Write("Histórico local: "+error.Message);}
 }
}
