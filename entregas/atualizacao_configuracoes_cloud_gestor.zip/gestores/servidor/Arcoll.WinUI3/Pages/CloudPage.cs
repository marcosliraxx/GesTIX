// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/CloudPage.cs
// Explorador Cloud nativo: usa a autenticação do gestor e mantém sincronização em segundo plano existente.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI;
using Windows.Storage.Pickers;

namespace Arcoll.WinUI3.Pages;
public sealed class CloudPage : UserControl, IPageDataSource
{
    readonly GestorRuntime _runtime;
    readonly MainWindow _window;
    readonly StackPanel _rows = new(){Spacing=5};
    readonly StackPanel _trail = new(){Orientation=Orientation.Horizontal,Spacing=5};
    readonly TextBlock _status = new(){Text="Conectando à nuvem...",TextWrapping=TextWrapping.Wrap};
    readonly Button _upload = new(){Content="Importar arquivos"};
    readonly Button _mkdir = new(){Content="Nova pasta"};
    readonly Button _refresh = new(){Content="Atualizar"};
    string _path="";
    bool _loading;
    public PageDataLoad DataLoad {get;} = new("Consultando arquivos do Cloud",true);
    public CloudPage(GestorRuntime runtime,MainWindow window)
    {
        _runtime=runtime;_window=window;
        var root=new Grid{RowSpacing=0};
        root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        root.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
        root.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        var header=new StackPanel{Orientation=Orientation.Horizontal,Spacing=8,Margin=new Thickness(18,15,18,13)};
        header.Children.Add(new TextBlock{Text="Meu Cloud",FontSize=19,FontWeight=Microsoft.UI.Text.FontWeights.SemiBold,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,15,0)});
        header.Children.Add(_upload);header.Children.Add(_mkdir);header.Children.Add(_refresh);root.Children.Add(header);
        _upload.Click+=async(_,_)=>await ImportAsync();
        _mkdir.Click+=async(_,_)=>await CreateFolderAsync();
        _refresh.Click+=async(_,_)=>await RefreshAsync();
        var breadcrumb=new ScrollViewer{HorizontalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollMode=ScrollMode.Enabled,VerticalScrollBarVisibility=ScrollBarVisibility.Disabled,Content=_trail,Margin=new Thickness(20,0,20,10)};
        Grid.SetRow(breadcrumb,1);root.Children.Add(breadcrumb);
        var listScroll=new ScrollViewer{Content=_rows,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Padding=new Thickness(15,4,15,8)};
        Grid.SetRow(listScroll,2);root.Children.Add(listScroll);
        _status.Margin=new Thickness(20,10,20,12);Grid.SetRow(_status,3);root.Children.Add(_status);
        Content=root;Loaded+=async(_,_)=>await RefreshAsync();
    }
    public void Navigate(string section){if(IsLoaded)_=RefreshAsync();}
    public void ApplyPalette(Palette palette){}
    public Task CollectDataAsync()=>RefreshAsync();
    HttpClient Http(){var c=_runtime.Platform.Config;var h=new HttpClientHandler{AllowAutoRedirect=false,UseProxy=false};var client=new HttpClient(h){Timeout=TimeSpan.FromMinutes(3)};PlatformClient.ApplyDefaults(client);client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Fingerprint",c.Fingerprint);client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Site-Code",c.SiteCode);client.DefaultRequestHeaders.TryAddWithoutValidation("X-Arcoll-Key",c.DownloadKey);return client;}
    string Endpoint(string api,string action)=>_runtime.Platform.Config.Origin.TrimEnd('/')+"/api/"+api+"?action="+Uri.EscapeDataString(action);
    async Task<JsonElement> RequestAsync(string action,object body,CancellationToken ct=default)
    {
        using var client=Http();using var request=new HttpRequestMessage(HttpMethod.Post,Endpoint("cloud.php",action));
        request.Content=PlatformClient.JsonBody(body);
        using var response=await client.SendAsync(request,ct);var raw=await response.Content.ReadAsStringAsync(ct);
        using var doc=JsonDocument.Parse(raw);var root=doc.RootElement;
        if(!response.IsSuccessStatusCode || !root.TryGetProperty("ok",out var ok)||ok.ValueKind!=JsonValueKind.True)
            throw new IOException(root.TryGetProperty("error",out var error)?error.GetString():"Falha na comunicação com o Cloud.");
        return root.Clone();
    }
    static string Str(JsonElement v,string key)=>v.TryGetProperty(key,out var x)&&x.ValueKind==JsonValueKind.String?x.GetString()??"":"";
    static bool Dir(JsonElement v)=>v.TryGetProperty("directory",out var x)&&x.ValueKind==JsonValueKind.True;
    void Breadcrumb()
    {
        _trail.Children.Clear();var parts=_path.Length==0?Array.Empty<string>():_path.Split('/');
        for(int i=0;i<=parts.Length;i++){
            var n=i==0?"Meu Cloud":parts[i-1];var target=string.Join('/',parts.Take(i));
            var button=new Button{Content=n,Padding=new Thickness(9,3,9,3)};
            button.Click+=async(_,_)=>{_path=target;await RefreshAsync();};_trail.Children.Add(button);
        }
    }
    public async Task RefreshAsync()
    {
        if(_loading||!_runtime.Can("backup"))return;
        _loading=true;_status.Text="Consultando pastas e arquivos sincronizados...";DataLoad.Begin("Carregando Cloud");
        try{
            Breadcrumb();_rows.Children.Clear();
            var count=0;string page="";
            do{
                var result=await RequestAsync("gestor-cloud-list",new{path=_path,page});var browser=result.GetProperty("browser");
                if(browser.TryGetProperty("entries",out var entries)&&entries.ValueKind==JsonValueKind.Array){
                    foreach(var entry in entries.EnumerateArray()){
                        count++;var name=Str(entry,"name");var label=Str(entry,"display");if(string.IsNullOrWhiteSpace(label))label=name;
                        var folder=Dir(entry);var item=new Grid{ColumnSpacing=10,Padding=new Thickness(6)};
                        item.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
                        item.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
                        var button=new Button{Content=(folder?"📁  ":"📄  ")+label,HorizontalAlignment=HorizontalAlignment.Stretch,HorizontalContentAlignment=HorizontalAlignment.Left};
                        button.Click+=async(_,_)=>{if(folder){_path=string.IsNullOrEmpty(_path)?name:_path+"/"+name;await RefreshAsync();}else await DownloadAsync(name);};
                        item.Children.Add(button);
                        var dl=new Button{Content=folder?"Baixar ZIP":"Baixar"};Grid.SetColumn(dl,1);dl.Click+=async(_,_)=>{if(folder)await DownloadFolderAsync(name);else await DownloadAsync(name);};item.Children.Add(dl);
                        _rows.Children.Add(item);
                    }
                }
                page=Str(browser,"next");
            }while(page.Length>0&&count<1000);
            if(count==0)_rows.Children.Add(new TextBlock{Text="Nenhum arquivo nesta pasta. Importe arquivos ou crie uma pasta.",Margin=new Thickness(12)});
            _status.Text=count+" item(ns) no Cloud";DataLoad.Complete();
        }catch(Exception ex){_rows.Children.Clear();_status.Text="Cloud indisponível: "+ex.Message;DataLoad.Fail(ex.Message);}finally{_loading=false;}
    }
    async Task CreateFolderAsync()
    {
        var input=new TextBox{PlaceholderText="Nome da pasta",MaxLength=120};
        var dialog=new ContentDialog{Title="Nova pasta no Cloud",Content=input,PrimaryButtonText="Criar",CloseButtonText="Cancelar",XamlRoot=XamlRoot};
        if(await dialog.ShowAsync()!=ContentDialogResult.Primary)return;
        var name=input.Text.Trim();if(name.Length==0)return;
        try{await MutateAsync("mkdir",name,null);await RefreshAsync();}
        catch(Exception ex){_status.Text="Não foi possível criar pasta: "+ex.Message;}
    }
    async Task ImportAsync()
    {
        try{
            var picker=new FileOpenPicker();picker.FileTypeFilter.Add("*");
            WinRT.Interop.InitializeWithWindow.Initialize(picker,WinRT.Interop.WindowNative.GetWindowHandle(_window));
            var chosen=await picker.PickMultipleFilesAsync();if(chosen is null||chosen.Count==0)return;
            var done=0;
            foreach(var file in chosen){_status.Text="Importando "+file.Name+"...";
                var path=file.Path;if(string.IsNullOrEmpty(path))throw new IOException("Arquivo inacessível: "+file.Name);
                using var stream=File.OpenRead(path);await MutateAsync("upload",file.Name,stream);done++;
            }
            await RefreshAsync();_status.Text=done+" arquivo(s) importado(s)";
        }catch(Exception ex){_status.Text="Falha na importação: "+ex.Message;}
    }
    async Task MutateAsync(string action,string name,Stream? file)
    {
        using var client=Http();using var form=new MultipartFormDataContent();
        form.Add(new StringContent(action),"action");form.Add(new StringContent(_path),"path");
        if(action=="mkdir")form.Add(new StringContent(name),"name");
        else if(file is not null){var content=new StreamContent(file);form.Add(content,"file",name);}
        using var result=await client.PostAsync(Endpoint("cloud-files.php",""),form);
        var raw=await result.Content.ReadAsStringAsync();using var doc=JsonDocument.Parse(raw);
        if(!result.IsSuccessStatusCode||!doc.RootElement.TryGetProperty("ok",out var ok)||ok.ValueKind!=JsonValueKind.True)
            throw new IOException(doc.RootElement.TryGetProperty("error",out var err)?err.GetString():"Operação não autorizada.");
    }
    async Task DownloadAsync(string name)
    {
        var relative=string.IsNullOrEmpty(_path)?name:_path+"/"+name;
        try{
            _status.Text="Baixando "+name+"...";
            using var client=Http();using var request=new HttpRequestMessage(HttpMethod.Post,Endpoint("cloud.php","gestor-cloud-download"));
            request.Content=PlatformClient.JsonBody(new{path=relative});
            using var response=await client.SendAsync(request,HttpCompletionOption.ResponseHeadersRead);
            if(!response.IsSuccessStatusCode)throw new IOException("Arquivo indisponível (HTTP "+(int)response.StatusCode+").");
            var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"Cloud Downloads");Directory.CreateDirectory(dir);
            var safe=Path.GetFileName(name);if(string.IsNullOrWhiteSpace(safe))throw new IOException("Nome de arquivo inválido.");
            var dest=Path.Combine(dir,safe);if(File.Exists(dest))dest=Path.Combine(dir,Path.GetFileNameWithoutExtension(safe)+"_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+Path.GetExtension(safe));
            await using var remote=await response.Content.ReadAsStreamAsync();await using var output=File.Create(dest);await remote.CopyToAsync(output);
            _status.Text="Baixado em "+dest;
        }catch(Exception ex){_status.Text="Download não concluído: "+ex.Message;}
    }
    async Task DownloadFolderAsync(string name)
    {
        var basePath=string.IsNullOrEmpty(_path)?name:_path+"/"+name;
        var root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"Cloud Downloads");
        Directory.CreateDirectory(root);
        var zipPath=Path.Combine(root,Path.GetFileName(name)+"_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".zip");
        var count=0;long total=0;
        try{
            using(var zip=ZipFile.Open(zipPath,ZipArchiveMode.Create)){
                var queue=new Queue<(string remote,string local)>();queue.Enqueue((basePath,""));
                while(queue.Count>0){if(queue.Count>80)throw new IOException("Pasta grande demais para download único.");var (remote,local)=queue.Dequeue();string page="";
                    do{
                        var d=await RequestAsync("gestor-cloud-list",new{path=remote,page});var browser=d.GetProperty("browser");
                        foreach(var entry in browser.GetProperty("entries").EnumerateArray()){
                            var itemName=Str(entry,"name");if(itemName.Contains('/')||itemName.Contains('\\')||itemName=="."||itemName=="..")continue;
                            var itemPath=remote+"/"+itemName;var archivePath=local+itemName;
                            if(Dir(entry)){zip.CreateEntry(archivePath+"/");queue.Enqueue((itemPath,archivePath+"/"));continue;}
                            if(++count>120)throw new IOException("Limite de 120 arquivos por download de pasta.");
                            if(entry.TryGetProperty("size",out var len)&&len.TryGetInt64(out var size)){total+=size;if(total>120L*1048576)throw new IOException("Limite de 120 MB por download de pasta.");}
                            _status.Text="Baixando "+count+" arquivo(s)...";
                            using var client=Http();using var req=new HttpRequestMessage(HttpMethod.Post,Endpoint("cloud.php","gestor-cloud-download"));
                            req.Content=PlatformClient.JsonBody(new{path=itemPath});
                            using var response=await client.SendAsync(req,HttpCompletionOption.ResponseHeadersRead);
                            if(!response.IsSuccessStatusCode)throw new IOException("Download de "+itemName+" não autorizado.");
                            await using var input=await response.Content.ReadAsStreamAsync();await using var dest=zip.CreateEntry(archivePath).Open();
                            await input.CopyToAsync(dest);
                        }
                        page=Str(browser,"next");
                    }while(page.Length>0);
                }
            }
            _status.Text="Pasta baixada: "+zipPath;
        }catch(Exception ex){try{File.Delete(zipPath);}catch{} _status.Text="Erro ao baixar pasta: "+ex.Message;}
    }

}
