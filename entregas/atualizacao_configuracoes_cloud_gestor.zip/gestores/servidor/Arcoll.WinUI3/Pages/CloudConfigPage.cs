// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/CloudConfigPage.cs
// Configuração nativa de sincronização do Gestor Servidor, sem WebView ou página externa.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Arcoll.WinUI3.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.Storage.Pickers;

namespace Arcoll.WinUI3.Pages;
public sealed class CloudConfigPage : UserControl, IPageDataSource
{
    private readonly GestorRuntime _runtime;
    private readonly MainWindow _window;
    private readonly StackPanel _folders = new() { Spacing = 7 };
    private readonly ComboBox _destinations = new() { PlaceholderText = "Escolha o armazenamento", MinWidth = 220 };
    private readonly ToggleSwitch _enabled = new() { Header = "Sincronização automática", IsOn = true };
    private readonly TextBlock _status = new() { Text = "Consultando configurações...", TextWrapping = TextWrapping.Wrap };
    private readonly Button _save = new() { Content = "Salvar configuração" };
    private readonly Button _add = new() { Content = "Escolher pasta no Windows" };
    private readonly ComboBox _schedule=new(){Header="Programação",ItemsSource=new[]{"continuous","interval","daily","manual"},SelectedIndex=0};
    private readonly NumberBox _interval=new(){Header="Intervalo (minutos)",Minimum=5,Maximum=10080,Value=60};
    private readonly TextBox _daily=new(){Header="Horário diário (HH:mm, hora local)",Text="02:00",MaxLength=5};
    private readonly NumberBox _bandwidth=new(){Header="Limite de envio (KB/s, 0 = ilimitado)",Minimum=0,Maximum=1048576,Value=0};
    private readonly NumberBox _maxMb=new(){Header="Tamanho máximo por arquivo (MB)",Minimum=1,Maximum=51200,Value=2048};
    private readonly TextBox _exclusions=new(){Header="Arquivos ignorados (um padrão por linha)",AcceptsReturn=true,Height=100,MaxLength=4000};
    private readonly ToggleSwitch _vdrive=new(){Header="Unidade virtual no Windows (somente leitura)"};
    private readonly ComboBox _letter=new(){Header="Letra da unidade",ItemsSource=new[]{"AUTO"}.Concat(Enumerable.Range('D',23).Select(n=>((char)n).ToString())).ToArray(),SelectedIndex=0};
    private readonly List<FolderItem> _selected = new();
    private JsonElement _settings;
    private bool _busy;
    public PageDataLoad DataLoad { get; } = new("Configuração Cloud", true);
    private sealed record FolderItem(string path, string label);
    private sealed record Destination(int Id, string Name)
    {
        public override string ToString() => Name;
    }
    public CloudConfigPage(GestorRuntime runtime, MainWindow window)
    {
        _runtime = runtime;
        _window = window;
        var root = new Grid { RowSpacing = 0 };
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var form = new StackPanel { Spacing = 14, Margin = new Thickness(19, 14, 19, 20) };
        form.Children.Add(new TextBlock { Text = "Cloud Config", FontSize = 21, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        form.Children.Add(new TextBlock { Text = "Defina as pastas do Gestor Servidor e o destino de backup. As configurações são verificadas a cada 30 segundos; os envios seguem a programação escolhida com o gestor conectado.", TextWrapping = TextWrapping.Wrap });
        form.Children.Add(new TextBlock { Text = "Pastas sincronizadas", FontSize = 15, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        form.Children.Add(_folders);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        buttons.Children.Add(_add);
        var manual = new Button { Content = "Adicionar caminho" };
        buttons.Children.Add(manual);form.Children.Add(buttons);
        form.Children.Add(new TextBlock { Text = "Destino da nuvem", FontSize = 15, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        form.Children.Add(_destinations);
        form.Children.Add(new TextBlock { Text = "O Drive da plataforma e as contas já vinculadas aparecem aqui. A autorização inicial de uma conta Google é realizada pelo proprietário na configuração Cloud da plataforma.", TextWrapping = TextWrapping.Wrap, Opacity = .8 });
        form.Children.Add(_enabled);
        form.Children.Add(new TextBlock{Text="Programação: continuous = contínua, interval = intervalo, daily = diária, manual = sob solicitação",TextWrapping=TextWrapping.Wrap});
        foreach(var control in new UIElement[]{_schedule,_interval,_daily,_bandwidth,_maxMb,_exclusions,_vdrive,_letter})form.Children.Add(control);
        form.Children.Add(new TextBlock { Text = "Sincronização incremental: arquivos locais excluídos continuam preservados na nuvem.", TextWrapping = TextWrapping.Wrap, Opacity = .8 });
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actions.Children.Add(_save);
        var refresh = new Button { Content = "Atualizar" };
        actions.Children.Add(refresh);
        var run=new Button{Content="Sincronizar agora"};actions.Children.Add(run);
        run.Click+=async(_,_)=>{try{await CallAsync("gestor-config-run",new{});_status.Text="Sincronização solicitada. Aguarde a próxima consulta do sincronizador.";}catch(Exception error){_status.Text=error.Message;}};
        form.Children.Add(actions);form.Children.Add(_status);
        root.Children.Add(new ScrollViewer { Content = form, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
        Content = root;
        Loaded += async (_, _) => await RefreshAsync();
        _add.Click += async (_, _) => await PickFolderAsync();
        manual.Click += async (_, _) => await AddManualAsync();
        _save.Click += async (_, _) => await SaveAsync();
        refresh.Click += async (_, _) => await RefreshAsync();
    }
    public void Navigate(string section) { if (IsLoaded) _ = RefreshAsync(); }
    public void ApplyPalette(Palette palette) { }
    public Task CollectDataAsync() => RefreshAsync();
    private Task<JsonElement> CallAsync(string action, object payload)=>CloudApiClient.PostAsync(_runtime.Platform.Config,action,payload);
    private static string Get(JsonElement obj, string key) => obj.ValueKind == JsonValueKind.Object && obj.TryGetProperty(key, out var value) && value.ValueKind == JsonValueKind.String ? value.GetString() ?? "" : "";
    private void RenderFolders()
    {
        _folders.Children.Clear();
        if (_selected.Count == 0) _folders.Children.Add(new TextBlock { Text = "Nenhuma pasta local selecionada.", Opacity = .7 });
        foreach (var folder in _selected.ToArray())
        {
            var row = new Grid { ColumnSpacing = 10, Padding = new Thickness(9) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.Children.Add(new TextBlock { Text = "📁  " + folder.label + "\n" + folder.path, TextWrapping = TextWrapping.Wrap, FontSize = 12 });
            var remove = new Button { Content = "Remover" };
            remove.Click += (_, _) => { _selected.Remove(folder); RenderFolders(); };
            Grid.SetColumn(remove, 1); row.Children.Add(remove);
            _folders.Children.Add(row);
        }
    }
    private void AddFolder(string path)
    {
        path = path.Trim();
        if (path.Length == 0 || _selected.Any(f => string.Equals(f.path.TrimEnd('\\'), path.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))) return;
        var label = System.IO.Path.GetFileName(path.TrimEnd('\\'));
        _selected.Add(new FolderItem(path, string.IsNullOrWhiteSpace(label) ? path : label));
        RenderFolders();
    }
    private async Task PickFolderAsync()
    {
        if (!_runtime.IsServer) { _status.Text = "Somente o Gestor Servidor pode sincronizar pastas."; return; }
        try
        {
            var picker = new FolderPicker(); picker.FileTypeFilter.Add("*");
            WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(_window));
            var folder = await picker.PickSingleFolderAsync();
            if (folder is not null) AddFolder(folder.Path);
        }
        catch (Exception ex) { _status.Text = "Não foi possível abrir o seletor: " + ex.Message; }
    }
    private async Task AddManualAsync()
    {
        var input = new TextBox { PlaceholderText = @"C:\Dados", MaxLength = 260 };
        var dialog = new ContentDialog { Title = "Adicionar pasta local", Content = input, PrimaryButtonText = "Adicionar", CloseButtonText = "Cancelar", XamlRoot = XamlRoot };
        if (await dialog.ShowAsync() == ContentDialogResult.Primary) AddFolder(input.Text);
    }
    private async Task RefreshAsync()
    {
        if (_busy) return;
        if (!_runtime.IsServer) { _status.Text = "Backup Cloud disponível somente no Gestor Servidor."; _save.IsEnabled = false; _add.IsEnabled = false; return; }
        _busy = true; DataLoad.Begin("Consultando Cloud"); _status.Text = "Consultando armazenamento conectado...";
        try
        {
            var result = await CallAsync("gestor-config-state", new { });
            var job = result.GetProperty("job");
            _settings = job.GetProperty("settings").Clone();
            _enabled.IsOn = job.GetProperty("enabled").GetBoolean();
            var policy=result.GetProperty("policy");
            double Number(string name,double fallback)=>_settings.TryGetProperty(name,out var n)&&n.TryGetDouble(out var value)?value:fallback;
            _schedule.SelectedItem=Get(_settings,"schedule");_interval.Value=Number("interval_minutes",60);_daily.Text=Get(_settings,"daily_time");
            _bandwidth.Value=Number("bandwidth_kbps",0);_maxMb.Maximum=policy.GetProperty("max_file_mb").GetDouble();_maxMb.Value=Math.Min(_maxMb.Maximum,Number("max_file_mb",2048));
            _interval.Minimum=policy.GetProperty("min_interval").GetDouble();
            _exclusions.Text=_settings.TryGetProperty("exclusions",out var patterns)&&patterns.ValueKind==JsonValueKind.Array?string.Join("\n",patterns.EnumerateArray().Select(v=>v.GetString())):"";
            _vdrive.IsEnabled=policy.GetProperty("vdrive").GetBoolean();_vdrive.IsOn=_vdrive.IsEnabled&&_settings.TryGetProperty("vdrive",out var drive)&&drive.ValueKind==JsonValueKind.True;
            _letter.SelectedItem=Get(_settings,"vdrive_letter");
            _selected.Clear();
            if (_settings.TryGetProperty("folders", out var folders) && folders.ValueKind == JsonValueKind.Array)
                foreach (var item in folders.EnumerateArray())
                {
                    var path = item.ValueKind == JsonValueKind.String ? item.GetString() ?? "" : Get(item, "path");
                    if (!string.IsNullOrWhiteSpace(path)) _selected.Add(new FolderItem(path, Get(item, "label")));
                }
            RenderFolders();_destinations.Items.Clear();
            var selected = job.TryGetProperty("connection_id", out var existing) && existing.ValueKind == JsonValueKind.Number ? existing.GetInt32() : 0;
            if (result.TryGetProperty("connections", out var connections) && connections.ValueKind == JsonValueKind.Array)
                foreach (var connection in connections.EnumerateArray())
                {
                    if (Get(connection, "status") != "active") continue;
                    var id = connection.GetProperty("id").GetInt32();
                    var managed = connection.TryGetProperty("managed", out var m) && m.ValueKind == JsonValueKind.True;
                    if(managed&&!policy.GetProperty("platform").GetBoolean()||!managed&&!policy.GetProperty("own").GetBoolean())continue;
                    var item = new Destination(id, (managed ? "Plataforma · " : "Meu Drive · ") + Get(connection, "label"));
                    _destinations.Items.Add(item);
                    if (selected == id) _destinations.SelectedItem = item;
                }
            _status.Text = _destinations.Items.Count == 0 ? "Nenhum destino conectado. Vincule o Google Drive na plataforma ou solicite o armazenamento da plataforma ao administrador." : "Configuração carregada.";
            DataLoad.Complete();
        }
        catch (Exception ex) { _status.Text = "Falha ao carregar Cloud Config: " + ex.Message; DataLoad.Fail(ex.Message); }
        finally { _busy = false; }
    }
    private async Task SaveAsync()
    {
        if (_busy || !_runtime.IsServer) return;
        _busy = true; _save.IsEnabled = false;
        try
        {
            var settings = _settings.ValueKind == JsonValueKind.Object ? JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(_settings.GetRawText()) ?? new() : new();
            settings["folders"] = JsonSerializer.SerializeToElement(_selected);
            settings["schedule"] = JsonSerializer.SerializeToElement(_schedule.SelectedItem?.ToString()??"continuous");
            if(new[]{_interval.Value,_bandwidth.Value,_maxMb.Value}.Any(double.IsNaN))throw new InvalidOperationException("Preencha os campos numéricos.");
            settings["interval_minutes"]=JsonSerializer.SerializeToElement((int)_interval.Value);
            settings["daily_time"]=JsonSerializer.SerializeToElement(_daily.Text.Trim());
            settings["bandwidth_kbps"]=JsonSerializer.SerializeToElement((int)_bandwidth.Value);
            settings["max_file_mb"]=JsonSerializer.SerializeToElement((int)_maxMb.Value);
            settings["exclusions"]=JsonSerializer.SerializeToElement(_exclusions.Text.Split('\n').Select(v=>v.Trim()).Where(v=>v.Length>0).ToArray());
            settings["vdrive"]=JsonSerializer.SerializeToElement(_vdrive.IsEnabled&&_vdrive.IsOn);
            settings["vdrive_letter"]=JsonSerializer.SerializeToElement(_letter.SelectedItem?.ToString()??"AUTO");
            settings["mirror_deletes"] = JsonSerializer.SerializeToElement(false);
            await CallAsync("gestor-config-save", new { settings, connection_id = (_destinations.SelectedItem as Destination)?.Id, enabled = _enabled.IsOn });
            _status.Text = "Configuração salva. A sincronização será aplicada automaticamente pelo Gestor Servidor.";
        }
        catch (Exception ex) { _status.Text = "Não foi possível salvar: " + ex.Message; }
        finally { _save.IsEnabled = true; _busy = false; }
    }
}
