// Caminho: gestores/servidor/Arcoll.WinUI3/Pages/CloudBackupPage.cs
using System.Diagnostics;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using System.Text.Json;
using Arcoll.WinUI3.Services;
namespace Arcoll.WinUI3.Pages;
public sealed class CloudBackupPage : MaintenancePage
{
    public CloudBackupPage(GestorRuntime runtime,Func<string,string,string,Task<bool>> confirm):base(runtime,confirm,"backup","Backup em nuvem","Estado, pastas, conexão e execução do backup da rede. Autenticação do provedor e escolha de destino permanecem no fluxo oficial da plataforma."){}
    private bool _cloudBusy;
    private async Task RefreshCloudAsync()
    {
        if(_cloudBusy)return;
        if(!Runtime.IsServer||!Runtime.Can("backup")){Status("Somente o Gestor Servidor autorizado pode consultar o backup.");return;}
        _cloudBusy=true;
        try{Report=await CloudApiClient.PostAsync(Runtime.Platform.Config,"gestor-state",new{});DataLoad.Complete();Status("Estado sincronizado com a plataforma.");}
        catch(Exception error){Status(error.Message);DataLoad.Fail(error.Message);}
        finally{_cloudBusy=false;Render();}
    }
    private async Task RequestCloudRunAsync()
    {
        if(!Runtime.IsServer||!Runtime.Can("backup"))throw new UnauthorizedAccessException("Backup disponível somente no Servidor autorizado.");
        await CloudApiClient.PostAsync(Runtime.Platform.Config,"gestor-config-run",new{});
        await RefreshCloudAsync();Status("Sincronização solicitada ao mesmo sincronizador da plataforma. Aguarde a próxima consulta (até 30 segundos).");
    }
    protected override void Build()
    {
        Actions(CollectAction("Atualizar estado do backup",RefreshCloudAsync),
            Action("Executar backup configurado",async()=>{
                if(await Confirm("Executar backup","Enviar as pastas configuradas ao destino conectado?","Executar")&&Runtime.Allowed)
                    await RequestCloudRunAsync();}));
        Text("Para alterar pastas e destino, abra Cloud > Cloud Config no Gestor Servidor. A configuração é nativa, sem redirecionar para páginas da plataforma.");
        var job=Part(Report,"job");var settings=Part(job,"settings");var status=Part(Report,"status");
        if(Report.ValueKind!=System.Text.Json.JsonValueKind.Object){Text("Atualize o estado para consultar a configuração real.");return;}
        Metrics(("Backup",Yes(job,"available")?"Disponível":"Indisponível","Configuração da rede"),
            ("Concluídos",Get(status,"files_done")+" / "+Get(status,"files_total"),"Arquivos enviados"),
            ("Transferidos",Ui.Size(Number(status,"bytes_done")),"De "+Ui.Size(Number(status,"bytes_total"))),
            ("Falhas",Get(status,"errors"),"Arquivos com erro"));
        Text(Yes(job,"available")?"Backup disponível":"Backup indisponível ou desativado",true);
        var connection=Part(Report,"connection");if(connection.ValueKind==System.Text.Json.JsonValueKind.Object)Text("Provedor: "+Get(connection,"provider")+" · "+Get(connection,"status"));
        Text("Estado: "+Get(status,"message"));Text("Última sincronização: "+Get(status,"last_run_at"));
        var panels = new Grid { ColumnSpacing = 12, RowSpacing = 10, MinHeight = 250 };
        for (var i=0;i<3;i++) panels.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
        var configured=Panel("Pastas configuradas");
        var synced=Panel("Pastas sincronizadas");
        var recent=Panel("Últimos arquivos sincronizados");
        var cfgRows=Rows(settings,"folders");
        if(cfgRows.Length==0) Info(configured,"Nenhuma pasta configurada.");
        foreach(var folder in cfgRows)
            Info(configured,"📁 "+Get(folder,"label")+"\n"+Get(folder,"path"));
        var syncRows=Rows(status,"folders");
        if(syncRows.Length==0) Info(synced,"O agente ainda não informou pastas sincronizadas.");
        foreach(var folder in syncRows)
            Info(synced,"📁 "+Get(folder,"label")+"\n"+Get(folder,"files")+" arquivos · "+Ui.Size(Number(folder,"bytes"))+(Yes(folder,"missing")?" · Indisponível":" · Conferida"));
        var files=Rows(status,"recent_files");
        if(files.Length==0) Info(recent,"Nenhum envio individual registrado. Os arquivos existentes permanecem em Meu Cloud.");
        foreach(var item in files)
            Info(recent,"✓ "+Get(item,"name")+"\n"+Get(item,"folder")+" · "+Ui.Size(Number(item,"size"))+" · "+Get(item,"at"));
        Grid.SetColumn(configured,0);Grid.SetColumn(synced,1);Grid.SetColumn(recent,2);
        panels.Children.Add(configured);panels.Children.Add(synced);panels.Children.Add(recent);
        View.Children.Add(panels);
        Text("Execuções recentes",true);
        foreach(var run in Rows(status,"runs")) Text(Get(run,"at")+" · "+Get(run,"files")+" arquivos · "+Get(run,"result"));
        foreach(var failure in Rows(status,"failures")) Text("Atenção: "+Get(failure,"path")+" · "+Get(failure,"message"));
    }
    private static StackPanel Panel(string title)
    {
        var stack = new StackPanel { Spacing = 7, Padding = new Thickness(11), MinWidth = 0 };
        stack.Children.Add(new TextBlock { Text=title, FontSize=14, FontWeight=Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,0,0,7) });
        return stack;
    }
    private static void Info(StackPanel panel,string text)
    {
        var border = new Border { CornerRadius=new CornerRadius(9), BorderThickness=new Thickness(1), Padding=new Thickness(10,9,10,9) };
        border.BorderBrush=new SolidColorBrush(Microsoft.UI.Colors.SlateGray);
        border.Child=new TextBlock { Text=text, TextWrapping=TextWrapping.Wrap, FontSize=12, MaxLines=5, IsTextSelectionEnabled=true };
        panel.Children.Add(border);
    }
}
