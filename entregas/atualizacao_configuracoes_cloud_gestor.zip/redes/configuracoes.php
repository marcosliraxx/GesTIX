<?php
/* Caminho: redes/configuracoes.php — configurações gerais e notificações em um único painel. */
declare(strict_types=1);
require_once __DIR__.'/../includes/error-logging.php';
$arcSectionFile='configuracoes';
require __DIR__.'/_base.php';
require_once __DIR__.'/../includes/network-storage.php';
if ((string)($_GET['tab']??'')==='cadastros') {
    header('Location: '.arc_workspace_base_url().'redes/cadastros.php?network='.(int)$networkId,true,303);
    exit;
}
require __DIR__.'/_topo.php';
$netPlatform=arc_storage_policy($pdo);$netCatalog=array_filter(arc_netstore_catalog(),static fn($meta)=>$meta['area']!=='cloud');$netAreas=arc_netstore_areas();unset($netAreas['cloud']);
$netPolicy=arc_netstore_policy($pdo,(int)$account,(int)$networkId);$netUsage=arc_netstore_usage($pdo,(int)$networkId);
$netPreserved=arc_netstore_preserved($pdo,(int)$networkId);
$netAreaBytes=array_fill_keys(array_keys($netAreas),0);
foreach($netCatalog as $netKey=>$netMeta)$netAreaBytes[$netMeta['area']]+=(int)$netUsage[$netKey]['bytes'];
$netManaged=array_sum($netAreaBytes);$netPreservedBytes=(int)array_sum(array_column($netPreserved,'bytes'));
$netLimit=(int)$netPolicy['global_mb']*1048576;$netCycles=!empty($netPlatform['network_cycles']);
$netCloudQuota=0;
$netEditable=$isNetworkOwner&&$netCycles;
$netAge=static function(?int $ts):string{if(!$ts)return '—';$d=max(0,time()-$ts);if($d<3600)return 'há '.max(1,intdiv($d,60)).' min';if($d<86400)return 'há '.intdiv($d,3600).' h';return 'há '.intdiv($d,86400).' dia(s)';};
$netPct=static fn(int $used,int $limit):int=>$limit>0?(int)min(100,round($used*100/$limit)):0;
$netCron=arc_platform_setting($pdo,'platform_storage_cron_last_run','');
?>

<section class="arc-network-settings" aria-label="Configurações da rede">
<header><div><h1><i class="fa fa-sliders"></i> Configurações</h1><p>Parâmetros gerais, monitoramento e notificações de <?=arc_h((string)$network['name'])?>.</p></div><span class="tag">Configuração unificada</span></header>
<?php if($arcError!==''):?><p role="alert" class="alert"><?=arc_h($arcError)?></p><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=arc_h($csrf)?>"><input type="hidden" name="action" value="network_preferences_update"><input type="hidden" name="return_tab" value="gerais">
<section class="card"><h2><i class="fa fa-tachometer"></i> Gerais e monitoramento</h2><p>Escolha a frequência de atualização dos dados da rede.</p><div class="fields"><label>Intervalo de monitoramento<select name="monitor_refresh"><?php foreach(['instant'=>'Instantâneo','1'=>'1 segundo','5'=>'5 segundos','10'=>'10 segundos','15'=>'15 segundos','30'=>'30 segundos','60'=>'60 segundos'] as $v=>$t):?><option value="<?=arc_h((string)$v)?>" <?=$networkPrefs['monitor_refresh']===(string)$v?'selected':''?>><?=arc_h($t)?></option><?php endforeach;?></select></label></div><p class="u-mt-12">Intervalos menores aumentam a frequência de consultas. Escolha de acordo com a capacidade da rede.</p></section>
<section class="card"><h2><i class="fa fa-bell-o"></i> Notificações</h2><?php if(arc_platform_setting($pdo,'platform_smtp_enabled','0')!=='1'):?><p role="status">Envio por e-mail indisponível: ative e configure SMTP em Admin › Configurações › Comunicação.</p><?php endif;?><p>Defina os limites e canais usados para os avisos da rede.</p><div class="fields"><label>Avisar quando a latência alcançar<select name="alert_latency"><?php foreach(['80','100','150','200','300'] as $v):?><option value="<?=$v?>" <?=$networkPrefs['alert_latency']===$v?'selected':''?>><?=$v?> ms</option><?php endforeach;?></select></label><label>Download mínimo (Mbps)<input type="number" name="alert_min_download_mbps" min="1" max="100000" value="<?=arc_h($networkPrefs['alert_min_download_mbps'])?>"></label><label>Intervalo dos testes automáticos (minutos)<select name="alert_speed_interval_minutes"><?php foreach([15,30,60,180,360,720,1440] as $minutes):?><option value="<?=$minutes?>" <?=(int)$networkPrefs['alert_speed_interval_minutes']===$minutes?'selected':''?>><?=$minutes?></option><?php endforeach;?></select></label><label class="toggle"><input type="checkbox" name="alert_low_speed" <?=$networkPrefs['alert_low_speed']==='1'?'checked':''?>> Detectar velocidade baixa</label><label class="toggle"><input type="checkbox" name="email_alerts" <?=$networkPrefs['email_alerts']==='1'?'checked':''?>> Receber avisos por e-mail</label></div><p>Testes de velocidade usam tráfego real e são executados somente pelo Servidor. E-mails seguem para o proprietário da rede, com SMTP ativo na administração e intervalo mínimo de 30 minutos por tipo de alerta.</p></section>
<div class="actions"><button class="button" type="submit" <?=!$isNetworkOwner?'disabled':''?>><i class="fa fa-save"></i> Salvar configurações</button></div>
</form></section>

<section class="arc-network-settings arc-netstore" id="armazenamento" aria-label="Armazenamento da rede">
<header><div><h1><i class="fa fa-database"></i> Armazenamento da rede</h1><p>Veja quanto <?=arc_h((string)$network['name'])?> ocupa em banco de dados, nuvem, logs e arquivos, defina limites e ciclos de autoexclusão dos dados operacionais mais antigos e faça a limpeza quando quiser.</p></div><span class="tag"><?=$netCycles?'Ciclos por rede':'Ciclos desativados pela plataforma'?></span></header>
<div class="ns-cards">
 <div class="ns-card is-total"><span>Total gerenciável</span><b><?=arc_h(arc_netstore_fmt($netManaged))?></b><span><?=$netLimit>0?arc_h('Limite da rede: '.arc_netstore_fmt($netLimit)):'Sem limite total definido'?></span><?php if($netLimit>0):$netPctV=$netPct($netManaged,$netLimit);?><div class="ns-bar" role="img" aria-label="<?=$netPctV?>% do limite"><i class="<?=$netPctV>=100?'is-full':($netPctV>=80?'is-hot':'')?>" style="width:<?=$netPctV?>%"></i></div><?php endif;?></div>
 <?php foreach($netAreas as $netAreaKey=>$netAreaLabel):?><div class="ns-card"><span><?=arc_h($netAreaLabel)?></span><b><?=arc_h(arc_netstore_fmt($netAreaBytes[$netAreaKey]))?></b><?php if($netAreaKey==='cloud'):?><span><?=$netCloudQuota>0?arc_h('Cota usada no provedor: '.arc_netstore_fmt($netCloudQuota)):'Registro local dos backups'?></span><?php else:?><span>Gerenciado por ciclos</span><?php endif;?></div><?php endforeach;?>
 <div class="ns-card"><span>Preservado (inventário e cadastros)</span><b><?=arc_h(arc_netstore_fmt($netPreservedBytes))?></b><span>Nunca apagado por ciclos</span></div>
</div>
<?php if(!$netCycles):?><p role="alert" class="alert">A administração da plataforma desativou os ciclos de autoexclusão por rede. Os valores abaixo são apenas informativos.</p><?php endif;?>
<form method="post" id="netstore-form"><input type="hidden" name="_csrf" value="<?=arc_h($csrf)?>"><input type="hidden" name="action" value="network_storage_save">
<div class="ns-global">
 <label class="toggle u-check-row"><input type="checkbox" name="storage_auto" value="1" <?=$netPolicy['auto']?'checked':''?> <?=!$netEditable?'disabled':''?>> Ativar ciclos automáticos desta rede</label>
 <label>Limite total da rede (MB, 0 = sem limite)<input type="number" name="storage_global_mb" min="0" max="1048576" value="<?=(int)$netPolicy['global_mb']?>" <?=!$netEditable?'disabled':''?>></label>
 <?php if((int)$netPlatform['network_cap_mb']>0):?><small class="u-text-muted">Teto da plataforma: <?=arc_h(arc_netstore_fmt((int)$netPlatform['network_cap_mb']*1048576))?> por rede.</small><?php endif;?>
</div>
<div class="ns-scroll"><table><thead><tr><th>Ciclo</th><th>Origem</th><th>Em uso</th><th>Mais antigo</th><th>Reter (dias)</th><th>Limite (MB)</th><th class="u-text-right">Limpeza</th></tr></thead><tbody>
<?php foreach($netAreas as $netAreaKey=>$netAreaLabel):?><tr class="ns-area"><td colspan="7"><?=arc_h($netAreaLabel)?> · <?=arc_h(arc_netstore_fmt($netAreaBytes[$netAreaKey]))?></td></tr>
<?php foreach($netCatalog as $netKey=>$netMeta):if($netMeta['area']!==$netAreaKey)continue;$netCfg=$netPolicy['categories'][$netKey];$netUse=$netUsage[$netKey];$netPctV=$netPct((int)$netUse['bytes'],(int)$netCfg['mb']*1048576);?>
<tr><td><input type="checkbox" name="storage_on[<?=arc_h($netKey)?>]" value="1" aria-label="Ciclo de <?=arc_h($netMeta['label'])?>" <?=$netCfg['on']?'checked':''?> <?=!$netEditable?'disabled':''?>></td>
<td><?=arc_h($netMeta['label'])?><?php if(!empty($netMeta['note'])):?><small><?=arc_h($netMeta['note'])?></small><?php endif;?></td>
<td><?php if(!$netUse['available']):?><span class="u-text-muted">Indisponível</span><?php else:?><b><?=arc_h(arc_netstore_fmt((int)$netUse['bytes']))?></b><small><?=number_format((int)$netUse['rows'],0,',','.')?> item(ns)</small><?php if($netCfg['mb']>0):?><div class="ns-bar" role="img" aria-label="<?=$netPctV?>% do limite"><i class="<?=$netPctV>=100?'is-full':($netPctV>=80?'is-hot':'')?>" style="width:<?=$netPctV?>%"></i></div><?php endif;?><?php endif;?></td>
<td><?=arc_h($netAge($netUse['oldest']))?></td>
<td><input type="number" name="storage_days[<?=arc_h($netKey)?>]" min="<?=(int)$netPlatform['network_min_days']?>" max="3650" value="<?=(int)$netCfg['days']?>" aria-label="Dias de retenção" <?=!$netEditable?'disabled':''?>></td>
<td><input type="number" name="storage_mb[<?=arc_h($netKey)?>]" min="0" max="1048576" value="<?=(int)$netCfg['mb']?>" aria-label="Limite em MB" <?=!$netEditable?'disabled':''?>></td>
<td class="u-text-right"><button type="submit" form="netstore-clean" name="category" value="<?=arc_h($netKey)?>" data-label="<?=arc_h($netMeta['label'])?>" class="button secondary small" <?=!$isNetworkOwner||!$netUse['available']||(int)$netUse['rows']===0?'disabled':''?>><i class="fa fa-trash-o"></i> Limpar</button></td></tr>
<?php endforeach;endforeach;?>
</tbody></table></div>
<p class="ns-note">Ao atingir o prazo ou o limite de uma origem, os itens mais antigos são removidos primeiro, até o uso cair para cerca de 90% do limite. Itens das últimas 24 horas, registros em andamento, fixados ou ainda necessários nunca são apagados. Prazo mínimo definido pela plataforma: <?=(int)$netPlatform['network_min_days']?> dia(s).</p>
<p class="ns-note">Execução automática: <?=$netPolicy['auto']&&$netCycles?'ativa':'desligada'?> · última execução desta rede: <strong><?=arc_h($netPolicy['last_run']!==''?$netPolicy['last_run']:'ainda não executada')?></strong> · rotina geral da plataforma: <strong><?=arc_h($netCron!==''?$netCron:'sem registro')?></strong></p>
<div class="ns-actions"><button class="button" type="submit" <?=!$netEditable?'disabled':''?>><i class="fa fa-save"></i> Salvar limites e ciclos</button></div>
</form>
<form method="post" id="netstore-clean"><input type="hidden" name="_csrf" value="<?=arc_h($csrf)?>"><input type="hidden" name="action" value="network_storage_clean">
<div class="ns-actions"><button type="submit" name="category" value="" data-label="todas as origens desta rede" class="button secondary" <?=!$isNetworkOwner?'disabled':''?>><i class="fa fa-eraser"></i> Limpar todas as origens agora</button></div></form>
<div class="ns-two">
 <div class="card"><h2><i class="fa fa-lock"></i> Dados preservados</h2><p>Inventário e cadastros atuais não entram nos ciclos de autoexclusão.</p><table class="u-minw-0"><tbody><?php foreach($netPreserved as $netRow):?><tr><td><?=arc_h($netRow['label'])?></td><td><?=number_format((int)$netRow['rows'],0,',','.')?></td><td class="u-text-right"><?=arc_h(arc_netstore_fmt((int)$netRow['bytes']))?></td></tr><?php endforeach;?><?php if(!$netPreserved):?><tr><td>Sem dados.</td></tr><?php endif;?></tbody></table></div>

</div>
</section>
<script>(()=>{const form=document.getElementById('netstore-clean');if(!form)return;form.addEventListener('submit',e=>{const b=e.submitter,label=b&&b.dataset.label?b.dataset.label:'todas as origens desta rede';if(!confirm('Apagar permanentemente os dados antigos de '+label+'? Itens das últimas 24 horas e registros em uso serão preservados. Esta ação não pode ser desfeita.'))e.preventDefault()})})();</script>
<?php require __DIR__.'/_rodape.php'; ?>
