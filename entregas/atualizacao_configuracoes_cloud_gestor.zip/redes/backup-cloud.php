<?php
/* Caminho: redes/backup-cloud.php — painel de sincronização, sem redirecionar para outra área. */
declare(strict_types=1);
$arcSectionFile='backup-cloud';require __DIR__.'/_base.php';
if(!in_array($teamRole,['owner','administrator','system_admin'],true)){http_response_code(403);exit('Sem autorização para o Backup Cloud.');}
$requested=(int)($_GET['gestor']??0);
$q=$pdo->prepare('SELECT id,machine_name FROM '.arc_table('network_gestores')." WHERE network_id=? AND account_id=? AND status='approved' AND installation_profile='server' ORDER BY id");
$q->execute([(int)$networkId,(int)$account]);$agents=$q->fetchAll(PDO::FETCH_ASSOC);$backupSelectedGestor=0;
foreach($agents as $a)if((int)$a['id']===$requested)$backupSelectedGestor=$requested;
if(!$backupSelectedGestor&&$agents)$backupSelectedGestor=(int)$agents[0]['id'];
require __DIR__.'/_topo.php';
?>

<section class="arc-bcloud" id="arc-bcloud" data-api="<?=arc_h(arc_workspace_base_url().'api/cloud.php')?>" data-network="<?=(int)$networkId?>" data-gestor="<?=$backupSelectedGestor?>" data-csrf="<?=arc_h($csrf)?>">
<header class="bc-head"><div><h2><i class="fa fa-cloud"></i> Backup Cloud</h2><small>Pastas selecionadas, sincronizadas e últimos arquivos enviados</small></div><div class="bc-tools"><button type="button" class="bc-btn" id="bc-refresh"><i class="fa fa-refresh"></i> Atualizar</button><button type="button" class="bc-btn" id="bc-run"><i class="fa fa-play"></i> Sincronizar agora</button></div></header>
<div class="bc-kpis"><span><strong id="bc-state">—</strong> Situação</span><span><strong id="bc-files">—</strong> Arquivos sincronizados</span><span><strong id="bc-date">—</strong> Última sincronização</span></div>
<div class="bc-columns"><section class="bc-panel"><h3><i class="fa fa-folder-open"></i> Pastas configuradas</h3><div id="bc-config" class="bc-list" aria-live="polite"></div></section><section class="bc-panel"><h3><i class="fa fa-check-circle"></i> Pastas sincronizadas</h3><div id="bc-synced" class="bc-list" aria-live="polite"></div></section><section class="bc-panel"><h3><i class="fa fa-history"></i> Últimos arquivos sincronizados</h3><div id="bc-recent" class="bc-list" aria-live="polite"></div></section></div>
<div id="bc-note" class="bc-footer" role="status">Consultando estado do sincronizador...</div></section>
<script>
(()=>{'use strict';const root=document.getElementById('arc-bcloud'),api=root.dataset.api,network=+root.dataset.network,gestor=+root.dataset.gestor,csrf=root.dataset.csrf,by=id=>document.getElementById(id);let busy=false;
const el=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls;if(text!==undefined)n.textContent=text;return n};
const niceDate=t=>{if(!t)return 'Não informado';let d=new Date(t.includes('T')?t:t.replace(' ','T'));return isNaN(d)?t:d.toLocaleString('pt-BR')};
const size=n=>{let x=+n||0;for(let u of ['B','KB','MB','GB','TB']){if(x<1024||u==='TB')return x.toLocaleString('pt-BR',{maximumFractionDigits:1})+' '+u;x/=1024}};
const friendly=p=>String(p||'').replace(/-[a-f0-9]{12,16}$/i,'');
function empty(box,message){box.replaceChildren(el('div','bc-empty',message))}
function row(box,icon,title,detail,mark='',warning=false){let item=el('div','bc-item'),i=el('i','fa '+icon),main=el('div','bc-info'),t=el('strong','',title),d=el('span','',detail);main.append(t,d);item.append(i,main);if(mark)item.append(el('span',warning?'bc-mark bc-pending':'bc-mark',mark));box.append(item)}
async function call(action){const r=await fetch(api+'?action='+action,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({network_id:network,gestor_id:gestor})});const data=await r.json();if(!r.ok||!data.ok)throw Error(data.error||'Falha ao consultar Cloud');return data}
async function load(){if(busy)return;busy=true;by('bc-refresh').disabled=true;try{if(!gestor)throw Error('Não existe gestor aprovado nesta rede.');let d=await call('state'),job=d.job||{},status=d.status||{},settings=job.settings||{},folders=Array.isArray(settings.folders)?settings.folders:[],reported=Array.isArray(status.folders)?status.folders:[],recent=Array.isArray(status.recent_files)?status.recent_files:[];by('bc-state').textContent=({idle:'Sincronizado',uploading:'Enviando',scanning:'Analisando',paused:'Pausado',error:'Atenção',disabled:'Desativado',waiting:'Aguardando'})[status.state]||'Aguardando';by('bc-files').textContent=(+status.synced_files||0).toLocaleString('pt-BR');by('bc-date').textContent=niceDate(status.last_run_at);by('bc-run').disabled=!(job.enabled&&job.connection_id);by('bc-note').textContent=(d.gestor&&d.gestor.online===false?'Gestor Servidor offline: a sincronização só ocorre quando ele estiver conectado. ':'')+(!job.enabled?'Sincronização desativada: ative em Cloud Config. ':(!job.connection_id?'Nenhum destino escolhido: defina em Cloud Config. ':''))+(status.message||'Nenhuma sincronização registrada.')+(!status.fresh&&status.reported_at?' · Última comunicação do agente: '+niceDate(status.reported_at):'');const config=by('bc-config'),synced=by('bc-synced'),history=by('bc-recent');config.replaceChildren();synced.replaceChildren();history.replaceChildren();
if(!folders.length)empty(config,'Nenhuma pasta configurada para este computador.');else folders.forEach(f=>row(config,'fa-folder',f.label||friendly((f.path||'').split(/[\/]/).pop()),f.path||'Caminho não informado',job.enabled?'Ativa':'Pausada',!job.enabled));
if(!reported.length)empty(synced,'O agente ainda não informou pastas sincronizadas.');else reported.forEach(f=>row(synced,'fa-folder',f.label||'Pasta',(+f.files||0)+' arquivo(s) · '+size(f.bytes||0),f.missing?'Indisponível':(+f.pending>0?'Pendente':'Conferida'),f.missing||+f.pending>0));
if(!recent.length)empty(history,'Nenhum envio individual registrado pelo agente atualizado. Os arquivos existentes continuam disponíveis em Meu Cloud.');else recent.forEach(f=>row(history,'fa-file-o',f.name||'Arquivo',friendly(f.folder||'')+' · '+size(f.size)+' · '+niceDate(f.at),'Concluído'));
}catch(e){by('bc-note').textContent=e.message;['bc-config','bc-synced','bc-recent'].forEach(id=>empty(by(id),'Não foi possível carregar: '+e.message))}finally{busy=false;by('bc-refresh').disabled=false}}
by('bc-refresh').onclick=load;by('bc-run').onclick=async()=>{if(!confirm('Solicitar agora a sincronização das pastas configuradas?'))return;const b=by('bc-run');b.disabled=true;try{await call('run');by('bc-note').textContent='Solicitação enviada. A execução depende de o Gestor estar conectado.';setTimeout(load,2200)}catch(e){by('bc-note').textContent=e.message}finally{b.disabled=false}};
load();let timer=setInterval(()=>{if(!document.hidden)load()},30000);window.addEventListener('pagehide',()=>clearInterval(timer));})();
</script>
<?php require __DIR__.'/_rodape.php'; ?>
